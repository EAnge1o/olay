"""Small JSONL evaluation harness."""
