import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";

import { LiveReportView } from "./LiveReport";
import {
  AccountProfileEvidence,
  AnalysisProcessProgress,
  CreatorSelfCheckReport,
  CrossCheckSection,
  MERGE_CROSS_LINKS,
  MERGE_LINK_ANCHOR_X,
  DecisionSupport,
  MaterialTraceEvidence,
  MethodBadge,
  TeamWorkspace,
  TechnicalViewToggle,
  WhoUsesSection,
  reportConfidenceProfiles,
  technicalConfig,
} from "./TeammateUI";
import type { CreatorReportInput, CreatorSelfCheckProgress } from "./TeammateUI";
import type { TeamQueueItem, TeamRelatedGroup, TeamSummary } from "./TeammateUI";
import {
  checkCreator,
  describeApiError,
  getReport,
  getSample,
  getStatus,
  getTeamQueue,
  looksLikeXhsLink,
  updateTeamStatus,
  type AgentStatusItem,
  type CreatorCheckRead,
  type ReportRead,
  type SampleRead,
} from "./api";
import { DEMO_INPUT, useLiveAnalysis, type LiveRun } from "./useLiveAnalysis";

type Screen = "home" | "workspace" | "chat" | "result" | "team";
type RecentTask = "makeup" | "serum" | "whitening";
type DimensionCode = "T" | "R" | "U" | "S";

interface RecentRunRecord {
  id: string;
  taskId: string;
  title: string;
  createdAt: string;
  trustScore: number;
  trustLabel: string;
  activeDimensions: DimensionCode[];
  report: ReportRead;
  sample: SampleRead | null;
  /** "creator" = 发布前自检 (restored into CreatorSelfCheckReport); absent = 核验记录. */
  kind?: "verify" | "creator";
  /** Who produced the report: 创作者发布前自检 or 核验别人的笔记. Old records are inferred. */
  role?: "creator" | "consumer";
  /** What a creator record needs to reopen its report (image files cannot be stored). */
  creator?: {
    draft: string;
    category: string;
    isCollaboration: boolean;
    imageNames: string[];
    result: CreatorCheckRead;
  };
}

const allDimensions: DimensionCode[] = ["T", "R", "U", "S"];
const RECENT_RUNS_STORAGE_KEY = "trulens-recent-runs-v1";

function loadRecentRuns(): RecentRunRecord[] {
  try {
    const raw = window.localStorage.getItem(RECENT_RUNS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is RecentRunRecord =>
        Boolean(item?.id && item?.taskId && item?.report?.task_id && typeof item?.title === "string"),
      )
      .slice(0, 8);
  } catch {
    return [];
  }
}

/** Identity tag of a record; old localStorage records without `role` are inferred from `kind`. */
function recentRunRole(run: RecentRunRecord): "creator" | "consumer" {
  return run.role ?? (run.kind === "creator" ? "creator" : "consumer");
}

function deriveRecentTitle(prompt: string, filename: string): string {
  if (filename.trim()) return filename.trim().slice(0, 30);
  const cleaned = prompt
    .replace(/https?:\/\/\S+/gi, "")
    .replace(/[【】]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned) return "内容真实性核验";
  return cleaned.length > 24 ? `${cleaned.slice(0, 24)}…` : cleaned;
}

function recentDateLabel(iso: string): string {
  const created = new Date(iso);
  const elapsed = Date.now() - created.getTime();
  if (!Number.isFinite(elapsed) || elapsed < 60_000) return "刚刚";
  if (elapsed < 3_600_000) return `${Math.max(1, Math.floor(elapsed / 60_000))} 分钟前`;
  if (elapsed < 86_400_000) return `${Math.max(1, Math.floor(elapsed / 3_600_000))} 小时前`;
  return created.toLocaleDateString("zh-CN", { month: "numeric", day: "numeric" });
}

function inferDimensions(prompt: string, filename: string): DimensionCode[] {
  const content = `${prompt} ${filename}`.toLowerCase();
  const normalizedPrompt = prompt.trim().toLowerCase();
  const mentionsComments = /评论|评论区|留言|回复|comment/.test(content);
  const mentionsAccount = /账号|帐号|博主|主页|历史内容|account|profile/.test(content);
  const mentionsImage = /配图|图片|图像|照片|视觉|对比图|image|photo/.test(content);
  const requestsFullAnalysis = /全部|完整|多模态|整篇帖子|小红书笔记|full/.test(content);
  const hasAnyLink =
    /(?:https?:\/\/|www\.)\S+|(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}(?:\/\S*)?/.test(normalizedPrompt);

  if (hasAnyLink) return allDimensions;
  if (requestsFullAnalysis && filename) return allDimensions;
  if (mentionsComments) return ["U", "S"];
  if (mentionsAccount) return ["T", "S"];
  if (mentionsImage) return ["R", "S"];
  if (filename) return ["R", "S"];
  return ["S"];
}

const portrait =
  "https://images.unsplash.com/photo-1675773051474-55c4b7d2cf53?crop=faces&fit=crop&fm=jpg&q=85&w=1200&h=1400";
const postImage =
  "https://images.unsplash.com/photo-1752245818739-890854ca3b81?crop=faces&fit=crop&fm=jpg&q=85&w=900&h=1100";
const roleAvatarByCode: Record<DimensionCode, string> = {
  T: "/agents/t.png",
  R: "/agents/r.png",
  U: "/agents/u.png",
  S: "/agents/s.png",
};

function Icon({
  children,
  size = 20,
  className = "",
}: {
  children: ReactNode;
  size?: number;
  className?: string;
}) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
    >
      {children}
    </svg>
  );
}

const Sparkle = ({ size = 20 }: { size?: number }) => (
  <Icon size={size}>
    <path
      d="M12 2.5c.7 5.2 3.4 8 8.7 8.7-5.3.7-8 3.5-8.7 8.8-.7-5.3-3.4-8.1-8.7-8.8C8.6 10.5 11.3 7.7 12 2.5Z"
      stroke="currentColor"
      strokeLinejoin="round"
      strokeWidth="1.5"
    />
  </Icon>
);

const truLensMarkConfig = {
  lens: { cx: 48, cy: 45, radius: 34, fill: "#F8F6FD", stroke: "#CFC5EE", width: 2 },
  diamond: {
    points: "48,21 72,45 48,69 24,45",
    fill: "#D9D0F4",
    stroke: "#A999D5",
    width: 1.2,
  },
  dots: [
    { code: "T", cx: 48, cy: 13, fill: "#D7CDED" },
    { code: "R", cx: 80, cy: 45, fill: "#D7CDED" },
    { code: "U", cx: 48, cy: 77, fill: "#D7CDED" },
    { code: "S", cx: 16, cy: 45, fill: "#D7CDED" },
  ],
  dot: { radius: 7, stroke: "#B7A8DC", width: 1 },
} as const;

function TruLensMark({ size = 25 }: { size?: number }) {
  return (
    <svg
      aria-hidden="true"
      className="trulens-mark"
      height={size}
      viewBox="0 0 116 100"
      width={size * 1.16}
    >
      <path d="M72 69 94 91" stroke="#B8A9E2" strokeLinecap="round" strokeWidth="13" />
      <path d="M72 69 94 91" stroke="#DDD6F2" strokeLinecap="round" strokeWidth="8" />
      <ellipse cx="46" cy="45" fill="none" rx="47" ry="19" stroke="#DDD6F2" strokeWidth="1.2" transform="rotate(-17 46 45)" />
      <circle
        cx={truLensMarkConfig.lens.cx}
        cy={truLensMarkConfig.lens.cy}
        fill={truLensMarkConfig.lens.fill}
        fillOpacity=".78"
        r={truLensMarkConfig.lens.radius}
        stroke={truLensMarkConfig.lens.stroke}
        strokeWidth={truLensMarkConfig.lens.width}
      />
      {truLensMarkConfig.dots.map((dot) => (
        <line key={`line-${dot.code}`} stroke="#C7BDE5" strokeWidth="1" x1="48" x2={dot.cx} y1="45" y2={dot.cy} />
      ))}
      <polygon
        fill={truLensMarkConfig.diamond.fill}
        fillOpacity=".88"
        points={truLensMarkConfig.diamond.points}
        stroke={truLensMarkConfig.diamond.stroke}
        strokeLinejoin="round"
        strokeWidth={truLensMarkConfig.diamond.width}
      />
      {truLensMarkConfig.dots.map((dot, index) => (
        <circle
          className={`trulens-mark-dot dot-${index + 1}`}
          cx={dot.cx}
          cy={dot.cy}
          fill={dot.fill}
          key={dot.code}
          r={truLensMarkConfig.dot.radius}
          stroke={truLensMarkConfig.dot.stroke}
          strokeWidth={truLensMarkConfig.dot.width}
        />
      ))}
      {truLensMarkConfig.dots.map((dot) => (
        <text
          fill="#554A70"
          fontFamily="DM Mono, monospace"
          fontSize="6.5"
          key={`text-${dot.code}`}
          textAnchor="middle"
          x={dot.cx}
          y={dot.cy + 2.3}
        >
          {dot.code}
        </text>
      ))}
      <path d="M96 10c.5 4 2.5 6 6.5 6.5-4 .5-6 2.5-6.5 6.5-.5-4-2.5-6-6.5-6.5 4-.5 6-2.5 6.5-6.5Z" fill="#B6A6E0" />
    </svg>
  );
}

function Logo() {
  return (
    <button className="logo" onClick={() => window.scrollTo({ top: 0 })}>
      <img alt="TruLens" src="/trulens-nav-logo.png" />
    </button>
  );
}

function Arrow({ size = 20 }: { size?: number }) {
  return (
    <Icon size={size}>
      <path d="M5 12h14M14 7l5 5-5 5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
    </Icon>
  );
}

function canvasCard(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  context.beginPath();
  context.roundRect(x, y, width, height, radius);
  context.fill();
}

function canvasParagraph(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
) {
  let line = "";
  let currentY = y;
  for (const character of text) {
    if (context.measureText(line + character).width > maxWidth && line) {
      context.fillText(line, x, currentY);
      line = character;
      currentY += lineHeight;
    } else {
      line += character;
    }
  }
  context.fillText(line, x, currentY);
}

async function exportTrustLongImage() {
  await document.fonts.ready;
  const canvas = document.createElement("canvas");
  canvas.width = 1440;
  canvas.height = 2920;
  const context = canvas.getContext("2d");
  if (!context) return;

  const background = context.createLinearGradient(0, 0, 1440, 2920);
  background.addColorStop(0, "#fbfafd");
  background.addColorStop(0.5, "#f2eff9");
  background.addColorStop(1, "#faf4f3");
  context.fillStyle = background;
  context.fillRect(0, 0, 1440, 2920);

  context.fillStyle = "rgba(211,199,241,.32)";
  context.beginPath();
  context.arc(1190, 430, 370, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "rgba(242,207,216,.26)";
  context.beginPath();
  context.arc(100, 2310, 390, 0, Math.PI * 2);
  context.fill();

  context.fillStyle = "#292535";
  context.font = '500 34px "DM Mono", monospace';
  context.fillText("✦ TruLens", 90, 110);
  context.textAlign = "right";
  context.font = '400 20px "DM Mono", monospace';
  context.fillStyle = "#817a89";
  context.fillText("TRUST PROFILE · 2025.06.18", 1350, 108);
  context.textAlign = "left";
  context.font = '500 76px "Noto Sans SC", sans-serif';
  context.fillStyle = "#272332";
  context.fillText("这篇种草，值得相信吗？", 90, 260);
  context.font = '400 25px "Noto Sans SC", sans-serif';
  context.fillStyle = "#827b88";
  context.fillText("秋冬奶油肌底妆分享 · 多模态内容可信度报告", 94, 316);

  context.fillStyle = "rgba(255,255,255,.8)";
  canvasCard(context, 90, 390, 1260, 650, 42);
  context.beginPath();
  context.arc(390, 705, 180, -Math.PI / 2, Math.PI * 1.18);
  context.strokeStyle = "#776b9d";
  context.lineWidth = 24;
  context.lineCap = "round";
  context.stroke();
  context.beginPath();
  context.arc(390, 705, 180, Math.PI * 1.18, Math.PI * 1.5);
  context.strokeStyle = "rgba(119,107,157,.14)";
  context.stroke();
  context.textAlign = "center";
  context.fillStyle = "#292535";
  context.font = '500 150px "Playfair Display", serif';
  context.fillText("84", 390, 740);
  context.font = '400 18px "DM Mono", monospace';
  context.fillStyle = "#89828e";
  context.fillText("TRUST SCORE / 100", 390, 790);

  context.textAlign = "left";
  context.fillStyle = "#e3f0e9";
  canvasCard(context, 680, 520, 150, 46, 23);
  context.fillStyle = "#547664";
  context.font = '500 19px "Noto Sans SC", sans-serif';
  context.fillText("●  高可信", 705, 551);
  context.fillStyle = "#292535";
  context.font = '500 52px "Noto Sans SC", sans-serif';
  context.fillText("真实内容为主，", 680, 660);
  context.fillText("有轻度 AI 修图。", 680, 730);
  context.fillStyle = "#756e7b";
  context.font = '400 23px "Noto Sans SC", sans-serif';
  canvasParagraph(context, "没有发现系统性 AI 造假或虚假营销证据。图片中存在局部生成式修饰，但不影响产品展示的主要真实性。", 680, 805, 540, 42);

  context.fillStyle = "#8b8491";
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("FOUR DIMENSIONS", 90, 1145);
  const exportDimensions = [
    ["T", "账号可信度", "82", "#eee9fb", "账号运营稳定，历史内容与商业合作节奏自然。"],
    ["R", "图像原生性", "88", "#e8f1fa", "发现两处生成式皮肤细化，但产品主体保持真实。"],
    ["U", "评论自然度", "74", "#f8eae7", "12% 短评存在相似句式，整体互动结构仍较自然。"],
    ["S", "文案真实性", "91", "#e7f2ec", "未使用绝对化功效承诺，合作标识与体验边界清晰。"],
  ];
  exportDimensions.forEach(([code, title, score, color, copy], index) => {
    const x = 90 + (index % 2) * 640;
    const y = 1210 + Math.floor(index / 2) * 430;
    context.fillStyle = color;
    canvasCard(context, x, y, 610, 390, 32);
    context.fillStyle = "#332e3c";
    context.font = '500 66px "Playfair Display", serif';
    context.fillText(code, x + 34, y + 85);
    context.font = '500 30px "Noto Sans SC", sans-serif';
    context.fillText(title, x + 34, y + 137);
    context.textAlign = "right";
    context.font = '500 72px "Playfair Display", serif';
    context.fillText(score, x + 565, y + 97);
    context.textAlign = "left";
    context.fillStyle = "rgba(49,43,59,.12)";
    canvasCard(context, x + 34, y + 174, 542, 6, 3);
    context.fillStyle = "#746982";
    canvasCard(context, x + 34, y + 174, 542 * (Number(score) / 100), 6, 3);
    context.fillStyle = "#716a77";
    context.font = '400 21px "Noto Sans SC", sans-serif';
    canvasParagraph(context, copy, x + 34, y + 237, 530, 38);
  });

  context.fillStyle = "rgba(255,255,255,.72)";
  canvasCard(context, 90, 2115, 1260, 480, 38);
  context.fillStyle = "#81788d";
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("TruLens DECISION SUPPORT", 135, 2185);
  context.fillStyle = "#292535";
  context.font = '500 48px "Noto Sans SC", sans-serif';
  context.fillText("可以参考，但请关注真实肤质差异。", 135, 2275);
  context.fillStyle = "#716a77";
  context.font = '400 24px "Noto Sans SC", sans-serif';
  canvasParagraph(context, "这篇内容可以作为妆效灵感与色号参考。由于博主对皮肤纹理做过局部 AI 修饰，不建议仅依据“零毛孔”效果判断产品遮瑕力。购买前可再查看自然光下的素人试色视频。", 135, 2360, 1150, 44);
  context.textAlign = "center";
  context.fillStyle = "#96909b";
  context.font = '400 18px "Noto Sans SC", sans-serif';
  context.fillText("由 TruLens 多模态模型生成 · AI 判断不构成医疗或购买建议", 720, 2750);
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("TruLens — BEAUTY, VERIFIED WITH INTELLIGENCE.", 720, 2815);

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png", 1));
  if (!blob) return;
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "TruLens-美妆内容可信度报告.png";
  link.click();
  URL.revokeObjectURL(url);
}

function ShareMenu({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const [exportingImage, setExportingImage] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const closeOnOutsideClick = (event: MouseEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) onClose();
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("mousedown", closeOnOutsideClick);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOnOutsideClick);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [onClose]);

  const copyReportLink = async () => {
    const url = new URL(window.location.href);
    url.searchParams.set("report", "true");
    try {
      await navigator.clipboard.writeText(url.toString());
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt("复制这份报告链接", url.toString());
    }
  };

  return (
    <div className="share-menu" ref={menuRef}>
      <div className="share-menu-title">
        <strong>分享鉴别结果</strong>
        <small>链接接收者可直接查看报告</small>
      </div>
      <button onClick={copyReportLink}>
        <span className="share-action-icon">
          <Icon size={17}>
            <path d="m9.5 14.5 5-5M7.3 16.7l-1 1a3.5 3.5 0 0 1-5-5l3.2-3.2a3.5 3.5 0 0 1 5 0M16.7 7.3l1-1a3.5 3.5 0 1 1 5 5l-3.2 3.2a3.5 3.5 0 0 1-5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>{copied ? "链接已复制" : "复制分享链接"}</strong><small>{copied ? "可以发送给好友了" : "生成可直接访问的报告链接"}</small></span>
        <span className={copied ? "copy-state copied" : "copy-state"}>{copied ? "✓" : "⌘C"}</span>
      </button>
      <button
        onClick={async () => {
          setExportingImage(true);
          await exportTrustLongImage();
          setExportingImage(false);
        }}
      >
        <span className="share-action-icon image">
          <Icon size={17}>
            <rect height="17" rx="2.5" stroke="currentColor" strokeWidth="1.5" width="18" x="3" y="3.5" />
            <circle cx="8.5" cy="9" r="1.6" stroke="currentColor" strokeWidth="1.4" />
            <path d="m5.5 18 4.2-4.6 2.7 2.6 2.2-2 3.9 4" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>{exportingImage ? "正在生成长图…" : "导出成长图"}</strong><small>适合保存到相册或社交平台分享</small></span>
        <Arrow size={15} />
      </button>
      <button
        onClick={() => {
          onClose();
          window.setTimeout(() => window.print(), 100);
        }}
      >
        <span className="share-action-icon pdf">
          <Icon size={17}>
            <path d="M6 3h8l4 4v14H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M14 3v5h4M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>导出为 PDF</strong><small>保存或打印完整鉴别报告</small></span>
        <Arrow size={15} />
      </button>
      <p>报告不包含原帖作者的私密信息</p>
    </div>
  );
}

const storyScene = {
  step: "01 / READ",
  eyebrow: "BEFORE YOU BUY",
  title: "你还相信你自己看到的吗？",
  body: "一张完美的照片、一篇动人的分享、成千上万条好评，都可能隐藏着你看不到的信息。",
};

function StoryVisual() {
  return (
    <div className="story-post">
      <div className="post-browser">
        <span /><span /><span />
        <small>note / 3285491</small>
      </div>
      <div className="post-image">
        <img alt="模拟美妆种草帖子" src={postImage} />
        <span className="post-image-tag">原始内容 · 6 张图片</span>
      </div>
      <div className="post-copy">
        <div className="mock-avatar" />
        <div><strong>秋冬奶油肌底妆分享</strong><span>今天也要认真护肤 · 2 小时前</span></div>
      </div>
      <div className="post-lines"><i /><i /><i /></div>
      <div className="reading-line"><span /></div>
      <small className="reading-caption">正在建立内容语境 · 68%</small>
    </div>
  );
}

function StoryScroller() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardScrollRef = useRef<HTMLDivElement>(null);
  const countFrameRef = useRef(0);
  const dataPlayedRef = useRef(false);
  const [currentPanel, setCurrentPanel] = useState(0);
  const [sectionVisible, setSectionVisible] = useState(false);
  const [answers, setAnswers] = useState<Array<QuizChoice | null>>([null, null, null]);
  const [dataValues, setDataValues] = useState([0, 0, 0]);
  const [scrollHintVisible, setScrollHintVisible] = useState(true);
  const score = answers.reduce((total, answer, index) => total + (answer === aiImageQuizQuestions[index].aiAnswer ? 1 : 0), 0);
  const unanswered = answers.filter((answer) => answer === null).length;
  const resultTitle = score === 3 ? "眼力不错。" : score === 2 ? "差一点。" : "这很正常，这正是 AI 图的厉害之处。";
  const activeStep = currentPanel === 0 ? "data" : currentPanel < 4 ? "quiz" : "result";

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setSectionVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.cancelAnimationFrame(countFrameRef.current);
    if (!sectionVisible || currentPanel !== 0 || dataPlayedRef.current) return;
    dataPlayedRef.current = true;
    const targets = [66, 57, 35.7];
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDataValues(targets);
      return;
    }
    const start = performance.now();
    const animate = (time: number) => {
      const amount = Math.min(1, (time - start) / 1200);
      const eased = 1 - Math.pow(1 - amount, 3);
      setDataValues(targets.map((target) => target * eased));
      if (amount < 1) countFrameRef.current = window.requestAnimationFrame(animate);
    };
    countFrameRef.current = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(countFrameRef.current);
  }, [currentPanel, sectionVisible]);

  const scrollToPanel = (nextPanel: number) => {
    const scroller = cardScrollRef.current;
    if (!scroller) return;
    const targetPanel = Math.max(0, Math.min(4, nextPanel));
    scroller.scrollTo({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      top: targetPanel * scroller.clientHeight,
    });
  };

  const choose = (questionIndex: number, choice: QuizChoice) => {
    if (answers[questionIndex]) return;
    setAnswers((current) => current.map((answer, index) => index === questionIndex ? choice : answer));
  };

  const resetQuiz = () => {
    setAnswers([null, null, null]);
    scrollToPanel(1);
  };

  return (
    <section className="story-scroller story-scene-0 relative" ref={sectionRef}>
      <div className="story-sticky">
        <div className="story-ambient ambient-one" />
        <div className="story-ambient ambient-two" />
        <div className="story-rail">
          <span>TruLens / HOW IT WORKS</span>
          <div><i style={{ height: `${((currentPanel + 1) / 5) * 100}%` }} /></div>
          <small>01</small>
        </div>
        <div className="story-copy-stack">
          <article className="story-copy-layer is-active">
            {storyScene.step !== "01 / READ" && <span className="story-step">{storyScene.step}</span>}
            <small>{storyScene.eyebrow}</small>
            <h2>{storyScene.title}</h2>
            <p>{storyScene.body}</p>
            <div className="read-step-list">
              <button className={activeStep === "data" ? "active" : ""} onClick={() => scrollToPanel(0)}>
                <span>01</span><strong>数字</strong><i />
              </button>
              <button className={activeStep === "quiz" ? "active" : ""} onClick={() => scrollToPanel(activeStep === "quiz" ? currentPanel : 1)}>
                <span>02</span><strong>小测{activeStep === "quiz" ? ` · 第 ${currentPanel} / 3 题` : ""}</strong><i />
              </button>
              <button className={activeStep === "result" ? "active" : ""} onClick={() => scrollToPanel(4)}>
                <span>03</span><strong>结果</strong><i />
              </button>
            </div>
          </article>
        </div>
        <div className="merged-story-visual">
          <i className="merged-orbit merged-orbit-one" />
          <i className="merged-orbit merged-orbit-two" />
          <div className="merged-story-card">
            <div
              aria-label="互动内容，可在卡片内上下滚动"
              className="merged-card-scroll"
              onScroll={(event) => {
                const scroller = event.currentTarget;
                const nextPanel = Math.max(0, Math.min(4, Math.round(scroller.scrollTop / scroller.clientHeight)));
                setCurrentPanel(nextPanel);
                if (scroller.scrollTop > 4) setScrollHintVisible(false);
              }}
              ref={cardScrollRef}
              tabIndex={0}
            >
              <section className="merged-track-screen merged-data-screen">
                <span className="merged-panel-kicker">不只是你 · NOT JUST YOU</span>
                {[
                  ["66", dataValues[0], "消费者自信能识别 AI 图片", "Clutch Survey · 2025 年 9 月"],
                  ["57", dataValues[1], "人在实测中判断出错", "Clutch Survey · 2025 年 9 月"],
                  ["35.7", dataValues[2], "第三方测评账号涉嫌虚假测评", "中消协《第三方测评消费体验调查》"],
                ].map(([target, value, label]) => (
                  <div key={String(target)}>
                    <strong>{Number(value).toFixed(String(target).includes(".") ? 1 : 0)}%</strong>
                    <span>{label}</span>
                  </div>
                ))}
                <small>来源：Clutch Survey, Sep 2025；中消协《第三方测评消费体验调查》</small>
              </section>
              {aiImageQuizQuestions.map((question, index) => {
                const answer = answers[index];
                return (
                  <section className="merged-track-screen merged-quiz-screen" key={question.title}>
                    <header><span>试试看 · TRY IT</span><small>第 {index + 1} / 3 题 · {question.title}</small></header>
                    <h3>哪一张是 AI 生成的？</h3>
                    <div className="quiz-options">
                      {question.images.map((image) => {
                        const answered = answer !== null;
                        const isSelected = answer === image.choice;
                        const isAi = question.aiAnswer === image.choice;
                        return (
                          <div className="quiz-option" key={image.choice}>
                            <button
                              aria-label={`选择 ${image.choice}`}
                              className={`quiz-image-placeholder ${image.image} ${isSelected ? "selected" : ""}`}
                              disabled={answered}
                              onClick={() => choose(index, image.choice)}
                            >
                              <span>{image.choice}</span>
                              <small>示例图</small>
                              {image.icon === "product" ? (
                                <Icon size={52}><path d="M8 8c2-4 6-4 8 0 1.8 3.5-1 7.5-4 10-3-2.5-5.8-6.5-4-10Z" stroke="currentColor" strokeWidth="1.2" /><path d="M9 13c2 .8 4 .8 6 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.2" /></Icon>
                              ) : image.icon === "compare" ? (
                                <Icon size={52}><rect height="15" rx="3" stroke="currentColor" strokeWidth="1.2" width="18" x="3" y="4.5" /><path d="M12 5v14M6 15l3-3 3 2 3-4 3 3" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.2" /></Icon>
                              ) : (
                                <Icon size={52}><circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.2" /><path d="M7 10c2-2 3 2 5 0s3 2 5 0M7 14c2-2 3 2 5 0s3 2 5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.2" /></Icon>
                              )}
                              {answered && isAi && (
                                <i
                                  className="quiz-ai-marker"
                                  style={{ left: question.reveal.left, top: question.reveal.top }}
                                >
                                  <b />
                                  <em>{question.reveal.label}</em>
                                </i>
                              )}
                            </button>
                            <button className="quiz-choice-button" disabled={answered} onClick={() => choose(index, image.choice)}>
                              我选 {image.choice}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                    <div aria-live="polite" className="quiz-reveal">
                      {answer && (
                        <>
                          <strong className={answer === question.aiAnswer ? "correct" : "incorrect"}>
                            <i>{answer === question.aiAnswer ? "✓" : "!"}</i>
                            {answer === question.aiAnswer ? "答对了" : "差一点"}
                          </strong>
                          <p>{question.explanation}</p>
                          <small>继续向下滚动 <i>↓</i></small>
                        </>
                      )}
                    </div>
                  </section>
                );
              })}
              <section className="merged-track-screen merged-result-screen">
                <span className="quiz-result-kicker">你的结果 · YOUR RESULT</span>
                <strong>{score} <small>/ 3</small></strong>
                <h3>{resultTitle}</h3>
                {unanswered > 0 && <p>还有 {unanswered} 题没答，向上滚动可以回去答。</p>}
                <small>接下来，让 TruLens 帮你看。</small>
                <div className="quiz-result-actions">
                  <button onClick={() => document.querySelector(".trust-section")?.scrollIntoView({ behavior: "smooth" })}>
                    让 TruLens 帮你看 <span><Arrow size={18} /></span>
                  </button>
                  <button onClick={resetQuiz}>再测一次</button>
                </div>
              </section>
            </div>
            <i className="merged-card-mask mask-top" />
            <i className="merged-card-mask mask-bottom" />
            {scrollHintVisible && <span className="merged-scroll-hint">在卡片内滚动 <i>↓</i></span>}
            <div className="merged-card-controls">
              <small>示例内容 · 图片为占位</small>
              <div>
                <span>{currentPanel + 1} / 5</span>
                <button aria-label="上一个面板" disabled={currentPanel === 0} onClick={() => scrollToPanel(currentPanel - 1)}>
                  <Icon size={17}><path d="m7 14 5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                </button>
                <button aria-label="下一个面板" disabled={currentPanel === 4} onClick={() => scrollToPanel(currentPanel + 1)}>
                  <Icon size={17}><path d="m7 10 5 5 5-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

type QuizChoice = "A" | "B";

const aiImageQuizQuestions: Array<{
  title: string;
  aiAnswer: QuizChoice;
  images: Array<{ choice: QuizChoice; image: string; icon: "texture" | "product" | "compare" }>;
  reveal: { left: string; top: string; label: string };
  explanation: string;
}> = [
  {
    title: "肤质特写",
    aiAnswer: "B",
    images: [
      { choice: "A", image: "soft-lilac", icon: "texture" },
      { choice: "B", image: "soft-pink", icon: "texture" },
    ],
    reveal: { left: "62%", top: "42%", label: "高光与肤色过渡" },
    explanation: "高光方向与背景光源不一致，肤色过渡出现断层。",
  },
  {
    title: "产品质地图",
    aiAnswer: "A",
    images: [
      { choice: "A", image: "soft-blue", icon: "product" },
      { choice: "B", image: "soft-lilac", icon: "product" },
    ],
    reveal: { left: "55%", top: "58%", label: "质地边缘与反光" },
    explanation: "质地边缘过于平滑，缺少真实的反光颗粒。",
  },
  {
    title: "使用前后对比",
    aiAnswer: "B",
    images: [
      { choice: "A", image: "soft-pink", icon: "compare" },
      { choice: "B", image: "soft-blue", icon: "compare" },
    ],
    reveal: { left: "68%", top: "48%", label: "前后阴影方向" },
    explanation: "前后对比图里的阴影方向前后矛盾。",
  },
];

const evidenceHotspots = [
  {
    id: 1,
    label: "光影一致性",
    text: "高光方向与背景光源不一致",
    x: "62%",
    y: "24%",
  },
  {
    id: 2,
    label: "拼接痕迹",
    text: "脸颊与颈部边缘存在不自然的过渡",
    x: "38%",
    y: "56%",
  },
  {
    id: 3,
    label: "色彩过渡",
    text: "肤色渐变出现断层",
    x: "68%",
    y: "72%",
  },
];

function EvidenceSection({ onStart }: { onStart: () => void }) {
  const sectionRef = useRef<HTMLElement>(null);
  const imageFrameRef = useRef<HTMLDivElement>(null);
  const lensTargetRef = useRef({ x: 50, y: 45 });
  const lensCurrentRef = useRef({ x: 50, y: 45 });
  const lensAnimationRef = useRef(0);
  const demoTimersRef = useRef<number[]>([]);
  const demoPlayedRef = useRef(false);
  const touchDraggingRef = useRef(false);
  const touchMovedRef = useRef(false);
  const [visible, setVisible] = useState(false);
  const [lensVisible, setLensVisible] = useState(false);
  const [lensRender, setLensRender] = useState({
    x: 50,
    y: 45,
    backgroundWidth: 774,
    backgroundHeight: 968,
    backgroundX: -337,
    backgroundY: -389,
  });
  const [comparison, setComparison] = useState(0);
  const [mobileForensic, setMobileForensic] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [nearbyHotspot, setNearbyHotspot] = useState<number | null>(null);
  const [userInteracted, setUserInteracted] = useState(false);
  const [demoRunning, setDemoRunning] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 },
    );
    observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!lensVisible) return;
    const animateLens = () => {
      const frame = imageFrameRef.current;
      if (!frame) return;
      const current = lensCurrentRef.current;
      const target = lensTargetRef.current;
      current.x += (target.x - current.x) * 0.18;
      current.y += (target.y - current.y) * 0.18;

      const bounds = frame.getBoundingClientRect();
      const diameter = Math.max(180, Math.min(300, bounds.width * 0.4));
      const pointX = (current.x / 100) * bounds.width;
      const pointY = (current.y / 100) * bounds.height;
      const backgroundWidth = bounds.width * 1.8;
      const backgroundHeight = bounds.height * 1.8;
      setLensRender({
        x: current.x,
        y: current.y,
        backgroundWidth,
        backgroundHeight,
        backgroundX: diameter / 2 - pointX * 1.8,
        backgroundY: diameter / 2 - pointY * 1.8,
      });

      let nearest: number | null = null;
      let nearestDistance = Number.POSITIVE_INFINITY;
      evidenceHotspots.forEach((hotspot) => {
        const hotspotX = (Number.parseFloat(hotspot.x) / 100) * bounds.width;
        const hotspotY = (Number.parseFloat(hotspot.y) / 100) * bounds.height;
        const distance = Math.hypot(pointX - hotspotX, pointY - hotspotY);
        if (distance < diameter * 0.3 && distance < nearestDistance) {
          nearest = hotspot.id;
          nearestDistance = distance;
        }
      });
      setNearbyHotspot(nearest);
      lensAnimationRef.current = window.requestAnimationFrame(animateLens);
    };
    lensAnimationRef.current = window.requestAnimationFrame(animateLens);
    return () => window.cancelAnimationFrame(lensAnimationRef.current);
  }, [lensVisible]);

  useEffect(() => {
    if (!visible || userInteracted || demoPlayedRef.current) return;
    demoPlayedRef.current = true;
    const moveDemoLens = (hotspotIndex: number) => {
      const hotspot = evidenceHotspots[hotspotIndex];
      lensTargetRef.current = {
        x: Number.parseFloat(hotspot.x),
        y: Number.parseFloat(hotspot.y),
      };
    };
    demoTimersRef.current = [
      window.setTimeout(() => {
        setDemoRunning(true);
        setLensVisible(true);
        moveDemoLens(0);
      }, 500),
      window.setTimeout(() => moveDemoLens(1), 1700),
      window.setTimeout(() => moveDemoLens(2), 2900),
      window.setTimeout(() => {
        setDemoRunning(false);
        setLensVisible(false);
        setNearbyHotspot(null);
      }, 5000),
    ];
    return () => demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
  }, [visible, userInteracted]);

  const stopDemoAndTakeControl = () => {
    if (!userInteracted) setUserInteracted(true);
    demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    demoTimersRef.current = [];
    setDemoRunning(false);
  };

  const setLensTargetFromPointer = (
    clientX: number,
    clientY: number,
    verticalOffset = 0,
  ) => {
    const frame = imageFrameRef.current;
    if (!frame) return;
    const bounds = frame.getBoundingClientRect();
    lensTargetRef.current = {
      x: Math.max(0, Math.min(100, ((clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((clientY - bounds.top - verticalOffset) / bounds.height) * 100)),
    };
  };

  const nearbyEvidence = nearbyHotspot
    ? evidenceHotspots.find((hotspot) => hotspot.id === nearbyHotspot)
    : null;

  return (
    <section className={`evidence-section reveal-section ${visible ? "is-visible" : ""}`} ref={sectionRef}>
      <div className="evidence-heading">
        <span className="section-tag">THE EVIDENCE</span>
        <h2>证据，不是结论</h2>
        <p>每一个判断，都指给你看它是从哪里来的。</p>
      </div>

      <div className="evidence-layout">
        <div className="evidence-copy">
          <div className="evidence-points">
            <div>
              <span>
                <Icon size={19}>
                  <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
                  <path d="m16 16 4 4M8 11h6M11 8v6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>图像取证</strong><small>检查光影、拼接痕迹、色彩过渡</small></p>
            </div>
            <div>
              <span>
                <Icon size={19}>
                  <path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d="M15 3v4h3M9 11h6M9 15h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>文案分析</strong><small>识别绝对化的功效宣称</small></p>
            </div>
            <div>
              <span>
                <Icon size={19}>
                  <path d="M5 6.5h14v9H9l-4 3v-12Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d="M8 10h8M8 13h5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>评论模式</strong><small>发现批量灌水与句式雷同</small></p>
            </div>
          </div>
          <p className="evidence-note">判定依据同步呈现，每一步都可追溯。</p>
          <button className="evidence-cta" onClick={onStart}>
            体验 TruLens Agent
            <span className="circle-arrow"><Arrow size={19} /></span>
          </button>
        </div>

        <div className="evidence-card">
          <div
            className={`evidence-image-frame ${mobileForensic ? "mobile-forensic" : ""}`}
            onClick={() => {
              if (window.matchMedia("(hover: none)").matches && !touchMovedRef.current) {
                setMobileForensic((current) => !current);
              }
              touchMovedRef.current = false;
            }}
            onPointerDown={(event) => {
              if (event.pointerType !== "touch") return;
              touchDraggingRef.current = true;
              touchMovedRef.current = false;
              event.currentTarget.setPointerCapture(event.pointerId);
              stopDemoAndTakeControl();
              setLensVisible(true);
              setLensTargetFromPointer(event.clientX, event.clientY, 90);
            }}
            onPointerEnter={(event) => {
              if (event.pointerType === "mouse") setLensVisible(true);
            }}
            onPointerLeave={(event) => {
              if (event.pointerType === "mouse" && !demoRunning) {
                setLensVisible(false);
                setNearbyHotspot(null);
              }
              setActiveHotspot(null);
            }}
            onPointerMove={(event) => {
              if (event.pointerType === "mouse") {
                stopDemoAndTakeControl();
                setLensVisible(true);
                setLensTargetFromPointer(event.clientX, event.clientY);
              } else if (touchDraggingRef.current) {
                touchMovedRef.current = true;
                stopDemoAndTakeControl();
                setLensTargetFromPointer(event.clientX, event.clientY, 90);
              }
            }}
            onPointerUp={(event) => {
              if (event.pointerType !== "touch") return;
              touchDraggingRef.current = false;
              setLensVisible(false);
              setNearbyHotspot(null);
            }}
            ref={imageFrameRef}
          >
            <img alt="肤质特写占位图" className="evidence-base-image" src={portrait} />
            <div
              className="evidence-forensic-layer evidence-slider-layer"
              style={{ clipPath: mobileForensic ? "inset(0)" : `inset(0 ${100 - comparison}% 0 0)` }}
            >
              <img alt="" src={portrait} />
              <span />
            </div>
            <div className={`evidence-image-dim ${lensVisible ? "visible" : ""}`} />
            <div
              className={`evidence-lens ${lensVisible ? "visible" : ""} ${nearbyHotspot ? "hotspot-near" : ""}`}
              style={{ left: `${lensRender.x}%`, top: `${lensRender.y}%` }}
            >
              <div
                className="evidence-lens-image"
                style={{
                  backgroundImage: `url(${portrait})`,
                  backgroundPosition: `${lensRender.backgroundX}px ${lensRender.backgroundY}px`,
                  backgroundSize: `${lensRender.backgroundWidth}px ${lensRender.backgroundHeight}px`,
                }}
              />
              <div className="evidence-lens-heat" />
              <div className="evidence-lens-grid" />
              <div className="evidence-lens-scan" />
              <div className="evidence-lens-glare" />
              <div className="evidence-reticle"><i /><b /><b /><b /><b /></div>
              <span>{nearbyEvidence ? `${nearbyEvidence.label} · 异常` : "取证层 · 扫描中"}</span>
            </div>
            <div className={`evidence-operation-hint ${userInteracted ? "hidden" : ""}`}>
              <Icon size={12}>
                <path d="m7 4 9 8-4 .8 2.2 4.2-2.2 1.1-2.1-4.2L7 17V4Z" fill="currentColor" />
              </Icon>
              移动鼠标，用镜头检查这张图
            </div>

            {evidenceHotspots.map((hotspot) => (
              <div
                className={`evidence-hotspot-wrap ${activeHotspot === hotspot.id ? "active" : ""} ${nearbyHotspot === hotspot.id ? "nearby" : ""}`}
                key={hotspot.id}
                style={{ left: hotspot.x, top: hotspot.y }}
              >
                <button
                  aria-label={`查看${hotspot.label}`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setActiveHotspot((current) => current === hotspot.id ? null : hotspot.id);
                  }}
                  onMouseEnter={() => setActiveHotspot(hotspot.id)}
                >
                  <i />
                </button>
                {activeHotspot === hotspot.id && (
                  <div className="hotspot-popover">
                    <small>钉 {hotspot.id}</small>
                    <strong>{hotspot.label}</strong>
                    <p>{hotspot.text}</p>
                  </div>
                )}
              </div>
            ))}
            <span className="mobile-evidence-hint">点击切换原图 / 取证层</span>
          </div>

          <div className="evidence-slider">
            <span>原图</span>
            <input
              aria-label="调整原图与取证层对比"
              max="100"
              min="0"
              onChange={(event) => setComparison(Number(event.target.value))}
              style={{ "--slider-value": `${comparison}%` } as React.CSSProperties}
              type="range"
              value={comparison}
            />
            <span>取证层</span>
          </div>
          <small className="example-data">示例数据</small>
        </div>
      </div>
    </section>
  );
}

const agentScenes: Array<{
  code: DimensionCode;
  label: string;
  input: string;
  question: string;
  description: string;
  score: number;
}> = [
  {
    code: "T",
    label: "账号可信度",
    input: "账号主页",
    question: "这个账号长期可靠吗？",
    description: "分析发布节奏、带货占比和历史内容的一致性。",
    score: 55,
  },
  {
    code: "R",
    label: "图像原生性",
    input: "图片",
    question: "这张图是真的吗？",
    description: "检查光影一致性、拼接痕迹和色彩过渡。",
    score: 30,
  },
  {
    code: "U",
    label: "评论自然度",
    input: "评论",
    question: "评论是真人说的吗？",
    description: "检查句式相似度、发布时间与账号特征。",
    score: 40,
  },
  {
    code: "S",
    label: "文案真实性",
    input: "文案",
    question: "这段话是体验，还是写好的脚本？",
    description: "识别模板化话术、绝对化用语和缺少依据的功效宣称。",
    score: 50,
  },
];

const dimensionImageHotspots = [
  { id: 1, left: 34, top: 58, tag: "光影", text: "高光方向与背景光源不一致" },
  { id: 2, left: 78, top: 82, tag: "色彩过渡", text: "肤色过渡出现断层" },
];

function AgentSceneVisual({ code, instance }: { code: DimensionCode; instance: string }) {
  const [ratioHovered, setRatioHovered] = useState(false);
  const [commentHover, setCommentHover] = useState<"similar" | "time" | null>(null);
  const [commentSelected, setCommentSelected] = useState<"similar" | "time" | null>(null);
  const commentFocus = commentHover ?? commentSelected;

  if (code === "T") {
    const bars = [24, 38, 31, 66, 42, 76, 54, 28, 70, 48, 84, 61, 35, 73, 58, 88, 46, 69, 53, 78, 39, 67, 82, 49, 72, 57, 86, 63, 44, 75];
    return (
      <div className={`agent-account-card ${ratioHovered ? "ratio-highlight" : ""}`}>
        <div className="account-placeholder-head">
          <span className="account-placeholder-avatar"><Sparkle size={17} /></span>
          <div><strong>晚风护肤札记</strong><small>@beauty_profile</small></div>
          <em>营销特征较多</em>
        </div>
        <div className="account-placeholder-data">
          <div className="posting-rhythm">
            <span>近 30 篇笔记发布节奏</span>
            <div>{bars.map((height, index) => (
              <button
                aria-label={`第 ${index + 1} 篇笔记${index < 24 ? "，带商品链接" : ""}`}
                className={index < 24 ? "commerce-bar" : ""}
                key={index}
                style={{ height: `${height}%` }}
              >
                {index < 24 && <span>这一篇带商品链接</span>}
              </button>
            ))}</div>
            <small><b /> 日常内容 <b /> 带货内容</small>
          </div>
          <div className="commerce-ratio">
            <span>带货占比</span>
            <button
              aria-describedby={`commerce-ratio-tip-${instance}`}
              onBlur={() => setRatioHovered(false)}
              onFocus={() => setRatioHovered(true)}
              onMouseEnter={() => setRatioHovered(true)}
              onMouseLeave={() => setRatioHovered(false)}
            >
              <strong>80%</strong><small>近 30 篇</small>
              <em id={`commerce-ratio-tip-${instance}`}>近 30 篇笔记中 24 篇带商品链接</em>
            </button>
          </div>
        </div>
        <small className="agent-visual-example">示例数据</small>
      </div>
    );
  }

  if (code === "R") {
    return <DimensionImageForensics instance={instance} />;
  }

  if (code === "U") {
    const comments = [
      "质地很轻薄，用了一周真的很服帖！",
      "质地很轻盈，用了一周妆效特别服帖。",
      "用了一周，质地轻薄而且真的很服帖！",
      "质地轻薄不厚重，一周后依然很服帖。",
      "鼻翼位置四小时后有一点卡粉，干皮需要先保湿。",
    ];
    return (
      <div className="agent-comment-evidence">
        <div className="comment-evidence-tabs">
          <button className={commentFocus === "similar" ? "active" : ""} onBlur={() => setCommentHover(null)} onClick={() => setCommentSelected(commentSelected === "similar" ? null : "similar")} onFocus={() => setCommentHover("similar")} onMouseEnter={() => setCommentHover("similar")} onMouseLeave={() => setCommentHover(null)}>句式相似</button>
          <button className={commentFocus === "time" ? "active" : ""} onBlur={() => setCommentHover(null)} onClick={() => setCommentSelected(commentSelected === "time" ? null : "time")} onFocus={() => setCommentHover("time")} onMouseEnter={() => setCommentHover("time")} onMouseLeave={() => setCommentHover(null)}>集中发布</button>
        </div>
        <div className={`comment-evidence-list ${commentFocus === "similar" ? "highlighted" : ""}`}>
          {comments.map((comment, index) => <p className={index < 4 ? "similar" : ""} key={comment}><i />{comment}</p>)}
        </div>
        <div className={`comment-time-axis ${commentFocus === "time" ? "highlighted" : ""}`}>
          <span>00:00</span><span>12:00</span><span>24:00</span>
          <div>{[8, 12, 14, 16, 18, 21, 23, 67, 82].map((left, index) => <i className={index < 6 ? "clustered" : ""} key={index} style={{ left: `${left}%` }} />)}</div>
          <em>2 小时内集中发布</em>
        </div>
        <small>62 条评论中 41 条句式相似</small>
        <small className="agent-visual-example">示例数据</small>
      </div>
    );
  }

  return (
    <div className="agent-copy-card script-evidence-card">
      <div className="copy-card-head"><i /><span>种草笔记文案</span><small>内容检查</small></div>
      <p>
        <button aria-describedby={`script-tip-template-${instance}`}>姐妹们闭眼入<span id={`script-tip-template-${instance}`}>模板化话术</span></button>！这款粉底液一抹显白，
        <button className="risk" aria-describedby={`script-tip-risk-${instance}`}>24 小时不脱妆<span id={`script-tip-risk-${instance}`}>绝对化用语</span></button>，油皮干皮都适用，
        <button className="claim" aria-describedby={`script-tip-claim-${instance}`}>用完皮肤状态真的变好了<span id={`script-tip-claim-${instance}`}>功效缺少依据</span></button>。
      </p>
      <div className="copy-risk-labels">
        <span>模板化话术</span><span>绝对化用语</span><span>功效缺少依据</span>
      </div>
      <small className="agent-visual-example">示例数据</small>
    </div>
  );
}

function DimensionImageForensics({ instance }: { instance: string }) {
  const frameRef = useRef<HTMLDivElement>(null);
  const targetRef = useRef({ x: dimensionImageHotspots[0].left, y: dimensionImageHotspots[0].top });
  const currentRef = useRef({ x: 50, y: 48 });
  const animationRef = useRef(0);
  const autoTimerRef = useRef(0);
  const [lensPosition, setLensPosition] = useState({ x: 50, y: 48 });
  const [manual, setManual] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [userMoved, setUserMoved] = useState(false);
  const [frameSize, setFrameSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const frame = frameRef.current;
    if (!frame) return;
    const measure = () => {
      const bounds = frame.getBoundingClientRect();
      setFrameSize({ width: bounds.width, height: bounds.height });
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(frame);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let hotspotIndex = 0;
    const moveAutomatically = () => {
      if (!manual) {
        const hotspot = dimensionImageHotspots[hotspotIndex % dimensionImageHotspots.length];
        targetRef.current = { x: hotspot.left, y: hotspot.top };
        hotspotIndex += 1;
      }
    };
    moveAutomatically();
    autoTimerRef.current = window.setInterval(moveAutomatically, 2000);
    const animate = () => {
      const damping = manual ? 1 : 0.12;
      currentRef.current.x += (targetRef.current.x - currentRef.current.x) * damping;
      currentRef.current.y += (targetRef.current.y - currentRef.current.y) * damping;
      setLensPosition({ ...currentRef.current });
      const nearby = dimensionImageHotspots.find((hotspot) => Math.hypot(hotspot.left - currentRef.current.x, hotspot.top - currentRef.current.y) < 12);
      if (!manual) setActiveHotspot(nearby?.id ?? null);
      animationRef.current = window.requestAnimationFrame(animate);
    };
    animationRef.current = window.requestAnimationFrame(animate);
    return () => {
      window.clearInterval(autoTimerRef.current);
      window.cancelAnimationFrame(animationRef.current);
    };
  }, [manual]);

  const moveLens = (clientX: number, clientY: number) => {
    const frame = frameRef.current;
    if (!frame) return;
    const bounds = frame.getBoundingClientRect();
    targetRef.current = {
      x: Math.max(0, Math.min(100, ((clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((clientY - bounds.top) / bounds.height) * 100)),
    };
  };

  const lensSize = Math.max(154, Math.min(214, frameSize.width * 0.46));
  const zoom = 2.25;
  const backgroundWidth = frameSize.width * zoom;
  const backgroundHeight = frameSize.height * zoom;
  const backgroundX = -(lensPosition.x / 100 * backgroundWidth - lensSize / 2);
  const backgroundY = -(lensPosition.y / 100 * backgroundHeight - lensSize / 2);

  return (
    <div
      className={`dimension-image-forensics ${manual ? "is-inspecting" : ""}`}
      onPointerEnter={(event) => {
        if (event.pointerType === "mouse") {
          setManual(true);
          moveLens(event.clientX, event.clientY);
        }
      }}
      onPointerLeave={() => {
        setManual(false);
        setActiveHotspot(null);
      }}
      onPointerMove={(event) => {
        if (event.pointerType !== "mouse") return;
        setUserMoved(true);
        moveLens(event.clientX, event.clientY);
      }}
      ref={frameRef}
    >
      <img alt="秋冬奶油肌底妆分享肤质特写示例" src={portrait} />
      <div
        className="dimension-forensic-lens"
        style={{
          backgroundImage: `url(${portrait})`,
          backgroundPosition: `${backgroundX}px ${backgroundY}px`,
          backgroundSize: `${backgroundWidth}px ${backgroundHeight}px`,
          width: lensSize,
          height: lensSize,
          left: `${lensPosition.x}%`,
          top: `${lensPosition.y}%`,
        }}
      >
        <i /><b />
        <span>取证层 · {manual ? `${zoom.toFixed(2)}× 实时放大` : "自动扫描"}</span>
      </div>
      {dimensionImageHotspots.map((hotspot) => (
        <button
          aria-describedby={`dimension-hotspot-${instance}-${hotspot.id}`}
          aria-label={`查看${hotspot.tag}证据`}
          className={`dimension-hotspot ${activeHotspot === hotspot.id ? "active" : ""}`}
          key={hotspot.id}
          onBlur={() => setActiveHotspot(null)}
          onClick={() => setActiveHotspot(activeHotspot === hotspot.id ? null : hotspot.id)}
          onFocus={() => setActiveHotspot(hotspot.id)}
          onMouseEnter={() => setActiveHotspot(hotspot.id)}
          onMouseLeave={() => {
            if (manual) setActiveHotspot(null);
          }}
          style={{ left: `${hotspot.left}%`, top: `${hotspot.top}%` }}
        >
          <i />
          {activeHotspot === hotspot.id && <span id={`dimension-hotspot-${instance}-${hotspot.id}`}><small>{hotspot.tag}</small>{hotspot.text}</span>}
        </button>
      ))}
      {!userMoved && <p>移动鼠标，用放大镜查看</p>}
      <small className="agent-visual-example">示例数据</small>
    </div>
  );
}

function FlowConnector({
  direction,
  lineProgress,
}: {
  direction: "in" | "out";
  lineProgress: number[];
}) {
  const inputPaths = ["M0 24 L120 120", "M0 72 L120 120", "M0 168 L120 120", "M0 216 L120 120"];
  const outputPaths = ["M0 120 L145 48", "M0 120 L145 120", "M0 120 L145 192"];
  const paths = direction === "in" ? inputPaths : outputPaths;
  return (
    <div className={`agent-flow-connector connector-${direction}`} aria-hidden="true">
      <svg viewBox={`0 0 ${direction === "in" ? 120 : 145} 240`}>
        {paths.map((path, index) => (
          <path
            d={path}
            key={path}
            pathLength="1"
            style={{ strokeDasharray: 1, strokeDashoffset: 1 - (lineProgress[index] ?? 0) }}
          />
        ))}
      </svg>
    </div>
  );
}

function CheckSection({ active, replayKey, staticMode }: { active: boolean; replayKey: number; staticMode: boolean }) {
  const previousIndexRef = useRef(0);
  const [activeCode, setActiveCode] = useState<DimensionCode>("T");
  const [direction, setDirection] = useState<"forward" | "backward">("forward");
  const [autoStopped, setAutoStopped] = useState(false);

  useEffect(() => {
    setActiveCode("T");
    previousIndexRef.current = 0;
    setDirection("forward");
    setAutoStopped(false);
  }, [replayKey]);

  useEffect(() => {
    if (!active || staticMode || autoStopped) return;
    const timer = window.setInterval(() => {
      const nextIndex = (previousIndexRef.current + 1) % agentScenes.length;
      setDirection(nextIndex === 0 ? "backward" : "forward");
      previousIndexRef.current = nextIndex;
      setActiveCode(agentScenes[nextIndex].code);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [active, autoStopped, replayKey, staticMode]);

  const activateScene = (code: DimensionCode) => {
    const index = agentScenes.findIndex((scene) => scene.code === code);
    setDirection(index > previousIndexRef.current ? "forward" : "backward");
    previousIndexRef.current = index;
    setActiveCode(code);
  };

  const selectScene = (code: DimensionCode) => {
    setAutoStopped(true);
    activateScene(code);
  };

  const renderPanel = (scene: (typeof agentScenes)[number], mobile = false) => (
    <div
      aria-hidden={!mobile && scene.code !== activeCode}
      className={`agent-dimension-panel ${mobile ? "mobile-panel" : `${scene.code === activeCode ? "active" : ""} slide-${direction}`}`}
      id={mobile ? `dimension-panel-${scene.code.toLowerCase()}` : undefined}
      inert={!mobile && scene.code !== activeCode}
      key={`${mobile ? "mobile" : "desktop"}-${scene.code}`}
    >
      {mobile && <h3 className="mobile-dimension-title"><span>{scene.code}</span>{scene.label}</h3>}
      <div className="agent-scene-copy">
        <span>{scene.code} · {scene.label}</span>
        <h3>{scene.question}</h3>
        <p>{scene.description}</p>
        <small>TruLens 的四个维度之一</small>
        <div className="agent-dimension-score">
          <span>该维度评分</span>
          <strong>{scene.score}</strong>
          <div><i style={{ width: `${scene.score}%` }} /></div>
        </div>
      </div>
      <div className={`agent-scene-visual scene-${scene.code.toLowerCase()}`}>
        <AgentSceneVisual code={scene.code} instance={mobile ? "mobile" : "desktop"} />
      </div>
    </div>
  );

  return (
      <section
        className="one-agent-section"
        id="how-check"
      >
        <div className="one-agent-sticky">
          <div className="one-agent-heading">
            <span className="section-tag">02 / 查 · 多模态鉴伪</span>
            <h2>四个维度，各自取证</h2>
            <p>证据，不是结论。每一个判断，都能指给你看它从哪里来。</p>
          </div>

          <div aria-label="选择 TruLens 核验维度" className="agent-segmented" role="tablist">
            {agentScenes.map((scene) => (
              <button
                aria-selected={activeCode === scene.code}
                className={activeCode === scene.code ? "active" : ""}
                key={scene.code}
                onClick={() => selectScene(scene.code)}
                role="tab"
              >
                <span>{scene.code}</span>{scene.label}
                {activeCode === scene.code && active && !autoStopped && !staticMode && <i className="agent-tab-timer" key={`${replayKey}-${scene.code}`} />}
              </button>
            ))}
          </div>

          <div className="agent-scene-shell" onFocusCapture={() => setAutoStopped(true)} onPointerEnter={() => setAutoStopped(true)}>
            {agentScenes.map((scene) => renderPanel(scene))}
          </div>
          <div className="agent-mobile-panels">
            {agentScenes.map((scene) => renderPanel(scene, true))}
          </div>
        </div>
      </section>
  );
}

// Cross-check arcs are defined once in TeammateUI (this scene is duplicated in
// both files) and imported here so the two copies cannot drift apart.

const MERGE_CROSS_CHECKS = [
  ["矛盾", "文案“直出实拍，无滤镜”", "图像：肤色过渡出现断层", "conflict"],
  ["矛盾", "文案“纯自费分享”", "账号：近 30 篇中 24 篇带商品链接", "conflict"],
  ["存疑", "评论“好用，已回购”集中", "文案：未提使用周期", "doubtful"],
] as const;

function MergeSection({ active, replayKey, staticMode }: { active: boolean; replayKey: number; staticMode: boolean }) {
  const animationFrameRef = useRef(0);
  const [elapsed, setElapsed] = useState(staticMode ? 4.6 : 0);

  useEffect(() => {
    window.cancelAnimationFrame(animationFrameRef.current);
    if (staticMode) {
      setElapsed(4.6);
      return;
    }
    if (!active) {
      setElapsed(0);
      return;
    }
    const startedAt = performance.now();
    const animate = (now: number) => {
      const nextElapsed = Math.min(4.6, (now - startedAt) / 1000);
      setElapsed(nextElapsed);
      if (nextElapsed < 4.6) animationFrameRef.current = window.requestAnimationFrame(animate);
    };
    animationFrameRef.current = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(animationFrameRef.current);
  }, [active, replayKey, staticMode]);

  // Everything settles by 4.6s and then stays on screen: results → cross-check links
  // and notes → convergence → the three outputs.
  const timedProgress = (start: number, duration: number) => Math.min(1, Math.max(0, (elapsed - start) / duration));
  const resultProgress = agentScenes.map((_, index) => timedProgress(0.25 + index * 0.35, 0.6));
  const crossLinkProgress = [timedProgress(1.3, 0.6), timedProgress(1.7, 0.6), timedProgress(2.1, 0.6)];
  const crossLabelProgress = [timedProgress(1.7, 0.5), timedProgress(2.1, 0.5), timedProgress(2.5, 0.5)];
  const convergenceProgress = timedProgress(2.6, 0.5);
  const outputProgress = [timedProgress(3, 0.5), timedProgress(3.35, 0.5), timedProgress(3.7, 0.5)];
  const verdictProgress = timedProgress(3.6, 0.35);

  return (
      <section className={`architecture-section ${active || staticMode ? "merge-visible" : ""}`} id="how-merge">
        <div className="architecture-sticky">
          <div className="architecture-heading">
            <span className="section-tag">03 / 合 · 语义一致性校验</span>
            <h2>四个结果，先对质，再汇成一个分数</h2>
            <p>单看一个维度，谎话可以很圆。放在一起，矛盾就藏不住了。</p>
          </div>

          <div className="one-agent-flow">
            <div className="flow-inputs merge-results">
              <small>四个维度的结果</small>
              <svg aria-hidden="true" className="merge-cross-links" viewBox="0 0 300 220">
                {MERGE_CROSS_LINKS.map((link, index) => (
                  <g key={link.id}>
                    <path
                      className={`cross-link-${link.tone}`}
                      d={link.d}
                      pathLength="1"
                      style={{ strokeDashoffset: 1 - crossLinkProgress[index] }}
                    />
                    <circle
                      className={`cross-link-dot cross-link-dot-${link.tone}`}
                      cx={MERGE_LINK_ANCHOR_X}
                      cy={link.from}
                      r="2.4"
                      style={{ opacity: crossLinkProgress[index] }}
                    />
                    <circle
                      className={`cross-link-dot cross-link-dot-${link.tone}`}
                      cx={MERGE_LINK_ANCHOR_X}
                      cy={link.to}
                      r="2.4"
                      style={{ opacity: crossLinkProgress[index] }}
                    />
                  </g>
                ))}
              </svg>
              {agentScenes.map((scene, index) => (
                <div
                  aria-label={`${scene.code} ${scene.label}，评分 ${scene.score}`}
                  className={`merge-result result-${scene.code.toLowerCase()}`}
                  key={scene.code}
                  style={{ "--result-progress": resultProgress[index] } as React.CSSProperties}
                >
                  <span>{scene.code}</span>
                  <div>
                    <strong>{scene.label}</strong>
                    <i><b style={{ width: `${scene.score * resultProgress[index]}%` }} /></i>
                  </div>
                  <em>{resultProgress[index] > 0 ? Math.round(scene.score * resultProgress[index]) : ""}</em>
                </div>
              ))}
            </div>

            {/* Grid spacer: the cross-check arcs above replace the old straight in-lines. */}
            <div aria-hidden="true" className="agent-flow-connector connector-in" />

            <div className="aperture-column">
              <div className="aperture-orbits">
            <i className="aperture-orbit orbit-inner" />
            <i className="aperture-orbit orbit-outer" />
            <svg aria-label="TruLens 的四个核验维度" className="agent-aperture" viewBox="0 0 280 280">
              {[
                { code: "T" as DimensionCode, path: "M138 18A122 122 0 0 0 18 138H92a48 48 0 0 1 46-46Z", x: 64, y: 80, label: "账号可信度" },
                { code: "R" as DimensionCode, path: "M142 18a122 122 0 0 1 120 120h-74a48 48 0 0 0-46-46Z", x: 216, y: 80, label: "图像原生性" },
                { code: "U" as DimensionCode, path: "M262 142a122 122 0 0 1-120 120v-74a48 48 0 0 0 46-46Z", x: 216, y: 205, label: "评论自然度" },
                { code: "S" as DimensionCode, path: "M138 262A122 122 0 0 1 18 142h74a48 48 0 0 0 46 46Z", x: 64, y: 205, label: "文案真实性" },
              ].map((petal, index) => (
                <g
                  aria-label={`${petal.code} ${petal.label}`}
                  className={`aperture-petal petal-${petal.code.toLowerCase()}`}
                  key={petal.code}
                  style={{ "--petal-progress": resultProgress[index] } as React.CSSProperties}
                >
                  <path d={petal.path} />
                  <text className="petal-letter" textAnchor="middle" x={petal.x} y={petal.y}>{petal.code}</text>
                  <text className="petal-label" textAnchor="middle" x={petal.x} y={petal.y + 16}>{petal.label}</text>
                </g>
              ))}
              <g className="merge-rays" style={{ "--merge-progress": convergenceProgress } as React.CSSProperties}>
                {/* Rays start just inside the petal labels so they never run across the text. */}
                <line pathLength="1" x1="86" x2="140" y1="86" y2="140" />
                <line pathLength="1" x1="194" x2="140" y1="86" y2="140" />
                <line pathLength="1" x1="194" x2="140" y1="194" y2="140" />
                <line pathLength="1" x1="86" x2="140" y1="194" y2="140" />
              </g>
              <g className="aperture-core">
                <circle cx="140" cy="140" r="45" />
                <g transform="translate(128 113)"><Sparkle size={24} /></g>
                <text textAnchor="middle" x="140" y="158">TruLens</text>
              </g>
            </svg>
              </div>
              <div className="merge-cross-checks">
                {MERGE_CROSS_CHECKS.map(([state, left, right, tone], index) => (
                  <div className={`cross-check-preview preview-${tone}`} key={left} style={{ "--preview-progress": crossLabelProgress[index] } as React.CSSProperties}>
                    <em>{state}</em><span>{left}</span><i>×</i><span>{right}</span>
                  </div>
                ))}
                <small>示例数据</small>
              </div>
            </div>

            <FlowConnector direction="out" lineProgress={outputProgress} />

            <div className="flow-outputs">
              <small>统一输出</small>
              <div
                aria-label={`Trust Score ${Math.round(43 * outputProgress[0])} / 100，置信度高`}
                className="merge-output score-output"
                style={{ "--output-progress": outputProgress[0], "--verdict-progress": verdictProgress } as React.CSSProperties}
              >
                <span>Trust Score 与置信度</span>
                <strong>{Math.round(43 * outputProgress[0])}<small>/ 100</small></strong>
                <em>置信度 高</em>
              </div>
              <div className="merge-output detail-output" style={{ "--output-progress": outputProgress[1] } as React.CSSProperties}><span>证据与交叉验证</span><strong>2 处矛盾 · 1 处存疑</strong></div>
              <div className="merge-output detail-output" style={{ "--output-progress": outputProgress[2] } as React.CSSProperties}><span>处理建议</span><strong>四类角色，各有下一步</strong></div>
            </div>
          </div>

          <small className="one-agent-example">示例数据</small>
        </div>
      </section>
  );
}

// Kept as a hot-reload compatibility bridge for sessions that still reference
// the pre-narrative component name. The current Home renders HowNarrative.
function OneAgentSection() {
  return (
    <>
      <CheckSection active replayKey={0} staticMode={false} />
      <MergeSection active replayKey={0} staticMode={false} />
    </>
  );
}

type ReportPart = "score" | "band" | "radar" | "evidence" | "missing" | "cross" | "advice";

const reportDimensions = [
  { code: "T" as DimensionCode, name: "账号可信度", score: 55, evidence: "近 30 篇笔记中 24 篇带商品链接" },
  { code: "R" as DimensionCode, name: "图像原生性", score: 30, evidence: "高光方向与背景光源不一致，肤色过渡出现断层" },
  { code: "U" as DimensionCode, name: "评论自然度", score: 40, evidence: "62 条评论中 41 条句式相似，集中在 2 小时内发布" },
  { code: "S" as DimensionCode, name: "文案真实性", score: 50, evidence: '文案模板化，并含绝对化用语“24 小时不脱妆”' },
];

const reportCallouts: Array<{ number: string; text: string; part: ReportPart; side: "left" | "right" }> = [
  { number: "01", text: "Trust Score 综合得分", part: "score", side: "left" },
  { number: "02", text: "风险色带", part: "band", side: "left" },
  { number: "03", text: "四维雷达图", part: "radar", side: "left" },
  { number: "04", text: "逐项证据，每个维度都附依据", part: "evidence", side: "right" },
  { number: "05", text: "购买建议，告诉你下一步", part: "advice", side: "right" },
  { number: "06", text: "交叉验证", part: "cross", side: "left" },
  { number: "07", text: "处理建议 · 按角色", part: "advice", side: "right" },
];

const reportRoleAdvice = [
  { role: "消费者", advice: "不建议依据这篇下单，先去官方渠道核实功效数据。" },
  { role: "创作者", advice: "如果内容属实，补充原图和凭证即可申诉。" },
  { role: "平台运营", advice: "建议人工复核，复核前先限流观察。" },
  { role: "品牌方", advice: "核实品牌名和功效数据是否被滥用，转合规评估。" },
];

function ReportSection({ active, onStart, staticMode }: { active: boolean; onStart: () => void; staticMode: boolean }) {
  const missingComments = false;
  const [activePart, setActivePart] = useState<ReportPart | null>(null);
  const [activeDimension, setActiveDimension] = useState<DimensionCode | null>(null);
  const [activeRole, setActiveRole] = useState(1);

  const focusCallout = (part: ReportPart | null) => {
    setActivePart(part);
    setActiveDimension(part === "missing" ? "U" : null);
  };

  const radarPoints = missingComments
    ? "M120 60.5 L147 110 M75 110 L120 60.5"
    : "M120 60.5 L147 110 L120 146 L75 110 Z";

  return (
    <section className={`report-showcase-section ${active || staticMode ? "is-visible" : ""} ${staticMode ? "is-static" : ""}`} id="how-report">
      <div className="report-showcase-heading">
        <span className="section-tag">04 / 报 · 决策与建议</span>
        <h2><span>一份报告，</span><span>读懂一条种草</span></h2>
        <p>不只告诉你真假，更告诉你为什么，以及下一步怎么做。</p>
      </div>

      <div className="report-showcase-stage">
        <div className="report-mode-switch single" role="tablist" aria-label="报告展示方式">
          <button
            aria-selected="true"
            className="active"
            role="tab"
          >
            多维可视化报告
          </button>
        </div>

        <article className={`trust-report-card ${missingComments ? "has-missing-data" : ""}`} data-focus={activePart ?? undefined}>
          <header className="trust-report-head">
            <div><strong>TruLens 核验报告</strong><small>秋冬奶油肌底妆分享 · 同一个 Agent 汇总四个维度</small></div>
            <span>示例数据</span>
          </header>

          {/* In the narrative the card has a fixed height; this layer scrolls up with the
              report scene so the cross-check and decision panels come into view. */}
          <div className="trust-report-body">
          <section className="report-score-block report-highlight part-score">
            <div className="report-score-ring">
              <span>Trust Score</span>
              <strong className="report-state-swap" key={missingComments ? "score-missing" : "score-complete"}>
                {missingComments ? "暂不评分" : <>43 <small>/ 100</small></>}
              </strong>
              {missingComments && <em>评论数据不足，已核验 3 / 4 个维度</em>}
            </div>
            <span className={`report-verdict ${missingComments ? "missing" : ""}`} key={missingComments ? "verdict-missing" : "verdict-complete"}>
              {missingComments ? "数据不足" : "存疑 · 谨慎参考"}
            </span>
          </section>

          <section className="report-risk-band report-highlight part-band">
            <div><i /></div>
            <span>高风险</span><span>可信</span>
          </section>

          <section className="report-dimensions-block">
            <div className="report-radar report-highlight part-radar">
              <svg aria-label="T R U S 四维雷达图" viewBox="0 0 240 220">
                {[0.25, 0.5, 0.75, 1].map((scale) => {
                  const radius = 90 * scale;
                  return (
                    <polygon
                      className="radar-grid"
                      key={scale}
                      points={`120,${110 - radius} ${120 + radius},110 120,${110 + radius} ${120 - radius},110`}
                    />
                  );
                })}
                {[
                  { code: "T" as DimensionCode, x: 120, y: 20, tx: 120, ty: 12 },
                  { code: "R" as DimensionCode, x: 210, y: 110, tx: 224, ty: 114 },
                  { code: "U" as DimensionCode, x: 120, y: 200, tx: 120, ty: 215 },
                  { code: "S" as DimensionCode, x: 30, y: 110, tx: 16, ty: 114 },
                ].map((axis) => (
                  <g
                    aria-label={`${axis.code} 维度`}
                    className={`radar-axis axis-${axis.code.toLowerCase()} ${activeDimension && activeDimension !== axis.code ? "dimmed" : ""} ${missingComments && axis.code === "U" ? "missing" : ""}`}
                    key={axis.code}
                    onBlur={() => setActiveDimension(null)}
                    onClick={() => setActiveDimension((current) => current === axis.code ? null : axis.code)}
                    onFocus={() => setActiveDimension(axis.code)}
                    onMouseEnter={() => setActiveDimension(axis.code)}
                    onMouseLeave={() => setActiveDimension(null)}
                    role="button"
                    tabIndex={0}
                  >
                    <line x1="120" x2={axis.x} y1="110" y2={axis.y} />
                    <circle cx={axis.x} cy={axis.y} r="10" />
                    <text textAnchor="middle" x={axis.tx} y={axis.ty}>{axis.code}</text>
                    {axis.code === "S" && <text className="radar-axis-name" textAnchor="start" x="4" y="130">文案真实性</text>}
                  </g>
                ))}
                <path className="radar-data" d={radarPoints} />
                {[
                  ["T", 120, 60.5],
                  ["R", 147, 110],
                  ["U", 120, 146],
                  ["S", 75, 110],
                ].map(([code, x, y]) => (
                  !(missingComments && code === "U") && (
                    <circle
                      className={`radar-point ${activeDimension && activeDimension !== code ? "dimmed" : ""}`}
                      cx={x}
                      cy={y}
                      key={code}
                      r="4"
                    />
                  )
                ))}
                {missingComments && <circle className="radar-point missing-point" cx="120" cy="146" r="5" />}
              </svg>
              <small>四维核验分布</small>
            </div>

            <div className="report-dimension-list">
              {reportDimensions.map((dimension) => {
                const isMissing = missingComments && dimension.code === "U";
                return (
                  <div
                    className={`report-dimension-row report-highlight part-evidence ${dimension.code === "U" ? "part-missing" : ""} ${activeDimension && activeDimension !== dimension.code ? "dimension-dimmed" : ""} ${activeDimension === dimension.code ? "dimension-active" : ""} ${isMissing ? "is-missing" : ""}`}
                    key={dimension.code}
                    onClick={() => setActiveDimension((current) => current === dimension.code ? null : dimension.code)}
                    onMouseEnter={() => setActiveDimension(dimension.code)}
                    onMouseLeave={() => setActiveDimension(null)}
                  >
                    <span className={`report-dimension-badge badge-${dimension.code.toLowerCase()}`}>{dimension.code}</span>
                    <div>
                      <span className="report-state-swap" key={`${dimension.code}-${isMissing ? "missing" : "complete"}`}>
                        <strong>{dimension.name}</strong><b>{isMissing ? "数据不足，未评分" : dimension.score}</b>
                      </span>
                      <div className="dimension-meter"><i style={{ width: isMissing ? "100%" : `${dimension.score}%` }} /></div>
                      <small>{isMissing ? "数据不足，未评分" : dimension.evidence}</small>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="report-cross-check report-highlight part-cross">
            <span>
              <Icon size={15}>
                <circle cx="8" cy="12" r="4.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
                <circle cx="16" cy="12" r="4.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
              </Icon>
            </span>
            <strong>交叉验证 · 2 处矛盾 · 1 处存疑</strong>
          </section>

          <section className="report-decision-panel report-highlight part-advice">
            <div className="report-decision-levels" aria-label="处置等级">
              <span><i />放行·轻提示</span>
              <span><i />提示·补充核验</span>
              <span className="active"><i />人工复核·处置</span>
            </div>
            <div className="report-role-advice">
              <div role="tablist" aria-label="查看不同角色的建议">
                {reportRoleAdvice.map((item, index) => (
                  <button
                    aria-selected={activeRole === index}
                    className={activeRole === index ? "active" : ""}
                    key={item.role}
                    onClick={() => setActiveRole(index)}
                    role="tab"
                    type="button"
                  >
                    {item.role}
                  </button>
                ))}
              </div>
              <p aria-live="polite" key={activeRole}>{reportRoleAdvice[activeRole].advice}</p>
            </div>
            <small>辅助决策，不构成购买建议或定性结论。</small>
          </section>
          </div>
        </article>

        <div className="report-callouts" aria-label="报告结构说明">
          {reportCallouts.map((callout, index) => (
            <button
              className={`report-callout callout-${callout.side} callout-${index + 1} ${index >= 5 ? "phase-two" : ""} ${activePart === callout.part ? "active" : ""}`}
              key={callout.number}
              onClick={() => focusCallout(activePart === callout.part ? null : callout.part)}
              onMouseEnter={() => focusCallout(callout.part)}
              onMouseLeave={() => focusCallout(null)}
            >
              <span>{callout.number}</span>
              <strong>{callout.text}</strong>
              <i />
            </button>
          ))}
        </div>
      </div>

      <p className="report-closing-line">想好下一步，决定，留给你。</p>
      <div className="report-final-action">
        <button onClick={onStart}>
          体验 TruLens Agent
          <span><Arrow size={18} /></span>
        </button>
        <small>示例数据，仅用于展示报告结构</small>
      </div>
    </section>
  );
}

const agentIntroExamples = [
  {
    label: "种草笔记",
    attachments: ["种草笔记截图.png", "评论区截图.png"],
    prompt: "这篇种草笔记可信吗？",
    score: 43,
    verdict: "存疑 · 谨慎参考",
    tone: "caution",
    reply: "账号带货占比高、评论句式相似、出现绝对化用语。下单前先核实 3 件事。",
  },
  {
    label: "清一色好评的评论区",
    attachments: ["评论区截图.png"],
    prompt: "这些好评是真的吗？",
    score: 31,
    verdict: "高风险",
    tone: "risk",
    reply: "62 条评论里有 41 条句式相似，集中在 2 小时内发布。",
  },
  {
    label: "过度修图的对比图",
    attachments: ["对比图.png"],
    prompt: "这张对比图被修过吗？",
    score: 28,
    verdict: "高风险",
    tone: "risk",
    reply: "高光方向与背景光源不一致，肤色过渡出现断层。",
  },
];

function AgentIntroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const demoTimersRef = useRef<number[]>([]);
  const playedRef = useRef(false);
  const [activeExample, setActiveExample] = useState(0);
  const [visibleAttachments, setVisibleAttachments] = useState(0);
  const [typedText, setTypedText] = useState("");
  const [sendPulse, setSendPulse] = useState(false);
  const [replyVisible, setReplyVisible] = useState(false);
  const [uploadHint, setUploadHint] = useState(false);
  const example = agentIntroExamples[activeExample];

  const clearDemoTimers = () => {
    demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    demoTimersRef.current = [];
  };

  const playDemo = (exampleIndex = activeExample) => {
    clearDemoTimers();
    const nextExample = agentIntroExamples[exampleIndex];
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setUploadHint(false);
    setVisibleAttachments(0);
    setTypedText("");
    setSendPulse(false);
    setReplyVisible(false);

    if (reduceMotion) {
      setVisibleAttachments(nextExample.attachments.length);
      setTypedText(nextExample.prompt);
      setReplyVisible(true);
      return;
    }

    nextExample.attachments.forEach((_, index) => {
      demoTimersRef.current.push(window.setTimeout(() => {
        setVisibleAttachments(index + 1);
      }, 180 + index * 200));
    });

    const typingStart = 300 + nextExample.attachments.length * 200;
    nextExample.prompt.split("").forEach((_, index) => {
      demoTimersRef.current.push(window.setTimeout(() => {
        setTypedText(nextExample.prompt.slice(0, index + 1));
      }, typingStart + index * 60));
    });

    const typingEnd = typingStart + nextExample.prompt.length * 60;
    demoTimersRef.current.push(window.setTimeout(() => setSendPulse(true), typingEnd + 180));
    demoTimersRef.current.push(window.setTimeout(() => setSendPulse(false), typingEnd + 620));
    demoTimersRef.current.push(window.setTimeout(() => setReplyVisible(true), typingEnd + 520));
  };

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !playedRef.current) {
          playedRef.current = true;
          playDemo(0);
          observer.disconnect();
        }
      },
      { threshold: 0.28 },
    );
    observer.observe(section);
    return () => {
      observer.disconnect();
      clearDemoTimers();
    };
  }, []);

  const selectExample = (index: number) => {
    setActiveExample(index);
    playDemo(index);
  };

  const showUploadHint = () => {
    setUploadHint(true);
    demoTimersRef.current.push(window.setTimeout(() => setUploadHint(false), 2000));
  };

  return (
    <section className="agent-intro-section" ref={sectionRef}>
      <div className="agent-intro-heading">
        <span className="section-tag">WHAT IS TRULENS</span>
        <h2>丢进一条种草笔记</h2>
        <p>TruLens 把它变成一份看得见依据的<span>可信度画像</span>。</p>
      </div>

      <div className="agent-intro-demo">
        <div className="agent-prompt-card">
          <div className="agent-prompt-attachments">
            {example.attachments.map((attachment, index) => (
              <span className={visibleAttachments > index ? "visible" : ""} key={attachment}>
                <i>
                  <Icon size={15}>
                    <rect height="14" rx="2" stroke="currentColor" strokeWidth="1.4" width="17" x="3.5" y="5" />
                    <circle cx="9" cy="10" r="1.5" stroke="currentColor" strokeWidth="1.3" />
                    <path d="m5.5 17 4-4 2.7 2.5 2.1-2 3.2 3.5" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.3" />
                  </Icon>
                </i>
                {attachment}
              </span>
            ))}
          </div>
          <div className="agent-prompt-text" aria-label={example.prompt}>
            {typedText}<i className="typing-cursor" />
          </div>
          <div className="agent-prompt-actions">
            <button aria-label="添加附件" className="agent-add-button" onClick={showUploadHint}>
              <Icon size={20}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            </button>
            {uploadHint && <span className="agent-upload-hint" role="status">演示版本，暂不支持上传</span>}
            <button
              aria-label="发送并重新播放演示"
              className={`agent-send-button ${sendPulse ? "pulse" : ""}`}
              onClick={() => playDemo()}
            >
              <Icon size={21}><path d="M12 19V5m0 0L7 10m5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7" /></Icon>
            </button>
          </div>
        </div>

        <div aria-live="polite" className="agent-intro-reply-live">
          {replyVisible && (
            <div className={`agent-intro-reply ${example.tone}`}>
              <div className="agent-reply-score" style={{ "--agent-score": example.score } as React.CSSProperties}>
                <div><strong>{example.score}</strong><small>/ 100</small></div>
              </div>
              <div className="agent-reply-copy">
                <span>{example.verdict}</span>
                <p>{example.reply}</p>
              </div>
              <small>示例数据</small>
            </div>
          )}
        </div>

        <div className="agent-example-row">
          <small>试试示例：</small>
          <div>
            {agentIntroExamples.map((item, index) => (
              <button
                aria-pressed={activeExample === index}
                className={activeExample === index ? "active" : ""}
                key={item.label}
                onClick={() => selectExample(index)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <p className="agent-intro-note">基于开源大模型 · 每个判断都附证据 · 数据不足时不硬判</p>
      <button
        className="agent-intro-next"
        onClick={() => document.querySelector(".story-scroller")?.scrollIntoView({ behavior: "smooth" })}
      >
        往下看，为什么你需要它
        <Icon size={16}><path d="M12 5v14m0 0-5-5m5 5 5-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
      </button>
    </section>
  );
}

const HOW_SCENE_RANGES = [
  { id: "trust", number: "01", label: "拆", start: 0, end: 0.24, status: "已收到" },
  { id: "how-check", number: "02", label: "查", start: 0.24, end: 0.48, status: "取证中" },
  { id: "how-merge", number: "03", label: "合", start: 0.48, end: 0.76, status: "评分中" },
  { id: "how-report", number: "04", label: "报", start: 0.76, end: 1, status: "报告已生成" },
];

// Share of the narrative's scroll travel used to fade one scene out / the next one in.
const HOW_FADE = 0.035;
const HOW_SHIFT = 16;

const smoothstep = (value: number) => {
  const t = Math.min(1, Math.max(0, value));
  return t * t * (3 - 2 * t);
};

function howSceneIndexAt(progress: number) {
  const index = HOW_SCENE_RANGES.findIndex((range) => progress < range.end);
  return index === -1 ? HOW_SCENE_RANGES.length - 1 : index;
}

function howScenePresentation(index: number, progress: number) {
  const range = HOW_SCENE_RANGES[index];
  const enter = index === 0 ? 1 : smoothstep((progress - range.start) / HOW_FADE);
  const exit = index === HOW_SCENE_RANGES.length - 1 ? 1 : 1 - smoothstep((progress - (range.end - HOW_FADE)) / HOW_FADE);
  const opacity = Math.min(enter, exit);
  const translateY = enter < 1 ? HOW_SHIFT * (1 - enter) : exit < 1 ? -HOW_SHIFT * (1 - exit) : 0;
  return { opacity, translateY };
}

function HowChapterRail({ activeChapter, onSelect }: { activeChapter: number; onSelect: (index: number) => void }) {
  return (
    <nav aria-label="How 章节导航" className="how-chapter-rail visible">
      <div>
        <span className="how-rail-progress" style={{ height: "calc(var(--how-progress, 0) * 100%)" }} />
        {HOW_SCENE_RANGES.map((chapter, index) => (
          <button className={activeChapter === index ? "active" : ""} key={chapter.id} onClick={() => onSelect(index)}>
            <i /><span>{chapter.number}</span><strong>{chapter.label}</strong>
          </button>
        ))}
      </div>
      <button className="how-report-link" onClick={() => onSelect(3)}>直接看报告</button>
    </nav>
  );
}

const trustTeamMembers = [
  ["T", "账号侦探", "Trustworthiness", "近 30 篇笔记的发布节奏与带货记录"],
  ["R", "视觉取证师", "Reality", "图片的光影、拼接痕迹与色彩过渡"],
  ["U", "口碑观察员", "User Voice", "评论的句式相似度与发布时间"],
  ["S", "文字检察官", "Script", "文案的话术模板与夸大用语"],
] as const;

function TrustMarquee() {
  const trackRef = useRef<HTMLDivElement>(null);
  const offsetRef = useRef(0);
  const speedRef = useRef(28);
  const targetSpeedRef = useRef(28);
  const groupWidthRef = useRef(0);

  useEffect(() => {
    const track = trackRef.current;
    const firstGroup = track?.firstElementChild as HTMLElement | null;
    if (!track || !firstGroup) return;

    const measure = () => {
      groupWidthRef.current = firstGroup.getBoundingClientRect().width;
    };
    measure();
    const resizeObserver = new ResizeObserver(measure);
    resizeObserver.observe(firstGroup);

    let frame = 0;
    let running = false;
    let previous = performance.now();
    const animate = (now: number) => {
      if (!running) return;
      const delta = Math.min(48, now - previous);
      previous = now;
      speedRef.current += (targetSpeedRef.current - speedRef.current) * 0.075;
      const width = groupWidthRef.current;
      if (width > 0) {
        offsetRef.current = (offsetRef.current + speedRef.current * delta / 1000) % width;
        track.style.transform = `translate3d(${-offsetRef.current}px,0,0)`;
      }
      frame = window.requestAnimationFrame(animate);
    };
    const start = () => {
      if (running) return;
      running = true;
      previous = performance.now();
      frame = window.requestAnimationFrame(animate);
    };
    const stop = () => {
      running = false;
      window.cancelAnimationFrame(frame);
    };
    start();
    return () => {
      stop();
      resizeObserver.disconnect();
    };
  }, []);

  const slowDown = () => {
    targetSpeedRef.current = 8;
  };
  const resume = () => {
    targetSpeedRef.current = 28;
  };
  return (
    <div
      aria-label="AI 信任顾问团队循环展示"
      className="trust-grid"
      onPointerCancel={resume}
      onPointerEnter={(event) => {
        if (event.pointerType === "mouse") slowDown();
      }}
      onPointerLeave={resume}
      role="region"
    >
      <div className="trust-marquee-track" ref={trackRef}>
        {[0, 1].map((group) => (
          <div aria-hidden={group === 1} className="trust-marquee-group" inert={group === 1} key={group}>
            {trustTeamMembers.map(([letter, name, title, text], index) => (
              <article
                className={`trust-card card-${index + 1}`}
                key={`${group}-${letter}`}
                tabIndex={group === 0 ? 0 : -1}
              >
                <span>{letter}</span>
                <h3>{name}</h3>
                <img
                  alt={group === 0 ? `${name}专家头像` : ""}
                  className="trust-card-expert"
                  src={roleAvatarByCode[letter]}
                />
                <div>
                  <strong>{title}</strong>
                  <p>
                    <small>{letter === "T" || letter === "R" ? "他" : "她"}看什么</small>
                    {letter === "T" || letter === "R" ? "他" : "她"}看：{text}
                  </p>
                </div>
              </article>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function TrustScene({ active }: { active: boolean }) {
  return (
    <section className={`trust-section ${active ? "is-entered" : ""}`} id="trust">
      <div className="trust-heading">
        <span className="section-tag">01 / 拆 · 多模态鉴伪</span>
        <h2><span>认识你的 AI</span><span>信任顾问团队</span></h2>
        <p>从四种信号，读懂一条种草笔记</p>
      </div>
      <svg aria-hidden="true" className="trust-split-lines" preserveAspectRatio="none" viewBox="0 0 1200 100">
        {["M600 0 L110 100", "M600 0 L430 100", "M600 0 L770 100", "M600 0 L1090 100"].map((path, index) => (
          <path d={path} key={path} pathLength="1" style={{ "--line-index": index } as React.CSSProperties} />
        ))}
      </svg>
      <TrustMarquee />
    </section>
  );
}

function HowNarrative({ onStart }: { onStart: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRefs = useRef<Array<HTMLDivElement | null>>([]);
  const frameRef = useRef(0);
  const targetProgressRef = useRef(0);
  const displayProgressRef = useRef(0);
  const previousSceneRef = useRef(0);
  const previousStageVisibleRef = useRef(false);
  const [activeScene, setActiveScene] = useState(0);
  const [stageVisible, setStageVisible] = useState(false);
  const [linearMode, setLinearMode] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [visibleScenes, setVisibleScenes] = useState<Set<number>>(new Set([0]));
  const [replayKeys, setReplayKeys] = useState([1, 0, 0, 0]);

  useEffect(() => {
    const mobileQuery = window.matchMedia("(max-width: 899px)");
    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updateMode = () => {
      setLinearMode(mobileQuery.matches || motionQuery.matches);
      setReducedMotion(motionQuery.matches);
    };
    updateMode();
    mobileQuery.addEventListener("change", updateMode);
    motionQuery.addEventListener("change", updateMode);
    return () => {
      mobileQuery.removeEventListener("change", updateMode);
      motionQuery.removeEventListener("change", updateMode);
    };
  }, []);

  useEffect(() => {
    if (linearMode) return;
    const container = containerRef.current;
    if (!container) return;

    // Scroll only sets a target; the rendered progress eases toward it each frame,
    // so coarse wheel steps still cross-fade instead of jumping between scenes.
    const render = (progress: number) => {
      sceneRefs.current.forEach((scene, index) => {
        if (!scene) return;
        const { opacity, translateY } = howScenePresentation(index, progress);
        scene.style.opacity = opacity.toFixed(3);
        scene.style.transform = `translate3d(0,${translateY.toFixed(2)}px,0)`;
        scene.style.visibility = opacity > 0.01 ? "visible" : "hidden";
      });
      const sceneIndex = howSceneIndexAt(progress);
      const range = HOW_SCENE_RANGES[sceneIndex];
      container.style.setProperty("--how-progress", progress.toFixed(4));
      container.style.setProperty("--how-scene-progress", Math.min(1, Math.max(0, (progress - range.start) / (range.end - range.start))).toFixed(4));
      if (sceneIndex !== previousSceneRef.current) {
        previousSceneRef.current = sceneIndex;
        setActiveScene(sceneIndex);
        setReplayKeys((keys) => keys.map((key, index) => index === sceneIndex ? key + 1 : key));
      }
    };

    const tick = () => {
      frameRef.current = 0;
      const target = targetProgressRef.current;
      const current = displayProgressRef.current;
      const next = Math.abs(target - current) < 0.0004 ? target : current + (target - current) * 0.16;
      displayProgressRef.current = next;
      render(next);
      if (next !== target) frameRef.current = window.requestAnimationFrame(tick);
    };

    const measure = () => {
      const bounds = container.getBoundingClientRect();
      const distance = Math.max(1, container.offsetHeight - window.innerHeight);
      targetProgressRef.current = Math.min(1, Math.max(0, -bounds.top / distance));
      const nextStageVisible = bounds.top < window.innerHeight * 0.65 && bounds.bottom > window.innerHeight * 0.35;
      setStageVisible(nextStageVisible);
      if (nextStageVisible && !previousStageVisibleRef.current) {
        const sceneIndex = howSceneIndexAt(displayProgressRef.current);
        setReplayKeys((keys) => keys.map((key, index) => index === sceneIndex ? key + 1 : key));
      }
      previousStageVisibleRef.current = nextStageVisible;
      if (!frameRef.current) frameRef.current = window.requestAnimationFrame(tick);
    };

    measure();
    displayProgressRef.current = targetProgressRef.current;
    render(displayProgressRef.current);
    window.addEventListener("scroll", measure, { passive: true });
    window.addEventListener("resize", measure);
    return () => {
      window.cancelAnimationFrame(frameRef.current);
      frameRef.current = 0;
      window.removeEventListener("scroll", measure);
      window.removeEventListener("resize", measure);
      container.style.removeProperty("--how-progress");
      container.style.removeProperty("--how-scene-progress");
      sceneRefs.current.forEach((scene) => {
        if (!scene) return;
        scene.style.removeProperty("opacity");
        scene.style.removeProperty("transform");
        scene.style.removeProperty("visibility");
      });
    };
  }, [linearMode]);

  useEffect(() => {
    if (!linearMode || reducedMotion) {
      if (reducedMotion) setVisibleScenes(new Set([0, 1, 2, 3]));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const index = Number((entry.target as HTMLElement).dataset.scene);
        setVisibleScenes((current) => {
          const next = new Set(current);
          if (entry.isIntersecting) next.add(index);
          else next.delete(index);
          return next;
        });
        if (entry.isIntersecting) {
          setActiveScene(index);
          setReplayKeys((keys) => keys.map((key, sceneIndex) => sceneIndex === index ? key + 1 : key));
        }
      });
    }, { threshold: 0.18 });
    sceneRefs.current.forEach((scene) => scene && observer.observe(scene));
    return () => observer.disconnect();
  }, [linearMode, reducedMotion]);

  const scrollToScene = (index: number) => {
    const container = containerRef.current;
    if (!container || linearMode) {
      document.getElementById(HOW_SCENE_RANGES[index].id)?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth" });
      return;
    }
    const top = window.scrollY + container.getBoundingClientRect().top;
    const distance = container.offsetHeight - window.innerHeight;
    const range = HOW_SCENE_RANGES[index];
    const settle = index === 0 ? 0 : HOW_FADE + 0.01;
    window.scrollTo({ top: top + (range.start + settle) * distance, behavior: "smooth" });
  };

  const activeRange = HOW_SCENE_RANGES[activeScene];
  const narrativeStatus =
    activeScene === 0
      ? "顾问团队已就位"
      : activeScene === 1
        ? "四个维度正在交替取证"
        : activeScene === 2
          ? "证据正在汇合与校准"
          : "一条种草笔记已还原为完整报告";

  const scenes = [
    <TrustScene active={linearMode ? visibleScenes.has(0) : stageVisible && activeScene === 0} />,
    <CheckSection active={linearMode ? visibleScenes.has(1) : stageVisible && activeScene === 1} replayKey={replayKeys[1]} staticMode={linearMode} />,
    <MergeSection active={linearMode ? visibleScenes.has(2) : stageVisible && activeScene === 2} replayKey={replayKeys[2]} staticMode={linearMode} />,
    <ReportSection active={linearMode ? visibleScenes.has(3) : stageVisible && activeScene === 3} onStart={onStart} staticMode={linearMode} />,
  ];

  return (
    <div className={`how-narrative ${linearMode ? "linear" : ""}`} id="how-journey" ref={containerRef}>
      <div className="how-stage">
        {!linearMode && <HowChapterRail activeChapter={activeScene} onSelect={scrollToScene} />}
        {!linearMode && (
          <div aria-live="polite" className="how-story-status">
            <span>{activeRange.number}</span>
            <div><small>TRUST NARRATIVE · {activeRange.label}</small><strong>{narrativeStatus}</strong></div>
            <i><b style={{ transform: "scaleX(var(--how-scene-progress, 0))" }} /></i>
          </div>
        )}
        <div aria-live="polite" className="sr-only">当前：{HOW_SCENE_RANGES[activeScene].number} {HOW_SCENE_RANGES[activeScene].label}</div>
        {scenes.map((scene, index) => {
          const interactive = linearMode || activeScene === index;
          return (
            <div
              aria-hidden={!linearMode && !interactive}
              className={`how-scene ${visibleScenes.has(index) ? "mobile-visible" : ""}`}
              data-scene={index}
              inert={!linearMode && !interactive}
              key={HOW_SCENE_RANGES[index].id}
              ref={(element) => { sceneRefs.current[index] = element; }}
            >
              <div className="how-scene-canvas">{scene}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

type HeroAttachment = {
  id: string;
  name: string;
  kind: "image" | "link";
  preview?: string;
  example?: boolean;
  value?: string;
};

const S_LABEL = "S · 文案真实性";
const HERO_SCENE_DURATION = 4200;

type HeroSceneData = {
  id: string;
  code: string;
  dimension: string;
  chineseName: string;
  englishName: string;
  action: string;
  result: string;
  icon: "search" | "focus" | "comment" | "quote" | "evidence" | "consistency" | "compass";
  visual: "account" | "reality" | "voice" | "copy" | "finale" | "consistency" | "decision";
  callouts: readonly string[];
};

const heroScenes: readonly HeroSceneData[] = [
  {
    id: "account",
    code: "T",
    dimension: "T · 账号可信度",
    chineseName: "账号侦探",
    englishName: "Trustworthiness",
    action: "翻账号底细",
    result: "你只管刷笔记",
    icon: "search",
    visual: "account",
    callouts: ["286 篇历史笔记", "身份信息一致", "推荐密度较高"],
  },
  {
    id: "reality",
    code: "R",
    dimension: "R · 图像原生性",
    chineseName: "视觉取证师",
    englishName: "Reality",
    action: "放大每寸皮肤",
    result: "你只管看对比图",
    icon: "focus",
    visual: "reality",
    callouts: ["局部磨皮痕迹", "光影一致"],
  },
  {
    id: "voice",
    code: "U",
    dimension: "U · 评论自然度",
    chineseName: "口碑观察员",
    englishName: "User Voice",
    action: "揪出复制的好评",
    result: "你只管刷评论",
    icon: "comment",
    visual: "voice",
    callouts: ["姐妹被你种草了！", "12% 评论句式雷同"],
  },
  {
    id: "copy",
    code: "S",
    dimension: S_LABEL,
    chineseName: "文案真实性",
    englishName: "待定",
    action: "核对每句说法",
    result: "你只管读文案",
    icon: "quote",
    visual: "copy",
    callouts: ["坚持7天，皮肤像鸡蛋一样嫩白", "夸大表述"],
  },
  {
    id: "consistency",
    code: "X",
    dimension: "语义一致性校验",
    chineseName: "交叉验证",
    englishName: "Semantic Consistency",
    action: "让四个发现互相对质",
    result: "你只管看哪里不一致",
    icon: "consistency",
    visual: "consistency",
    callouts: ["矛盾", "存疑"],
  },
  {
    id: "decision",
    code: "D",
    dimension: "决策与建议",
    chineseName: "行动建议",
    englishName: "Decision & Advice",
    action: "想好下一步",
    result: "决定，留给你",
    icon: "compass",
    visual: "decision",
    callouts: ["消费者", "创作者", "平台", "品牌方"],
  },
  {
    id: "evidence",
    code: "TL",
    dimension: "TRULENS · 证据模式",
    chineseName: "可信度画像",
    englishName: "Evidence first",
    action: "每个判断，都附证据",
    result: "",
    icon: "evidence",
    visual: "finale",
    callouts: [],
  },
];

function HeroActionIcon({ name }: { name: HeroSceneData["icon"] }) {
  if (name === "search") {
    return <Icon size={28}><circle cx="11" cy="11" r="6" stroke="currentColor" strokeWidth="1.35" /><path d="m16 16 4 4M8 11h6M11 8v6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "focus") {
    return <Icon size={28}><path d="M4 9V5a1 1 0 0 1 1-1h4m6 0h4a1 1 0 0 1 1 1v4m0 6v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4M8 12h8" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "comment") {
    return <Icon size={28}><path d="M5 17.5 3.8 21l4-2.1c1.2.7 2.6 1.1 4.2 1.1 4.9 0 8.8-3.5 8.8-8S16.9 4 12 4s-8.8 3.5-8.8 8c0 2.1.7 4 1.8 5.5Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.35" /><path d="M8 12h8M8 9h5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "quote") {
    return <Icon size={28}><path d="M7.5 8.5H5.7A2.7 2.7 0 0 0 3 11.2V16h5v-5H5.6M17.5 8.5h-1.8a2.7 2.7 0 0 0-2.7 2.7V16h5v-5h-2.4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "consistency") {
    return <Icon size={28}><circle cx="9" cy="12" r="5.5" stroke="currentColor" strokeWidth="1.35" /><circle cx="15" cy="12" r="5.5" stroke="currentColor" strokeWidth="1.35" /></Icon>;
  }
  if (name === "compass") {
    return <Icon size={28}><circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.35" /><path d="m15.5 8.5-2.1 4.9-4.9 2.1 2.1-4.9 4.9-2.1Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.35" /></Icon>;
  }
  return <Sparkle size={28} />;
}

function AccountHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock account-mock">
      <div className="mock-profile-head">
        <span className="mock-profile-avatar"><img alt="" src={roleAvatarByCode.T} /></span>
        <div><b>美妆内容创作者</b><small>虚构主页 · 公开内容样本</small></div>
        <dl><div><dt>18.6k</dt><dd>关注者</dd></div><div><dt>286</dt><dd>历史笔记</dd></div><div><dt>68%</dt><dd>推荐内容</dd></div></dl>
      </div>
      <div className="mock-note-grid">{Array.from({ length: 8 }, (_, index) => <i key={index}><span /></i>)}</div>
      <span className="account-scan-line" />
      <div className="mock-callouts">{scene.callouts.map((label) => <span key={label}>{label}</span>)}</div>
    </div>
  );
}

function RealityHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock reality-mock">
      <div className="skin-panel before"><span>BEFORE</span></div>
      <div className="skin-panel after"><span>AFTER</span></div>
      {scene.callouts.map((label, index) => <div className={`forensic-box box-${index + 1}`} key={label}><span>{label}</span></div>)}
      <div className="reality-meter"><span>纹理保留</span><i><b /></i><strong>71%</strong></div>
    </div>
  );
}

function VoiceHeroScene({ scene }: { scene: HeroSceneData }) {
  const comments = [scene.callouts[0], "质地比想象中清爽", scene.callouts[0], scene.callouts[0], "使用感需要时间观察"];
  return (
    <div className="hero-product-mock voice-mock">
      <div className="comment-title"><span>评论样本</span><small>语义聚类中</small></div>
      <div className="comment-list">{comments.map((comment, index) => <div className={comment === scene.callouts[0] ? "matched" : ""} key={`${comment}-${index}`}><i /><span>{comment}</span><small>{String(index + 2).padStart(2, "0")}</small></div>)}</div>
      <svg aria-hidden="true" className="comment-links" viewBox="0 0 500 300"><path d="M75 67 C410 70 415 165 77 183" /><path d="M78 67 C455 88 455 216 79 223" /></svg>
      <span className="voice-callout">{scene.callouts[1]}</span>
    </div>
  );
}

function CopyHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock copy-mock">
      <div className="copy-document-head"><i /><div><b>一篇待核验的种草笔记</b><small>正文证据分析</small></div></div>
      <div className="copy-lines"><i /><i /><i /></div>
      <p>最近持续记录肤感变化，<mark>{scene.callouts[0]}</mark>，使用前后看起来非常明显。</p>
      <div className="copy-lines lower"><i /><i /></div>
      <span className="copy-callout">{scene.callouts[1]}</span>
    </div>
  );
}

function FinaleHeroScene() {
  return (
    <div className="hero-product-mock finale-mock">
      <span className="finale-trace"><i /><i /><i /><i /></span>
      <small>EVIDENCE BEFORE CONCLUSION</small>
    </div>
  );
}

function ConsistencyHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div aria-hidden="true" className="hero-product-mock consistency-mock">
      <svg className="consistency-network" viewBox="0 0 360 360">
        <line x1="180" x2="285" y1="55" y2="180" />
        <line x1="285" x2="180" y1="180" y2="305" />
        <line x1="180" x2="75" y1="305" y2="180" />
        <line x1="75" x2="180" y1="180" y2="55" />
        <line x1="75" x2="285" y1="180" y2="180" />
        <line x1="180" x2="180" y1="55" y2="305" />
        {[
          ["T", 180, 55],
          ["R", 285, 180],
          ["U", 180, 305],
          ["S", 75, 180],
        ].map(([code, x, y]) => <g key={code}><circle cx={x} cy={y} r="27" /><text textAnchor="middle" x={x} y={Number(y) + 5}>{code}</text></g>)}
        <circle className="network-junction" cx="180" cy="180" r="10" />
      </svg>
      <div className="consistency-compare-card compare-left">
        <span>{scene.callouts[0]}</span>
        <div><i /><i /><i /></div>
        <div><i /><i /></div>
      </div>
      <div className="consistency-compare-card compare-right">
        <span>{scene.callouts[1]}</span>
        <div><i /><i /></div>
        <div><i /><i /><i /></div>
      </div>
    </div>
  );
}

function DecisionHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div aria-hidden="true" className="hero-product-mock decision-mock">
      <div className="decision-ladder-mock">
        <span className="ladder-pass"><i />放行 · 轻提示</span>
        <span className="ladder-verify active"><i />提示 · 补充核验</span>
        <span className="ladder-review"><i />人工复核 · 处置</span>
      </div>
      <div className="decision-advice-mock">
        <div className="decision-role-tags">{scene.callouts.map((role, index) => <span className={index === 0 ? "active" : ""} key={role}>{role}</span>)}</div>
        <div className="decision-blurred-lines"><i /><i /><i /><i /></div>
      </div>
    </div>
  );
}

function HeroSceneVisual({ scene }: { scene: HeroSceneData }) {
  if (scene.visual === "account") return <AccountHeroScene scene={scene} />;
  if (scene.visual === "reality") return <RealityHeroScene scene={scene} />;
  if (scene.visual === "voice") return <VoiceHeroScene scene={scene} />;
  if (scene.visual === "copy") return <CopyHeroScene scene={scene} />;
  if (scene.visual === "consistency") return <ConsistencyHeroScene scene={scene} />;
  if (scene.visual === "decision") return <DecisionHeroScene scene={scene} />;
  return <FinaleHeroScene />;
}

/** Idle placeholder typed out by the landing hero composer. */
const HERO_DEMO_PHRASE = "这篇种草笔记可信吗？";

function HeroComposer({
  onSubmit,
  onEngagedChange,
  expanded,
}: {
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
  onEngagedChange: (engaged: boolean) => void;
  expanded: boolean;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const idleTimerRef = useRef<number | null>(null);
  const objectUrlsRef = useRef<string[]>([]);
  const [value, setValue] = useState("");
  const [attachments, setAttachments] = useState<HeroAttachment[]>([]);
  const [interacted, setInteracted] = useState(false);
  const [focused, setFocused] = useState(false);
  const [demoText, setDemoText] = useState("");
  const [dragging, setDragging] = useState(false);
  const [shaking, setShaking] = useState(false);
  const reducedMotion = Boolean(useReducedMotion());
  const idleDemo = !interacted && !focused && !value && attachments.length === 0;
  const canSubmit = Boolean(value.trim() || attachments.length);

  useEffect(() => () => {
    objectUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
    if (idleTimerRef.current) window.clearTimeout(idleTimerRef.current);
  }, []);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(textarea.scrollHeight, 174)}px`;
    textarea.style.overflowY = textarea.scrollHeight > 174 ? "auto" : "hidden";
  }, [value]);

  useEffect(() => {
    if (!idleDemo) {
      setDemoText("");
      return;
    }
    if (reducedMotion) {
      // No typewriter effect: show the finished phrase immediately.
      setDemoText(HERO_DEMO_PHRASE);
      return;
    }
    let cancelled = false;
    const wait = (duration: number) => new Promise((resolve) => window.setTimeout(resolve, duration));
    const run = async () => {
      while (!cancelled) {
        const phrase = HERO_DEMO_PHRASE;
        for (let index = 1; index <= phrase.length && !cancelled; index += 1) {
          setDemoText(phrase.slice(0, index));
          await wait(90);
        }
        await wait(1800);
        for (let index = phrase.length - 1; index >= 0 && !cancelled; index -= 1) {
          setDemoText(phrase.slice(0, index));
          await wait(35);
        }
      }
    };
    run();
    return () => { cancelled = true; };
  }, [idleDemo, reducedMotion]);

  const activate = () => {
    if (idleTimerRef.current) window.clearTimeout(idleTimerRef.current);
    setInteracted(true);
    setDemoText("");
    onEngagedChange(true);
  };

  const addFiles = (files: File[]) => {
    const images = files.filter((file) => file.type.startsWith("image/"));
    if (!images.length) return;
    activate();
    setAttachments((current) => [
      ...current,
      ...images.map((file) => {
        const preview = URL.createObjectURL(file);
        objectUrlsRef.current.push(preview);
        return { id: `${file.name}-${file.lastModified}-${Math.random()}`, name: file.name, kind: "image" as const, preview };
      }),
    ]);
  };

  const removeAttachment = (id: string) => {
    setAttachments((current) => {
      const target = current.find((item) => item.id === id);
      if (target?.preview?.startsWith("blob:")) URL.revokeObjectURL(target.preview);
      return current.filter((item) => item.id !== id);
    });
  };

  const addLink = (url: string) => {
    activate();
    setAttachments((current) => [
      ...current,
      { id: `link-${Date.now()}`, name: url.length > 30 ? `${url.slice(0, 30)}…` : url, kind: "link", value: url },
    ]);
  };

  const submit = () => {
    if (!canSubmit) {
      setShaking(false);
      window.requestAnimationFrame(() => setShaking(true));
      window.setTimeout(() => setShaking(false), 240);
      activate();
      textareaRef.current?.focus();
      return;
    }
    const link = attachments.find((attachment) => attachment.kind === "link");
    const writtenPrompt = value.trim();
    const linkValue = link?.value ?? link?.name;
    const prompt = writtenPrompt
      ? `${writtenPrompt}${linkValue ? `\n链接：${linkValue}` : ""}`
      : (linkValue ? `请帮我鉴别这个链接：${linkValue}` : "请帮我鉴别我上传的美妆种草内容");
    const filename = attachments.find((attachment) => attachment.kind === "image")?.name ?? "";
    onSubmit(prompt, filename, attachments.some((attachment) => attachment.example));
  };

  return (
    <div className={`hero-composer-wrap ${expanded ? "expanded" : ""}`}>
      <div
        className={`hero-composer ${focused ? "focused" : ""} ${dragging ? "dragging" : ""} ${shaking ? "shake" : ""}`}
        onDragEnter={(event) => {
          event.preventDefault();
          activate();
          setDragging(true);
        }}
        onDragLeave={(event) => {
          if (!event.currentTarget.contains(event.relatedTarget as Node)) setDragging(false);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          addFiles(Array.from(event.dataTransfer.files));
        }}
      >
        {dragging && <div className="hero-drop-overlay">松开以添加截图</div>}
        {attachments.length > 0 && (
          <div className="hero-attachments">
            {attachments.map((attachment) => (
              <span className="hero-attachment" key={attachment.id}>
                {attachment.kind === "image" ? (
                  <img alt="" src={attachment.preview} />
                ) : (
                  <i><Icon size={14}><path d="M10 13a4 4 0 0 0 5.7.1l2.4-2.4A4 4 0 0 0 12.4 5l-1.3 1.3M14 11a4 4 0 0 0-5.7-.1l-2.4 2.4A4 4 0 0 0 11.6 19l1.3-1.3" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" /></Icon></i>
                )}
                <b>{attachment.name}</b>
                {attachment.example && <em>示例</em>}
                <button aria-label="移除附件" onClick={() => removeAttachment(attachment.id)}>×</button>
              </span>
            ))}
          </div>
        )}
        <div className="hero-composer-tools">
          <div className="hero-textarea-shell">
            {idleDemo && <span aria-hidden="true" className="hero-demo-placeholder">{demoText}<i /></span>}
            <textarea
              aria-label="输入你想鉴别的种草内容"
              id="hero-trust-input"
              onBlur={() => {
                setFocused(false);
                if (!value && attachments.length === 0) {
                  idleTimerRef.current = window.setTimeout(() => {
                    setInteracted(false);
                    onEngagedChange(false);
                  }, 4000);
                }
              }}
              onChange={(event) => {
                activate();
                setValue(event.target.value);
              }}
              onFocus={() => {
                activate();
                setFocused(true);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  submit();
                }
              }}
              onPaste={(event) => {
                const pastedText = event.clipboardData.getData("text").trim();
                const imageFiles = Array.from(event.clipboardData.files).filter((file) => file.type.startsWith("image/"));
                if (imageFiles.length) {
                  event.preventDefault();
                  addFiles(imageFiles);
                } else if (/^https?:\/\//i.test(pastedText)) {
                  event.preventDefault();
                  addLink(pastedText);
                }
              }}
              ref={textareaRef}
              rows={1}
              value={value}
            />
          </div>
          <button
            aria-disabled={!canSubmit}
            aria-label="开始鉴别"
            className={`hero-send-button ${canSubmit ? "" : "disabled"}`}
            onClick={submit}
          >
            <Icon size={21}><path d="M12 19V5m0 0L7 10m5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7" /></Icon>
          </button>
        </div>
      </div>
      <p className="hero-promises hero-sequence-6">
        <span>每个判断都附证据</span><i /><span>数据不足时不硬判</span><i /><span>你可以反驳</span>
      </p>
    </div>
  );
}

const landingNavigation = [
  { id: "how-journey", label: "产品介绍" },
  { id: "why-trust", label: "Why Trust Us" },
  { id: "who-uses", label: "谁在用" },
  { id: "learn", label: "美妆鉴别指南" },
  { id: "faq", label: "FAQ" },
] as const;

function LandingNavigation({ onStart, onTeam }: { onStart: () => void; onTeam: () => void }) {
  // Annotated with the full union: `landingNavigation` is `as const`, so
  // inferring from `[0].id` would pin the state to the literal "how-journey"
  // and reject every other section id.
  type SectionId = (typeof landingNavigation)[number]["id"];
  const [activeSection, setActiveSection] = useState<SectionId>(landingNavigation[0].id);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const updateActiveSection = () => {
      const marker = window.scrollY + 140;
      // Annotated so the later `active = item.id` (the full union) is allowed.
      let active: SectionId = landingNavigation[0].id;
      landingNavigation.forEach((item) => {
        const section = document.getElementById(item.id);
        if (section && section.offsetTop <= marker) active = item.id;
      });
      setActiveSection(active);
    };
    updateActiveSection();
    window.addEventListener("scroll", updateActiveSection, { passive: true });
    window.addEventListener("resize", updateActiveSection);
    return () => {
      window.removeEventListener("scroll", updateActiveSection);
      window.removeEventListener("resize", updateActiveSection);
    };
  }, []);

  const goToSection = (id: (typeof landingNavigation)[number]["id"]) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      block: "start",
    });
    setActiveSection(id);
    setMenuOpen(false);
  };

  return (
    <nav aria-label="主要导航" className="home-nav cinematic-nav landing-navigation">
      <button className="logo landing-brand" onClick={() => window.scrollTo({ top: 0 })}>
        <img alt="TruLens" src="/trulens-nav-logo.png" />
      </button>
      <div className="landing-nav-desktop">
        <div className="landing-nav-links">
          {landingNavigation.map((item) => (
            <button
              aria-current={activeSection === item.id ? "page" : undefined}
              className={activeSection === item.id ? "active" : ""}
              key={item.id}
              onClick={() => goToSection(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>
        <button className="landing-team-entry" onClick={onTeam}>团队版</button>
        <button className="landing-nav-cta" onClick={onStart}>开始核验 <span>↗</span></button>
      </div>
      <div className="landing-nav-mobile">
        <button className="landing-nav-mobile-cta" onClick={onStart}>开始核验 <span>↗</span></button>
        <button
          aria-expanded={menuOpen}
          aria-label={menuOpen ? "关闭导航菜单" : "打开导航菜单"}
          className={`landing-menu-toggle ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <i /><i />
        </button>
      </div>
      {menuOpen && (
        <div className="landing-mobile-menu">
          {landingNavigation.map((item) => (
            <button
              aria-current={activeSection === item.id ? "page" : undefined}
              className={activeSection === item.id ? "active" : ""}
              key={item.id}
              onClick={() => goToSection(item.id)}
            >
              {item.label}<span>→</span>
            </button>
          ))}
          <button onClick={onTeam}>团队版<span>→</span></button>
        </div>
      )}
    </nav>
  );
}

function TruLensHero({
  onSubmit,
}: {
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
}) {
  const reducedMotion = Boolean(useReducedMotion());
  const elapsedRef = useRef(0);
  const [activeIndex, setActiveIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [composerEngaged, setComposerEngaged] = useState(false);
  const paused = false;
  const activeScene = heroScenes[activeIndex];

  const goToScene = (index: number) => {
    elapsedRef.current = 0;
    setProgress(0);
    setActiveIndex((index + heroScenes.length) % heroScenes.length);
  };

  useEffect(() => {
    let animationFrame = 0;
    let previousTime = performance.now();
    const tick = (time: number) => {
      const delta = time - previousTime;
      previousTime = time;
      if (!paused) {
        elapsedRef.current += delta;
        if (elapsedRef.current >= HERO_SCENE_DURATION) {
          elapsedRef.current = 0;
          setProgress(0);
          setActiveIndex((current) => (current + 1) % heroScenes.length);
        } else {
          setProgress(elapsedRef.current / HERO_SCENE_DURATION);
        }
      }
      animationFrame = window.requestAnimationFrame(tick);
    };
    animationFrame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [paused]);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      if (event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLInputElement) return;
      event.preventDefault();
      elapsedRef.current = 0;
      setProgress(0);
      setActiveIndex((current) => event.key === "ArrowRight"
        ? (current + 1) % heroScenes.length
        : (current - 1 + heroScenes.length) % heroScenes.length);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <section
      aria-label="TruLens 产品能力演示"
      className={`cinematic-hero scene-${activeScene.id} ${composerEngaged ? "composer-engaged" : ""}`}
    >
      <AnimatePresence initial={false}>
        <motion.div
          animate={{ opacity: 1, scale: 1 }}
          className="hero-scene-background"
          exit={{ opacity: 0 }}
          initial={{ opacity: 0, scale: reducedMotion ? 1 : 1.018 }}
          key={activeScene.id}
          transition={{ duration: reducedMotion ? 0.2 : 0.6, ease: [0.22, 0.7, 0.2, 1] }}
        >
          <HeroSceneVisual scene={activeScene} />
        </motion.div>
      </AnimatePresence>
      <div className="cinematic-title-shell">
        <AnimatePresence mode="wait">
          <motion.div
            animate={{ opacity: 1, y: 0 }}
            className={`cinematic-title ${activeScene.visual === "finale" ? "finale-title" : ""}`}
            exit={{ opacity: 0, y: reducedMotion ? 0 : -8 }}
            initial={{ opacity: 0, y: reducedMotion ? 0 : 18 }}
            key={`title-${activeScene.id}`}
            transition={{ duration: reducedMotion ? 0.2 : 0.6, ease: [0.22, 0.7, 0.2, 1] }}
          >
            {activeScene.visual === "finale" ? (
              <h1>{activeScene.action}</h1>
            ) : (
              <h1>
                <span>TruLens 替你</span>
                <em><HeroActionIcon name={activeScene.icon} />{activeScene.action}</em>
                <span>{activeScene.result}</span>
              </h1>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="cinematic-controls">
        <div aria-label="场景进度" className="hero-scene-progress">
          {heroScenes.map((scene, index) => (
            <button
              aria-label={`切换到${scene.dimension}`}
              className={index === activeIndex ? "active" : ""}
              key={scene.id}
              onClick={() => goToScene(index)}
            >
              <i style={{ transform: `scaleX(${index < activeIndex ? 1 : index === activeIndex ? progress : 0})` }} />
            </button>
          ))}
        </div>
        <HeroComposer expanded={activeScene.visual === "finale"} onEngagedChange={setComposerEngaged} onSubmit={onSubmit} />
      </div>
    </section>
  );
}

const whyTrustContent = {
  eyebrow: "WHY TRUST US",
  exampleLabel: "示例数据",
  title: "凭什么，",
  emphasis: "相信我们？",
  subtitle: "TruLens 判断别人是否可信，也用同样的标准要求自己。",
  promises: [
    {
      id: "evidence",
      number: "01",
      label: "证据",
      title: "每个判断都附证据",
      description: "分数背后不是一句'AI 觉得'。每个结论都能点开，看到原始截图、被标出的句子、被框出的区域。",
      conclusion: "图像主体可信，但存在轻度 AI 修饰痕迹",
      signals: [
        { label: "原始信号", tone: "purple" },
        { label: "模型检测", tone: "rose" },
        { label: "评分结论", tone: "green" },
      ],
    },
    {
      id: "restraint",
      number: "02",
      label: "克制",
      title: "数据不足时不硬判",
      description: "只给了文字，就只评文字。没有评论区，就不会假装看过评论区。",
      dimensions: ["T", "R", "U", "S"],
      unavailable: "未提供 · 不计分",
      scoreLabel: "文案真实性",
      score: "78",
      scoreNote: "仅基于 1 个维度",
    },
    {
      id: "appeal",
      number: "03",
      label: "申诉",
      title: "你可以反驳",
      description: "我们也可能看走眼。不同意，就告诉我们理由，TruLens 会结合你的补充再核对一次。",
      userMessage: "这条评论是我真实用过之后写的",
      agentMessage: "已记录你的补充，正在重新核对评论维度……",
    },
  ],
  verification: {
    weights: [
      { code: "T", value: 25 },
      { code: "R", value: 30 },
      { code: "U", value: 20 },
      { code: "S", value: 25 },
    ],
    caption: "评分规则公开",
    sample: "在 {SAMPLE_COUNT} 条自建美妆样本上测试",
    metric: "{METRIC_NAME}：{METRIC_VALUE}",
  },
  backToTop: "回到顶部，试一条笔记 →",
} as const;

type PromiseData = (typeof whyTrustContent.promises)[number];

function EvidencePromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "evidence" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo evidence-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <motion.p animate={{ opacity: 1, y: 0 }} initial={reducedMotion ? false : { opacity: 0, y: 8 }} transition={{ duration: reducedMotion ? 0 : 0.35 }}>
        {data.conclusion}
      </motion.p>
      <div className="evidence-signal-row">
        {data.signals.map((signal, index) => (
          <div className="evidence-signal-step" key={signal.label}>
            {index > 0 && (
              <motion.i
                animate={{ scaleX: 1 }}
                initial={reducedMotion ? false : { scaleX: 0 }}
                transition={{ delay: reducedMotion ? 0 : 0.65 + index * 0.62, duration: reducedMotion ? 0 : 0.38 }}
              />
            )}
            <motion.span
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className={`signal-${signal.tone}`}
              initial={reducedMotion ? false : { opacity: 0, scale: 0.82, y: 7 }}
              transition={{ delay: reducedMotion ? 0 : 0.35 + index * 0.62, duration: reducedMotion ? 0 : 0.42, type: "spring", bounce: 0.22 }}
            >
              <b />{signal.label}
            </motion.span>
          </div>
        ))}
      </div>
    </div>
  );
}

function RestraintPromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "restraint" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo restraint-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <div className="restraint-dimensions">
        {data.dimensions.map((dimension, index) => (
          <motion.span
            animate={dimension === "S" ? { opacity: 1, filter: "grayscale(0)" } : { opacity: 0.32, filter: "grayscale(1)" }}
            className={`restraint-${dimension.toLowerCase()}`}
            initial={reducedMotion || dimension === "S" ? false : { opacity: 1, filter: "grayscale(0)" }}
            key={dimension}
            transition={{ delay: reducedMotion ? 0 : 0.65 + index * 0.58, duration: reducedMotion ? 0 : 0.45 }}
          >
            {dimension}
          </motion.span>
        ))}
      </div>
      <motion.small
        animate={{ opacity: 1, y: 0 }}
        className="unavailable-note"
        initial={reducedMotion ? false : { opacity: 0, y: 5 }}
        transition={{ delay: reducedMotion ? 0 : 2.45, duration: reducedMotion ? 0 : 0.35 }}
      >
        {data.unavailable}
      </motion.small>
      <motion.div
        animate={{ opacity: 1, y: 0 }}
        className="restraint-score"
        initial={reducedMotion ? false : { opacity: 0, y: 8 }}
        transition={{ delay: reducedMotion ? 0 : 2.8, duration: reducedMotion ? 0 : 0.4 }}
      >
        <span>{data.scoreLabel} <strong>{data.score}</strong></span>
        <small>{data.scoreNote}</small>
      </motion.div>
    </div>
  );
}

function AppealPromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "appeal" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo appeal-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <motion.p animate={{ opacity: 1, y: 0 }} className="appeal-user" initial={reducedMotion ? false : { opacity: 0, y: 7 }} transition={{ duration: reducedMotion ? 0 : 0.38 }}>
        {data.userMessage}
      </motion.p>
      <motion.div
        animate={{ opacity: 1, y: 0 }}
        className="appeal-agent"
        initial={reducedMotion ? false : { opacity: 0, y: 7 }}
        transition={{ delay: reducedMotion ? 0 : 0.9, duration: reducedMotion ? 0 : 0.4 }}
      >
        <span>
          <motion.i animate={{ width: "100%" }} initial={reducedMotion ? false : { width: "0%" }} transition={{ delay: reducedMotion ? 0 : 1.25, duration: reducedMotion ? 0 : 1.35, ease: "linear" }}>
            {data.agentMessage}
          </motion.i>
        </span>
        <b>
          <motion.i animate={{ scaleX: 1 }} initial={reducedMotion ? false : { scaleX: 0 }} transition={{ delay: reducedMotion ? 0 : 2.7, duration: reducedMotion ? 0 : 0.95, ease: [0.22, 0.7, 0.2, 1] }} />
        </b>
      </motion.div>
    </div>
  );
}

function PromiseCard({ data }: { data: PromiseData }) {
  const cardRef = useRef<HTMLElement>(null);
  const reducedMotion = Boolean(useReducedMotion());
  const playedRef = useRef(false);
  const [replayKey, setReplayKey] = useState(0);

  useEffect(() => {
    const card = cardRef.current;
    if (!card || reducedMotion) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !playedRef.current) {
        playedRef.current = true;
        setReplayKey((key) => key + 1);
        observer.disconnect();
      }
    }, { threshold: 0.35 });
    observer.observe(card);
    return () => observer.disconnect();
  }, [reducedMotion]);

  const replay = () => {
    if (!reducedMotion) setReplayKey((key) => key + 1);
  };

  return (
    <article
      className="promise-card"
      onClick={replay}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          replay();
        }
      }}
      onMouseEnter={replay}
      ref={cardRef}
      tabIndex={0}
    >
      <span className="promise-card-label"><b>{data.number}</b><i />{data.label}</span>
      {data.id === "evidence" && <EvidencePromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      {data.id === "restraint" && <RestraintPromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      {data.id === "appeal" && <AppealPromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      <div className="promise-card-copy">
        <h3>{data.title}</h3>
        <p>{data.description}</p>
      </div>
    </article>
  );
}

function TrustVerificationBand() {
  const data = whyTrustContent.verification;
  const hasUnfilledPlaceholder = [data.sample, data.metric].some((value) => /\{[A-Z_]+\}/.test(value));
  if (hasUnfilledPlaceholder) return null;
  return (
    <section className="trust-verification-band">
      <div>
        <div className="verification-weights">
          {data.weights.map((weight) => <i className={`weight-${weight.code.toLowerCase()}`} key={weight.code} style={{ flex: weight.value }}>{weight.code} {weight.value}%</i>)}
        </div>
        <small>{data.caption}</small>
      </div>
      <p><span>{data.sample}</span><strong>{data.metric}</strong></p>
    </section>
  );
}

function WhyTrustSection() {
  const scrollToComposer = () => {
    window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
    window.setTimeout(() => document.getElementById("hero-trust-input")?.focus(), 650);
  };

  return (
    <section className="why-trust-section" id="why-trust">
      <div className="why-trust-shell">
        <header className="why-trust-heading">
          <span>{whyTrustContent.eyebrow}</span>
          <h2>{whyTrustContent.title}<em>{whyTrustContent.emphasis}</em></h2>
          <p>{whyTrustContent.subtitle}</p>
        </header>
        <div className="promise-card-grid">
          {whyTrustContent.promises.map((promise) => <PromiseCard data={promise} key={promise.id} />)}
        </div>
        <TrustVerificationBand />
        <button className="why-trust-back" onClick={scrollToComposer}>{whyTrustContent.backToTop}</button>
      </div>
    </section>
  );
}

const learnContent = {
  eyebrow: "LEARN",
  title: "先学四个看法，",
  emphasis: "再试一试",
  subtitle: "这些是线索，不是判决。看得多了，你自己也会有判断。",
  progress: ["四个线索", "动手试试", "你的结果"],
  clueSection: {
    label: "01 · 四个线索",
    intro: "你不需要懂算法。下面这四个地方，值得多看一眼。",
    closing: "这些只是线索。线索越多，越值得认真核对。",
  },
  clues: [
    {
      code: "T",
      title: "看账号",
      points: [
        "翻一翻历史笔记：是不是突然从日常分享转成密集推荐同类产品？",
        "简介和内容是否一致，有没有标注合作？",
        "粉丝涨得快，不代表互动是真的，对一对点赞、收藏和评论的比例。",
      ],
      example: {
        labels: ["周末散步随记", "换季护肤记录", "精华推荐", "面霜推荐", "同类精华推荐"],
        note: "短时间内连续推荐",
      },
    },
    {
      code: "R",
      title: "看图片",
      points: [
        "对比图里，前后两张的光线方向、角度、背景是否一致？",
        "皮肤的毛孔和细纹是不是在某一侧突然变得特别光滑？",
        "看边缘：发际线、下颌线有没有涂抹或扭曲的痕迹。",
      ],
      reminder: "滤镜和轻度修饰很常见，不等于造假。关键是效果对比是否被刻意放大。",
      example: {
        labels: ["局部过于光滑", "光影方向不一致"],
      },
    },
    {
      code: "U",
      title: "看评论",
      points: [
        "有没有大量几乎一样的句式？",
        "发布时间是不是扎堆？",
        "只有夸奖，没有具体使用细节（用了多久、什么肤质、有没有缺点）的评论，要多留意。",
      ],
      example: {
        comments: ["姐妹被你种草了！", "真的被种草了姐妹！", "已经下单，被你种草了", "用了两周，眼周稍干", "敏感肌试用后没有刺痛"],
      },
    },
    {
      code: "S",
      title: "看文案",
      points: [
        "当心绝对化的说法：“一周变白”“彻底解决”“闭眼冲”。",
        "有没有写使用周期、使用条件，以及“因人而异”？",
        "功效描述和成分、价位是否对得上？",
      ],
      example: {
        text: "这款精华质地清爽，坚持7天，皮肤像鸡蛋一样嫩白，姐妹们闭眼冲。",
        highlight: "坚持7天，皮肤像鸡蛋一样嫩白",
        note: "夸大表述",
      },
    },
  ],
  quizSection: {
    label: "02 · 你现在可以分辨吗？",
    title: "你现在可以分辨吗？",
    description: "不用选真假。点出你觉得可疑的地方，我们再告诉你那里有什么。",
    reveal: "看看答案",
    retry: "再试一次",
    next: "下一题",
    found: "你找到了 {FOUND} / {TOTAL} 处线索",
  },
  rounds: [
    {
      id: "copy",
      label: "回合 1 · 文案",
      kind: "text",
      items: [
        { text: "作为敏感肌，我最近在找一款保湿精华。", suspicious: false, explanation: "" },
        { text: "用了这瓶一周，皮肤状态直接提升一个 level。", suspicious: true, explanation: "“直接提升一个 level”没有说明周期、使用条件和个体差异。" },
        { text: "质地偏清爽，我会薄涂两层，冬天可能还要叠一层面霜。", suspicious: false, explanation: "" },
        { text: "坚持 7 天，皮肤像鸡蛋一样嫩白，姐妹们闭眼冲！", suspicious: true, explanation: "“7 天变白”“闭眼冲”属于绝对化、催促式说法。" },
      ],
    },
    {
      id: "comments",
      label: "回合 2 · 评论",
      kind: "comments",
      items: [
        { text: "姐妹被你种草了！", suspicious: true, explanation: "句式雷同、缺少使用细节。" },
        { text: "已经买第三瓶！", suspicious: true, explanation: "句式简短，缺少具体使用信息。" },
        { text: "用了两周，T 区出油少了，但眼周有点干，我会换成薄涂。", suspicious: false, explanation: "含具体使用细节，更像真实互动。" },
        { text: "被你种草了姐妹！", suspicious: true, explanation: "与第 1 条几乎同一句式。" },
        { text: "同敏感肌，我拿去试了一小块，没有刺痛，会再观察一周。", suspicious: false, explanation: "含具体使用细节，更像真实互动。" },
        { text: "想问下有没有色号推荐？", suspicious: false, explanation: "提问型评论，更像真实互动。" },
      ],
      answerNote: "第 1、2、4 条句式雷同、缺少使用细节；另外三条含具体使用细节或提问。",
    },
    {
      id: "image",
      label: "回合 3 · 图片",
      kind: "image",
      image: {
        src: "/evidence/skin-comparison.jpg",
        alt: "虚构的护肤前后对比图",
      },
      samples: ["使用前", "使用后"],
      items: [
        { text: "右侧脸颊纹理", suspicious: true, explanation: "右侧脸颊纹理过于光滑。", x: 72, y: 45 },
        { text: "两张图的光线方向", suspicious: true, explanation: "前后两张图的光线方向不一致。", x: 49, y: 24 },
        { text: "背景色调", suspicious: true, explanation: "前后背景色调有轻微偏移。", x: 55, y: 76 },
      ],
    },
  ],
  result: {
    label: "03 · 你的结果",
    title: "你找到了 {FOUND} / 8 条线索",
    bands: [
      { min: 6, text: "眼力不错。不过人眼也会累、会漏。" },
      { min: 3, text: "有一些门道已经看出来了。剩下的线索，值得再看一遍。" },
      { min: 0, text: "这些线索确实不容易一眼看出来，这很正常。" },
    ],
    summary: "就算是认真看，人眼也不总是可靠。示例统计称，66% 的消费者自信能识别 AI 生成的图片，但实测中 57% 判断出错；正式发布前仍需核对原始调查口径。",
    source: "示例统计 · 发布前需核验原始报告",
    sourceCheck: "",
    prompt: "现在，把一条真实的种草笔记交给 TruLens。",
    primary: "用 TruLens 检查一条笔记 →",
    reset: "再玩一次",
  },
  footer: "TruLens · 示例内容均为自造样本，不涉及真实账号与真人。",
  exampleLabel: "示例数据",
} as const;

type LearnClue = (typeof learnContent.clues)[number];
type LearnRound = (typeof learnContent.rounds)[number];

function LearnClueExample({ clue }: { clue: LearnClue }) {
  if (clue.code === "T") {
    return (
      <div className="learn-account-example">
        {clue.example.labels.map((label, index) => <span className={index > 1 ? "dense" : ""} key={label}>{label}</span>)}
        <small>{clue.example.note}</small>
      </div>
    );
  }
  if (clue.code === "R") {
    return (
      <div className="learn-image-example">
        <div><span>BEFORE</span></div><div><span>AFTER</span></div>
        {clue.example.labels.map((label, index) => <i className={`learn-image-callout callout-${index + 1}`} key={label}>{label}</i>)}
        <small>{learnContent.exampleLabel}</small>
      </div>
    );
  }
  if (clue.code === "U") {
    return (
      <div className="learn-comment-example">
        {clue.example.comments.map((comment, index) => <span className={index < 3 ? "similar" : ""} key={comment}>{comment}</span>)}
        <svg aria-hidden="true" viewBox="0 0 420 150"><path d="M15 19 C380 25 380 62 15 68 C380 72 380 108 15 116" /></svg>
      </div>
    );
  }
  const parts = clue.example.text.split(clue.example.highlight);
  return (
    <div className="learn-copy-example">
      <p>{parts[0]}<mark>{clue.example.highlight}</mark>{parts[1]}</p>
      <small>{clue.example.note}</small>
    </div>
  );
}

function LearnClueCard({ clue, index }: { clue: LearnClue; index: number }) {
  const reducedMotion = Boolean(useReducedMotion());
  return (
    <motion.article
      className={`learn-clue-card clue-${clue.code.toLowerCase()}`}
      initial={reducedMotion ? false : { opacity: 0, y: 14 }}
      transition={{ duration: reducedMotion ? 0 : 0.5, delay: reducedMotion ? 0 : index * 0.04 }}
      viewport={{ amount: 0.2, once: true }}
      whileInView={{ opacity: 1, y: 0 }}
    >
      <header><span>{clue.code}</span><h3>{clue.title}</h3></header>
      <ul>{clue.points.map((point) => <li key={point}>{point}</li>)}</ul>
      {"reminder" in clue && <p className="learn-reminder">{clue.reminder}</p>}
      <LearnClueExample clue={clue} />
    </motion.article>
  );
}

function QuizRound({
  focusOnMount = false,
  index,
  nextLabel = learnContent.quizSection.next,
  onComplete,
  onNext,
  resetKey,
  round,
}: {
  focusOnMount?: boolean;
  index: number;
  nextLabel?: string;
  onComplete: (index: number, score: number | null) => void;
  onNext: () => void;
  resetKey: number;
  round: LearnRound;
}) {
  const headerRef = useRef<HTMLElement>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [revealed, setRevealed] = useState(false);
  const total = round.items.filter((item) => item.suspicious).length;
  const found = round.items.filter((item, itemIndex) => item.suspicious && selected.has(itemIndex)).length;

  useEffect(() => {
    setSelected(new Set());
    setRevealed(false);
  }, [resetKey]);

  useEffect(() => {
    if (focusOnMount) headerRef.current?.focus({ preventScroll: true });
  }, []);

  const toggle = (itemIndex: number) => {
    if (revealed) return;
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(itemIndex)) next.delete(itemIndex);
      else next.add(itemIndex);
      return next;
    });
  };

  const reveal = () => {
    setRevealed(true);
    onComplete(index, found);
  };

  const itemClass = (item: LearnRound["items"][number], itemIndex: number) => [
    selected.has(itemIndex) ? "selected" : "",
    revealed && item.suspicious ? "answer" : "",
    revealed && item.suspicious && !selected.has(itemIndex) ? "missed" : "",
  ].filter(Boolean).join(" ");

  return (
    <article className={`learn-quiz-round round-${round.kind}`}>
      <header ref={headerRef} tabIndex={-1}><span>{round.label}</span><small>{index + 1} / {learnContent.rounds.length}</small></header>
      <div className="round-progress">{learnContent.rounds.map((item, dotIndex) => <i className={dotIndex <= index ? "active" : ""} key={item.id} />)}</div>
      {round.kind === "image" ? (
        <div className="quiz-image-sample">
          {round.samples.map((label, sampleIndex) => (
            <div className={`sample-${sampleIndex}`} key={label}>
              <img alt={`${round.image.alt} · ${label}`} src={round.image.src} />
              <span>{label}</span>
              <small>虚构样本</small>
            </div>
          ))}
          {round.items.map((item, itemIndex) => (
            <button
              aria-label={`选择图片线索：${item.text}`}
              aria-pressed={selected.has(itemIndex)}
              className={itemClass(item, itemIndex)}
              key={item.text}
              onClick={() => toggle(itemIndex)}
              style={{ left: `${item.x}%`, top: `${item.y}%` }}
            >
              <i /><span>{revealed ? item.explanation : item.text}</span>
            </button>
          ))}
        </div>
      ) : (
        <div className={`quiz-select-list ${round.kind === "comments" ? "comment-select-list" : ""}`}>
          {round.items.map((item, itemIndex) => (
            <button
              aria-label={`选择${round.kind === "comments" ? "评论" : "句子"}：${item.text}`}
              aria-pressed={selected.has(itemIndex)}
              className={itemClass(item, itemIndex)}
              key={item.text}
              onClick={() => toggle(itemIndex)}
            >
              <span>{item.text}</span>
              {revealed && item.suspicious && <small>{item.explanation}</small>}
            </button>
          ))}
          {round.kind === "comments" && revealed && (
            <svg aria-hidden="true" className="quiz-comment-curve" viewBox="0 0 500 300"><path d="M18 30 C470 35 470 85 18 91 C470 96 470 190 18 194" /></svg>
          )}
        </div>
      )}
      {revealed && (
        <div aria-live="polite" className="round-answer">
          <strong>{learnContent.quizSection.found.replace("{FOUND}", String(found)).replace("{TOTAL}", String(total))}</strong>
          {"answerNote" in round && <p>{round.answerNote}</p>}
        </div>
      )}
      <footer>
        {!revealed ? (
          <button className="round-reveal" onClick={reveal}>{learnContent.quizSection.reveal}</button>
        ) : (
          <>
            <button onClick={() => { setSelected(new Set()); setRevealed(false); onComplete(index, null); }}>{learnContent.quizSection.retry}</button>
            <button className="round-next" onClick={onNext}>{nextLabel}</button>
          </>
        )}
      </footer>
    </article>
  );
}

function LearnResult({
  focusOnMount = false,
  found,
  onReset,
}: {
  focusOnMount?: boolean;
  found: number;
  onReset: () => void;
}) {
  const reducedMotion = Boolean(useReducedMotion());
  const titleRef = useRef<HTMLElement>(null);
  useEffect(() => {
    if (focusOnMount) titleRef.current?.focus({ preventScroll: true });
  }, []);
  const resultText = learnContent.result.bands.find((band) => found >= band.min)?.text ?? learnContent.result.bands[2].text;
  const scrollToComposer = () => {
    window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
    window.setTimeout(() => document.getElementById("hero-trust-input")?.focus(), reducedMotion ? 0 : 650);
  };
  return (
    <motion.section
      animate={{ opacity: 1, y: 0 }}
      className="learn-result"
      initial={reducedMotion ? false : { opacity: 0, y: 18 }}
      transition={{ duration: reducedMotion ? 0 : 0.5 }}
    >
      <span>{learnContent.result.label}</span>
      <strong ref={titleRef} tabIndex={-1}>{learnContent.result.title.replace("{FOUND}", String(found))}</strong>
      <h3>{resultText}</h3>
      <p>{learnContent.result.summary}</p>
      <small>{learnContent.result.source}</small>
      {learnContent.result.sourceCheck && <i aria-hidden="true">{learnContent.result.sourceCheck}</i>}
      <b>{learnContent.result.prompt}</b>
      <button className="learn-result-primary" onClick={scrollToComposer}>{learnContent.result.primary}</button>
      <button className="learn-result-reset" onClick={onReset}>{learnContent.result.reset}</button>
    </motion.section>
  );
}

function LearnSection() {
  const cluesRef = useRef<HTMLElement>(null);
  const quizRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const reducedMotion = Boolean(useReducedMotion());
  const [progress, setProgress] = useState(0);
  // 0–2: the round on screen; RESULT_STEP: the summary. Rounds swap in place, one at a time.
  const RESULT_STEP = learnContent.rounds.length;
  const [currentRound, setCurrentRound] = useState(0);
  const [interacted, setInteracted] = useState(false);
  const [stageMinHeight, setStageMinHeight] = useState(0);
  const [scores, setScores] = useState<Array<number | null>>([null, null, null]);
  const [resetKey, setResetKey] = useState(0);
  const complete = scores.every((score) => score !== null);
  const found = scores.reduce<number>((sum, score) => sum + (score ?? 0), 0);

  // The clues and the quiz now sit in the normal page flow, so progress follows the page scroll.
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const line = window.innerHeight * 0.45;
      const quizTop = quizRef.current?.getBoundingClientRect().top ?? Infinity;
      setProgress(quizTop < line ? (currentRound === RESULT_STEP ? 2 : 1) : 0);
    };
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [currentRound]);

  // The stage only grows (tallest round / answer seen so far), so swapping rounds never
  // makes the card snap shorter. Re-measured from scratch when the width changes.
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    let width = stage.offsetWidth;
    const observer = new ResizeObserver(() => {
      const content = stage.firstElementChild as HTMLElement | null;
      if (!content) return;
      const widthChanged = stage.offsetWidth !== width;
      width = stage.offsetWidth;
      setStageMinHeight((current) => (widthChanged ? content.offsetHeight : Math.max(current, content.offsetHeight)));
    });
    const observeContent = () => {
      observer.disconnect();
      observer.observe(stage);
      if (stage.firstElementChild) observer.observe(stage.firstElementChild);
    };
    observeContent();
    const mutation = new MutationObserver(observeContent);
    mutation.observe(stage, { childList: true });
    return () => {
      observer.disconnect();
      mutation.disconnect();
    };
  }, []);

  const goToStep = (step: number) => {
    setInteracted(true);
    setCurrentRound(step);
  };

  const scrollToBlock = (element: HTMLElement | null) => {
    if (!element) return;
    window.scrollTo({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      top: element.getBoundingClientRect().top + window.scrollY - 96,
    });
  };

  const resetAll = () => {
    setScores([null, null, null]);
    setResetKey((key) => key + 1);
    goToStep(0);
  };

  return (
    <section className="learn-section" id="learn">
      <div className="learn-layout">
        <aside className="learn-intro">
          <span>{learnContent.eyebrow}</span>
          <h2>{learnContent.title}<em>{learnContent.emphasis}</em></h2>
          <p>{learnContent.subtitle}</p>
          <nav aria-label="学习进度">
            {learnContent.progress.map((label, index) => (
              <button className={progress === index ? "active" : progress > index ? "complete" : ""} key={label} onClick={() => {
                if (index === 0) scrollToBlock(cluesRef.current);
                if (index === 1) scrollToBlock(quizRef.current);
                if (index === 2 && complete) {
                  goToStep(RESULT_STEP);
                  scrollToBlock(quizRef.current);
                }
              }}>
                <i /><span>{label}</span>
              </button>
            ))}
          </nav>
        </aside>
        <div className="learn-card-wrap">
          <div className="learn-scroll-card">
            <div className="learn-card-content">
              <section className="learn-clues" ref={cluesRef}>
                <span className="learn-section-label">{learnContent.clueSection.label}</span>
                <p className="learn-section-intro">{learnContent.clueSection.intro}</p>
                <div className="learn-clue-list">
                  {learnContent.clues.map((clue, index) => <LearnClueCard clue={clue} index={index} key={clue.code} />)}
                </div>
                <p className="learn-clue-closing">{learnContent.clueSection.closing}</p>
              </section>
              <section className="learn-quiz" ref={quizRef}>
                <span className="learn-section-label">{learnContent.quizSection.label}</span>
                <h2>{learnContent.quizSection.title}</h2>
                <p>{learnContent.quizSection.description}</p>
                <div
                  className="learn-round-stage"
                  ref={stageRef}
                  style={{ minHeight: stageMinHeight || undefined }}
                >
                  <AnimatePresence initial={false} mode="wait">
                    <motion.div
                      animate={{ opacity: 1, x: 0 }}
                      className="learn-round-slide"
                      exit={reducedMotion ? { opacity: 1 } : { opacity: 0, x: -16 }}
                      initial={reducedMotion ? false : { opacity: 0, x: 16 }}
                      key={currentRound === RESULT_STEP ? `result-${resetKey}` : `round-${currentRound}-${resetKey}`}
                      transition={{ duration: reducedMotion ? 0 : 0.26, ease: [0.22, 0.7, 0.2, 1] }}
                    >
                      {currentRound === RESULT_STEP ? (
                        <LearnResult focusOnMount={interacted} found={found} onReset={resetAll} />
                      ) : (
                        <QuizRound
                          focusOnMount={interacted}
                          index={currentRound}
                          nextLabel={currentRound === learnContent.rounds.length - 1 ? "查看结果" : learnContent.quizSection.next}
                          onComplete={(roundIndex, score) => setScores((current) => current.map((value, scoreIndex) => scoreIndex === roundIndex ? score : value))}
                          onNext={() => {
                            if (currentRound < learnContent.rounds.length - 1) goToStep(currentRound + 1);
                            else if (complete) goToStep(RESULT_STEP);
                          }}
                          resetKey={resetKey}
                          round={learnContent.rounds[currentRound]}
                        />
                      )}
                    </motion.div>
                  </AnimatePresence>
                </div>
              </section>
            </div>
          </div>
          <i className="learn-fade learn-fade-top" /><i className="learn-fade learn-fade-bottom" />
        </div>
      </div>
      <footer className="learn-footer">{learnContent.footer}</footer>
    </section>
  );
}

const faqContent = {
  eyebrow: "QUESTIONS & ANSWERS",
  title: "FAQ",
  subtitle: "关于 TruLens 的使用、结果和边界，这里先把常见问题说清楚。",
  groups: [
    {
      title: "一、它是什么、怎么用",
      items: [
        {
          question: "TruLens 是什么？能帮我做什么？",
          answer: "TruLens 是一个帮你判断美妆种草笔记是否可信的 AI 智能体。你把笔记丢进来，它从账号、图片、评论、文案四个角度看一遍，给你一个可信度分数，并把每个判断的依据摊开给你看。",
        },
        {
          question: "我需要提供什么？只给文字也行吗？",
          answer: "可以提供笔记链接、复制的文字或截图，三种都行，也可以组合着给。你给什么，我们就分析什么。只给文字，就只分析文案。",
        },
      ],
    },
    {
      title: "二、怎么理解结果",
      items: [
        {
          question: "84 分是什么意思？高可信就一定是真的吗？",
          answer: "分数是对这篇笔记在当前可见信息下的可信度评估，不是真伪判决。分数高代表没发现明显问题，但仍可能有值得留意的地方，所以请一并看报告里标出的留意项和每个维度的证据。",
        },
      ],
    },
    {
      title: "三、它的边界",
      items: [
        {
          question: "TruLens 会判错吗？",
          answer: "会。任何自动检测都可能漏掉或误判。所以我们不只给分数，还给证据，数据不足时不硬判，你不同意时也可以反驳。",
        },
        {
          question: "为什么不直接告诉我“真”还是“假”？",
          answer: "因为一个“真或假”的结论，对一篇真假混杂的笔记并不诚实。很多笔记是真的在分享，只是图被修得过头，或者评论里混了几条模板。我们给的是可信度和依据，让你自己判断。",
        },
        {
          question: "TruLens 能告诉我这个产品好不好用、适不适合我的皮肤吗？",
          answer: "不能。TruLens 判断的是这篇笔记可不可信，不是产品功效评测，也不是医疗建议，更不会替你决定买不买。",
        },
      ],
    },
    {
      title: "四、隐私与数据",
      items: [
        {
          question: "我提交的内容会被保存吗？",
          answer: "会保存在本次演示环境的本地数据库与上传目录中，用于生成和查看报告。当前版本还没有提供自助删除入口，正式上线前需要补充数据保留期限与删除流程。",
        },
      ],
    },
    {
      title: "五、追问和反驳",
      items: [
        {
          question: "报告出来之后，我还能做什么？",
          answer: "你可以基于这篇笔记继续追问，比如“为什么图片这一项扣分”，回答会标明用到了哪几个维度。如果你不同意某个判断，可以补充理由、上传证据并选择对应维度；当前版本会记录这些材料并展示复核过程，不会自动改动已经生成的分数。",
        },
      ],
    },
  ],
} as const;

type FAQItemData = (typeof faqContent.groups)[number]["items"][number];

function FAQItem({ index, item }: { index: number; item: FAQItemData }) {
  const [open, setOpen] = useState(false);
  const reducedMotion = Boolean(useReducedMotion());
  const answerId = `faq-answer-${index}`;
  return (
    <article className={`faq-item ${open ? "open" : ""}`}>
      <button aria-controls={answerId} aria-expanded={open} onClick={() => setOpen((current) => !current)}>
        <span>{String(index + 1).padStart(2, "0")}</span>
        <strong>{item.question}</strong>
        <i aria-hidden="true"><b /><b /></i>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            animate={{ height: "auto", opacity: 1 }}
            className="faq-answer"
            exit={{ height: 0, opacity: 0 }}
            id={answerId}
            initial={reducedMotion ? false : { height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.28, ease: [0.22, 0.7, 0.2, 1] }}
          >
            <p>{item.answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}

function FAQSection() {
  let itemIndex = 0;
  return (
    <section className="faq-section" id="faq">
      <header className="faq-heading">
        <span>{faqContent.eyebrow}</span>
        <h2>{faqContent.title}</h2>
        <p>{faqContent.subtitle}</p>
      </header>
      <div className="faq-shell">
        {faqContent.groups.map((group) => (
          <section className="faq-group" key={group.title}>
            <h3>{group.title}</h3>
            <div>
              {group.items.map((item) => {
                const currentIndex = itemIndex;
                itemIndex += 1;
                return <FAQItem index={currentIndex} item={item} key={item.question} />;
              })}
            </div>
          </section>
        ))}
      </div>
    </section>
  );
}

const footerContent = {
  explore: {
    title: "EXPLORE",
    links: [
      { label: "产品介绍", target: "how-journey" },
      { label: "信任依据", target: "why-trust" },
      { label: "美妆鉴别指南", target: "learn" },
      { label: "常见问题 FAQ", target: "faq" },
    ],
  },
  information: {
    title: "INFORMATION",
    links: ["隐私政策", "使用说明", "联系我们"],
  },
  copyright: "© 2026 TruLens. All rights reserved.",
  statement: "Made for more mindful beauty choices.",
} as const;

function LandingFooter() {
  const scrollTo = (target: string) => {
    document.getElementById(target)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      block: "start",
    });
  };
  return (
    <footer className="landing-footer">
      <div className="landing-footer-main">
        <div className="landing-footer-brand-area">
          <button className="landing-footer-brand" onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" })}>
            <img alt="TruLens" src="/trulens-nav-logo.png" />
          </button>
          <input aria-label="输入要鉴别的内容" placeholder="我今天帮你鉴别什么？" />
        </div>
        <nav aria-label="页脚探索导航" className="landing-footer-column">
          <strong>{footerContent.explore.title}</strong>
          {footerContent.explore.links.map((link) => (
            <button key={link.target} onClick={() => scrollTo(link.target)}>{link.label}</button>
          ))}
        </nav>
        <div className="landing-footer-column landing-footer-information">
          <strong>{footerContent.information.title}</strong>
          {footerContent.information.links.map((link) => <span key={link}>{link}</span>)}
        </div>
      </div>
      <div className="landing-footer-bottom">
        <span>{footerContent.copyright}</span>
        <span>{footerContent.statement}</span>
      </div>
    </footer>
  );
}

function Home({
  onCreator,
  onStart,
  onSubmit,
  onTeam,
}: {
  onCreator: () => void;
  onStart: () => void;
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
  onTeam: () => void;
}) {

  return (
    <main className="home">
      <LandingNavigation onStart={onStart} onTeam={onTeam} />

      <TruLensHero onSubmit={onSubmit} />

      <HowNarrative onStart={onStart} />

      <WhyTrustSection />

      <WhoUsesSection onCreator={onCreator} onTeam={onTeam} onVerify={onStart} />

      <LearnSection />

      <FAQSection />

      <LandingFooter />
    </main>
  );
}

function Sidebar({
  active,
  activeTask,
  archivedScore,
  activeRecentId,
  collapsed,
  historyCleared,
  recentRuns,
  onNew,
  onLogout,
  onRecent,
  onResetAgent,
  onReport,
  onTask,
  onTaskReport,
  onToggle,
}: {
  active: Screen;
  activeTask: RecentTask;
  archivedScore: number | null;
  activeRecentId: string | null;
  collapsed: boolean;
  historyCleared: boolean;
  recentRuns: RecentRunRecord[];
  onNew: () => void;
  onLogout: () => void;
  onRecent: (id: string) => void;
  onResetAgent: () => void;
  onReport: (task: RecentTask) => void;
  onTask: (task: RecentTask) => void;
  onTaskReport: (taskId: string) => void;
  onToggle: () => void;
}) {
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [accountDialog, setAccountDialog] = useState<"help" | "reset" | "add" | "logout" | null>(null);
  const [accountInput, setAccountInput] = useState("");
  const [accountAdded, setAccountAdded] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchCategory, setSearchCategory] = useState<"all" | "reports">("all");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [reportLibrary, setReportLibrary] = useState<Array<{
    taskId: string;
    title: string;
    date: string;
    status: string;
    score: number;
  }>>([]);
  useEffect(() => {
    void getTeamQueue()
      .then((data) => {
        setReportLibrary(
          data.items.map((item) => ({
            taskId: item.task_id,
            title: item.title,
            date: recentDateLabel(item.created_at),
            status: item.risk_level === "high" ? "高风险" : item.risk_level === "medium" ? "中风险" : "高可信",
            score: Math.round(item.score),
          })),
        );
      })
      .catch(() => setReportLibrary([]));
  }, []);
  const searchableTasks = reportLibrary.filter(
    (item) => !recentRuns.some((run) => run.taskId === item.taskId),
  );
  const filteredSearchTasks = historyCleared
    ? []
    : searchableTasks.filter((item) =>
      `${item.title} ${item.date} ${item.status}`.toLowerCase().includes(searchQuery.trim().toLowerCase()),
    );
  const filteredRecentRuns = historyCleared
    ? []
    : recentRuns.filter((item) =>
      `${item.title} ${recentDateLabel(item.createdAt)} ${item.trustLabel}`
        .toLowerCase()
        .includes(searchQuery.trim().toLowerCase()),
    );
  const searchResultCount = filteredRecentRuns.length + filteredSearchTasks.length;

  useEffect(() => {
    if (!accountDialog) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setAccountDialog(null);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [accountDialog]);

  useEffect(() => {
    if (!searchOpen) return;
    searchInputRef.current?.focus();
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [searchOpen]);

  const openDialog = (dialog: Exclude<typeof accountDialog, null>) => {
    setAccountMenuOpen(false);
    setAccountDialog(dialog);
    if (dialog === "add") {
      setAccountInput("");
      setAccountAdded(false);
    }
  };

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="side-top">
        <Logo />
        <div className="side-top-actions">
          <button
            aria-label="搜索历史对话和报告"
            className="icon-button sidebar-search-button"
            onClick={() => {
              setAccountMenuOpen(false);
              setSearchQuery("");
              setSearchCategory("all");
              setSearchOpen(true);
            }}
            title="搜索"
          >
            <Icon size={18}>
              <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
              <path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
            </Icon>
          </button>
          <button
            aria-label={collapsed ? "展开侧栏" : "收起侧栏"}
            aria-pressed={collapsed}
            className="icon-button mobile-hide sidebar-toggle"
            onClick={onToggle}
            title={collapsed ? "展开侧栏" : "收起侧栏"}
          >
            <Icon size={18}>
              <path d="M4 5h16M4 12h10M4 19h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
            </Icon>
          </button>
        </div>
      </div>
      <button className="new-analysis" onClick={onNew}>
        <span>
          <Sparkle size={17} /> 新建鉴别
        </span>
        <small>⌘ K</small>
      </button>
      <button
        className="sidebar-report-library"
        onClick={() => {
          setAccountMenuOpen(false);
          setSearchQuery("");
          setSearchCategory("reports");
          setSearchOpen(true);
        }}
        title="报告库"
      >
        <span>
          <Icon size={17}>
            <path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" />
            <path d="M15 3v4h3M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" />
          </Icon>
          报告库
        </span>
        <small>{historyCleared ? 0 : recentRuns.length + searchableTasks.length}</small>
      </button>
      <button
        className="sidebar-help-guide"
        onClick={() => openDialog("help")}
        title="帮助指引"
      >
        <span>
          <Icon size={17}>
            <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.4" />
            <path d="M9.7 9.2a2.5 2.5 0 1 1 3.1 2.4c-.6.3-.8.8-.8 1.5M12 16.7v.1" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
          帮助指引
        </span>
      </button>
      <div className="side-label">最近任务</div>
      <div className="history">
        {historyCleared ? (
          <p className="history-empty">暂无检测记录</p>
        ) : (
          <>
            {recentRuns.map((run) => (
              <button
                className={activeRecentId === run.id && active === "result" ? "active" : ""}
                key={run.id}
                onClick={() => onRecent(run.id)}
              >
                <span className="history-thumb purple" title={run.activeDimensions.length ? undefined : "暂不评分"}>{run.activeDimensions.length ? Math.round(run.trustScore) : "—"}</span>
                <span>
                  <strong>{run.title}</strong>
                  <small><i className={`recent-role-tag role-${recentRunRole(run)}`}>{recentRunRole(run) === "creator" ? "创作者" : "消费者"}</i>{recentDateLabel(run.createdAt)} · {run.kind === "creator" ? "发布前自检" : run.trustLabel}</small>
                </span>
              </button>
            ))}
            <button className={!activeRecentId && activeTask === "makeup" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onReport("makeup")}>
              <span className="history-thumb">
                <img alt="" src={postImage} />
              </span>
              <span>
                <strong>秋冬奶油肌底妆分享</strong>
                <small><i className="recent-role-tag role-demo">示例</i>{archivedScore ? `今天 · 已归档 · ${archivedScore} 分` : "今天 · 高可信"}</small>
              </span>
            </button>
            <button className={!activeRecentId && activeTask === "serum" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onReport("serum")}>
              <span className="history-thumb purple">
                <Sparkle size={15} />
              </span>
              <span>
                <strong>热门精华测评合集</strong>
                <small><i className="recent-role-tag role-demo">示例</i>昨天 · 存在风险</small>
              </span>
            </button>
            <button className={!activeRecentId && activeTask === "whitening" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onReport("whitening")}>
              <span className="history-thumb blue">S</span>
              <span>
                <strong>七天美白挑战</strong>
                <small><i className="recent-role-tag role-demo">示例</i>3 天前 · 疑似营销</small>
              </span>
            </button>
          </>
        )}
      </div>
      {searchOpen && (
        <div
          aria-modal="true"
          className="global-search-backdrop"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setSearchOpen(false);
          }}
          role="dialog"
        >
          <div className="global-search-dialog">
            <header className="global-search-header">
              <div className="global-search-input">
                <Icon size={21}>
                  <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
                  <path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
                <input
                  aria-label="搜索历史对话和报告"
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder="搜索历史对话或报告…"
                  ref={searchInputRef}
                  value={searchQuery}
                />
                {searchQuery && <button aria-label="清空搜索" onClick={() => setSearchQuery("")}>×</button>}
              </div>
              <button aria-label="关闭搜索" className="global-search-close" onClick={() => setSearchOpen(false)}>
                <Icon size={20}><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
              </button>
            </header>

            <div className="global-search-tabs" role="tablist">
              <button
                aria-selected={searchCategory === "all"}
                className={searchCategory === "all" ? "active" : ""}
                onClick={() => setSearchCategory("all")}
                role="tab"
              >
                <span>
                  <Icon size={18}><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /></Icon>
                </span>
                <strong>全部</strong>
                <small>历史对话</small>
              </button>
              <button
                aria-selected={searchCategory === "reports"}
                className={searchCategory === "reports" ? "active" : ""}
                onClick={() => setSearchCategory("reports")}
                role="tab"
              >
                <span>
                  <Icon size={18}><path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /><path d="M15 3v4h3M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" /></Icon>
                </span>
                <strong>报告库</strong>
                <small>历史报告合集</small>
              </button>
            </div>

            <div className="global-search-results">
              <div className="global-search-result-heading">
                <span>{searchCategory === "all" ? "历史对话" : "报告库"}</span>
                <small>{searchResultCount} 项结果</small>
              </div>
              {searchResultCount ? (
                <>
                  {filteredRecentRuns.map((run) => (
                    <button
                      className="global-search-result"
                      key={`recent-${run.id}`}
                      onClick={() => {
                        setSearchOpen(false);
                        onRecent(run.id);
                      }}
                    >
                      <span className="global-search-result-icon report">
                        <Icon size={18}><path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /><path d="M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" /></Icon>
                      </span>
                      <span>
                        <strong>{run.title}</strong>
                        <small><i className={`recent-role-tag role-${recentRunRole(run)}`}>{recentRunRole(run) === "creator" ? "创作者" : "消费者"}</i>{recentDateLabel(run.createdAt)} · {run.kind === "creator" ? "发布前自检" : run.trustLabel}</small>
                      </span>
                      <b>{run.activeDimensions.length ? <>{Math.round(run.trustScore)}<small>/100</small></> : <small>暂不评分</small>}</b>
                      <i>›</i>
                    </button>
                  ))}
                  {filteredSearchTasks.map((item) => (
                    <button
                      className="global-search-result"
                      key={`library-${item.taskId}`}
                      onClick={() => {
                        setSearchOpen(false);
                        onTaskReport(item.taskId);
                      }}
                    >
                      <span className="global-search-result-icon report">
                        <Icon size={18}><path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /><path d="M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" /></Icon>
                      </span>
                      <span>
                        <strong>{item.title}</strong>
                        <small>{item.date} · {item.status}</small>
                      </span>
                      <b>{item.score}<small>/100</small></b>
                      <i>›</i>
                    </button>
                  ))}
                </>
              ) : (
                <div className="global-search-empty">
                  <Icon size={24}><circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.4" /><path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" /></Icon>
                  <strong>没有找到相关内容</strong>
                  <small>尝试搜索任务名称、日期或核验状态</small>
                </div>
              )}
            </div>
            <footer className="global-search-footer"><span><kbd>Esc</kbd> 关闭</span><span>点击结果即可打开</span></footer>
          </div>
        </div>
      )}
      {accountMenuOpen && <button aria-label="关闭账户菜单" className="account-menu-scrim" onClick={() => setAccountMenuOpen(false)} />}
      {accountMenuOpen && (
        <div className="account-menu">
          <button className="account-menu-reset" onClick={() => openDialog("reset")}>
            <span className="account-menu-icon">
              <Icon size={20}><path d="M19 8a7 7 0 1 0 .2 7.6M19 4v4h-4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
            </span>
            <span><strong>重置 Agent</strong><small>清空聊天与检测历史</small></span>
          </button>
          <div className="account-menu-divider" />
          <button onClick={() => openDialog("add")}>
            <span className="account-menu-icon">
              <Icon size={20}><circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" /><path d="M12 8v8M8 12h8" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            </span>
            <span><strong>添加账号</strong><small>绑定另一个登录账号</small></span>
          </button>
          <button onClick={() => openDialog("logout")}>
            <span className="account-menu-icon">
              <Icon size={20}><path d="M10 5H5v14h5M14 8l4 4-4 4M9 12h9" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
            </span>
            <span><strong>退出登录</strong><small>退出当前个人账户</small></span>
          </button>
        </div>
      )}
      <div className="side-bottom">
        <button
          aria-expanded={accountMenuOpen}
          className={accountMenuOpen ? "account-trigger active" : "account-trigger"}
          onClick={() => setAccountMenuOpen((open) => !open)}
        >
          <span className="avatar">YZ</span>
          <span>
            <strong>Yuzuki</strong>
            <small>个人账户</small>
          </span>
          <span className="dots">
            <Icon size={18}><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5" /><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
          </span>
        </button>
      </div>

      {accountDialog && (
        <div
          aria-modal="true"
          className="account-dialog-backdrop"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setAccountDialog(null);
          }}
          role="dialog"
        >
          <div className={`account-dialog ${accountDialog === "help" ? "account-dialog-wide" : ""}`}>
            <button aria-label="关闭弹窗" className="account-dialog-close" onClick={() => setAccountDialog(null)}>×</button>
            {accountDialog === "help" && (
              <>
                <span className="account-dialog-tag">HELP CENTER</span>
                <h2>帮助指引</h2>
                <p>快速了解如何使用 TruLens 完成一次内容核验。</p>
                <div className="help-guide">
                  <section>
                    <h3>使用教程</h3>
                    <ol>
                      <li><span>1</span><div><strong>提供内容</strong><small>粘贴种草链接，或上传需要核验的图片。</small></div></li>
                      <li><span>2</span><div><strong>等待四维核验</strong><small>TruLens 从账号、图片、评论和宣传维度检查证据。</small></div></li>
                      <li><span>3</span><div><strong>阅读报告</strong><small>查看 Trust Score、逐项依据和购买建议。</small></div></li>
                    </ol>
                  </section>
                  <section className="help-faq">
                    <h3>FAQ</h3>
                    <details><summary>链接无法识别怎么办？</summary><p>请确认链接可公开访问，也可以补充截图或原始文案。</p></details>
                    <details><summary>Agent 的核查结论可以当作最终定论吗？</summary><p>TruLens Agent 是辅助核验工具，AI 存在误判、信息遗漏风险，不能直接作为事实定论，重要内容建议交叉查阅权威原始来源。</p></details>
                    <details><summary>数据不足会怎样显示？</summary><p>缺失维度会明确标注“数据不足”，不会由 AI 自动补全。</p></details>
                  </section>
                </div>
              </>
            )}
            {accountDialog === "reset" && (
              <>
                <span className="account-dialog-tag">RESET AGENT</span>
                <h2>重置 TruLens Agent？</h2>
                <p>这会清空当前聊天信息和所有检测历史。操作完成后无法恢复。</p>
                <div className="reset-summary"><span>聊天内容</span><strong>全部清空</strong><span>检测历史</span><strong>全部清空</strong></div>
                <div className="account-dialog-actions">
                  <button onClick={() => setAccountDialog(null)}>取消</button>
                  <button className="danger" onClick={() => { onResetAgent(); setAccountDialog(null); }}>确认重置</button>
                </div>
              </>
            )}
            {accountDialog === "add" && (
              <>
                <span className="account-dialog-tag">ADD ACCOUNT</span>
                <h2>添加账号</h2>
                <p>输入邮箱，将另一个账号添加到当前设备。</p>
                {accountAdded ? (
                  <div className="account-added"><span>✓</span><strong>账号已添加</strong><small>{accountInput}</small></div>
                ) : (
                  <>
                    <label className="account-input-label">邮箱地址<input onChange={(event) => setAccountInput(event.target.value)} placeholder="name@example.com" type="email" value={accountInput} /></label>
                    <div className="account-dialog-actions">
                      <button onClick={() => setAccountDialog(null)}>取消</button>
                      <button disabled={!accountInput.includes("@")} onClick={() => setAccountAdded(true)}>添加账号</button>
                    </div>
                  </>
                )}
              </>
            )}
            {accountDialog === "logout" && (
              <>
                <span className="account-dialog-tag">SIGN OUT</span>
                <h2>退出当前账户？</h2>
                <p>退出后将返回首页，本地检测记录不会被删除。</p>
                <div className="account-dialog-actions">
                  <button onClick={() => setAccountDialog(null)}>取消</button>
                  <button className="danger" onClick={() => { onLogout(); setAccountDialog(null); }}>退出登录</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </aside>
  );
}

const suggestionItems = [
  ["鉴别配图真实性", "上传截图或粘贴帖子链接"],
  ["分析博主的历史可信度", "输入主页链接，检索长期行为"],
  ["检查产品功效宣传", "识别夸大、误导与安全风险"],
];

function Composer({
  accountUrl,
  compact = false,
  filename,
  onAccountUrl,
  onFile,
  onPickFile,
  onPauseToggle,
  onSubmit,
  pauseDisabled = false,
  paused = false,
  preset = "",
}: {
  accountUrl?: string;
  compact?: boolean;
  filename: string;
  onAccountUrl?: (value: string) => void;
  onFile: (name: string) => void;
  /** Hands the real File to the caller so it can actually be uploaded. */
  onPickFile?: (file: File | null) => void;
  onPauseToggle?: () => void;
  onSubmit: (prompt: string) => void;
  pauseDisabled?: boolean;
  paused?: boolean;
  preset?: string;
}) {
  const [value, setValue] = useState("");
  const [accountError, setAccountError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const accountInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setValue(preset);
  }, [preset]);

  const accountValue = (accountUrl ?? "").trim();
  const validAccountUrl = /xiaohongshu\.com\/user\/profile\/|xhslink\.(com|cn)/i.test(accountValue);
  // The author homepage is optional: the backend discovers it from the note page,
  // so only a *supplied* value has to parse as a profile link.
  const accountMissing = Boolean(!compact && accountValue && !validAccountUrl);
  const noteUrl = value.match(/https?:\/\/[^\s，,、）)]+/)?.[0] ?? "";

  const pasteAccountUrl = async () => {
    try {
      const clipboard = await navigator.clipboard.readText();
      const profileUrl = clipboard.match(
        /https?:\/\/[^\s，,、）)]*xiaohongshu\.com\/user\/profile\/[0-9a-zA-Z]+(?:\?[^\s，,、）)]*)?/i,
      )?.[0] ?? clipboard.trim();
      onAccountUrl?.(profileUrl);
      setAccountError("");
      accountInputRef.current?.focus();
    } catch {
      setAccountError("无法读取剪贴板，请手动粘贴账号主页链接。");
      accountInputRef.current?.focus();
    }
  };

  const submit = () => {
    if (accountMissing) {
      setAccountError("账号主页链接无法识别，请粘贴 xiaohongshu.com/user/profile/… 链接，或清空此项由系统自动获取。");
      return;
    }
    if (value.trim() || filename) {
      onSubmit(value.trim() || "请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
      setValue("");
    }
  };

  return (
    <div className={`composer ${compact ? "composer-compact" : ""}`}>
      <textarea
        aria-label="输入鉴别需求"
        onChange={(event) => setValue(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            submit();
          }
        }}
        placeholder={compact ? "继续追问这份报告…" : "粘贴帖子链接，或告诉我你想鉴别什么…"}
        rows={compact ? 1 : 3}
        value={value}
      />
      {!compact && (
        <label className="composer-account-field">
          <span>账号主页 · 可选，留空自动获取</span>
          <input
            aria-label="账号主页链接"
            aria-required={false}
            onChange={(event) => {
              setAccountError("");
              onAccountUrl?.(event.target.value);
            }}
            placeholder="https://www.xiaohongshu.com/user/profile/…"
            ref={accountInputRef}
            value={accountUrl ?? ""}
          />
        </label>
      )}
      {!compact && looksLikeXhsLink(value) && (
        <section className="composer-account-method" aria-label="获取账号主页链接的方法">
          <header>
            <strong>账号主页链接从哪里来？</strong>
            <span className={validAccountUrl ? "ready" : ""}><i />{validAccountUrl ? "已识别" : "待填写"}</span>
          </header>
          <ol>
            <li><b>1</b><span>打开笔记，点击作者头像进入主页</span></li>
            <li><b>2</b><span>在主页右上角点击「分享」→「复制链接」</span></li>
            <li><b>3</b><span>回到这里粘贴以 <code>/user/profile/</code> 开头的链接</span></li>
          </ol>
          <div className="composer-account-method-actions">
            {noteUrl && (
              <button onClick={() => window.open(noteUrl, "_blank", "noopener,noreferrer")} type="button">
                打开笔记
                <Icon size={13}><path d="M7 17 17 7M9 7h8v8" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
              </button>
            )}
            <button onClick={() => void pasteAccountUrl()} type="button">粘贴账号链接</button>
          </div>
        </section>
      )}
      {!compact && accountError && <p className="composer-account-error">{accountError}</p>}
      {filename && (
        <div className="file-chip">
          <span className="file-preview"><img alt="" src={postImage} /></span>
          <span><strong>{filename}</strong><small>已准备进行图像取证</small></span>
          <button aria-label="移除附件" onClick={() => { onFile(""); onPickFile?.(null); }}>×</button>
        </div>
      )}
      <div className="composer-actions">
        <div>
          <input
            accept="image/*"
            hidden
            onChange={(event) => {
              const file = event.target.files?.[0] ?? null;
              onFile(file?.name || "");
              onPickFile?.(file);
            }}
            ref={inputRef}
            type="file"
          />
          <button className="tool-button" onClick={() => inputRef.current?.click()} title="上传图片">
            <Icon size={18}>
              <path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
            </Icon>
          </button>
          {!compact && (
            <button className="tool-button" title="粘贴链接">
              <Icon size={18}>
                <path d="m9.5 14.5 5-5M7.3 16.7l-1 1a3.5 3.5 0 0 1-5-5l3.2-3.2a3.5 3.5 0 0 1 5 0M16.7 7.3l1-1a3.5 3.5 0 1 1 5 5l-3.2 3.2a3.5 3.5 0 0 1-5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
              </Icon>
            </button>
          )}
          {!compact && <span className="composer-hint">支持图片、链接与文案</span>}
        </div>
        <div className="composer-submit-actions">
          {compact && onPauseToggle && (
            <button
              aria-label={pauseDisabled ? "当前回答已完成" : paused ? "继续生成" : "暂停生成"}
              className={paused ? "composer-pause paused" : "composer-pause"}
              disabled={pauseDisabled}
              onClick={onPauseToggle}
              title={pauseDisabled ? "当前回答已完成" : paused ? "继续生成" : "暂停生成"}
            >
              <Icon size={21}>
                {paused ? (
                  <path d="m8 5 11 7-11 7V5Z" fill="currentColor" />
                ) : (
                  <>
                    <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" />
                    <rect fill="currentColor" height="6" rx="1.2" width="6" x="9" y="9" />
                  </>
                )}
              </Icon>
            </button>
          )}
          <button className="send-button" disabled={(!value.trim() && !filename) || accountMissing} onClick={submit}>
            <Arrow size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

const NEW_ANALYSIS_EXAMPLE_TEXT = "最近换季皮肤有点干，连续使用这款精华 14 天后，我个人感觉保湿度有所提升。本文为自费购买，具体效果会因肤质和使用方式不同。";

/**
 * Frontend mirror of backend/app/services/xhs_service.py `normalize()` (format only,
 * no network): /explore/<id>, /discovery/item/<id>, a bare 24-hex note id, or an
 * xhslink short link (resolved by the backend at verification time).
 */
type XhsNoteCheck =
  | { ok: true; value: string; kind: "note" | "short" }
  | { ok: false; reason: "empty" | "profile" | "unrecognized" };

const XHS_URL_IN_TEXT = /https?:\/\/[^\s，,、）)】」"'<>]+/i;

function checkXhsNoteInput(raw: string): XhsNoteCheck {
  const text = raw.trim();
  if (!text) return { ok: false, reason: "empty" };
  const explore = text.match(/https?:\/\/[^\s，,、）)]*xiaohongshu\.com\/(?:explore|discovery\/item)\/[0-9a-zA-Z]+(?:\?[^\s，,、）)]*)?/i);
  if (explore) return { ok: true, value: explore[0], kind: "note" };
  const short = text.match(/https?:\/\/[^\s，,、）)]*xhslink\.(?:com|cn)\/[^\s，,、）)]+/i);
  if (short) return { ok: true, value: short[0], kind: "short" };
  if (/xhslink\.(?:com|cn)\//i.test(text)) return { ok: true, value: text.match(XHS_URL_IN_TEXT)?.[0] ?? text, kind: "short" };
  // A homepage link is not a note: the backend would misread the user id as a note id.
  if (/\/user\/profile\//i.test(text)) return { ok: false, reason: "profile" };
  const bareId = text.match(/\b[0-9a-f]{24}\b/);
  if (bareId) return { ok: true, value: text.match(XHS_URL_IN_TEXT)?.[0] ?? bareId[0], kind: "note" };
  return { ok: false, reason: "unrecognized" };
}

/** Same idea for the author homepage (backend `normalize_account()`). */
function extractXhsProfileLink(raw: string): string | null {
  const text = raw.trim();
  if (!text) return null;
  const profile = text.match(/https?:\/\/[^\s，,、）)]*xiaohongshu\.com\/user\/profile\/[0-9a-zA-Z]+(?:\?[^\s，,、）)]*)?/i);
  if (profile) return profile[0];
  const short = text.match(/https?:\/\/[^\s，,、）)]*xhslink\.(?:com|cn)\/[^\s，,、）)]+/i);
  return short ? short[0] : null;
}

/**
 * 账号历史 form ⇄ the JSON the backend already accepts (core/utils.normalize_account_history):
 * {"handle": "...", "posts": [{"text": "...", "published_at": "2026-09-01T00:00:00Z"}]}.
 * A post line is "日期 | 内容" (date optional); no date → no published_at key.
 */
type AccountPostDraft = { text: string; date?: string };

function parseAccountPostLines(raw: string): AccountPostDraft[] {
  return raw
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const matched = line.match(/^(\d{4}-\d{2}-\d{2})\s*\|\s*(.+)$/);
      return matched ? { date: matched[1], text: matched[2].trim() } : { text: line.replace(/^\|\s*/, "") };
    })
    .filter((post) => post.text);
}

function buildAccountHistoryJson(handle: string, posts: AccountPostDraft[]): string {
  const payload: { handle?: string; posts: Array<{ text: string; published_at?: string }> } = {
    ...(handle.trim() ? { handle: handle.trim() } : {}),
    posts: posts.map((post) => (post.date ? { text: post.text, published_at: `${post.date}T00:00:00Z` } : { text: post.text })),
  };
  return JSON.stringify(payload);
}

/** Legacy JSON (e.g. pasted or restored) → form fields; null when it is not that shape. */
function parseAccountHistoryJson(raw: string): { handle: string; lines: string } | null {
  try {
    const parsed = JSON.parse(raw);
    const posts = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.posts) ? parsed.posts : null;
    if (!posts) return null;
    const lines = posts
      .map((post: unknown) => {
        if (typeof post === "string") return post;
        if (!post || typeof post !== "object") return "";
        const item = post as { text?: unknown; published_at?: unknown; created_at?: unknown };
        const text = typeof item.text === "string" ? item.text : "";
        const when = typeof item.published_at === "string" ? item.published_at : typeof item.created_at === "string" ? item.created_at : "";
        const date = when.match(/^\d{4}-\d{2}-\d{2}/)?.[0];
        return text ? (date ? `${date} | ${text}` : text) : "";
      })
      .filter(Boolean)
      .join("\n");
    return { handle: typeof parsed?.handle === "string" ? parsed.handle : "", lines };
  } catch {
    return null;
  }
}

/** Share text with the link removed — what is worth carrying over to 文案 / 图片核验. */
function stripLinksFromShareText(raw: string) {
  return raw.replace(/https?:\/\/[^\s，,、）)】」]+/gi, " ").replace(/复制后打开.*$/s, "").replace(/\s+/g, " ").trim();
}

function NewAnalysisForm({
  accountUrl,
  onAccountUrl,
  creatorPreset = "",
  initialMode = "link",
  onFile,
  onSubmitCreator,
  onSubmitLink,
  onSubmitManual,
  manualPreset = "",
  notice = "",
  preset = "",
  workspaceMode = "verify",
}: {
  accountUrl: string;
  creatorPreset?: string;
  initialMode?: "link" | "manual" | "creator";
  onAccountUrl: (value: string) => void;
  onFile: (name: string) => void;
  onSubmitCreator: (input: CreatorReportInput) => void;
  onSubmitLink: (noteUrl: string, accountUrl: string, rawInput?: string) => void;
  onSubmitManual: (input: { text: string; image: File | null; comments: string; accountHistory: string }) => void;
  manualPreset?: string;
  /** One short line shown when a verification bounced back here (e.g. the link could not be fetched). */
  notice?: string;
  preset?: string;
  workspaceMode?: "verify" | "creator";
}) {
  const [verifyMode, setVerifyMode] = useState<"link" | "manual">(initialMode === "manual" ? "manual" : "link");
  const mode: "link" | "manual" | "creator" = workspaceMode === "creator" ? "creator" : verifyMode;
  const [noteLink, setNoteLink] = useState(preset);
  const [manualText, setManualText] = useState(manualPreset);
  // Recognition step: nothing is submitted until the user confirms on this screen.
  const [review, setReview] = useState<null | "recognition" | "link-error">(null);
  const [linkErrorReason, setLinkErrorReason] = useState<"profile" | "unrecognized">("unrecognized");
  const noteInputRef = useRef<HTMLInputElement>(null);
  const [manualFile, setManualFile] = useState<File | null>(null);
  const [manualComments, setManualComments] = useState("");
  // 账号历史 as a plain form; turned into the backend's JSON only on submit.
  const [accountHandle, setAccountHandle] = useState("");
  const [accountPostsText, setAccountPostsText] = useState("");
  // 评论区截图: kept and shown on the front end only — the backend has no field for them
  // (sending them as `image` would make them count as R 配图).
  const [commentShots, setCommentShots] = useState<Array<{ id: string; name: string; url: string }>>([]);
  const commentShotInputRef = useRef<HTMLInputElement>(null);
  const accountPosts = parseAccountPostLines(accountPostsText);
  const accountHistoryReady = accountPosts.length >= 3;
  const accountHistoryPartial = accountPosts.length > 0 && !accountHistoryReady;
  // Only a history the backend can score is sent; fewer than 3 posts means 本次不评估账号.
  const manualAccountHistory = accountHistoryReady ? buildAccountHistoryJson(accountHandle, accountPosts) : "";
  const addCommentShots = (files: File[]) => {
    const next = files
      .filter((file) => file.type.startsWith("image/"))
      .map((file) => ({ id: `${file.name}-${file.lastModified}-${Math.random()}`, name: file.name, url: URL.createObjectURL(file) }));
    if (next.length) setCommentShots((current) => [...current, ...next]);
  };
  const removeCommentShot = (id: string) =>
    setCommentShots((current) => {
      const target = current.find((shot) => shot.id === id);
      if (target) URL.revokeObjectURL(target.url);
      return current.filter((shot) => shot.id !== id);
    });
  const [supplementOpen, setSupplementOpen] = useState(false);
  const [creatorDraft, setCreatorDraft] = useState(creatorPreset);
  const [creatorImages, setCreatorImages] = useState<Array<{ id: string; name: string; url: string; file: File }>>([]);
  const [creatorCollaboration, setCreatorCollaboration] = useState(false);
  const [creatorCategory, setCreatorCategory] = useState("护肤");
  const [preview, setPreview] = useState("");
  const [error, setError] = useState(notice);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const creatorFileInputRef = useRef<HTMLInputElement>(null);
  const accountInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setNoteLink(preset);
  }, [preset]);

  useEffect(() => {
    if (!manualPreset) return;
    setVerifyMode("manual");
    setManualText(manualPreset);
  }, [manualPreset]);

  useEffect(() => {
    if (!creatorPreset) return;
    setCreatorDraft(creatorPreset);
  }, [creatorPreset]);

  useEffect(() => {
    if (initialMode !== "creator") setVerifyMode(initialMode);
  }, [initialMode]);

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview);
  }, [preview]);

  const noteCheck = checkXhsNoteInput(noteLink);
  const accountLink = extractXhsProfileLink(accountUrl);
  // The button only needs content; whether it is a usable note link is decided on click
  // (an unusable one opens the 「链接无法识别」 screen instead of a disabled button).
  const linkReady = Boolean(noteLink.trim());
  const manualReady = Boolean(manualText.trim() || manualFile);
  const creatorReady = Boolean(creatorDraft.trim() || creatorImages.length);

  const selectFile = (file: File | null) => {
    if (preview) URL.revokeObjectURL(preview);
    setManualFile(file);
    setPreview(file ? URL.createObjectURL(file) : "");
    onFile(file?.name ?? "");
  };

  const addCreatorImages = (files: File[]) => {
    const room = Math.max(0, 9 - creatorImages.length);
    const next = files
      .filter((file) => file.type.startsWith("image/"))
      .slice(0, room)
      .map((file) => ({
        id: `${file.name}-${file.lastModified}-${Math.random()}`,
        name: file.name,
        url: URL.createObjectURL(file),
        file,
      }));
    if (next.length) {
      setCreatorImages((current) => [...current, ...next]);
      setError("");
    }
  };

  const removeCreatorImage = (id: string) => {
    setCreatorImages((current) => {
      const target = current.find((image) => image.id === id);
      if (target) URL.revokeObjectURL(target.url);
      return current.filter((image) => image.id !== id);
    });
  };

  const loadExample = () => {
    setVerifyMode("manual");
    setManualText(NEW_ANALYSIS_EXAMPLE_TEXT);
    setError("");
  };

  const confirmAndStart = () => {
    setReview(null);
    if (mode === "link") {
      if (!noteCheck.ok) return;
      onSubmitLink(noteCheck.value, accountLink ?? "", noteLink);
      return;
    }
    onSubmitManual({
      text: manualText.trim(),
      image: manualFile,
      comments: manualComments.trim(),
      accountHistory: manualAccountHistory.trim(),
    });
  };

  const submit = () => {
    setError("");
    if (mode === "link") {
      if (!noteCheck.ok) {
        if (noteCheck.reason === "empty") {
          setError("请填写小红书笔记链接。");
          return;
        }
        setLinkErrorReason(noteCheck.reason);
        setReview("link-error");
        return;
      }
      if (accountUrl.trim() && !accountLink) {
        // Optional: left blank it is discovered from the note. But when the user
        // *does* supply one it has to be a profile link we can read.
        setError("作者主页链接无法识别，请粘贴 xiaohongshu.com/user/profile/… 或 xhslink 链接，或留空由系统自动获取。");
        accountInputRef.current?.focus();
        return;
      }
      setReview("recognition");
      return;
    }

    if (mode === "creator") {
      if (!creatorReady) {
        setError("请填写草稿文案或上传配图。");
        return;
      }
      onSubmitCreator({
        draft: creatorDraft.trim() || "请检查这些待发布配图",
        images: creatorImages,
        isCollaboration: creatorCollaboration,
        category: creatorCategory,
        isExample: false,
      });
      return;
    }

    if (looksLikeXhsLink(manualText)) {
      setError("检测到笔记链接。请切换到「链接核验」，并同时填写账号主页链接。");
      return;
    }
    if (!manualReady) {
      setError("请填写文案或上传图片。");
      return;
    }
    setReview("recognition");
  };

  const backToInput = (openSupplements = false) => {
    setReview(null);
    if (openSupplements && mode === "manual") setSupplementOpen(true);
  };

  if (review === "link-error" && mode === "link") {
    return (
      <div className="verification-feedback-panel link-error-panel" role="alert">
        <span className="verification-panel-icon">!</span>
        <small>LINK UNRECOGNIZED</small>
        <h3>链接无法识别</h3>
        <p>
          {linkErrorReason === "profile"
            ? "这看起来是作者主页链接，而不是笔记链接。请把它填到「作者主页链接」，笔记链接一栏请粘贴笔记本身的链接。"
            : "没有在输入内容里找到可用的小红书笔记链接。"}
        </p>
        <ul className="link-error-tips">
          <li>请粘贴小红书笔记链接（xiaohongshu.com 或 xhslink.com 开头）。</li>
          <li>如果是分享文案，请直接粘贴整段分享内容，系统会提取其中的链接。</li>
          <li>也可以切换到「文案 / 图片核验」，手动输入文案和图片。</li>
        </ul>
        <div>
          <button onClick={() => { setReview(null); window.setTimeout(() => noteInputRef.current?.focus(), 0); }} type="button">重新输入链接</button>
          <button onClick={() => { setReview(null); setVerifyMode("manual"); setError(""); }} type="button">改用文案 / 图片核验 <Arrow size={16} /></button>
        </div>
      </div>
    );
  }

  if (review === "recognition" && mode !== "creator") {
    const isLink = mode === "link";
    const textLength = manualText.trim().replace(/\s/g, "").length;
    const commentCount = manualComments.split(/\n+/).map((line) => line.trim()).filter(Boolean).length;
    const materials: Array<{ key: string; label: string; ready: boolean; detail?: string; thumb?: string; expected?: boolean; canAdd?: boolean }> = isLink
      ? [
          { key: "copy", label: "帖子正文", ready: true, expected: true, detail: "预计获取" },
          { key: "images", label: "配图", ready: true, expected: true, detail: "预计获取" },
          { key: "comments", label: "评论", ready: true, expected: true, detail: "预计获取" },
          { key: "reviews", label: "商品评价", ready: false, detail: "链接核验不包含" },
          { key: "service", label: "客服凭证", ready: false, detail: "链接核验不包含" },
        ]
      : [
          { key: "copy", label: "帖子正文", ready: textLength > 0, detail: textLength ? `${textLength} 字` : "", canAdd: true },
          { key: "images", label: manualFile ? "配图 · 1 张" : "配图", ready: Boolean(manualFile), thumb: preview || undefined, canAdd: true },
          { key: "comments", label: "评论", ready: commentCount > 0, detail: commentCount ? `${commentCount} 条` : "", canAdd: true },
          ...(commentShots.length
            ? [{ key: "comment-shots", label: `评论截图 · ${commentShots.length} 张（已添加，暂不参与评分）`, ready: true, thumb: commentShots[0].url }]
            : []),
          ...(accountPosts.length
            ? [{ key: "account", label: `账号历史 · ${accountPosts.length} 篇`, ready: accountHistoryReady, detail: accountHistoryReady ? "" : "不足 3 篇，本次不评估账号", canAdd: true }]
            : []),
          { key: "reviews", label: "商品评价", ready: false },
          { key: "service", label: "客服凭证", ready: false },
        ];
    const enabledDimensions: DimensionCode[] = isLink
      ? ["T", "R", "U", "S"]
      : (["T", "R", "U", "S"] as DimensionCode[]).filter((code) =>
          code === "T" ? Boolean(manualAccountHistory.trim()) : code === "R" ? Boolean(manualFile) : code === "U" ? commentCount > 0 : textLength > 0,
        );
    const dimensionLabels: Record<DimensionCode, string> = { T: "账号可信度", R: "图像原生性", U: "评论自然度", S: "文案真实性" };
    const missingReasons: Record<DimensionCode, string> = { T: accountHistoryPartial ? "账号历史不足 3 篇，本次不评估账号" : "未提供账号信息，不参与计分", R: "未提供图片，不参与计分", U: "未提供评论，不参与计分", S: "未提供文案，不参与计分" };
    return (
      <div className="verification-recognition-panel">
        <header><small>MATERIAL RECOGNITION</small><h3>识别结果</h3><p>{isLink ? "请确认 Agent 即将使用的材料与核验范围。链接内容会在开始核验后抓取，以下为预计获取的材料。" : "请确认 Agent 即将使用的材料与核验范围。"}</p></header>
        <div className="recognition-layout">
          <section>
            <span>材料清单</span>
            {materials.map((material) => (
              <div className={material.ready ? (material.expected ? "ready expected" : "ready") : "missing"} key={material.key}>
                <i>{material.ready ? (material.expected ? "…" : "✓") : "✕"}</i>
                <strong>{material.label}</strong>
                {material.thumb ? <img alt="" className="recognition-thumb" src={material.thumb} /> : material.detail ? <small>{material.detail}</small> : <small />}
                {!material.ready && material.canAdd ? <button onClick={() => backToInput(true)} type="button">补充</button> : <span />}
              </div>
            ))}
          </section>
          <section>
            <span>本次启用维度</span>
            {allDimensions.map((code) => {
              const enabled = enabledDimensions.includes(code);
              return (
                <div className={enabled ? "enabled" : "disabled"} key={code}>
                  <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
                  <div><strong>{dimensionLabels[code]}</strong><small>{enabled ? (isLink && code !== "T" ? "预计核验" : "将核验") : missingReasons[code]}</small></div>
                </div>
              );
            })}
          </section>
        </div>
        <p className="recognition-scope-note"><Sparkle size={14} /> Agent 只会核验你提供的材料，缺失的部分不会被推测或补全。</p>
        <footer>
          <button onClick={() => backToInput(true)} type="button">补充材料</button>
          <button onClick={confirmAndStart} type="button">确认并开始 <Arrow size={16} /></button>
        </footer>
      </div>
    );
  }

  return (
    <div className={`composer new-analysis-composer mode-${mode}`}>
      {mode !== "creator" && (
        <div className="analysis-mode-switch" role="group" aria-label="核验方式">
          <button
            aria-pressed={mode === "link"}
            className={mode === "link" ? "active" : ""}
            onClick={() => { setVerifyMode("link"); setError(""); }}
            type="button"
          >
            链接核验
          </button>
          <button
            aria-pressed={mode === "manual"}
            className={mode === "manual" ? "active" : ""}
            onClick={() => { setVerifyMode("manual"); setError(""); }}
            type="button"
          >
            文案 / 图片核验
          </button>
        </div>
      )}

      {mode === "link" ? (
        <>
          <div className="new-analysis-link-fields">
            <label className="new-analysis-field">
              <span>笔记链接</span>
              <input
                aria-label="笔记链接"
                ref={noteInputRef}
                onChange={(event) => { setNoteLink(event.target.value); setError(""); }}
                onKeyDown={(event) => { if (event.key === "Enter") submit(); }}
                placeholder="粘贴公开可访问的笔记链接"
                value={noteLink}
              />
            </label>
            <label className="new-analysis-field">
              <span>作者主页链接 <small>可选，留空自动获取</small></span>
              <input
                aria-label="作者主页链接"
                onChange={(event) => { onAccountUrl(event.target.value); setError(""); }}
                onKeyDown={(event) => { if (event.key === "Enter") submit(); }}
                placeholder="留空则从笔记自动获取，用于账号可信度"
                ref={accountInputRef}
                value={accountUrl}
              />
            </label>
          </div>
        </>
      ) : mode === "manual" ? (
        <>
          <div className="new-analysis-manual">
            <label className="new-analysis-field">
              <span>文案 <small>可选</small></span>
              <textarea
                aria-label="待核验文案"
                onChange={(event) => { setManualText(event.target.value); setError(""); }}
                placeholder="粘贴需要核验的种草文案…"
                rows={4}
                value={manualText}
              />
            </label>
            <div className="new-analysis-upload">
              <input
                accept="image/jpeg,image/png,image/webp"
                hidden
                onChange={(event) => selectFile(event.target.files?.[0] ?? null)}
                ref={fileInputRef}
                type="file"
              />
              {manualFile ? (
                <span className="new-analysis-file">
                  {preview && <img alt="" src={preview} />}
                  <span><strong>{manualFile.name}</strong><small>图片将进入 R 维图像原生性分析</small></span>
                  <button aria-label="移除图片" onClick={() => selectFile(null)} type="button">×</button>
                </span>
              ) : (
                <button className="new-analysis-upload-button" onClick={() => fileInputRef.current?.click()} type="button">
                  <Icon size={18}><path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" /></Icon>
                  上传图片
                  <small>JPG / PNG / WebP</small>
                </button>
              )}
            </div>
          </div>
          <div className={`new-analysis-supplements ${supplementOpen ? "open" : ""}`}>
            <button
              aria-expanded={supplementOpen}
              className="new-analysis-supplement-toggle"
              onClick={() => setSupplementOpen((open) => !open)}
              type="button"
            >
              <span>＋ 补充评论与账号历史（可选）</span>
              <small>{supplementOpen ? "收起" : "展开"}</small>
            </button>
            {supplementOpen && (
              <div className="new-analysis-supplement-grid">
                <label className="new-analysis-field">
                  <span><b>U</b> 评论 <em>每行一条</em></span>
                  <textarea
                    aria-label="补充评论"
                    onChange={(event) => setManualComments(event.target.value)}
                    placeholder={"好用\n同敏感肌，用了一周没有刺痛，但眼周有点干"}
                    rows={4}
                    value={manualComments}
                  />
                  <div className="new-analysis-upload comment-shot-upload">
                    <input
                      accept="image/jpeg,image/png,image/webp,image/gif,image/heic"
                      aria-label="添加评论区截图"
                      hidden
                      multiple
                      onChange={(event) => { addCommentShots(Array.from(event.target.files ?? [])); event.target.value = ""; }}
                      ref={commentShotInputRef}
                      type="file"
                    />
                    <button className="new-analysis-upload-button" onClick={() => commentShotInputRef.current?.click()} type="button">
                      <Icon size={16}><path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" /></Icon>
                      添加评论区截图
                      <small>可上传评论区截图（可选）</small>
                    </button>
                    {commentShots.length > 0 && (
                      <div className="creator-preview-grid comment-shot-grid">
                        {commentShots.map((shot) => (
                          <figure key={shot.id}>
                            <img alt={shot.name} src={shot.url} />
                            <button aria-label={`删除${shot.name}`} onClick={() => removeCommentShot(shot.id)} type="button">×</button>
                          </figure>
                        ))}
                      </div>
                    )}
                    {commentShots.length > 0 && <small className="comment-shot-note">截图暂不参与评分，评论自然度只根据上方文字评论判断。</small>}
                  </div>
                </label>
                <div className="new-analysis-field account-history-form">
                  <span><b>T</b> 账号历史 <em>至少 3 篇才评估</em></span>
                  <input
                    aria-label="账号名"
                    onChange={(event) => setAccountHandle(event.target.value)}
                    placeholder="例如：护肤小账本"
                    value={accountHandle}
                  />
                  <textarea
                    aria-label="近期笔记"
                    onChange={(event) => {
                      const value = event.target.value;
                      // Old JSON pasted in: turn it back into the form when it parses, else keep it as typed.
                      const legacy = /^\s*[[{]/.test(value) ? parseAccountHistoryJson(value) : null;
                      if (legacy) {
                        if (legacy.handle && !accountHandle) setAccountHandle(legacy.handle);
                        setAccountPostsText(legacy.lines);
                        return;
                      }
                      setAccountPostsText(value);
                    }}
                    placeholder={"2026-09-01 | 换季护肤记录：最近皮肤有点干\n2026-09-05 | 空瓶记录：这瓶面霜用完了"}
                    rows={4}
                    value={accountPostsText}
                  />
                  <small className={accountHistoryPartial ? "account-history-hint warn" : "account-history-hint"}>
                    {accountHistoryPartial ? "账号历史不足 3 篇，本次不评估账号" : "每行一篇，可选日期，用 | 分隔；至少 3 篇才会评估账号可信度"}
                  </small>
                </div>
              </div>
            )}
            <div className="new-analysis-dimension-preview" aria-label="预计启用维度">
              <span>本次预计启用</span>
              {[
                ["S", Boolean(manualText.trim()), "文案"],
                ["R", Boolean(manualFile), "图片"],
                ["U", Boolean(manualComments.trim()), "评论"],
                ["T", Boolean(manualAccountHistory.trim()), "账号"],
              ].map(([code, enabled, label]) => (
                <b className={enabled ? "enabled" : ""} key={String(code)}>{code} {label}</b>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="new-analysis-creator">
          <label className="new-analysis-field">
            <span><b>01</b> 草稿文案 <em>可选</em></span>
            <textarea
              aria-label="创作者草稿文案"
              maxLength={3000}
              onChange={(event) => { setCreatorDraft(event.target.value); setError(""); }}
              placeholder="粘贴你准备发布的笔记文案…"
              rows={5}
              value={creatorDraft}
            />
          </label>
          <div className="new-analysis-upload creator-upload">
            <input
              accept="image/*"
              hidden
              multiple
              onChange={(event) => addCreatorImages(Array.from(event.target.files ?? []))}
              ref={creatorFileInputRef}
              type="file"
            />
            <button
              className="new-analysis-upload-button"
              disabled={creatorImages.length >= 9}
              onClick={() => creatorFileInputRef.current?.click()}
              type="button"
            >
              <Icon size={18}><path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" /></Icon>
              上传待发布配图
              <small>{creatorImages.length} / 9 · 首张进入 R 维</small>
            </button>
            {creatorImages.length > 0 && (
              <div className="creator-preview-grid">
                {creatorImages.map((image) => (
                  <figure key={image.id}>
                    <img alt={image.name} src={image.url} />
                    <button aria-label={`删除${image.name}`} onClick={() => removeCreatorImage(image.id)} type="button">×</button>
                  </figure>
                ))}
              </div>
            )}
          </div>
          <div className="creator-form-options">
            <label>
              <input checked={creatorCollaboration} onChange={(event) => setCreatorCollaboration(event.target.checked)} type="checkbox" />
              这篇是合作或赠品
            </label>
            <label>
              <span>品类</span>
              <select onChange={(event) => setCreatorCategory(event.target.value)} value={creatorCategory}>
                <option>护肤</option>
                <option>彩妆</option>
                <option>其他</option>
              </select>
            </label>
          </div>
        </div>
      )}

      {error && <p className="new-analysis-error">{error}</p>}
      <div className="new-analysis-actions">
        <span>
          {mode === "link"
            ? "填写笔记链接即可，作者主页留空会自动获取"
            : mode === "creator"
              ? "草稿文案与配图至少提供一项"
              : "文案与图片至少提供一项"}
        </span>
        {mode !== "creator" && (
          <button className="new-analysis-example" onClick={loadExample} type="button">载入示例</button>
        )}
        <button
          className="new-analysis-submit"
          disabled={mode === "link" ? !linkReady : mode === "creator" ? !creatorReady : !manualReady}
          onClick={submit}
          type="button"
        >
          开始核验
          <span><Arrow size={16} /></span>
        </button>
      </div>
    </div>
  );
}

function Workspace({
  accountUrl,
  creatorPreset = "",
  filename,
  initialMode = "link",
  onAccountUrl,
  onFile,
  onPickFile,
  onHome,
  onSubmitCreator,
  onSubmitLink,
  onSubmitManual,
  manualPreset = "",
  notice = "",
  preset = "",
}: {
  accountUrl: string;
  creatorPreset?: string;
  filename: string;
  initialMode?: "link" | "manual" | "creator";
  onAccountUrl: (value: string) => void;
  onFile: (name: string) => void;
  onPickFile?: (file: File | null) => void;
  onHome: () => void;
  onSubmitCreator: (input: CreatorReportInput) => void;
  onSubmitLink: (noteUrl: string, accountUrl: string, rawInput?: string) => void;
  onSubmitManual: (input: { text: string; image: File | null; comments: string; accountHistory: string }) => void;
  manualPreset?: string;
  notice?: string;
  preset?: string;
}) {
  const [workspaceMode, setWorkspaceMode] = useState<"verify" | "creator">(initialMode === "creator" ? "creator" : "verify");

  useEffect(() => {
    setWorkspaceMode(initialMode === "creator" ? "creator" : "verify");
  }, [initialMode]);

  useEffect(() => {
    if (creatorPreset) setWorkspaceMode("creator");
  }, [creatorPreset]);

  return (
    <section className="workspace">
      <div className="workspace-orb orb-left" />
      <div className="workspace-orb orb-right" />
      <header className="workspace-header">
        <div className="workspace-status-group">
          <button aria-label="返回首页" className="workspace-home" onClick={onHome} title="返回首页">
            <Icon size={22}>
              <path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </Icon>
          </button>
        </div>
        <div aria-label="核验模式" className="workspace-mode-switch">
          <button className={workspaceMode === "verify" ? "active" : ""} onClick={() => setWorkspaceMode("verify")} type="button">核验别人的笔记</button>
          <button className={workspaceMode === "creator" ? "active" : ""} onClick={() => setWorkspaceMode("creator")} type="button">我是创作者 · 发布前自检</button>
        </div>
      </header>
      <div className="workspace-center">
        <div className="agent-symbol"><Sparkle size={29} /></div>
        <p className="hello">你好，我是 TruLens</p>
        <h2>今天想鉴别什么？</h2>
        <p className="workspace-intro">上传美妆种草内容，我会从账号、图像、评论和文案四个维度寻找 AI 生成与营销造假痕迹。</p>
        <NewAnalysisForm
          accountUrl={accountUrl}
          creatorPreset={creatorPreset}
          initialMode={initialMode}
          onAccountUrl={onAccountUrl}
          onFile={onFile}
          onSubmitCreator={onSubmitCreator}
          onSubmitLink={onSubmitLink}
          onSubmitManual={onSubmitManual}
          manualPreset={manualPreset}
          notice={notice}
          preset={preset}
          workspaceMode={workspaceMode}
        />
        <div className="suggestions" />
      </div>
    </section>
  );
}

function AnalysisSteps({
  done,
  activeDimensions,
  paused,
  liveAgents,
  liveMode,
  overallScore,
  creatorMode = false,
}: {
  done: boolean;
  activeDimensions: DimensionCode[];
  paused: boolean;
  /** Backend trust_score (already rounded) for a real run; the demo derives its own. */
  overallScore?: number;
  /** 创作者发布前自检: list every expert, with the ones lacking pre-publish data shown as 未启用. */
  creatorMode?: boolean;
  /** Real per-dimension status from `/api/status`; omitted in demo mode. */
  liveAgents?: AgentStatusItem[];
  /** Suppress story-deck verdicts while a real backend run is in flight. */
  liveMode?: boolean;
}) {
  const [expandedRole, setExpandedRole] = useState<string | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const liveAgentsByCode = new Map<string, AgentStatusItem>(
    (liveAgents ?? []).map((item) => [item.code, item]),
  );
  const roles = [
    {
      code: "T",
      role: "账号侦探",
      dimension: "Trustworthiness",
      weight: 25,
      score: 82,
      verdict: "可信",
      thinking: "正在回溯 286 篇历史内容与商业合作轨迹…",
      thinkingLabels: ["我正在冷静思考", "让我核对一下", "事实不会说谎"],
      insight: "账号持续运营 2.3 年，商业内容占比 18%，身份与发布节奏稳定。",
      evidence: ["历史内容连续，无集中删帖", "商业合作均有明确标识", "互动增长曲线未见突变"],
    },
    {
      code: "R",
      role: "视觉取证师",
      dimension: "Reality",
      weight: 30,
      score: 88,
      verdict: "轻度修饰",
      thinking: "正在比对皮肤纹理、边缘结构与光影方向…",
      thinkingLabels: ["我在快速扫图", "有异常，抓到了", "我再确认一遍"],
      insight: "面中存在两处生成式细化痕迹，但产品主体与整体光影保持真实。",
      evidence: ["局部毛孔纹理重复", "产品边缘连续自然", "环境光线方向一致"],
    },
    {
      code: "U",
      role: "口碑观察员",
      dimension: "User Voice",
      weight: 20,
      score: 74,
      verdict: "需留意",
      thinking: "正在聚类评论语义、发布时间与互动关系…",
      thinkingLabels: ["我在听大家说", "我在头脑风暴中", "慢慢拼出共识"],
      insight: "12% 的短评存在相似句式，其余评论具有具体问题与真实讨论特征。",
      evidence: ["有效评论 168 条", "同质短评占比 12%", "未发现批量账号联动"],
    },
    {
      code: "S",
      role: "宣传安全官",
      dimension: "Safety",
      weight: 25,
      score: 91,
      verdict: "安全",
      thinking: "正在核验功效承诺、广告表达与风险边界…",
      thinkingLabels: ["正在严谨审阅", "我按规范核验", "准备出具意见"],
      insight: "未发现绝对化功效承诺，合作标识清晰，个人体验边界完整。",
      evidence: ["无医疗功效宣称", "包含个体差异说明", "品牌合作标识清晰"],
    },
  ];
  const activeRoles = roles
    .filter((item) => activeDimensions.includes(item.code as DimensionCode))
    .map((item) => {
      // Live scores override the demo ones as soon as /api/status reports them.
      // `assessed: null` => no live data yet (keep the story-deck animation);
      // `false` => the backend ran the dimension but had nothing to judge, so
      // the card must read "暂不评分" instead of showing a number.
      const live = liveAgentsByCode.get(item.code);
      if (!live) return { ...item, assessed: null as boolean | null };
      if (!live.assessed || live.trust_score == null) {
        return { ...item, assessed: false as boolean | null, verdict: "暂不评分" };
      }
      return {
        ...item,
        assessed: true as boolean | null,
        score: Math.round(live.trust_score),
        verdict: live.trust_label ?? item.verdict,
      };
    });
  const scoredRoles = activeRoles.filter((item) => item.assessed !== false);
  const activeWeightTotal = activeRoles.reduce((total, item) => total + item.weight, 0);
  const analysisScore = overallScore ?? Math.round(
    scoredRoles.reduce((total, item) => total + item.score, 0) / (scoredRoles.length || 1),
  );
  // A real run weighs only the dimensions the backend actually assessed.
  const weightedRoles = liveMode && done ? activeRoles.filter((item) => item.assessed === true) : activeRoles;
  const weightedTotal = weightedRoles.reduce((total, item) => total + item.weight, 0) || 1;
  const assessedCodes = activeRoles.filter((item) => item.assessed === true).map((item) => item.code);
  const dimensionWord = ["", "单", "双", "三", "四"][activeRoles.length];
  const disabledRoles = creatorMode ? roles.filter((item) => !activeDimensions.includes(item.code as DimensionCode)) : [];
  const disabledReason = (code: string) =>
    code === "T" || code === "U" ? "发布前暂无账号互动与评论数据，未启用" : code === "R" ? "未提供待发布配图，未启用" : "未提供文案，未启用";

  useEffect(() => {
    if (done || paused) return;
    const timer = window.setInterval(() => {
      setElapsedSeconds((current) => Math.min(10, current + 0.1));
    }, 100);
    return () => window.clearInterval(timer);
  }, [done, paused]);

  const thinkingStage = Math.min(2, Math.floor(elapsedSeconds / 1.8));
  const reasoningStage = done ? 4 : Math.min(4, Math.floor(elapsedSeconds / 2));
  const reasoningFlow = [
    [`调用${activeRoles.length}个分析视角`, `正在唤醒 ${activeRoles.map((item) => item.code).join(" / ")} 分析角色`],
    [`生成${dimensionWord}维评分`, "正在校准各维度分数与证据权重"],
    ["发现关键风险", "正在定位可能改变消费判断的核心风险"],
    ["内部推理", "Reasoning · 正在消解不同证据之间的冲突"],
    ["生成最终报告", "正在组织可解释结论与决策依据"],
  ];
  const debateMessages = [
    ["T", "账号侦探", "提出判断", "账号轨迹稳定，现有证据不支持系统性造假。"],
    ["R", "视觉取证师", "提出异议", "我不同意完全放行。两处生成式修饰必须降低图像证据权重。"],
    ["U", "口碑观察员", "补充证据", "评论里确有相似话术，但多数反馈具体，暂不足以否定整篇内容。"],
    ["S", "宣传安全官", "形成裁定", "综合各方证据，建议保留风险说明后判定为高可信。"],
  ];
  const activeDebateMessages = debateMessages.filter(([code]) => activeDimensions.includes(code as DimensionCode));
  const debateDuration = 4 / activeDebateMessages.length;
  const debateIndex = Math.min(activeDebateMessages.length - 1, Math.floor(Math.max(0, elapsedSeconds - 4) / debateDuration));
  const activeDebate = activeDebateMessages[debateIndex];
  const debateFocus = activeDimensions.includes("R")
    ? "图像修饰是否足以改变宣传安全维度的判断？"
    : activeDimensions.includes("U")
      ? "评论异常是否足以推翻文案本身的安全性？"
      : "账号历史信号与当前宣传表达是否相互一致？";

  return (
    <div className={`trus-council ${done ? "is-complete" : "is-thinking"} ${paused ? "is-paused" : ""}`}>
      <div className="council-header">
        <div className="council-avatars">
          {activeRoles.map((item) => (
            <span className={`council-avatar role-${item.code.toLowerCase()}`} key={item.code}>
              <img alt="" src={roleAvatarByCode[item.code as DimensionCode]} />
              <i>{item.code}</i>
            </span>
          ))}
        </div>
        <div className="council-title">
          <span>TRUS REASONING COUNCIL</span>
          <strong>你的 AI 信任评审团正在讨论</strong>
          <small>{done ? `${activeRoles.length} 个角色已完成验证，点击角色查看证据` : `${activeRoles.length} 个角色正在分析当前输入`}</small>
        </div>
        <div className="council-state">
          <i />
          {done ? `${activeRoles.length} / ${activeRoles.length} 完成 · ${elapsedSeconds.toFixed(1)} 秒` : paused ? `已暂停 · ${elapsedSeconds.toFixed(1)} 秒` : `已思考 ${elapsedSeconds.toFixed(1)} 秒`}
        </div>
      </div>

      <div className="reasoning-flow">
        <div className="reasoning-flow-steps">
          {reasoningFlow.map(([label], index) => (
            <div
              className={index < reasoningStage || done ? "completed" : index === reasoningStage ? "active" : ""}
              key={label}
            >
              <span>{index < reasoningStage || done ? "✓" : index + 1}</span>
              <small>{label}</small>
            </div>
          ))}
        </div>
        <p key={reasoningStage}>
          <Sparkle size={13} />
          {done ? "推理链已完成，最终报告已生成" : reasoningFlow[reasoningStage][1]}
        </p>
      </div>

      <div className="council-columns">
        <span>分析视角与观点</span>
        <span>权重</span>
        <span>判断</span>
      </div>

      <div className="council-roles">
        {activeRoles.map((item, index) => (
          <div className={`council-role-wrap ${expandedRole === item.code ? "expanded" : ""}`} key={item.code}>
            <button
              className={`council-role role-${item.code.toLowerCase()}`}
              onClick={() => setExpandedRole((current) => current === item.code ? null : item.code)}
              style={{ "--role-delay": `${index * 120}ms` } as React.CSSProperties}
            >
              <span className="role-persona">
                <span className="role-avatar">
                  <img alt={`${item.role}角色`} src={roleAvatarByCode[item.code as DimensionCode]} />
                  <i>{item.code}</i>
                </span>
                <span>
                  <strong>{item.code === "S" ? "文案检查官" : item.role}</strong>
                  <small>{item.code === "S" ? "Script" : item.dimension}</small>
                  <p>{done ? liveMode ? "该维度已完成，证据与结论见完整报告。" : item.insight : item.thinking}</p>
                </span>
              </span>
              <span className="role-weight">{Math.round((item.weight / activeWeightTotal) * 100)}%</span>
              <span className="role-judgement">
                {liveMode && item.assessed === null ? (
                  <><i /><small>核验中</small></>
                ) : done ? (
                  <><strong>{item.assessed === false ? "—" : item.score}</strong><small>{item.verdict}</small></>
                ) : reasoningStage >= 1 ? (
                  <><strong>{item.assessed === false ? "—" : item.score}</strong><small>{item.thinkingLabels[thinkingStage]}</small></>
                ) : (
                  <><i /><small>{item.thinkingLabels[thinkingStage]}</small></>
                )}
              </span>
              <span className="role-chevron">⌄</span>
            </button>
            <div className="role-progress"><i style={{ "--role-score": `${liveMode && item.assessed === null ? 0 : item.assessed === false ? 0 : item.score}%` } as React.CSSProperties} /></div>
            {expandedRole === item.code && (
              <div className="role-evidence">
                <span>证据链</span>
                {item.evidence.map((evidence) => <p key={evidence}>✓ {evidence}</p>)}
              </div>
            )}
          </div>
        ))}
        {disabledRoles.map((item) => (
          <div className="council-role-wrap council-role-disabled" key={item.code}>
            <div aria-disabled="true" className={`council-role role-${item.code.toLowerCase()}`}>
              <span className="role-persona">
                <span className="role-avatar">
                  <img alt={`${item.role}角色`} src={roleAvatarByCode[item.code as DimensionCode]} />
                  <i>{item.code}</i>
                </span>
                <span>
                  <strong>{item.role}</strong>
                  <small>{item.dimension}</small>
                  <p>{disabledReason(item.code)}</p>
                </span>
              </span>
              <span className="role-weight">—</span>
              <span className="role-judgement"><strong>—</strong><small>未启用</small></span>
            </div>
          </div>
        ))}
      </div>

      {!liveMode && reasoningStage >= 2 && reasoningStage < 4 && activeDebateMessages.length > 1 && (
        <div className="expert-debate">
          <div className="debate-header">
            <span><i /> EXPERT DISCUSSION</span>
            <div className="debate-cast">
              {activeDebateMessages.map(([code], index) => (
                <i className={index === debateIndex ? "active" : index < debateIndex ? "heard" : ""} key={code}>
                  {code}
                </i>
              ))}
            </div>
            <small>{debateIndex + 1} / {activeDebateMessages.length}</small>
          </div>
          <div className={`debate-message role-${activeDebate[0].toLowerCase()}`} key={debateIndex}>
            <span className="debate-avatar">
              <img alt={`${activeDebate[1]}头像`} src={roleAvatarByCode[activeDebate[0] as DimensionCode]} />
              <i>{activeDebate[0]}</i>
            </span>
            <div>
              <span><strong>{activeDebate[1]}</strong><small>{activeDebate[2]}</small></span>
              <p>“{activeDebate[3]}”</p>
            </div>
          </div>
          <div className="debate-focus">
            <span>争议焦点</span>
            {debateFocus}
          </div>
        </div>
      )}

      {!liveMode && reasoningStage >= 2 && reasoningStage < 4 && activeDebateMessages.length === 1 && (
        <div className="reasoning-finding stage-3">
          <span>INDEPENDENT REVIEW</span>
          <p>{activeDebate[3]}</p>
        </div>
      )}

      {reasoningStage >= 4 && (!liveMode || done) && (
        <div className="debate-consensus">
          <span><Sparkle size={13} /> {creatorMode && disabledRoles.length ? `${activeRoles.length} 位专家完成，${disabledRoles.length} 位未启用` : activeRoles.length > 1 ? `${activeRoles.length} 位专家达成共识` : `${activeRoles[0].role}完成独立审查`}</span>
          <p>
            {liveMode && done
              ? `本次结论仅基于已评估的维度（${assessedCodes.join(" / ") || "无"}）；未评估的维度不计入加权。`
              : activeRoles.length > 1 ? "已结合当前可用模态完成交叉验证，并生成对应维度的可信度报告。" : "当前输入仅支持单维度判断，报告会明确标注证据范围。"}
          </p>
        </div>
      )}

      <div className="council-result">
        <div>
          {weightedRoles.map((item, index) => (
            <span key={item.code}>
              {index > 0 && (item.code === "R" ? <span className="fg-inline-italic">+</span> : <i>+</i>)}
              <span>{item.code} {liveMode && done ? Math.round((item.weight / weightedTotal) * 100) : item.code === "R" || item.code === "U" ? 25 : Math.round((item.weight / activeWeightTotal) * 100)}%</span>
            </span>
          ))}
        </div>
        <div>
          <small>{done ? "加权结果" : `等待交叉验证 · ${elapsedSeconds.toFixed(1)}s`}</small>
          {done ? <><strong>{analysisScore}</strong><span>{analysisScore >= 80 ? "高可信" : "需留意"}</span></> : <span className="council-loading"><i /><i /><i /></span>}
        </div>
      </div>
    </div>
  );
}

const initialQuickFollowups = [
  "哪些图片区域可能经过 AI 修饰？",
  "评论区有哪些异常话术？",
  "这个博主长期可信吗？",
  "我该购买吗",
];

const appealPrompt = "我想申诉或辩解当前核验结论";
const appealOptions: Array<{
  code: DimensionCode;
  label: string;
  role: string;
  reply: string;
}> = [
  {
    code: "R",
    label: "视觉取证不准",
    role: "视觉专家",
    reply: "收到您的申诉！视觉专家 R 正在重新对该区域进行局部像素频域分析……正在剥离环境光影干扰……请稍候。",
  },
  {
    code: "T",
    label: "账号侦测误判",
    role: "账号专家",
    reply: "收到您的申诉！账号专家 T 正在重新回溯主页简介、历史动态与商业合作轨迹……正在排除账号成长周期带来的误判……请稍候。",
  },
  {
    code: "U",
    label: "评论区误伤",
    role: "评论专家",
    reply: "收到您的申诉！评论专家 U 正在重新聚类评论句式、发布时间与互动关系……正在区分真实共鸣与协同传播……请稍候。",
  },
  {
    code: "S",
    label: "文案检查误判",
    role: "文案专家",
    reply: "收到您的申诉！文案专家 S 正在重新核对原文语境、体验边界与功效主张……正在排除修辞表达造成的误判……请稍候。",
  },
];

function getInitialQuickFollowups(activeDimensions: DimensionCode[]) {
  if (activeDimensions.length === 1) {
    return ["文案中有哪些夸大表达？", "是否存在绝对化宣传？", "这段文案足以支持决策吗？", "还需要补充什么证据？"];
  }
  if (activeDimensions.includes("U")) {
    return ["哪些评论最像批量生成的？", "评论与文案结论一致吗？", "真实用户主要在讨论什么？", "评论区整体可信吗？"];
  }
  if (activeDimensions.includes("T")) {
    return ["这个博主长期可信吗？", "商业合作比例高吗？", "历史内容有没有异常？", "账号与文案是否一致？"];
  }
  return ["哪些图片区域可能经过 AI 修饰？", "图片与文案结论一致吗？", "有没有整图生成痕迹？", "当前证据足够可信吗？"];
}

function getNextQuickFollowups(question?: string) {
  if (!question) return initialQuickFollowups;
  if (question.includes("图片区域") || question.includes("AI 修饰")) {
    return [
      "这些修饰会影响产品效果判断吗？",
      "能进一步解释脸颊区域的异常吗？",
      "这是普通美化还是 AI 造假？",
      "我还需要查看哪些原图？",
    ];
  }
  if (question.includes("效果") || question.includes("美化") || question.includes("原图")) {
    return [
      "这项图像风险会如何影响帖子可信度？",
      "如果图片可信度降低，我该如何决策？",
      "哪些证据能够抵消这项风险？",
      "评论是否支持图片中的结论？",
    ];
  }
  if (question.includes("评论") || question.includes("话术")) {
    return [
      "哪些评论最像批量生成的？",
      "真实用户主要在意什么问题？",
      "评论异常会影响可信分吗？",
      "结合图片给我最终建议",
    ];
  }
  if (question.includes("博主") || question.includes("账号")) {
    return [
      "她的商业合作比例高吗？",
      "历史内容有没有前后矛盾？",
      "哪些账号行为值得警惕？",
      "结合本篇内容给出可信结论",
    ];
  }
  if (question.includes("购买") || question.includes("最终建议") || question.includes("相差")) {
    return [
      "哪些证据最影响这次购买决定？",
      "如果只看可信度，我该如何选择？",
      "当前还缺少什么关键证据？",
      "帮我总结这次决策的风险等级",
    ];
  }
  return [
    "这条证据的置信度是多少？",
    "还有其他风险需要注意吗？",
    "它会如何影响购买决定？",
    "帮我总结当前结论",
  ];
}

function ContextualFollowupAnswer({ question }: { question: string }) {
  let title = "已结合当前报告继续核验";
  let answer = "这条新问题与已有的账号、图像、评论和文案证据进行了交叉验证。目前没有出现足以推翻原结论的新风险信号。";
  let facts = ["与原始证据一致", "未发现新增高风险项", "综合可信度保持稳定"];

  if (question.includes("影响产品效果")) {
    title = "会影响对遮瑕力的判断，但不影响色号参考";
    answer = "AI 细化主要抹平了面中毛孔和轻微卡粉，因此画面会高估底妆的柔焦与遮瑕表现。产品色号、光泽方向和整体服帖度没有明显被改变。";
    facts = ["遮瑕表现可能被高估", "色号参考仍有效", "建议查看 4 小时持妆图"];
  } else if (question.includes("脸颊区域")) {
    title = "异常来自过度均匀的高频皮肤纹理";
    answer = "真实皮肤的毛孔、绒毛和细小纹理通常具有随机变化；该区域出现重复频率和方向高度一致的纹理，同时没有对应的光影起伏。";
    facts = ["纹理周期重复", "毛孔方向一致", "缺少自然光影起伏"];
  } else if (question.includes("普通美化") || question.includes("AI 造假")) {
    title = "更接近 AI 辅助美化，而非整图造假";
    answer = "人物结构、产品边缘和环境光线都保持连续，异常只集中在局部皮肤纹理。这说明工具可能用于精修肤质，而不是重新生成产品效果。";
    facts = ["主体结构真实", "局部生成式精修", "未改变产品形态"];
  } else if (question.includes("哪些原图") || question.includes("确认什么")) {
    title = "优先补充三类未经精修的证据";
    answer = "自然光近景、四小时后的持妆图，以及包含鼻翼与下颌边缘的视频帧，最能验证遮瑕、卡粉和真实皮肤纹理。";
    facts = ["自然光近景", "四小时持妆图", "连续视频原帧"];
  } else if (question.includes("评论")) {
    title = "评论区存在少量同质话术，但未形成批量水评";
    answer = "约 12% 的短评使用了相似的情绪词和购买号召，发布时间也较集中；其余评论包含肤质差异、使用时长和具体问题，整体仍有真实讨论特征。";
    facts = ["相似短评 12%", "真实提问占多数", "未发现大规模账号联动"];
  } else if (question.includes("帖子可信度") || question.includes("图像风险")) {
    title = "图像证据折损会降低结论强度，但不会让整篇帖子失信";
    answer = "当前图像维度的异常只影响视觉展示证据，账号轨迹、评论结构和文案安全性仍提供独立支持。因此综合可信度会小幅下降，而不是直接变成“不可信”。";
    facts = ["视觉证据权重下降", "其他模态仍可验证", "综合结论保持中高可信"];
  } else if (
    question.includes("购买") ||
    question.includes("决策") ||
    question.includes("风险等级") ||
    question.includes("只看可信度") ||
    question.includes("关键证据")
  ) {
    title = "帖子可以作为参考，但不足以单独支持购买决定";
    answer = "账号历史和文本表达提供了正向可信信号，局部图像修饰则降低了展示证据的可靠性。更稳妥的决策方式，是把这篇帖子作为一个信息来源，并等待其他独立内容对关键结论形成交叉验证。";
    facts = ["整体可信度较高", "图像证据存在折损", "需要独立来源交叉验证"];
  }

  return (
    <div className="contextual-answer">
      <span className="contextual-answer-tag">FOLLOW-UP INSIGHT</span>
      <strong>{title}</strong>
      <p>{answer}</p>
      <div>{facts.map((fact) => <span key={fact}>✓ {fact}</span>)}</div>
    </div>
  );
}

function ArgueReviewFlow({
  evidenceName,
  explanation,
  onArchive,
  onViewReport,
  option,
  recordOnly = false,
  baseScore,
  scopeCodes,
  creatorMode = false,
}: {
  evidenceName: string;
  explanation: string;
  onArchive: (score: number) => void;
  onViewReport: (score: number) => void;
  option: (typeof appealOptions)[number];
  /**
   * Real (link) run: the appeal is only recorded — nothing is recomputed, so the score
   * stays at the backend's trust_score and the copy must not claim a re-analysis.
   */
  recordOnly?: boolean;
  baseScore?: number;
  /** Dimensions the run actually assessed (record-only mode shows just these experts). */
  scopeCodes?: DimensionCode[];
  /** 创作者发布前自检: the appeal is about a self-check score. */
  creatorMode?: boolean;
}) {
  const [stage, setStage] = useState(0);
  const [archived, setArchived] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const accepted = !recordOnly && (option.code === "R" || option.code === "S");
  const oldScore = recordOnly && baseScore != null ? baseScore : 84;
  const newScore = recordOnly ? oldScore : option.code === "R" ? 93 : option.code === "S" ? 90 : oldScore;
  const castCodes: DimensionCode[] = recordOnly && scopeCodes?.length ? scopeCodes : ["T", "R", "U", "S"];
  const decisionCopy = recordOnly
    ? creatorMode
      ? "已记录你的申诉与补充材料，自检分数维持原样，建议结合证据人工复核。"
      : "已记录你的申诉与补充材料，综合分维持原样，建议结合证据人工复核。"
    : option.code === "R"
    ? "感谢纠错，经二次复核，该区域确系环境强反光与底妆高光叠加，并非 AI 生成式修饰。我们已降低原异常信号权重，并对视觉取证结论作出修正。"
    : option.code === "S"
      ? "感谢补充。结合完整上下文后，原文属于个人体验描述而非确定性功效承诺，文案风险等级已下调。"
      : option.code === "U"
        ? "您的申诉部分成立：部分短评可能来自真实用户的品牌共识，但评论区仍存在明显的同质化传播痕迹，因此综合信任分维持原样，建议重点关注评论风险。"
        : "您的申诉部分成立：账号的高关注数不足以单独证明互关增长，但历史内容中的产品推荐密度依然较高，因此综合信任分维持原样，并优化账号风险提示。";
  const thinkingLabels = recordOnly ? [
    `已接收针对${option.role} ${option.code} 的申诉材料`,
    "已记录申诉理由，正在整理复核材料",
    `正在汇总 ${castCodes.join(" / ")} 的原始证据，供人工复核参考`,
    "正在核对申诉理由与原始证据的对应关系",
    "申诉记录已生成，原始结论保持不变",
  ] : [
    `正在仅调用 ${option.role} ${option.code} 接收申诉材料`,
    `${option.role} ${option.code} 正在独立重检争议证据`,
    "单维复核完成，T / R / U / S 圆桌会议已启动",
    "四位专家正在交换反证并重新校准权重",
    "圆桌会诊结束，重新评估报告已生成",
  ];

  useEffect(() => {
    if (stage >= 4) return;
    const timer = window.setTimeout(() => setStage((current) => current + 1), stage >= 2 ? 1700 : 1300);
    return () => window.clearTimeout(timer);
  }, [stage]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [stage]);

  return (
    <div className="argue-consultation">
      <div className="argue-consultation-head">
        <div>
          <span>{recordOnly ? "ARGUE RECORD · 申诉记录" : "ARGUE COUNCIL · 重新会诊"}</span>
          <strong>
            {recordOnly
              ? stage < 4 ? `正在记录针对“${option.label}”的申诉` : "申诉记录已生成"
              : stage < 2 ? `${option.role}正在单独复核“${option.label}”` : stage < 4 ? "四位专家正在进行圆桌会议" : "重新评估报告已生成"}
          </strong>
          {explanation && <small>用户补充：“{explanation}”</small>}
          {evidenceName && <small>新增证据：{evidenceName}</small>}
        </div>
        <span className="argue-live"><i /> {stage < 4 ? (recordOnly ? "整理中" : "会诊中") : "已完成"}</span>
      </div>

      <div className="argue-council-cast">
        {castCodes.map((code) => (
          <span className={`${code === option.code ? "lead" : ""} ${code === option.code || stage >= 2 ? "active" : ""}`} key={code}>
            <img alt={`${code} 专家`} src={roleAvatarByCode[code]} />
            <i>{code}</i>
          </span>
        ))}
        <div>
          <span>{thinkingLabels[stage]}</span>
          <small>{Math.min(100, 18 + stage * 22)}% · {recordOnly ? "正在整理复核材料" : "正在重新计算证据权重"}</small>
        </div>
      </div>

      <div className="argue-thinking-flow">
        {(recordOnly ? ["接收申诉材料", "整理复核材料", "汇总原始证据", "生成申诉记录"] : ["专属专家接单", "单维证据复核", "四专家圆桌会议", "生成重评报告"]).map((label, index) => (
          <span className={stage > index ? "complete" : stage === index ? "active" : ""} key={label}>
            <i>{stage > index ? "✓" : index + 1}</i>{label}
          </span>
        ))}
      </div>

      {stage >= 1 && (
        <div className={`argue-expert-feedback role-${option.code.toLowerCase()}`}>
          <span>
            <img alt={`${option.role} ${option.code}`} src={roleAvatarByCode[option.code]} />
            <i>{option.code}</i>
          </span>
          <div>
            <small>{option.role} · {recordOnly ? "申诉材料已记录" : "单专家二次取证"}</small>
            <p>{recordOnly ? `收到您的申诉，已记录申诉理由${evidenceName ? "与补充证据" : ""}，正在整理复核材料。本次不会重新运行模型，原始结论与分数保持不变。` : option.reply}</p>
          </div>
        </div>
      )}

      {stage >= 2 && stage < 4 && (
        <div className="argue-roundtable-note">
          <span><Sparkle size={13} /> ROUND TABLE</span>
          <p>
            {recordOnly
              ? `申诉材料已与 ${castCodes.join(" / ")} 的原始证据放在一起，供人工复核时对照；综合分不会因此自动变化。`
              : "专项复核结果已提交圆桌。T / R / U / S 正在从账号、图像、评论与文案四个维度重新评估其对综合信任分的影响。"}
          </p>
        </div>
      )}

      {stage >= 4 && (
        <div className={`argue-final-decision ${accepted ? "accepted" : "partial"}`}>
          <header>
            <div>
              <span>{recordOnly ? "申诉记录 · 待人工复核" : `重新评估报告 · ${accepted ? "申诉已采纳" : "申诉部分成立"}`}</span>
              <strong>{recordOnly ? (creatorMode ? "自检分数维持原样，申诉已记录" : "综合分维持原样，申诉已记录") : accepted ? "AI 已修正原核验结论" : "保留原分数，风险提示已优化"}</strong>
            </div>
            <div className="argue-score-change">
              <span>{oldScore}</span><i>→</i><strong>{newScore}</strong><small>/100</small>
            </div>
          </header>
          <p>{decisionCopy}</p>
          <div className="argue-decision-meta">
            <span>{recordOnly ? `申诉维度 ${option.code} · ${option.label}` : `复核编号 TL-A-${option.code}-0618`}</span>
            <span>原始报告与申诉过程已保留</span>
          </div>
          <div className="argue-final-actions">
            <button
              className={archived ? "archived" : ""}
              disabled={archived}
              onClick={() => {
                setArchived(true);
                onArchive(newScore);
              }}
            >
              {archived ? "✓ 已保存到报告库" : "保存到报告库"}
              {!archived && <Arrow size={16} />}
            </button>
            <button className="view-revised-report" onClick={() => onViewReport(newScore)}>
              {recordOnly ? "查看核验报告" : "查看新报告"} <Arrow size={16} />
            </button>
          </div>
        </div>
      )}
      <div ref={endRef} />
    </div>
  );
}

/**
 * One readable sentence for a failed run. The backend joins a prefix and a reason
 * ("无法识别的链接：无法识别的链接，…"), so never show it verbatim.
 */
/** Backend `assessed_dimensions` uses agent keys (account/image/comment/text); map to T/R/U/S. */
function assessedDimensionCodes(keys: readonly string[] | undefined): DimensionCode[] {
  const byKey: Record<string, DimensionCode> = { account: "T", image: "R", comment: "U", comments: "U", text: "S", T: "T", R: "R", U: "U", S: "S" };
  return allDimensions.filter((code) => (keys ?? []).some((key) => byKey[key] === code));
}

function friendlyLiveError(raw: string): { message: string; fallback: boolean } {
  if (/抓取失败|无法抓取|抓取超时|抓取无法启动|没有返回结果|未取到正文|安全限制|登录/.test(raw)) {
    return { message: "暂时无法获取该链接内容，可以复制笔记文案和图片，使用「文案 / 图片核验」。", fallback: true };
  }
  if (/请求失败 \(5\d\d\)|无法连接后端|network_error/.test(raw)) {
    return { message: "暂时无法连接核验服务，请稍后点击「重试」。", fallback: false };
  }
  if (/无法识别的账号主页链接/.test(raw)) return { message: "作者主页链接无法识别，请粘贴 xiaohongshu.com/user/profile/… 或 xhslink 开头的主页链接，或留空由系统自动获取。", fallback: false };
  if (/无法识别的链接|链接为空/.test(raw)) return { message: "链接无法识别：请粘贴小红书笔记链接（xiaohongshu.com 或 xhslink.com 开头），或直接粘贴整段分享内容。", fallback: true };
  if (/账号主页链接需要与笔记链接一起使用/.test(raw)) return { message: "作者主页链接需要与笔记链接一起使用，请填写笔记链接。", fallback: false };
  const parts = raw.split(/[：:]/);
  const deduped = parts.length > 1 && parts[1].startsWith(parts[0]) ? parts.slice(1).join("：") : raw;
  return { message: `核验未完成：${deduped}`, fallback: false };
}

function Chat({
  prompt,
  filename,
  isExampleSubmission,
  activeDimensions,
  live,
  onArchiveReport,
  onFile,
  onHome,
  onResult,
  onTechnicalViewChange,
  onUseManual,
  onViewRevisedReport,
  appealRecordOnly = false,
  creatorMode = false,
  appealPreset = null,
  onAppealSubmitted,
  technicalView,
}: {
  prompt: string;
  filename: string;
  isExampleSubmission: boolean;
  activeDimensions: DimensionCode[];
  /** The real pipeline run. When absent the scripted demo animation plays alone. */
  live?: LiveRun;
  onArchiveReport: (score: number) => void;
  onFile: (name: string) => void;
  onHome: () => void;
  onResult: () => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  /** Switch to 文案 / 图片核验, carrying whatever text is worth keeping. */
  onUseManual?: (text: string) => void;
  onViewRevisedReport: (score: number) => void;
  /** Real backend run (link or 文案 / 图片): appeals are recorded only, never "recomputed". */
  appealRecordOnly?: boolean;
  /** 创作者发布前自检: same page, creator copy, T/U shown as 未启用, no appeal. */
  creatorMode?: boolean;
  /** Open the appeal right away with this dimension / explanation pre-filled (「我有异议」). */
  appealPreset?: { code: DimensionCode; text: string; issueId?: string; nonce: number } | null;
  onAppealSubmitted?: (appeal: { code: DimensionCode; issueId?: string }) => void;
  technicalView: boolean;
}) {
  const [done, setDone] = useState(false);
  // Creator self-check plays the expert animation for at least this long, even when
  // checkCreator answers sooner; a slower answer simply keeps the 「等待结果」 state.
  const CREATOR_MIN_ANIMATION_MS = 4500;
  const chatMountedAtRef = useRef(Date.now());
  const readyAtChatMountRef = useRef(Boolean(live?.phase === "done" && live.report));
  const [paused, setPaused] = useState(false);
  const [quickPrompt, setQuickPrompt] = useState("");
  const [followups, setFollowups] = useState<Array<{ id: number; question: string; answered: boolean; detail?: string; evidenceName?: string }>>([]);
  const [appealDraftCode, setAppealDraftCode] = useState<DimensionCode | null>(null);
  const [appealExplanation, setAppealExplanation] = useState("");
  const [appealEvidenceName, setAppealEvidenceName] = useState("");
  const [shareOpen, setShareOpen] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const replyTimerRef = useRef<number | null>(null);
  const analysisRemainingRef = useRef(10000);
  const analysisStartedAtRef = useRef(0);
  const followupRemainingRef = useRef(1100);
  const followupStartedAtRef = useRef(0);
  const latestFollowup = followups[followups.length - 1];
  const hasAppealed = followups.some((followup) => followup.question === appealPrompt);
  const recordOnlyAppeal = Boolean(appealRecordOnly && live?.report);
  const assessedCodes = assessedDimensionCodes(live?.report?.assessed_dimensions);
  const visibleAppealOptions = recordOnlyAppeal ? appealOptions.filter((option) => assessedCodes.includes(option.code)) : appealOptions;
  const selectedAppeal = appealOptions.find((option) =>
    followups.some((followup) => followup.question === option.label),
  );
  const isGenerating = !done || Boolean(latestFollowup && !latestFollowup.answered);
  const isArgueFlow = hasAppealed && (!latestFollowup || latestFollowup.question === appealPrompt || Boolean(selectedAppeal));
  const quickFollowups = isArgueFlow
    ? []
    : latestFollowup && !latestFollowup.answered
    ? []
    : latestFollowup
      ? getNextQuickFollowups(latestFollowup.question)
      : getInitialQuickFollowups(activeDimensions);
  const expertNames: Record<DimensionCode, string> = {
    T: "账号侦探",
    R: "视觉取证师",
    U: "口碑观察员",
    S: "宣传安全官",
  };
  const scoreByDimension: Record<DimensionCode, number> = { T: 82, R: 88, U: 74, S: 91 };
  const liveAgents = live?.agents ?? [];
  const liveAgentsByCode = new Map<string, AgentStatusItem>(
    liveAgents.map((item) => [item.code, item]),
  );
  const liveReport = live?.report ?? null;
  const liveReady = Boolean(live?.phase === "done" && liveReport);
  const liveActive = Boolean(live && live.phase !== "idle");
  const liveFailed = live?.phase === "error";
  const processStage = done ? 3 : liveAgents.length ? 2 : 1;
  // The real verdict wins the moment it exists; until then the demo numbers keep
  // the animation populated so nothing renders empty while polling.
  const analysisScore = liveReport
    ? Math.round(liveReport.trust_score)
    : Math.round(activeDimensions.reduce((total, code) => total + scoreByDimension[code], 0) / activeDimensions.length);
  const analysisSummary = liveReport
    ? `可信度 ${Math.round(liveReport.trust_score)}/100 · ${liveReport.trust_label}（已核验 ${liveReport.assessed_dimensions.length}/4 个维度）`
    : activeDimensions.includes("R")
      ? "图像主体可信，但存在轻度 AI 修饰痕迹"
      : activeDimensions.includes("U")
        ? "评论整体可参考，但存在少量相似话术"
        : activeDimensions.includes("T")
          ? "账号轨迹稳定，宣传表达未见明显风险"
          : "文案表达整体安全，未见高风险宣传承诺";
  useEffect(() => {
    // A real backend run owns completion. The scripted countdown is only for
    // the static fallback, otherwise it would reveal demo scores while the
    // actual evidence pipeline is still running.
    if (liveActive || paused || done) return;
    analysisStartedAtRef.current = Date.now();
    const timer = window.setTimeout(() => {
      analysisRemainingRef.current = 0;
      setDone(true);
    }, analysisRemainingRef.current);
    return () => {
      window.clearTimeout(timer);
      analysisRemainingRef.current = Math.max(
        0,
        analysisRemainingRef.current - (Date.now() - analysisStartedAtRef.current),
      );
    };
  }, [liveActive, paused, done]);

  useEffect(() => {
    // The real pipeline finished: end the scripted animation immediately and
    // jump to the report instead of waiting out the remaining demo time.
    if (!liveReady) return;
    // Stay on this page: the score card below offers 「查看核验结果」, and only that
    // click opens the report.
    analysisRemainingRef.current = 0;
    // Coming back from the report (result already there at mount) shows the score at once.
    const wait = creatorMode && !readyAtChatMountRef.current ? Math.max(0, CREATOR_MIN_ANIMATION_MS - (Date.now() - chatMountedAtRef.current)) : 0;
    if (!wait) {
      setDone(true);
      return;
    }
    const timer = window.setTimeout(() => setDone(true), wait);
    return () => window.clearTimeout(timer);
  }, [liveReady]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [done, followups]);

  useEffect(() => {
    if (!latestFollowup || latestFollowup.answered || paused) return;
    const followupId = latestFollowup.id;
    followupStartedAtRef.current = Date.now();
    replyTimerRef.current = window.setTimeout(() => {
      followupRemainingRef.current = 0;
      setFollowups((current) =>
        current.map((item) => item.id === followupId ? { ...item, answered: true } : item),
      );
    }, followupRemainingRef.current);
    return () => {
      if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current);
      followupRemainingRef.current = Math.max(
        0,
        followupRemainingRef.current - (Date.now() - followupStartedAtRef.current),
      );
    };
  }, [latestFollowup, paused]);

  const sendFollowup = (question: string, detail?: string, evidenceName?: string) => {
    const cleanQuestion = question.trim();
    if (!cleanQuestion || (latestFollowup && !latestFollowup.answered)) return;
    if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current);
    setQuickPrompt("");
    setPaused(false);
    followupRemainingRef.current = 1100;
    const id = Date.now();
    setFollowups((current) => [...current, { id, question: cleanQuestion, answered: false, detail, evidenceName }]);
  };

  const appliedPresetRef = useRef<number | null>(null);
  useEffect(() => {
    if (!appealPreset || !done || appliedPresetRef.current === appealPreset.nonce) return;
    appliedPresetRef.current = appealPreset.nonce;
    if (!hasAppealed) sendFollowup(appealPrompt);
    setAppealDraftCode(appealPreset.code);
    setAppealExplanation(appealPreset.text);
    setAppealEvidenceName("");
  }, [appealPreset?.nonce, done]);

  const submitAppeal = () => {
    const option = appealOptions.find((item) => item.code === appealDraftCode);
    if (!option) return;
    sendFollowup(option.label, appealExplanation.trim(), appealEvidenceName);
    onAppealSubmitted?.({ code: option.code, issueId: appealPreset && appealPreset.code === option.code ? appealPreset.issueId : undefined });
    setAppealDraftCode(null);
    setAppealExplanation("");
    setAppealEvidenceName("");
  };

  return (
    <section className="chat">
      <header className="chat-header">
        <div className="chat-header-main">
          <button aria-label="返回首页" className="chat-home-button" onClick={onHome} title="返回首页">
            <Icon size={22}>
              <path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </Icon>
          </button>
          <div className="chat-header-title">
            <strong>{creatorMode ? "创作者发布前自检" : activeDimensions.length === 1 ? "文案安全性鉴别" : `${activeDimensions.length} 维内容鉴别`}</strong>
            <small>{liveFailed ? "核验失败" : paused && isGenerating ? "生成已暂停" : !done ? liveActive ? "核验进行中…" : `正在调用 ${activeDimensions.map((code) => expertNames[code]).join("、")}…` : latestFollowup && !latestFollowup.answered ? "正在生成追问回答…" : "分析完成"}</small>
          </div>
        </div>
        <div className="chat-header-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <div className="share-wrap">
            <button className="header-share" onClick={() => setShareOpen((open) => !open)}>
              <Icon size={17}>
                <circle cx="18" cy="5" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="6" cy="12" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="18" cy="19" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <path d="m8 11 8-5M8 13l8 5" stroke="currentColor" strokeWidth="1.5" />
              </Icon>
              分享
            </button>
            {shareOpen && <ShareMenu onClose={() => setShareOpen(false)} />}
          </div>
        </div>
      </header>
      <div className="chat-scroll">
        {!liveActive && (
          <div className="demo-version-banner">
            <Sparkle size={14} />
            <span><strong>演示版本</strong>以下为示例结果，并非对你输入内容的判断</span>
          </div>
        )}
        <div className="user-message">
          <div>
            <p>{prompt}</p>
            {filename && (
              <span className="message-attachment">
                <img alt="待分析美妆帖子预览" src={postImage} />
                <span><strong>{filename}</strong><small>{isExampleSubmission ? "示例 · 演示附件" : "图片内容 · 已上传"}</small></span>
              </span>
            )}
          </div>
          <span className="avatar user-avatar">YZ</span>
        </div>

        <div className="agent-message">
          <span className="agent-avatar"><Sparkle size={17} /></span>
          <div className="agent-content">
            <div className="agent-name">TruLens <span>多模态鉴别 Agent</span></div>
            <p>
              {creatorMode
                ? `收到。发布前自检仅调用 ${activeDimensions.map((code) => expertNames[code]).join("和")}；账号和评论数据发布前还没有，会明确标记为未启用。`
                : <>收到。根据当前输入，我将调用 {activeDimensions.map((code) => expertNames[code]).join("和")}，只分析有足够证据支持的维度。</>}
            </p>
            {creatorMode && live?.error && (
              <p className="live-error">
                {friendlyLiveError(live.error).message}
                {friendlyLiveError(live.error).fallback && onUseManual && (
                  <button className="live-resume-button" onClick={() => onUseManual(stripLinksFromShareText(prompt))} type="button">
                    改用文案 / 图片核验
                  </button>
                )}
                {creatorMode && (
                  <button className="live-resume-button" onClick={() => void live.resume()} type="button">
                    重试
                  </button>
                )}
                {!creatorMode && live.taskId && (
                  <>
                    <br />
                    任务编号：{live.taskId}。如果任务已在后台完成，请刷新后从「最近任务」重新打开。
                    <button
                      className="live-resume-button"
                      onClick={() => void live.resume()}
                      type="button"
                    >
                      重新获取结果
                    </button>
                  </>
                )}
              </p>
            )}
            <AnalysisProcessProgress
              creatorMode={creatorMode}
              done={done}
              stage={processStage}
              technicalView={technicalView}
            />
            <AnalysisSteps activeDimensions={activeDimensions} done={done} paused={paused} liveAgents={liveAgents} liveMode={liveActive} overallScore={liveReport ? analysisScore : undefined} creatorMode={creatorMode} />
            {!done && !liveFailed ? (
              <div className={`thinking ${paused ? "paused" : ""}`}><i /><i /><i /> {paused ? "分析已暂停，点击继续恢复推理" : creatorMode ? (liveReady ? "专家正在整理自检结论…" : "专家正在核验，等待自检结果返回…") : activeDimensions.length > 1 ? `${activeDimensions.length} 位专家正在交换证据并校准权重` : `${expertNames[activeDimensions[0]]}正在独立核验证据`}</div>
            ) : done && !liveFailed ? (
              <>
                <div className="analysis-complete">
                  <div className="mini-score" style={{ "--mini-score": liveReport && !liveReport.assessed_dimensions.length ? 0 : analysisScore } as React.CSSProperties}>
                    {liveReport && !liveReport.assessed_dimensions.length
                      ? <span><strong>—</strong>暂不评分</span>
                      : <span><strong>{analysisScore}</strong>/100</span>}
                    <small>综合可信度</small>
                  </div>
                  <div>
                    <strong>{analysisSummary}</strong>
                    <p>
                      {liveReport
                        ? `本次结论仅基于已评估的维度（${assessedDimensionCodes(liveReport.assessed_dimensions).join(" / ") || "无"}）生成；未评估的维度显示“暂不评分”，不计入加权，也不会被模型假设或补全。`
                        : `本次结论仅基于当前输入可识别的 ${activeDimensions.join(" / ")} 维度生成；未提供的模态不会被模型假设或补全。`}
                    </p>
                    <div className="evidence-tags">
                      {activeDimensions.map((code) => {
                        const item = liveAgentsByCode.get(code);
                        return (
                          <span key={code}>
                            {expertNames[code]}
                            {item && !item.assessed ? "暂不评分" : "已完成"}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                </div>
                <motion.div
                  animate={{ opacity: 1, y: 0 }}
                  className="analysis-result-entry"
                  initial={{ opacity: 0, y: 10 }}
                  transition={{ delay: 0.18, duration: 0.42 }}
                >
                  <small>分析已完成，点击查看完整报告</small>
                  <button onClick={onResult} type="button">{creatorMode ? "查看自检报告 →" : "查看核验结果 →"}</button>
                </motion.div>
                <button
                  className="appeal-button"
                  disabled={hasAppealed}
                  onClick={() => sendFollowup(appealPrompt)}
                >
                  {hasAppealed ? "已进入申诉辩论" : "申诉或辩解"}
                </button>
              </>
            ) : null}
          </div>
        </div>

        {followups.map((followup, index) => {
          const isImageDetection = followup.question.includes("图片区域") || followup.question.includes("AI 修饰");
          const isAppealStart = followup.question === appealPrompt;
          const appealSelection = appealOptions.find((option) => option.label === followup.question);
          return (
            <div className="followup-thread" key={followup.id}>
              <div className="user-message followup-user-message">
                <div>
                  <p>{followup.question}</p>
                  {followup.detail && <small className="appeal-user-detail">我觉得这里没问题，因为：{followup.detail}</small>}
                  {followup.evidenceName && <small className="appeal-user-evidence">附件证据 · {followup.evidenceName}</small>}
                </div>
                <span className="avatar user-avatar">YZ</span>
              </div>
              <div className="agent-message followup-agent-message">
                <span className="agent-avatar"><Sparkle size={17} /></span>
                <div className="agent-content">
                  <div className="agent-name">
                    TruLens
                    <span>
                      {isAppealStart || appealSelection
                        ? "ARGUE · 结论复议"
                        : isImageDetection
                          ? "图像取证 Agent"
                          : `上下文推理 · 回合 ${index + 2}`}
                    </span>
                  </div>
                  {!followup.answered ? (
                    <div className={`agent-typing ${paused ? "paused" : ""}`}>
                      <span><i /><i /><i /></span>
                      {paused
                        ? "回答已暂停，点击顶部继续"
                        : isAppealStart
                          ? "正在建立申诉议题并召回复核专家"
                          : appealSelection
                            ? `正在将异议移交给${appealSelection.role} ${appealSelection.code}`
                            : "正在结合上一轮证据生成回答"}
                    </div>
                  ) : isAppealStart ? (
                    <div className="argue-entry">
                      <div className="argue-entry-head">
                        <span><Sparkle size={14} /> 已进入 ARGUE 辩论环节</span>
                        <small>原结论暂不变更</small>
                      </div>
                      <strong>收到。你不同意当前核验结果的哪一部分？</strong>
                      <p>
                        {creatorMode
                          ? "请选择一项具体异议，TruLens 会记录你的申诉理由与补充材料，供人工复核参考；自检分数不会因此自动变化。"
                          : "请选择一项具体异议，TruLens 会将原始证据和评分依据交给对应专家重新审查。"}
                      </p>
                      <div className="argue-options">
                        {recordOnlyAppeal && !visibleAppealOptions.length && <p className="argue-empty-note">本次没有已评估的维度，暂无可申诉的专家结论。</p>}
                        {visibleAppealOptions.map((option) => (
                          <div
                            className={`argue-option-card ${appealDraftCode === option.code && !selectedAppeal ? "selected" : ""}`}
                            key={option.code}
                          >
                            <button
                              disabled={Boolean(selectedAppeal)}
                              onClick={() => {
                                setAppealDraftCode(option.code);
                                setAppealExplanation("");
                                setAppealEvidenceName("");
                              }}
                            >
                              <span className={`report-dimension-badge badge-${option.code.toLowerCase()}`}>{option.code}</span>
                              <span><strong>{option.label}</strong><small>{recordOnlyAppeal ? `记录对${option.role}结论的申诉，供人工复核` : `${option.role}重新核验`}</small></span>
                              <i aria-hidden="true">{appealDraftCode === option.code ? "⌄" : "→"}</i>
                            </button>
                            {appealDraftCode === option.code && !selectedAppeal && (
                              <div className="argue-appeal-input">
                                <label htmlFor={`appeal-${option.code}`}>补充你的判断依据 <small>选填</small></label>
                                <textarea
                                  id={`appeal-${option.code}`}
                                  onChange={(event) => setAppealExplanation(event.target.value)}
                                  placeholder={creatorMode ? "如果内容属实，补充原图、检测报告或使用凭证即可申诉。" : "我觉得这里没问题，因为……"}
                                  rows={3}
                                  value={appealExplanation}
                                />
                                <div className="argue-appeal-actions">
                                  <label className="argue-evidence-upload" title={creatorMode ? "可上传原图、检测报告、合作说明等" : "上传图片或其他证据"}>
                                    <input
                                      accept="image/*,.pdf,.doc,.docx,.txt"
                                      onChange={(event) => setAppealEvidenceName(event.target.files?.[0]?.name ?? "")}
                                      type="file"
                                    />
                                    <Icon size={15}><path d="M12 16V4m0 0L8 8m4-4 4 4M5 14v5h14v-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                                    <span>{appealEvidenceName || (creatorMode ? "可上传原图、检测报告、合作说明等" : "上传图片或其他证据")}</span>
                                  </label>
                                  <div>
                                    <button className="skip" onClick={submitAppeal}>跳过，不填写</button>
                                    <button onClick={submitAppeal}>{appealExplanation.trim() || appealEvidenceName ? "提交申诉材料" : "直接提交"} <Arrow size={14} /></button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : appealSelection ? (
                    <ArgueReviewFlow
                      evidenceName={followup.evidenceName ?? ""}
                      explanation={followup.detail ?? ""}
                      onArchive={onArchiveReport}
                      onViewReport={onViewRevisedReport}
                      option={appealSelection}
                      baseScore={recordOnlyAppeal ? analysisScore : undefined}
                      recordOnly={recordOnlyAppeal}
                      creatorMode={creatorMode}
                      scopeCodes={recordOnlyAppeal ? assessedCodes : undefined}
                    />
                  ) : isImageDetection ? (
                    <>
                      <p>检测完成。我在主图中定位到 <strong>2 处疑似 AI 辅助修饰区域</strong>。它们更接近局部美化，而不是整张图片由 AI 生成。</p>
                      <div className="photo-detection-result">
                        <div className="detected-photo">
                          <img alt="照片 AI 修饰区域检测结果" src={postImage} />
                          <span className="detection-box zone-a"><i>A</i></span>
                          <span className="detection-box zone-b"><i>B</i></span>
                          <div className="detection-scanline" />
                          <small>IMAGE FORENSICS · FRAME 01</small>
                        </div>
                        <div className="detection-findings">
                          <div className="detection-score">
                            <span>图像原生性</span>
                            <strong>88<small>/100</small></strong>
                          </div>
                          <div className="finding-item">
                            <span>A</span>
                            <div>
                              <strong>面中与脸颊纹理</strong>
                              <p>局部毛孔纹理重复且过于均匀，疑似使用生成式皮肤细化。</p>
                            </div>
                            <em>78%</em>
                          </div>
                          <div className="finding-item">
                            <span>B</span>
                            <div>
                              <strong>唇周与下颌边缘</strong>
                              <p>边缘过渡异常平滑，但光影方向与原图保持一致。</p>
                            </div>
                            <em>64%</em>
                          </div>
                        </div>
                      </div>
                      <div className="detection-conclusion">
                        <span>结论</span>
                        <p>产品主体、背景和整体光影未发现生成痕迹。修饰主要集中在肤质优化，可能会让底妆遮瑕力看起来优于真实效果，建议参考自然光下的素人试妆。</p>
                      </div>
                    </>
                  ) : (
                    <ContextualFollowupAnswer question={followup.question} />
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div className="chat-end-anchor" ref={chatEndRef} />
      </div>
      <div className="chat-composer-wrap">
        {!isArgueFlow && (
          <div className="quick-followups">
            <span>{quickFollowups.length ? "继续追问" : "正在生成追问"}</span>
            <div>
              {quickFollowups.length ? quickFollowups.map((question) => (
                <button
                  className={quickPrompt === question ? "active" : ""}
                  key={question}
                  onClick={() => setQuickPrompt(question)}
                >
                  {question}
                </button>
              )) : <span className="quick-loading"><i /><i /><i /></span>}
            </div>
          </div>
        )}
        <Composer
          compact
          filename=""
          onFile={onFile}
          onPauseToggle={() => setPaused((current) => !current)}
          onSubmit={sendFollowup}
          pauseDisabled={!isGenerating}
          paused={paused}
          preset={quickPrompt}
        />
        <small>TruLens 可能会出错，请结合实际体验判断。</small>
      </div>
    </section>
  );
}

const dimensions = [
  { code: "T", title: "账号可信度", en: "Trustworthiness", score: 82, status: "可信", tone: "violet", text: "“眠云的护肤手账”明确标注为虚构演示账号，简介与历史笔记都围绕日常护肤、精华体验和成分记录展开；内容轨迹稳定，连续体验记录仍需结合原始素材核对。", evidence: ["粉丝 3.5 万", "获赞与收藏 24.6 万", "历史内容垂直"] },
  { code: "R", title: "图像原生性", en: "Reality", score: 88, status: "轻度修饰", tone: "blue", text: "左右脸对比中的人物结构、拍摄角度和环境光线基本一致；右侧皮肤微纹理明显减少，存在局部磨皮或生成式细化信号。", evidence: ["人物结构一致", "右脸纹理减少", "未见整图生成"] },
  { code: "U", title: "评论自然度", en: "User Voice", score: 74, status: "较自然", tone: "peach", text: "可见评论以保湿感、成分、敏感肌适配和使用周期等具体问题为主，作者也针对肤质差异与成分进行回复；暂未发现集中复制的模板话术。", evidence: ["问题表达具体", "作者回复有针对性", "评论地域与时间分散"] },
  { code: "S", title: "文案真实性", en: "Safety", score: 91, status: "安全", tone: "green", text: "未使用绝对化功效承诺，色号、持妆与肤质描述均保留了个人体验边界。", evidence: ["无医疗功效宣称", "含个体差异说明", "合作标识清晰"] },
];

const archivedTasks = {
  makeup: {
    date: "今天",
    title: "秋冬奶油肌底妆分享",
    subtitle: "秋冬奶油肌底妆分享 · 多模态可信度报告",
    score: 84,
    status: "高可信",
    tone: "trusted",
    headline: "内容整体可信，图像存在轻度修饰痕迹。",
    summary: "账号身份与历史内容轨迹稳定，评论区保留真实体验反馈，文案表达边界清晰；右侧肤质细节存在局部优化，但未发现整图生成证据。",
    risks: [
      ["图像修饰", "右侧眼下与面中区域的微纹理明显减少", "低"],
      ["评论同质", "部分短评重复品牌名称，缺少具体体验", "中"],
      ["账号内容", "历史笔记长期垂直于美妆护肤领域", "低"],
    ],
    dimensions,
    decision: "这篇内容可以作为底妆效果参考，但局部肤质可能经过优化。建议结合自然光原图和其他真实用户的持妆反馈作出购买决定。",
  },
  serum: {
    date: "2025.06.17",
    title: "热门精华测评合集",
    subtitle: "12 款热门精华横向测评 · 多模态可信度报告",
    score: 58,
    status: "存在风险",
    tone: "warning",
    headline: "部分结论可信，评论与功效表达存在异常。",
    summary: "账号本身具有稳定运营记录，但测评中的排序逻辑缺少统一标准；部分评论存在协同传播特征，三项功效结论未提供可追溯依据。",
    risks: [
      ["评论协同", "27 个账号在 18 分钟内发布高度相似的推荐话术", "高"],
      ["测评标准", "不同产品使用了不同观察周期，横向排名依据不足", "中"],
      ["功效表达", "“修护翻倍”等结论未标注数据来源", "中"],
    ],
    dimensions: [
      { code: "T", title: "账号可信度", en: "Trustworthiness", score: 68, status: "一般", tone: "violet", text: "账号持续运营 1.8 年，但近 30 天商业合作密度明显上升。", evidence: ["历史发布 174 篇", "商业内容占比 42%", "近期合作集中"] },
      { code: "R", title: "图像原生性", en: "Reality", score: 81, status: "较真实", tone: "blue", text: "产品包装与质地图片未发现明显生成痕迹，部分对比图曝光不一致。", evidence: ["主体边缘自然", "两组曝光差异", "无整图生成"] },
      { code: "U", title: "评论自然度", en: "User Voice", score: 42, status: "高风险", tone: "peach", text: "评论区存在集中发布与重复句式，真实体验反馈被营销话术稀释。", evidence: ["相似评论 31%", "27 个关联账号", "发布时间集中"] },
      { code: "S", title: "文案真实性", en: "Safety", score: 47, status: "需核验", tone: "green", text: "多处功效对比缺乏统一条件，部分结论超出个人体验表达边界。", evidence: ["3 项无来源结论", "对比标准不统一", "合作标识存在"] },
    ],
    decision: "暂缓将该合集作为主要决策依据。建议寻找采用统一测试周期、披露合作关系，并能提供原始观察记录的独立测评进行交叉验证。",
  },
  whitening: {
    date: "2025.06.15",
    title: "七天美白挑战",
    subtitle: "短周期功效挑战 · 多模态可信度报告",
    score: 39,
    status: "疑似营销",
    tone: "danger",
    headline: "内容具有明显营销结构，关键效果证据不足。",
    summary: "账号、评论和文案同时出现营销信号。前后对比图拍摄条件不一致，“七天显著变白”的核心结论缺少可验证记录，不足以支持内容主张。",
    risks: [
      ["视觉对比", "前后图片的白平衡、曝光与拍摄角度均不一致", "高"],
      ["时间证据", "未提供连续七天的原始记录或可验证时间信息", "高"],
      ["传播结构", "核心口号在多个关联账号中同步出现", "高"],
    ],
    dimensions: [
      { code: "T", title: "账号可信度", en: "Trustworthiness", score: 55, status: "需留意", tone: "violet", text: "账号存在真实历史内容，但挑战发布前后集中出现同品牌合作。", evidence: ["运营 11 个月", "合作发布集中", "关联账号 8 个"] },
      { code: "R", title: "图像原生性", en: "Reality", score: 43, status: "条件异常", tone: "blue", text: "对比图未发现整图生成，但曝光和白平衡差异足以改变视觉结果。", evidence: ["曝光差异 +18%", "白平衡不一致", "拍摄角度变化"] },
      { code: "U", title: "评论自然度", en: "User Voice", score: 38, status: "低可信", tone: "peach", text: "大量评论重复挑战口号，缺少具体使用过程与差异化体验。", evidence: ["重复话术 36%", "短时集中发布", "体验细节不足"] },
      { code: "S", title: "文案真实性", en: "Safety", score: 22, status: "高风险", tone: "green", text: "短周期确定性功效表达缺乏依据，并使用明显的结果导向措辞。", evidence: ["绝对化表达 4 处", "无证据来源", "缺少差异说明"] },
    ],
    decision: "不建议根据该帖子作出购买决定。核心主张缺少可追溯证据，且三个模态的风险信号相互强化，应等待独立来源或更完整记录。",
  },
};

const archivedConversations = {
  makeup: {
    prompt: "请帮我鉴别这篇“秋冬奶油肌底妆分享”是否可信，重点检查账号、图片和评论区。",
    acknowledgement: "收到。我已完成账号历史、左右脸肤质对比、评论区原文和宣传文案的多模态核验，并保留了生成报告时使用的证据。",
    followups: [
      ["图片里哪些地方可能经过修饰？", "右侧眼下与面中区域的毛孔和微纹理明显少于左侧，但人物结构、拍摄角度与主光方向保持一致，更接近局部磨皮或生成式细化，而不是整图生成。"],
      ["评论区整体可信吗？", "可见评论包含保湿感、成分、敏感肌适配和使用周期等具体问题，作者回复也结合了不同肤质与使用方式。当前样本未见集中复制的模板话术，整体互动较自然，但仍只代表可见评论范围。"],
    ],
  },
  serum: {
    prompt: "帮我核验这篇 12 款热门精华横向测评，重点看排名依据和评论自然度。",
    acknowledgement: "收到。我会对账号历史、测评图片、评论传播结构和功效文案进行交叉核验，并检查不同产品是否使用了统一测评标准。",
    followups: [
      ["这些产品的测评标准一致吗？", "不完全一致。部分产品观察 7 天，部分产品观察 28 天，肤质、用量和搭配产品也没有统一，因此现有横向排名不能直接比较。"],
      ["评论区有没有协同传播？", "有明显信号。27 个账号在 18 分钟内发布高度相似的推荐话术，且多个账号缺少其他真实互动记录。"],
    ],
  },
  whitening: {
    prompt: "这篇“七天美白挑战”可信吗？请检查前后对比图和功效宣传。",
    acknowledgement: "收到。我会核验账号合作记录、前后图片条件、评论区传播结构，以及“七天显著变白”等核心功效主张。",
    followups: [
      ["前后对比图的问题在哪里？", "两组图片的曝光、白平衡和拍摄角度均不一致。即使没有整图生成，这些条件差异也足以让后图看起来更亮。"],
      ["“七天显著变白”有依据吗？", "当前内容没有提供连续七天的原始记录、统一光线下的测量结果或可追溯数据，因此不足以支持确定性功效结论。"],
    ],
  },
};

function ArchivedConversation({
  onHome,
  onResult,
  task,
}: {
  onHome: () => void;
  onResult: () => void;
  task: RecentTask;
}) {
  const data = archivedTasks[task];
  const conversation = archivedConversations[task];
  return (
    <section className="chat archived-chat">
      <header className="chat-header">
        <div className="chat-header-main">
          <button aria-label="返回首页" className="chat-home-button" onClick={onHome} title="返回首页">
            <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
          </button>
          <div className="chat-header-title"><strong>{data.title}</strong><small>{data.date} · 历史对话记录</small></div>
        </div>
      </header>

      <div className="chat-scroll">
        <div className="user-message">
          <div><p>{conversation.prompt}</p></div>
          <span className="avatar user-avatar">YZ</span>
        </div>
        <div className="agent-message">
          <span className="agent-avatar"><Sparkle size={17} /></span>
          <div className="agent-content">
            <div className="agent-name">TruLens <span>多模态鉴别 Agent</span></div>
            <p>{conversation.acknowledgement}</p>
            <div className="archive-analysis-summary">
              <span className="archive-chat-score">{data.score}<small>/100</small></span>
              <div><strong>{data.headline}</strong><p>{data.summary}</p></div>
              <button className="report-button" onClick={onResult}>查看核验报告 <Arrow size={17} /></button>
            </div>
          </div>
        </div>

        {conversation.followups.map(([question, answer], index) => (
          <div className="followup-thread" key={question}>
            <div className="user-message followup-user-message">
              <div><p>{question}</p></div>
              <span className="avatar user-avatar">YZ</span>
            </div>
            <div className="agent-message followup-agent-message">
              <span className="agent-avatar"><Sparkle size={17} /></span>
              <div className="agent-content">
                <div className="agent-name">TruLens <span>上下文推理 · 回合 {index + 2}</span></div>
                <p>{answer}</p>
              </div>
            </div>
          </div>
        ))}
        <p className="archive-chat-end">历史对话已结束 · 报告保留生成时的证据与结论</p>
      </div>
    </section>
  );
}

type UnifiedReportDimension = {
  code: string;
  title: string;
  en: string;
  score: number;
  status: string;
  tone: string;
  text: string;
  evidence: string[];
  method?: "llm" | "rule";
};

const accountActivityBars = [
  34, 48, 41, 62, 78, 56, 39, 72, 81, 46,
  68, 85, 57, 74, 64, 88, 44, 69, 52, 79,
  43, 71, 77, 49, 73, 61, 86, 65, 82, 59,
];

function AccountActivityEvidence() {
  return (
    <section className="account-activity-evidence" aria-label="眠云的护肤手账账号活跃度">
      <header>
        <span className="account-activity-mark"><Sparkle size={20} /></span>
        <div><strong>眠云的护肤手账</strong><small>账号活跃度</small></div>
        <em>内容垂直</em>
      </header>
      <div className="account-activity-body">
        <div className="account-posting-rhythm">
          <span>近 30 篇笔记发布节奏</span>
          <div className="account-activity-bars">
            {accountActivityBars.map((height, index) => (
              <i
                aria-label={`第 ${index + 1} 篇，${index > 21 ? "日常内容" : "带货内容"}`}
                className={index > 19 ? "organic" : "commerce"}
                key={`${height}-${index}`}
                style={{ height: `${height}%` }}
              />
            ))}
          </div>
          <small><i />日常内容 <i />带货内容</small>
        </div>
        <div className="account-commerce-share">
          <span>带货占比</span>
          <div><strong>67%</strong><small>近 30 篇</small></div>
        </div>
      </div>
      <small className="account-activity-example">示例数据</small>
    </section>
  );
}

function ReportEvidenceModal({
  code,
  dimension,
  onClose,
  showAccountActivity = false,
  technicalView,
}: {
  code: DimensionCode;
  dimension: UnifiedReportDimension;
  onClose: () => void;
  showAccountActivity?: boolean;
  technicalView: boolean;
}) {
  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [onClose]);

  const modalTitle = {
    T: "账号可信度证据链",
    R: "图像原生性证据链",
    U: "评论自然度证据链",
    S: "文案真实性证据链",
  }[code];

  return (
    <div
      aria-label={modalTitle}
      aria-modal="true"
      className={`report-evidence-backdrop evidence-${code.toLowerCase()}`}
      onMouseDown={(event) => {
        if (event.currentTarget === event.target) onClose();
      }}
      role="dialog"
    >
      <article className="report-evidence-modal">
        <header className="report-evidence-header">
          <div>
            <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
            <div>
              <small>EVIDENCE CHAIN · 可解释评分依据</small>
              <strong>{modalTitle}</strong>
            </div>
          </div>
          <div className="evidence-modal-score">
            <span>维度评分</span>
            <strong>{Math.round(dimension.score)}<small>/ 100</small></strong>
          </div>
          <button aria-label="关闭证据链" className="evidence-modal-close" onClick={onClose}>
            <Icon size={18}><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
          </button>
        </header>

        <div className="evidence-chain-summary">
          <span>结论</span>
          <p>{dimension.text}</p>
          <div>
            {dimension.evidence.map((item) => (
              <span className="evidence-summary-item" key={item}>
                <small>{item}</small>
                {technicalView && <MethodBadge method={dimension.method ?? "llm"} />}
              </span>
            ))}
          </div>
        </div>

        {code === "T" && (
          <>
            <AccountProfileEvidence />
            <div className="account-evidence-layout">
              <div className="evidence-source-pair">
                <figure>
                  <img alt={`${showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}账号主页原始材料`} src="/evidence/account-profile.jpg" />
                  <figcaption>图 1 · 账号主页与公开资料</figcaption>
                </figure>
                <figure>
                  <img alt={`${showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}历史美妆护肤笔记原始材料`} src="/evidence/account-history.jpg" />
                  <figcaption>图 2 · 历史笔记内容抽样</figcaption>
                </figure>
              </div>
              <div className="evidence-document account-evidence-document">
                <div className="evidence-document-head">
                  <span className="evidence-profile-avatar">贴</span>
                  <div><strong>{showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}</strong><small>{showAccountActivity ? "ID：mianyun_demo_208 · 虚拟档案" : "小红书号 601047506 · IP 广东"}</small></div>
                  <em>账号材料 2 份</em>
                </div>
                <div className="account-metrics">
                  <span><strong>128</strong>关注</span>
                  <span><strong>3.5 万</strong>粉丝</span>
                  <span><strong>24.6 万</strong>获赞与收藏</span>
                </div>
                <section>
                  <small>账号简介</small>
                  <p>“慢慢护肤，认真记录”｜日常护肤｜精华体验｜成分记录。<mark>主页已明确标注为虚构演示账号</mark>。</p>
                </section>
                <section>
                  <small>历史动态文本抽样</small>
                  <p><b>05-12</b> 换季护肤清单｜我的精简步骤 <em>♡ 326</em></p>
                  <p><b>05-10</b> <mark>连续 7 天精华记录（虚构示例）</mark> <em>♡ 184</em></p>
                  <p><b>05-08</b> 护肤日记：保湿感比想象中重要 <em>♡ 241</em></p>
                  <p><b>05-06</b> 成分党笔记｜新手怎么读精华 <em>♡ 118</em></p>
                </section>
                <footer><span>演示身份标注清楚</span><span>内容垂直稳定</span><span className="attention">连续体验需核对原始素材</span></footer>
              </div>
            </div>
            {showAccountActivity && <AccountActivityEvidence />}
          </>
        )}

        {code === "R" && (
          <>
            <div className="image-evidence-layout">
              <div className="report-forensic-image">
                <img alt="同一人物左右脸肤质对比原始材料" src="/evidence/skin-comparison.jpg" />
                <span className="forensic-anchor anchor-one">①</span>
                <span className="forensic-anchor anchor-two">②</span>
                <small>图 3 · 左右脸肤质对比原图</small>
              </div>
              <div className="forensic-findings">
                <span>锚点检测</span>
                <div><b>①</b><p><strong>左侧原始肤质区域</strong><small>毛孔、色素点与细小起伏分布自然，保留随机高频纹理，可作为真实皮肤基准。</small></p><em>基准</em></div>
                <div><b>②</b><p><strong>右侧眼下与面中区域</strong><small>微纹理和毛孔明显减少，表面平滑度显著高于左侧，符合局部磨皮或生成式细化特征。</small></p><em>72%</em></div>
                <p>两侧五官结构、镜头角度和主光方向基本一致，未见拼接错位或整图生成；当前风险集中在右侧肤质呈现被优化。</p>
              </div>
            </div>
            <MaterialTraceEvidence hasMatches={dimension.score < 90} technicalView={technicalView} />
          </>
        )}

        {code === "U" && (
          <>
            <div className="comment-evidence-layout">
              <div className="comment-source-stack">
                <figure><img alt="评论区原始材料上半部分" src="/evidence/comments-1.jpg" /><figcaption>图 4 · 评论原文</figcaption></figure>
                <figure><img alt="评论区原始材料下半部分" src="/evidence/comments-2.jpg" /><figcaption>图 5 · 评论原文</figcaption></figure>
              </div>
              <div className="evidence-document comment-evidence-document">
                <div className="comment-analysis-head"><span>评论区原文抽样</span><small>可见样本 12 条 · 具体问题与追问为主</small></div>
                <div className="report-comment detailed"><i>晚</i><p><strong>晚风饮茶</strong>用了几天，保湿感还不错，先继续观察</p><time>江苏</time></div>
                <div className="report-comment"><i>鱼</i><p><strong>小鱼汽水</strong>这个精华的质地看起来好清爽呀</p><time>广东</time></div>
                <div className="report-comment detailed"><i>梨</i><p><strong>阿梨今天早睡</strong>七天变化会不会和作息也有关系？</p><time>浙江</time></div>
                <div className="report-comment"><i>桃</i><p><strong>桃桃汽泡</strong>蹲一个后续，敏感肌能用吗？</p><time>上海</time></div>
                <div className="report-comment detailed"><i>橘</i><p><strong>橘子海</strong>姐妹们先看成分表，别只看前后对比图</p><time>四川</time></div>
                <div className="report-comment"><i>薄</i><p><strong>薄荷糖不加冰</strong>请问这是合作分享吗？</p><time>北京</time></div>
                <div className="report-comment detailed"><i>眠</i><p><strong>眠云的护肤手账</strong>我自己是敏感肌，用下来没什么刺激感，建议先在耳后试一下哦</p><time>作者回复</time></div>
                <div className="report-comment"><i>云</i><p><strong>云朵收藏夹</strong>期待更多真实使用记录～</p><time>湖北</time></div>
                <footer><span className="comment-swatch" />浅紫色标记具体问题与作者回复 <b>互动自然 · 未见集中模板话术</b></footer>
              </div>
            </div>
            <p className="comment-simulation-note">以上评论均为模拟文本，刻意包含不同观点与表达模式，方便测试对重复话术、夸大效果、购买引导及合作披露缺失等线索的识别能力。</p>
          </>
        )}

        {code === "S" && (
          <div className="evidence-document copy-evidence-document">
            <div className="evidence-document-head copy-source-head">
              <div><small>帖子原文</small><strong>秋冬奶油肌底妆分享</strong></div>
              <em>语义主张检测</em>
            </div>
            <div className="copy-evidence-legend" aria-label="文本标注说明">
              <span className="template">模版化术语</span>
              <span className="absolute">绝对化用语</span>
              <span className="unsupported">功效缺少依据</span>
            </div>
            <p>
              最近换季皮肤有点干，试了这套底妆。妆前薄涂，粉底少量叠加，在我脸上<mark className="unsupported">大约能维持 8 小时</mark>。<mark className="template">像开了原生柔焦一样</mark>，<mark className="absolute">毛孔直接隐形</mark>，但鼻翼到下午还是会有一点卡粉。色号是按我自己的肤色选的，<mark className="absolute">所有肤质都能放心入</mark>。本篇含品牌合作，具体效果会因肤质和上妆方式不同。
            </p>
            <div className="copy-annotations">
              <span><b>01</b><p><strong>模板化话术</strong><small>“像开了原生柔焦一样”属于常见的效果包装表达。</small></p></span>
              <span><b>02</b><p><strong>绝对化用语</strong><small>“毛孔直接隐形”“所有肤质都能放心入”把个人体验扩大为确定结论。</small></p></span>
              <span><b>03</b><p><strong>功效缺少依据</strong><small>“大约能维持 8 小时”未提供测试条件或可核对记录。</small></p></span>
            </div>
            <footer><span>已披露品牌合作</span><span>保留个体体验边界</span><span className="attention">2 处表述需留意</span></footer>
          </div>
        )}

        {(code === "T" || code === "R" || code === "S") && (
          <small className="evidence-ai-case-note">虚构案例 · AI 生成</small>
        )}

        <footer className="evidence-modal-footer">
          <p><span /> 原始信号 <i /> 模型检测 <em /> 评分结论</p>
          <button onClick={onClose}>返回报告</button>
        </footer>
      </article>
    </div>
  );
}

const evidenceDimensionOptions: Record<DimensionCode, { label: string; hint: string }> = {
  T: { label: "账号可信度", hint: "账号主页链接、简介或历史发布记录" },
  R: { label: "图像原生性", hint: "原始图片、对比图或局部细节截图" },
  U: { label: "评论自然度", hint: "评论区截图、评论文本或发布时间信息" },
  S: { label: "文案真实性", hint: "笔记正文、标题或功效描述" },
};

function EvidenceExpansionPrompt({
  availableCodes,
  onAddEvidence,
}: {
  availableCodes: DimensionCode[];
  onAddEvidence: (code: DimensionCode) => void;
}) {
  const missingCodes = allDimensions.filter((code) => !availableCodes.includes(code));
  const [mode, setMode] = useState<"idle" | "adding" | "dismissed">("idle");
  const [selectedCode, setSelectedCode] = useState<DimensionCode>(missingCodes[0] ?? "T");
  const [evidenceText, setEvidenceText] = useState("");
  const [filename, setFilename] = useState("");
  const [addedCode, setAddedCode] = useState<DimensionCode | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!missingCodes.includes(selectedCode) && missingCodes[0]) setSelectedCode(missingCodes[0]);
  }, [missingCodes, selectedCode]);

  if (!missingCodes.length || mode === "dismissed") return null;

  const submitEvidence = () => {
    if (!evidenceText.trim() && !filename) return;
    onAddEvidence(selectedCode);
    setAddedCode(selectedCode);
    setEvidenceText("");
    setFilename("");
    setMode("idle");
  };

  return (
    <section className="evidence-expansion-prompt" aria-live="polite">
      <div className="evidence-expansion-heading">
        <span>
          <Icon size={18}>
            <path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" />
          </Icon>
        </span>
        <div>
          <small>MORE EVIDENCE · 可选</small>
          <h3>{addedCode ? `${evidenceDimensionOptions[addedCode].label}证据已加入` : "要加入更多维度的证据吗？"}</h3>
          <p>
            {addedCode
              ? `报告已纳入新的证据维度。你还可以继续补充其余 ${missingCodes.length} 个维度。`
              : `当前报告基于 ${availableCodes.length} 个维度生成。补充证据可以让交叉核验更充分，也可以保留当前结果。`}
          </p>
        </div>
      </div>

      {mode === "idle" ? (
        <div className="evidence-expansion-actions">
          <button onClick={() => { setAddedCode(null); setMode("adding"); }}>补充更多证据</button>
          <button onClick={() => setMode("dismissed")}>先看当前报告</button>
        </div>
      ) : (
        <div className="evidence-expansion-form">
          <div aria-label="选择要补充的证据维度" className="missing-dimension-options" role="group">
            {missingCodes.map((code) => (
              <button
                aria-pressed={selectedCode === code}
                className={selectedCode === code ? "active" : ""}
                key={code}
                onClick={() => setSelectedCode(code)}
              >
                <span>{code}</span>
                <div><strong>{evidenceDimensionOptions[code].label}</strong><small>{evidenceDimensionOptions[code].hint}</small></div>
              </button>
            ))}
          </div>
          <label className="evidence-expansion-input">
            <span>粘贴链接或补充说明</span>
            <textarea
              onChange={(event) => setEvidenceText(event.target.value)}
              placeholder={evidenceDimensionOptions[selectedCode].hint}
              rows={3}
              value={evidenceText}
            />
          </label>
          <div className="evidence-expansion-submit">
            <input
              accept="image/*"
              onChange={(event) => setFilename(event.target.files?.[0]?.name ?? "")}
              ref={fileRef}
              type="file"
            />
            <button className="evidence-upload-button" onClick={() => fileRef.current?.click()}>
              <Icon size={15}><path d="M12 16V5m0 0L8 9m4-4 4 4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.4" /></Icon>
              {filename || "上传截图"}
            </button>
            <div>
              <button onClick={() => setMode("idle")}>暂不补充</button>
              <button
                className="evidence-submit-button"
                disabled={!evidenceText.trim() && !filename}
                onClick={submitEvidence}
              >
                加入证据并重新核验
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function UnifiedReportTemplate({
  decision,
  dimensions: availableDimensions,
  onAddEvidence,
  onContinue,
  continueLabel,
  score,
  status,
  subtitle,
  technicalView = false,
  title,
  tone,
}: {
  decision: string;
  dimensions: UnifiedReportDimension[];
  onAddEvidence?: (code: DimensionCode) => void;
  onContinue: () => void;
  continueLabel: string;
  score: number;
  status: string;
  subtitle: string;
  technicalView?: boolean;
  title: string;
  tone: string;
}) {
  const [openEvidence, setOpenEvidence] = useState<DimensionCode | null>(null);
  const [confidenceOpen, setConfidenceOpen] = useState(false);
  const [activeReportSection, setActiveReportSection] = useState("forensics-section");
  const orderedCodes = ["T", "R", "U", "S"];
  const isCurrentFullReport = title === "当前美妆种草内容" && availableDimensions.length === 4;
  const confidenceLevel = (availableDimensions.length === 4 ? "high" : availableDimensions.length >= 2 ? "medium" : "low") as "high" | "medium" | "low";
  const confidence = reportConfidenceProfiles[confidenceLevel];
  const scoreWeights: Record<string, number> = { T: 25, R: 30, U: 25, S: 20 };
  const dimensionMap = new Map(availableDimensions.map((dimension) => [dimension.code, dimension]));
  const missingDimensions = orderedCodes
    .filter((code) => !dimensionMap.has(code))
    .map((code) => ({ T: "账号材料", R: "图片材料", U: "评论材料", S: "文案材料" })[code])
    .filter(Boolean);
  const radarCoordinates = orderedCodes.map((code, index) => {
    const dimension = dimensionMap.get(code);
    const radius = dimension ? dimension.score * 0.9 : 0;
    if (index === 0) return [120, 110 - radius];
    if (index === 1) return [120 + radius, 110];
    if (index === 2) return [120, 110 + radius];
    return [120 - radius, 110];
  });

  useEffect(() => {
    const sectionIds = ["forensics-section", "cross-check-section", "decision-section"];
    const observer = new IntersectionObserver((entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((left, right) => right.intersectionRatio - left.intersectionRatio)[0];
      if (visible) setActiveReportSection(visible.target.id);
    }, { rootMargin: "-24% 0px -58% 0px", threshold: [0.05, 0.25, 0.5] });
    sectionIds.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, [isCurrentFullReport]);

  return (
    <div className="unified-report-page">
      <article className={`unified-report-card ${tone}`}>
        <header>
          <div><strong>TruLens 核验报告</strong><small>{title === "当前美妆种草内容" ? "当前美妆种草内容 · 一个 Agent 汇总四个维度·生成核验报告" : `${title} · 同一个 Agent 汇总四个维度`}</small></div>
          <span>AI 生成报告</span>
        </header>

        <nav aria-label="报告章节导航" className="report-anchor-nav">
          {[
            ["forensics-section", "① 鉴伪结果"],
            ["cross-check-section", "② 一致性校验"],
            ["decision-section", "③ 决策与建议"],
          ].map(([id, label]) => (
            <button
              className={activeReportSection === id ? "active" : ""}
              key={id}
              onClick={() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" })}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="unified-score-row">
          <div className="unified-score-cluster">
            <div className="unified-score">
              <span>Trust Score</span>
              <strong>{score}<small>/ 100</small></strong>
              <em>基于 {availableDimensions.length}/4 个维度</em>
              {confidenceLevel === "low" && <p>材料有限，结论仅供参考</p>}
            </div>
            <div className="report-confidence-wrap">
              <button
                className={`report-confidence confidence-${confidenceLevel}`}
                onClick={() => setConfidenceOpen((open) => !open)}
              >
                <span>置信度</span>
                <strong>{confidence.label}</strong>
                <i>{[1, 2, 3].map((bar) => <b className={bar <= confidence.bars ? "filled" : ""} key={bar} />)}</i>
              </button>
              {confidenceOpen && (
                <div className="report-confidence-popover">
                  <strong>置信度依据</strong>
                  <span>启用维度 <b>{availableDimensions.length}/4</b></span>
                  <span>证据条数 <b>{confidence.evidenceCount}</b></span>
                  <span>交叉验证项 <b>{confidence.crossCheckCount}</b></span>
                  <span>缺失材料 <b>{missingDimensions.length ? missingDimensions.join("、") : "无"}</b></span>
                </div>
              )}
            </div>
          </div>
          <div className="unified-verdict-group">
            <span className="unified-verdict">{status}</span>
            {isCurrentFullReport && (
              <button onClick={() => document.getElementById("cross-check-section")?.scrollIntoView({ behavior: "smooth", block: "center" })}>
                已完成交叉验证 ↓
              </button>
            )}
          </div>
        </div>

        <div className="unified-risk-band">
          <div><i style={{ left: `${score}%` }} /></div>
          <span>高风险</span><span>可信</span>
        </div>

        <section className="report-section-block" id="forensics-section">
          <header className="report-section-heading"><span>Multimodal Forensics</span><h2>① 四维结果</h2></header>
        <div className="unified-dimensions">
          <div className="unified-radar">
            <svg aria-label="T R U S 四维核验分布" viewBox="0 0 240 220">
              {[0.25, 0.5, 0.75, 1].map((scale) => {
                const radius = 90 * scale;
                return <polygon className="radar-grid" key={scale} points={`120,${110 - radius} ${120 + radius},110 120,${110 + radius} ${120 - radius},110`} />;
              })}
              <line x1="120" x2="120" y1="20" y2="200" />
              <line x1="30" x2="210" y1="110" y2="110" />
              <polygon className="unified-radar-data" points={radarCoordinates.map(([x, y]) => `${x},${y}`).join(" ")} />
              {[
                ["T", 120, 20, 120, 10, 120, 32],
                ["R", 210, 110, 226, 114, 226, 126],
                ["U", 120, 200, 120, 217, 120, 204],
                ["S", 30, 110, 14, 114, 14, 126],
              ].map(([code, x, y, tx, ty, mx, my]) => (
                <g className={dimensionMap.has(String(code)) ? "" : "missing"} key={code}>
                  <circle cx={x} cy={y} r="10" />
                  <text textAnchor="middle" x={tx} y={ty}>{code}</text>
                  {!dimensionMap.has(String(code)) && <text className="radar-disabled-label" textAnchor="middle" x={mx} y={my}>未启用</text>}
                </g>
              ))}
              {radarCoordinates.map(([x, y], index) => dimensionMap.has(orderedCodes[index]) && <circle className="unified-radar-point" cx={x} cy={y} key={orderedCodes[index]} r="4" />)}
            </svg>
            <small>四维核验分布</small>
          </div>

          <div className="unified-dimension-list">
            {orderedCodes.map((code) => {
              const dimension = dimensionMap.get(code);
              return (
                <button
                  aria-label={dimension ? `查看${dimension.title}评分证据链` : `${code} 维度数据不足`}
                  className={`unified-dimension-row ${dimension ? "" : "missing"}`}
                  disabled={!dimension}
                  key={code}
                  onClick={() => dimension && setOpenEvidence(code as DimensionCode)}
                >
                  <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
                  <div>
                    <span>
                      <strong>{dimension?.title ?? { T: "账号可信度", R: "图像原生性", U: "评论自然度", S: "文案真实性" }[code as DimensionCode]}</strong>
                      <b>{dimension ? <>{dimension.score}<small>/100 · 权重 {scoreWeights[code]}%</small><i aria-hidden="true">查看证据 →</i></> : "数据不足"}</b>
                    </span>
                    <div><i style={{ width: dimension ? `${dimension.score}%` : "0%" }} /></div>
                    <small>{dimension?.text ?? "尚未提供该维度所需材料，未参与评分。"}</small>
                    <AnimatePresence>
                      {technicalView && dimension && (
                        <motion.p
                          animate={{ opacity: 1, height: "auto" }}
                          className="technical-capability"
                          exit={{ opacity: 0, height: 0 }}
                          initial={{ opacity: 0, height: 0 }}
                        >
                          所用能力 · {technicalConfig.dimensionCapabilities[code as DimensionCode]}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        </section>

        <CrossCheckSection
          activeDimensions={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          technicalView={technicalView}
        />

        <DecisionSupport
          activeDimensions={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          confidenceLevel={availableDimensions.length === 4 ? "high" : availableDimensions.length >= 2 ? "medium" : "low"}
          continueLabel={continueLabel}
          onContinue={onContinue}
          score={score}
          subtitle={subtitle || decision}
        />
      </article>
      <AnimatePresence>
        {technicalView && (
          <motion.section
            animate={{ opacity: 1, height: "auto", y: 0 }}
            className="technical-explanation"
            exit={{ opacity: 0, height: 0, y: -4 }}
            initial={{ opacity: 0, height: 0, y: -4 }}
          >
            <div>
              <section><strong>模型</strong>{technicalConfig.models.map((model) => <span key={model}>{model}</span>)}</section>
              <section><strong>部署</strong><span>{technicalConfig.deployment}</span></section>
            </div>
            <small>{technicalConfig.disclaimer}</small>
          </motion.section>
        )}
      </AnimatePresence>
      <p className="method-note">本报告由 TruLens 根据当前可用信号生成；未提供的模态不参与判断，AI 结论不构成医疗或购买建议。</p>
      {onAddEvidence && availableDimensions.length < allDimensions.length && (
        <EvidenceExpansionPrompt
          availableCodes={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          onAddEvidence={onAddEvidence}
        />
      )}
      {openEvidence && dimensionMap.get(openEvidence) && (
        <ReportEvidenceModal
          code={openEvidence}
          dimension={dimensionMap.get(openEvidence)!}
          onClose={() => setOpenEvidence(null)}
          showAccountActivity={tone === "trusted"}
          technicalView={technicalView}
        />
      )}
    </div>
  );
}

function ArchivedResult({
  task,
  onBack,
  onTechnicalViewChange,
  technicalView,
  demoNotice = false,
}: {
  demoNotice?: boolean;
  task: Exclude<RecentTask, "makeup">;
  onBack: () => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  technicalView: boolean;
}) {
  const data = archivedTasks[task];
  return (
    <section className="result archive-result">
      <header className="result-header">
        <button aria-label="返回新鉴别" className="back-button" onClick={onBack} title="返回新鉴别">
          <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
        </button>
        <div className="result-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <button onClick={() => window.print()}>
            <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            导出 PDF
          </button>
        </div>
      </header>
      {demoNotice && <p className="demo-report-notice">虚构示例，不涉及真实账号</p>}
      <UnifiedReportTemplate
        continueLabel="开始新的鉴别"
        decision={data.decision}
        dimensions={data.dimensions}
        onContinue={onBack}
        score={data.score}
        status={data.status}
        subtitle={data.headline}
        technicalView={technicalView}
        title={data.title}
        tone={data.tone}
      />
    </section>
  );
}

function Result({
  onBack,
  onAddEvidence,
  scoreOverride,
  activeDimensions,
  liveReport,
  liveSample,
  creatorError,
  creatorInput,
  creatorLoading,
  creatorResult,
  demoNotice = false,
  recentNotice = null,
  creatorProgress,
  creatorAppeals,
  onCreatorDispute,
  onCreatorProgress,
  onCreatorRecheck,
  onContinueOther,
  onReturnModify,
  onTechnicalViewChange,
  technicalView,
}: {
  onBack: () => void;
  onAddEvidence: (code: DimensionCode) => void;
  scoreOverride?: number | null;
  activeDimensions: DimensionCode[];
  /** Real report from the backend; when present the hardcoded deck is bypassed. */
  liveReport?: ReportRead | null;
  liveSample?: SampleRead | null;
  creatorError?: string | null;
  creatorInput?: CreatorReportInput | null;
  creatorLoading?: boolean;
  creatorResult?: CreatorCheckRead | null;
  /** Fixed example opened from the sidebar: label it as fictional. */
  demoNotice?: boolean;
  /** Background refresh of a sidebar record's report. */
  recentNotice?: { state: "loading" | "error"; onRetry: () => void } | null;
  creatorProgress?: CreatorSelfCheckProgress | null;
  creatorAppeals?: Array<{ code: DimensionCode; issueId?: string }>;
  onCreatorDispute?: (dispute: { code: DimensionCode; text: string; issueId?: string }) => void;
  onCreatorProgress?: (progress: CreatorSelfCheckProgress) => void;
  onCreatorRecheck?: (draft: string) => Promise<CreatorCheckRead>;
  onContinueOther?: () => void;
  onReturnModify?: (draft: string) => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  technicalView: boolean;
}) {
  const [shareOpen, setShareOpen] = useState(false);
  // 导出 PDF stays locked until the self-check is complete (reported by the report itself).
  const [creatorCompletion, setCreatorCompletion] = useState<{ complete: boolean; reasons: string[] }>({ complete: false, reasons: [] });
  const reportDimensions = dimensions.filter((item) => activeDimensions.includes(item.code as DimensionCode));
  const reportScore = scoreOverride ?? Math.round(reportDimensions.reduce((total, item) => total + item.score, 0) / reportDimensions.length);
  const dimensionName = ["", "单维", "双维", "三维", "四维"][reportDimensions.length];
  const reportHeadline = activeDimensions.includes("R")
    ? "图片主体可信，存在轻度 AI 修饰。"
    : activeDimensions.includes("U")
      ? "评论整体自然，少量话术需留意。"
      : activeDimensions.includes("T")
        ? "账号轨迹稳定，长期行为可信。"
        : "文案表达安全，未见高风险宣称。";
  if (creatorInput) {
    return (
      <section className="result creator-result">
        <header className="result-header">
          <button aria-label="返回过程页" className="back-button" onClick={onBack} title="返回过程页">
            <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
          </button>
          <div className="result-actions">
            <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
            <span className="creator-locked-action" title={creatorCompletion.complete ? "" : "采用修改建议并再次检测通过后，可保存自检记录"}>
              <button disabled={!creatorCompletion.complete} onClick={() => window.print()} type="button">
                <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
                导出 PDF
              </button>
            </span>
          </div>
        </header>
        <CreatorSelfCheckReport
          key={creatorResult?.task_id ?? "creator-report"}
          onCompletionChange={setCreatorCompletion}
          onProgressChange={onCreatorProgress}
          onRecheck={onCreatorRecheck}
          progress={creatorProgress}
          appeals={creatorAppeals}
          onDispute={onCreatorDispute}
          error={creatorError}
          input={creatorInput}
          loading={creatorLoading}
          onContinueAgent={onBack}
          onContinueOther={onContinueOther ?? onBack}
          onRestart={() => undefined}
          onReturnModify={onReturnModify ?? (() => onBack())}
          result={creatorResult}
          technicalView={technicalView}
        />
      </section>
    );
  }
  return (
    <section className="result">
      <header className="result-header">
        <button aria-label="返回对话" className="back-button" onClick={onBack} title="返回对话">
          <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
        </button>
        <div className="result-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <button onClick={() => window.print()}>
            <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            导出 PDF
          </button>
          <div className="share-wrap">
            <button onClick={() => setShareOpen((open) => !open)}>
              <Icon size={17}><circle cx="18" cy="5" r="2" stroke="currentColor" strokeWidth="1.5" /><circle cx="6" cy="12" r="2" stroke="currentColor" strokeWidth="1.5" /><circle cx="18" cy="19" r="2" stroke="currentColor" strokeWidth="1.5" /><path d="m8 11 8-5M8 13l8 5" stroke="currentColor" strokeWidth="1.5" /></Icon>
              分享
            </button>
            {shareOpen && <ShareMenu onClose={() => setShareOpen(false)} />}
          </div>
        </div>
      </header>
      {demoNotice && <p className="demo-report-notice">虚构示例，不涉及真实账号</p>}
      {recentNotice?.state === "loading" && !liveReport && <p className="recent-report-loading">正在打开报告…</p>}
      {recentNotice?.state === "error" && (
        <p className="live-error recent-report-error">
          暂时无法获取最新报告，当前显示的是已保存的版本。
          <button className="live-resume-button" onClick={recentNotice.onRetry} type="button">重试</button>
        </p>
      )}
      {liveReport ? (
        <LiveReportView
          continueLabel="开始新的核验"
          onContinue={onBack}
          report={liveReport}
          sample={liveSample ?? null}
          technicalView={technicalView}
        />
      ) : (
        <UnifiedReportTemplate
          continueLabel="向 Agent 继续追问"
          decision={activeDimensions.length < 4
            ? "当前输入不足以完成四维交叉验证。建议补充账号主页、原始图片或评论区，以获得更完整的可信度判断。"
            : "当前四种信号已完成交叉验证，报告可以作为内容可信度与消费决策之间的参考依据。"}
          dimensions={reportDimensions}
          onAddEvidence={onAddEvidence}
          onContinue={onBack}
          score={reportScore}
          status={reportScore >= 80 ? "高可信" : "需留意"}
          subtitle={reportHeadline}
          technicalView={technicalView}
          title={activeDimensions.includes("R") ? "当前美妆种草内容" : `${dimensionName}内容核验`}
          tone={reportScore >= 80 ? "trusted" : "warning"}
        />
      )}
    </section>
  );
}

function TeamPage({
  onBack,
  onOpenReport,
}: {
  onBack: () => void;
  onOpenReport: (taskId: string) => void;
}) {
  const [items, setItems] = useState<TeamQueueItem[]>([]);
  const [groups, setGroups] = useState<TeamRelatedGroup[]>([]);
  const [summary, setSummary] = useState<TeamSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError(null);
    void getTeamQueue()
      .then((data) => {
        setItems(
          data.items.map((item) => ({
            id: item.id,
            taskId: item.task_id,
            title: item.title,
            author: item.author,
            score: Math.round(item.score),
            risk:
              item.risk_level === "high"
                ? "高风险"
                : item.risk_level === "medium"
                  ? "中风险"
                  : "高可信",
            confidence:
              item.confidence === "high" ? "高" : item.confidence === "medium" ? "中" : "低",
            dimensions: item.dimensions,
            contradiction: item.contradiction,
            issueType: item.issue_type as TeamQueueItem["issueType"],
            actions: item.actions,
            status:
              item.status === "pending"
                ? "待复核"
                : item.status === "watching"
                  ? "观察中"
                  : "已处理",
            checks: item.checks.map((check) => [check.claim, check.evidence] as [string, string]),
          })),
        );
        setGroups(
          data.groups.map((group) => ({
            id: group.id,
            signals: group.signals,
            members: group.members.map((member) => ({
              id: member.id,
              taskId: member.task_id,
              title: member.title,
              author: member.author,
              createdAt: member.created_at,
              time: new Date(member.created_at).toLocaleDateString("zh-CN", {
                month: "2-digit",
                day: "2-digit",
              }),
            })),
          })),
        );
        setSummary({
          total: data.summary.total,
          highRisk: data.summary.high_risk,
          pending: data.summary.pending,
          trusted: data.summary.trusted,
          mediumRisk: data.summary.medium_risk,
          confidenceHigh: data.summary.confidence_high,
          confidenceMedium: data.summary.confidence_medium,
          confidenceLow: data.summary.confidence_low,
        });
      })
      .catch((err) => setError(describeApiError(err)))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleUpdateStatus = async (taskIds: string[], status: "待复核" | "观察中" | "已处理") => {
    const apiStatus = status === "待复核" ? "pending" : status === "观察中" ? "watching" : "done";
    await Promise.all(taskIds.map((taskId) => updateTeamStatus(taskId, apiStatus)));
    load();
  };

  return (
    <TeamWorkspace
      error={error}
      groups={groups}
      items={items}
      loading={loading}
      onBack={onBack}
      onOpenReport={(taskId) => taskId && onOpenReport(taskId)}
      onRefresh={load}
      onUpdateStatus={handleUpdateStatus}
      summary={summary ?? undefined}
    />
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("report") === "true") return "result";
    return "home";
  });
  const [filename, setFilename] = useState("");
  const [prompt, setPrompt] = useState("请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
  const [pendingPrompt, setPendingPrompt] = useState("");
  const [creatorInput, setCreatorInput] = useState<CreatorReportInput | null>(null);
  const [creatorSeed, setCreatorSeed] = useState("");
  const [creatorResult, setCreatorResult] = useState<CreatorCheckRead | null>(null);
  // In-memory 发布前自检 progress (draft edits, adopt/ignore, 再次检测 result). Cleared per submission.
  const [creatorProgress, setCreatorProgress] = useState<CreatorSelfCheckProgress | null>(null);
  // 创作者自检 appeals (front-end record only) and a pending 「我有异议」 pre-fill.
  const [creatorAppeals, setCreatorAppeals] = useState<Array<{ code: DimensionCode; issueId?: string }>>([]);
  // Where 「返回」 goes after opening a report from the sidebar, and the fetch state of that report.
  const [returnScreen, setReturnScreen] = useState<Screen>("workspace");
  const [recentLoad, setRecentLoad] = useState<{ id: string; state: "loading" | "error" | "missing" } | null>(null);
  const [creatorAppealPreset, setCreatorAppealPreset] = useState<{ code: DimensionCode; text: string; issueId?: string; nonce: number } | null>(null);
  const [creatorLoading, setCreatorLoading] = useState(false);
  const [creatorError, setCreatorError] = useState<string | null>(null);
  const [workspaceInitialMode, setWorkspaceInitialMode] = useState<"link" | "manual" | "creator">("link");
  const [manualSeed, setManualSeed] = useState("");
  // The note field as typed (share text included), so a failed crawl can carry the copy over.
  const [lastLinkInput, setLastLinkInput] = useState("");
  // What the last 核验别人的笔记 run was given, so a failed run returns to a filled-in form.
  const [lastSubmission, setLastSubmission] = useState<{ kind: "link" | "manual"; note: string; account: string; text: string } | null>(null);
  const [workspaceNotice, setWorkspaceNotice] = useState("");
  const [activeTask, setActiveTask] = useState<RecentTask>("makeup");
  const [activeDimensions, setActiveDimensions] = useState<DimensionCode[]>(allDimensions);
  const [exampleSubmission, setExampleSubmission] = useState(false);
  const [historyCleared, setHistoryCleared] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [technicalView, setTechnicalView] = useState(false);
  const [viewingHistory, setViewingHistory] = useState(false);
  const [archivedScore, setArchivedScore] = useState<number | null>(() => {
    const saved = window.localStorage.getItem("trulens-archived-score");
    return saved ? Number(saved) : null;
  });
  const [revisedScore, setRevisedScore] = useState<number | null>(null);
  // The single source of truth for the real backend pipeline. Every screen that
  // shows live data reads from here; deleting this + the props below reverts the
  // app to the pure story-deck behaviour.
  const live = useLiveAnalysis();
  const [liveFile, setLiveFile] = useState<File | null>(null);
  const [accountUrl, setAccountUrl] = useState("");
  const [recentRuns, setRecentRuns] = useState<RecentRunRecord[]>(loadRecentRuns);
  const [activeRecentId, setActiveRecentId] = useState<string | null>(null);
  const [viewedRecentId, setViewedRecentId] = useState<string | null>(null);
  const viewedRecent = viewedRecentId
    ? recentRuns.find((run) => run.id === viewedRecentId) ?? null
    : null;
  const viewingVerifyRecord = Boolean(viewedRecent && viewedRecent.kind !== "creator");
  // A fixed example case opened from the sidebar shows its demo report, never live data.
  const viewingDemoReport = viewingHistory && !viewedRecent;

  // Screens replace the previous page in place, so the browser otherwise keeps
  // the homepage's scroll offset. Reset before paint so route-level pages such
  // as the team workspace always open from their header.
  useLayoutEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [screen]);

  useEffect(() => {
    window.localStorage.setItem(RECENT_RUNS_STORAGE_KEY, JSON.stringify(recentRuns));
  }, [recentRuns]);

  useEffect(() => {
    if (!live.taskId || !live.report) return;
    const now = new Date().toISOString();
    const next: RecentRunRecord = {
      id: live.taskId,
      taskId: live.taskId,
      title: deriveRecentTitle(prompt, filename),
      createdAt: now,
      trustScore: live.report.trust_score,
      trustLabel: live.report.trust_label,
      activeDimensions: [...activeDimensions],
      report: live.report,
      sample: live.sample,
      role: "consumer",
    };
    setRecentRuns((current) => {
      const existing = current.find((run) => run.id === next.id);
      const merged = existing ? { ...next, createdAt: existing.createdAt } : next;
      return [merged, ...current.filter((run) => run.id !== next.id)].slice(0, 8);
    });
    setActiveRecentId(live.taskId);
    setHistoryCleared(false);
  }, [activeDimensions, filename, live.report, live.sample, live.taskId, prompt]);

  useEffect(() => {
    const taskId = new URLSearchParams(window.location.search).get("task");
    if (!taskId) return;
    let cancelled = false;
    void Promise.all([getReport(taskId), getStatus(taskId)])
      .then(async ([report, status]) => {
        if (cancelled) return;
        const sample = await getSample(status.sample_id).catch(() => null);
        if (cancelled) return;
        const active = report.dimensions
          .filter((dimension) => dimension.assessed)
          .map((dimension) => dimension.code);
        const record: RecentRunRecord = {
          id: taskId,
          taskId,
          title: deriveRecentTitle(sample?.text_content ?? "", sample?.image?.filename ?? "") || `历史核验 ${taskId.slice(0, 8)}`,
          createdAt: sample?.created_at ?? report.created_at,
          trustScore: report.trust_score,
          trustLabel: report.trust_label,
          activeDimensions: active,
          report,
          sample,
          role: "consumer",
        };
        setRecentRuns((current) => [
          record,
          ...current.filter((run) => run.id !== taskId),
        ].slice(0, 8));
        setHistoryCleared(false);
        setActiveRecentId(taskId);
        setViewedRecentId(taskId);
        setActiveTask("makeup");
        setActiveDimensions(active);
        setRevisedScore(null);
        setScreen("result");
      })
      .catch(() => {
        if (!cancelled) setScreen("workspace");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const start = () => {
    live.reset();
    setLiveFile(null);
    setAccountUrl("");
    setPendingPrompt("");
    setCreatorInput(null);
    setCreatorSeed("");
    setWorkspaceInitialMode("link");
    setActiveRecentId(null);
    setViewedRecentId(null);
    setActiveTask("makeup");
    setExampleSubmission(false);
    setViewingHistory(false);
    setScreen("workspace");
  };
  const submit = (
    newPrompt: string,
    submittedFilename = filename,
    isExample = false,
    submittedAccountUrl = "",
  ) => {
    const isLink = !isExample && looksLikeXhsLink(newPrompt);
    setActiveTask("makeup");
    setViewingHistory(false);
    setActiveRecentId(null);
    setViewedRecentId(null);
    setFilename(submittedFilename);
    setExampleSubmission(isExample);
    setActiveDimensions(inferDimensions(newPrompt, submittedFilename));
    setRevisedScore(null);
    setPrompt(newPrompt);
    setAccountUrl("");
    setPendingPrompt("");
    setCreatorInput(null);
    setCreatorSeed("");
    setScreen("chat");

    // Kick off the real analysis. The example path submits the curated demo
    // payload (so the demo is reproducible); a pasted Xiaohongshu link is sent
    // as `url` for the backend to crawl; anything else is treated as the copy.
    const image = isExample ? null : liveFile;
    void live.start(
      isExample
        ? { ...DEMO_INPUT, source: "frontend-example" }
        : isLink
          ? { url: newPrompt, accountUrl: submittedAccountUrl.trim() || undefined, source: "frontend-link" }
          : { text: newPrompt, image, source: "frontend" },
    );
  };

  const submitLink = (noteUrl: string, profileUrl: string, rawInput = noteUrl) => {
    setLastLinkInput(rawInput);
    setLastSubmission({ kind: "link", note: rawInput, account: profileUrl, text: "" });
    setWorkspaceNotice("");
    // The author homepage is optional: the crawler discovers it from the note.
    // Only reject the note itself; a supplied-but-unusable profile is validated
    // before this callback in NewAnalysisForm.
    if (!looksLikeXhsLink(noteUrl)) {
      return;
    }
    live.reset();
    setLiveFile(null);
    setAccountUrl("");
    setPendingPrompt("");
    setCreatorInput(null);
    setCreatorSeed("");
    setFilename("");
    setExampleSubmission(false);
    setActiveTask("makeup");
    setActiveDimensions(allDimensions);
    setRevisedScore(null);
    setPrompt(noteUrl);
    setActiveRecentId(null);
    setViewedRecentId(null);
    setViewingHistory(false);
    setScreen("chat");
    void live.start({
      url: noteUrl,
      accountUrl: profileUrl,
      source: "frontend-link",
      agents: ["account", "image", "comment", "text"],
    });
  };

  const submitManual = ({
    text,
    image,
    comments,
    accountHistory,
  }: {
    text: string;
    image: File | null;
    comments: string;
    accountHistory: string;
  }) => {
    if (!text.trim() && !image) return;
    setLastSubmission({ kind: "manual", note: "", account: "", text });
    setWorkspaceNotice("");
    live.reset();
    setLiveFile(null);
    setAccountUrl("");
    setPendingPrompt("");
    setCreatorInput(null);
    setCreatorSeed("");
    setFilename(image?.name ?? "");
    setExampleSubmission(false);
    setActiveTask("makeup");
    setActiveDimensions([
      ...(image ? ["R" as DimensionCode] : []),
      ...(text.trim() ? ["S" as DimensionCode] : []),
      ...(comments.trim() ? ["U" as DimensionCode] : []),
      ...(accountHistory.trim() ? ["T" as DimensionCode] : []),
    ]);
    setRevisedScore(null);
    setPrompt(text.trim() || "请核验我上传的图片内容");
    setActiveRecentId(null);
    setViewedRecentId(null);
    setViewingHistory(false);
    setScreen("chat");
    void live.start({
      text: text.trim() || undefined,
      image,
      comments: comments.trim() || undefined,
      accountHistory: accountHistory.trim() || undefined,
      source: "frontend-manual",
    });
  };

  const submitCreator = (input: CreatorReportInput) => {
    setActiveTask("makeup");
    setViewingHistory(false);
    setActiveRecentId(null);
    setViewedRecentId(null);
    setFilename(input.images.length ? `${input.images.length} 张待发布配图` : "");
    setExampleSubmission(input.isExample);
    setActiveDimensions(input.images.length ? ["R", "S"] : ["S"]);
    setRevisedScore(null);
    setPrompt(input.draft);
    setCreatorInput(input);
    setCreatorResult(null);
    setCreatorError(null);
    setCreatorLoading(true);
    setCreatorSeed("");
    // Experts think on the chat page first; the report opens from 「查看自检报告」.
    setScreen("chat");
    runCreatorCheck(input);
  };

  // Same checkCreator call and arguments as before; reused by 「重试」.
  // A verification that failed (e.g. a well-formed link the backend could not fetch) does not
  // linger on the process page: go back to the input with one short line and the inputs kept.
  useEffect(() => {
    if (screen !== "chat" || creatorInput || live.phase !== "error" || !lastSubmission) return;
    const message = friendlyLiveError(live.error ?? "").message;
    live.reset();
    if (lastSubmission.kind === "link") {
      setPendingPrompt(lastSubmission.note);
      setAccountUrl(lastSubmission.account);
      setWorkspaceInitialMode("link");
    } else {
      setManualSeed(lastSubmission.text);
      setWorkspaceInitialMode("manual");
    }
    setWorkspaceNotice(message);
    setScreen("workspace");
  }, [live.phase, screen]);

  const loadRecentReport = (id: string, taskId: string, hasCache: boolean) => {
    void getReport(taskId)
      .then((report) => {
        setRecentRuns((current) =>
          current.map((item) =>
            item.id === id ? { ...item, report, trustScore: report.trust_score, trustLabel: report.trust_label } : item,
          ),
        );
        setRecentLoad((current) => (current?.id === id ? null : current));
      })
      .catch(() => setRecentLoad((current) => (current && current.id !== id ? current : { id, state: hasCache ? "error" : "missing" })));
  };

  const runCreatorCheck = (input: CreatorReportInput) => {
    setCreatorProgress(null);
    setCreatorAppeals([]);
    setCreatorAppealPreset(null);
    setCreatorResult(null);
    setCreatorError(null);
    setCreatorLoading(true);
    const image = input.images.find((item) => item.file)?.file ?? null;
    void checkCreator({
      draft: input.draft,
      isCollaboration: input.isCollaboration,
      category: input.category,
      image,
    })
      .then((result) => {
        setCreatorResult(result);
        const record: RecentRunRecord = {
          id: result.task_id,
          taskId: result.task_id,
          title: deriveRecentTitle(input.draft, input.images[0]?.name ?? ""),
          createdAt: new Date().toISOString(),
          trustScore: result.report.trust_score,
          trustLabel: result.report.trust_label,
          activeDimensions: result.report.dimensions.filter((dimension) => dimension.assessed).map((dimension) => dimension.code),
          report: result.report,
          sample: null,
          kind: "creator",
          role: "creator",
          creator: {
            draft: input.draft,
            category: input.category,
            isCollaboration: input.isCollaboration,
            imageNames: input.images.map((image) => image.name),
            result,
          },
        };
        setRecentRuns((current) => [record, ...current.filter((run) => run.id !== record.id)].slice(0, 8));
        setActiveRecentId(record.id);
        setHistoryCleared(false);
        setActiveDimensions(
          result.report.dimensions
            .filter((dimension) => dimension.assessed)
            .map((dimension) => dimension.code),
        );
      })
      .catch((err) => setCreatorError(describeApiError(err)))
      .finally(() => setCreatorLoading(false));
  };

  // checkCreator's result in the shape the verification chat already understands, so the
  // creator flow renders through the very same Chat / AnalysisSteps components.
  const creatorLive: LiveRun = {
    phase: creatorLoading ? "running" : creatorError ? "error" : creatorResult ? "done" : creatorInput ? "running" : "idle",
    taskId: creatorResult?.task_id ?? null,
    sampleId: creatorResult?.sample_id ?? null,
    status: null,
    agents: (creatorResult?.report.dimensions ?? []).map((dimension) => ({
      agent: dimension.key,
      code: dimension.code,
      label: dimension.label,
      status: "completed" as const,
      assessed: dimension.assessed,
      risk_level: dimension.risk_level,
      risk_score: dimension.risk_score,
      trust_level: dimension.trust_level,
      trust_score: dimension.trust_score,
      trust_label: dimension.trust_label,
      duration_ms: null,
      error_message: null,
    })),
    report: creatorResult?.report ?? null,
    sample: null,
    error: creatorError,
    start: async () => undefined,
    resume: async () => {
      if (creatorInput) runCreatorCheck(creatorInput);
    },
    reset: () => undefined,
  };

  const openTaskReport = (taskId: string) => {
    void Promise.all([getReport(taskId), getStatus(taskId)])
      .then(async ([report, status]) => {
        const sample = await getSample(status.sample_id).catch(() => null);
        const active = report.dimensions
          .filter((dimension) => dimension.assessed)
          .map((dimension) => dimension.code);
        const record: RecentRunRecord = {
          id: taskId,
          taskId,
          title: deriveRecentTitle(sample?.text_content ?? "", sample?.image?.filename ?? ""),
          createdAt: sample?.created_at ?? report.created_at,
          trustScore: report.trust_score,
          trustLabel: report.trust_label,
          activeDimensions: active,
          report,
          sample,
          role: "consumer",
        };
        setRecentRuns((current) => [
          record,
          ...current.filter((run) => run.id !== taskId),
        ].slice(0, 8));
        setActiveRecentId(taskId);
        setViewedRecentId(taskId);
        setActiveTask("makeup");
        setViewingHistory(false);
        setActiveDimensions(active);
        setRevisedScore(null);
        setScreen("result");
      })
      .catch((err) => {
        console.error("task report open failed", err);
      });
  };

  if (screen === "home") {
    return (
      <Home
        onCreator={() => {
          setCreatorInput(null);
          setCreatorSeed("");
          setWorkspaceInitialMode("creator");
          setScreen("workspace");
        }}
        onStart={start}
        onSubmit={(newPrompt, submittedFilename, isExample) => submit(newPrompt, submittedFilename, isExample)}
        onTeam={() => setScreen("team")}
      />
    );
  }

  if (screen === "team") {
    return (
      <TeamPage
        onBack={() => setScreen("home")}
        onOpenReport={openTaskReport}
      />
    );
  }

  return (
    <main className={`app-shell ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar
        active={screen}
        activeTask={activeTask}
        archivedScore={archivedScore}
        activeRecentId={activeRecentId}
        collapsed={sidebarCollapsed}
        historyCleared={historyCleared}
        recentRuns={recentRuns}
        onLogout={() => {
          setFilename("");
          setAccountUrl("");
          setCreatorInput(null);
          setCreatorSeed("");
          live.reset();
          setActiveRecentId(null);
          setViewedRecentId(null);
          setScreen("home");
        }}
        onNew={() => {
          setFilename("");
          setAccountUrl("");
          setPendingPrompt("");
          setCreatorInput(null);
          setCreatorSeed("");
          setWorkspaceInitialMode("link");
          setExampleSubmission(false);
          setActiveTask("makeup");
          setActiveDimensions(allDimensions);
          setViewingHistory(false);
          live.reset();
          setLiveFile(null);
          setActiveRecentId(null);
          setViewedRecentId(null);
          setScreen("workspace");
        }}
        onRecent={(id) => {
          const run = recentRuns.find((item) => item.id === id);
          if (!run) return;
          setReturnScreen(screen === "result" ? returnScreen : screen);
          setActiveRecentId(id);
          setViewedRecentId(id);
          setActiveTask("makeup");
          setViewingHistory(false);
          setRevisedScore(null);
          setActiveDimensions(run.activeDimensions?.length ? run.activeDimensions : allDimensions);
          if (run.kind === "creator") {
            // Rebuild the creator report from what the record saved (no backend call).
            if (!run.creator?.result) {
              setRecentLoad({ id, state: "missing" });
              setScreen("result");
              return;
            }
            setRecentLoad(null);
            setCreatorInput({
              draft: run.creator.draft,
              images: [],
              isCollaboration: run.creator.isCollaboration,
              category: run.creator.category,
              isExample: false,
            });
            setCreatorResult(run.creator.result);
            setCreatorError(null);
            setCreatorLoading(false);
            setCreatorProgress(null);
            setCreatorAppeals([]);
            setScreen("result");
            return;
          }
          // Verification record: show the cached report at once, refresh it in the background.
          setRecentLoad(run.report ? null : { id, state: "loading" });
          setScreen("result");
          loadRecentReport(id, run.taskId, Boolean(run.report));
        }}
        onResetAgent={() => {
          setFilename("");
          setAccountUrl("");
          setPendingPrompt("");
          setCreatorInput(null);
          setCreatorSeed("");
          setWorkspaceInitialMode("link");
          setExampleSubmission(false);
          setPrompt("请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
          setActiveTask("makeup");
          setActiveDimensions(allDimensions);
          setHistoryCleared(true);
          setViewingHistory(false);
          live.reset();
          setLiveFile(null);
          setRecentRuns([]);
          window.localStorage.removeItem(RECENT_RUNS_STORAGE_KEY);
          setActiveRecentId(null);
          setViewedRecentId(null);
          setArchivedScore(null);
          window.localStorage.removeItem("trulens-archived-score");
          setScreen("workspace");
        }}
        onReport={(task) => {
          setReturnScreen(screen === "result" ? returnScreen : screen);
          setRecentLoad(null);
          setActiveRecentId(null);
          setViewedRecentId(null);
          setActiveTask(task);
          setViewingHistory(true);
          if (task === "makeup") setActiveDimensions(allDimensions);
          setScreen("result");
        }}
        onTask={(task) => {
          setActiveRecentId(null);
          setViewedRecentId(null);
          setActiveTask(task);
          setViewingHistory(true);
          if (task === "makeup") setActiveDimensions(allDimensions);
          setScreen("chat");
        }}
        onTaskReport={openTaskReport}
        onToggle={() => setSidebarCollapsed((collapsed) => !collapsed)}
      />
      {screen === "workspace" && (
        <Workspace
          accountUrl={accountUrl}
          creatorPreset={creatorSeed}
          filename={filename}
          initialMode={workspaceInitialMode}
          onAccountUrl={setAccountUrl}
          onFile={setFilename}
          onPickFile={setLiveFile}
          onHome={() => setScreen("home")}
          manualPreset={manualSeed}
          notice={workspaceNotice}
          preset={pendingPrompt}
          onSubmitCreator={submitCreator}
          onSubmitLink={submitLink}
          onSubmitManual={submitManual}
        />
      )}
      {screen === "chat" && activeTask === "makeup" && !viewingHistory && (
        <Chat
          activeDimensions={creatorInput ? (creatorInput.images.length ? ["R", "S"] : ["S"]) : activeDimensions}
          creatorMode={Boolean(creatorInput)}
          appealPreset={creatorInput ? creatorAppealPreset : null}
          onAppealSubmitted={(appeal) => {
            if (creatorInput) setCreatorAppeals((current) => [...current, appeal]);
          }}
          filename={filename}
          isExampleSubmission={exampleSubmission}
          key={creatorInput ? "creator-chat" : "verify-chat"}
          live={creatorInput ? creatorLive : live}
          onArchiveReport={(score) => {
            setArchivedScore(score);
            setHistoryCleared(false);
            window.localStorage.setItem("trulens-archived-score", String(score));
          }}
          onFile={setFilename}
          onHome={() => setScreen("home")}
          onResult={() => {
            setActiveTask("makeup");
            setRevisedScore(null);
            setScreen("result");
          }}
          onTechnicalViewChange={setTechnicalView}
          appealRecordOnly
          onUseManual={(text) => {
            live.reset();
            setManualSeed(stripLinksFromShareText(lastLinkInput) || text);
            setWorkspaceInitialMode("manual");
            setScreen("workspace");
          }}
          onViewRevisedReport={(score) => {
            setActiveTask("makeup");
            setRevisedScore(score);
            setScreen("result");
          }}
          prompt={prompt}
          technicalView={technicalView}
        />
      )}
      {screen === "chat" && viewingHistory && (
        <ArchivedConversation
          onHome={() => {
            setViewingHistory(false);
            setScreen("workspace");
          }}
          onResult={() => setScreen("result")}
          task={activeTask}
        />
      )}
      {screen === "result" && activeTask === "makeup" && recentLoad?.state === "missing" && (
        <section className="result recent-report-missing">
          <div>
            <strong>该记录的报告无法打开</strong>
            <p>这条记录没有可还原的报告，也暂时无法从服务端取回。</p>
            <div>
              <button onClick={() => { setRecentLoad(null); setViewedRecentId(null); setActiveRecentId(null); setScreen("workspace"); }} type="button">新建核验</button>
              {viewedRecent && viewedRecent.kind !== "creator" && (
                <button onClick={() => { setRecentLoad({ id: viewedRecent.id, state: "loading" }); loadRecentReport(viewedRecent.id, viewedRecent.taskId, false); }} type="button">重试</button>
              )}
            </div>
          </div>
        </section>
      )}
      {screen === "result" && activeTask === "makeup" && recentLoad?.state !== "missing" && (
        <Result
          activeDimensions={activeDimensions}
          creatorError={creatorError}
          creatorInput={viewingVerifyRecord || viewingDemoReport ? null : creatorInput}
          demoNotice={viewingDemoReport}
          recentNotice={viewedRecent && recentLoad && recentLoad.id === viewedRecent.id ? { state: recentLoad.state, onRetry: () => { setRecentLoad({ id: viewedRecent.id, state: "loading" }); loadRecentReport(viewedRecent.id, viewedRecent.taskId, Boolean(viewedRecent.report)); } } : null}
          creatorLoading={creatorLoading}
          creatorResult={creatorResult}
          creatorProgress={creatorProgress}
          creatorAppeals={creatorAppeals}
          onCreatorDispute={(dispute) => {
            setCreatorAppealPreset({ ...dispute, nonce: Date.now() });
            setScreen("chat");
          }}
          onCreatorProgress={setCreatorProgress}
          onCreatorRecheck={(draft) => {
            // 再次检测: the same checkCreator call and argument format as the first check.
            const input = creatorInput;
            const image = input?.images.find((item) => item.file)?.file ?? null;
            return checkCreator({
              draft,
              isCollaboration: input?.isCollaboration ?? false,
              category: input?.category ?? "护肤",
              image,
            }).catch((err) => {
              throw new Error(describeApiError(err));
            });
          }}
          liveReport={viewingDemoReport ? null : viewedRecent?.report ?? live.report}
          liveSample={viewingDemoReport ? null : viewedRecent?.sample ?? live.sample}
          onAddEvidence={(code) => setActiveDimensions((current) => allDimensions.filter((dimension) => current.includes(dimension) || dimension === code))}
          onBack={() => {
            // Opened from the sidebar (a record or a fixed example): back to where the user was.
            if (viewedRecent || viewingDemoReport) {
              setViewedRecentId(null);
              setActiveRecentId(null);
              setViewingHistory(false);
              setScreen(returnScreen === "result" ? "workspace" : returnScreen);
              return;
            }
            // Creator report → back to its score page while the result is still here.
            if (creatorInput && (creatorResult || creatorLoading)) {
              setScreen("chat");
              return;
            }
            if (creatorInput) {
              setCreatorInput(null);
              setCreatorResult(null);
              setCreatorError(null);
              setCreatorLoading(false);
              setScreen("workspace");
              return;
            }
            if (viewedRecent) {
              setViewedRecentId(null);
              setActiveRecentId(null);
              setScreen("workspace");
              return;
            }
            setScreen("chat");
          }}
          onContinueOther={() => {
            setCreatorInput(null);
            setCreatorSeed("");
            setWorkspaceInitialMode("creator");
            setScreen("workspace");
          }}
          onReturnModify={(draft) => {
            setCreatorInput(null);
            setCreatorSeed(draft);
            setWorkspaceInitialMode("creator");
            setScreen("workspace");
          }}
          onTechnicalViewChange={setTechnicalView}
          scoreOverride={revisedScore}
          technicalView={technicalView}
        />
      )}
      {screen === "result" && activeTask !== "makeup" && (
        <ArchivedResult
          demoNotice
          onBack={() => {
            setViewingHistory(false);
            setScreen(returnScreen === "result" ? "workspace" : returnScreen);
          }}
          onTechnicalViewChange={setTechnicalView}
          task={activeTask}
          technicalView={technicalView}
        />
      )}
    </main>
  );
}
