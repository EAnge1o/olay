// @ts-nocheck
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Fragment, useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";

import type { CreatorCheckRead } from "./api";

type Screen = "home" | "workspace" | "chat" | "result" | "team";
type RecentTask = "makeup" | "serum" | "whitening";
type DimensionCode = "T" | "R" | "U" | "S";
type WorkspaceMode = "verify" | "creator";

type CreatorReportInput = {
  draft: string;
  images: Array<{ id: string; name: string; url: string; file?: File; example?: boolean }>;
  isCollaboration: boolean;
  category: string;
  isExample: boolean;
};

const allDimensions: DimensionCode[] = ["T", "R", "U", "S"];

function inferDimensions(prompt: string, filename: string): DimensionCode[] {
  const content = `${prompt} ${filename}`.toLowerCase();
  const normalizedPrompt = prompt.trim().toLowerCase();
  const mentionsComments = /评论|评论区|留言|回复|comment/.test(content);
  const mentionsAccount = /账号|帐号|博主|主页|历史内容|account|profile/.test(content);
  const mentionsImage = /配图|图片|图像|照片|视觉|对比图|image|photo/.test(content);
  const requestsFullAnalysis = /全部|完整|多模态|整篇帖子|小红书笔记|full/.test(content);
  const hasAnyLink =
    /(?:https?:\/\/|www\.)\S+|(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}(?:\/\S*)?/.test(normalizedPrompt);

  if (hasAnyLink) return allDimensions;
  if (requestsFullAnalysis && filename) return allDimensions;
  if (mentionsComments) return ["U", "S"];
  if (mentionsAccount) return ["T", "S"];
  if (mentionsImage) return ["R", "S"];
  if (filename) return ["R", "S"];
  return ["S"];
}

const portrait =
  "https://images.unsplash.com/photo-1675773051474-55c4b7d2cf53?crop=faces&fit=crop&fm=jpg&q=85&w=1200&h=1400";
const postImage =
  "https://images.unsplash.com/photo-1752245818739-890854ca3b81?crop=faces&fit=crop&fm=jpg&q=85&w=900&h=1100";
const roleAvatarByCode: Record<DimensionCode, string> = {
  T: "/agents/t.png",
  R: "/agents/r.png",
  U: "/agents/u.png",
  S: "/agents/s.png",
};

function Icon({
  children,
  size = 20,
  className = "",
}: {
  children: ReactNode;
  size?: number;
  className?: string;
}) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
    >
      {children}
    </svg>
  );
}

const Sparkle = ({ size = 20 }: { size?: number }) => (
  <Icon size={size}>
    <path
      d="M12 2.5c.7 5.2 3.4 8 8.7 8.7-5.3.7-8 3.5-8.7 8.8-.7-5.3-3.4-8.1-8.7-8.8C8.6 10.5 11.3 7.7 12 2.5Z"
      stroke="currentColor"
      strokeLinejoin="round"
      strokeWidth="1.5"
    />
  </Icon>
);

const truLensMarkConfig = {
  lens: { cx: 48, cy: 45, radius: 34, fill: "#F8F6FD", stroke: "#CFC5EE", width: 2 },
  diamond: {
    points: "48,21 72,45 48,69 24,45",
    fill: "#D9D0F4",
    stroke: "#A999D5",
    width: 1.2,
  },
  dots: [
    { code: "T", cx: 48, cy: 13, fill: "#D7CDED" },
    { code: "R", cx: 80, cy: 45, fill: "#D7CDED" },
    { code: "U", cx: 48, cy: 77, fill: "#D7CDED" },
    { code: "S", cx: 16, cy: 45, fill: "#D7CDED" },
  ],
  dot: { radius: 7, stroke: "#B7A8DC", width: 1 },
} as const;

function TruLensMark({ size = 25 }: { size?: number }) {
  return (
    <svg
      aria-hidden="true"
      className="trulens-mark"
      height={size}
      viewBox="0 0 116 100"
      width={size * 1.16}
    >
      <path d="M72 69 94 91" stroke="#B8A9E2" strokeLinecap="round" strokeWidth="13" />
      <path d="M72 69 94 91" stroke="#DDD6F2" strokeLinecap="round" strokeWidth="8" />
      <ellipse cx="46" cy="45" fill="none" rx="47" ry="19" stroke="#DDD6F2" strokeWidth="1.2" transform="rotate(-17 46 45)" />
      <circle
        cx={truLensMarkConfig.lens.cx}
        cy={truLensMarkConfig.lens.cy}
        fill={truLensMarkConfig.lens.fill}
        fillOpacity=".78"
        r={truLensMarkConfig.lens.radius}
        stroke={truLensMarkConfig.lens.stroke}
        strokeWidth={truLensMarkConfig.lens.width}
      />
      {truLensMarkConfig.dots.map((dot) => (
        <line key={`line-${dot.code}`} stroke="#C7BDE5" strokeWidth="1" x1="48" x2={dot.cx} y1="45" y2={dot.cy} />
      ))}
      <polygon
        fill={truLensMarkConfig.diamond.fill}
        fillOpacity=".88"
        points={truLensMarkConfig.diamond.points}
        stroke={truLensMarkConfig.diamond.stroke}
        strokeLinejoin="round"
        strokeWidth={truLensMarkConfig.diamond.width}
      />
      {truLensMarkConfig.dots.map((dot, index) => (
        <circle
          className={`trulens-mark-dot dot-${index + 1}`}
          cx={dot.cx}
          cy={dot.cy}
          fill={dot.fill}
          key={dot.code}
          r={truLensMarkConfig.dot.radius}
          stroke={truLensMarkConfig.dot.stroke}
          strokeWidth={truLensMarkConfig.dot.width}
        />
      ))}
      {truLensMarkConfig.dots.map((dot) => (
        <text
          fill="#554A70"
          fontFamily="DM Mono, monospace"
          fontSize="6.5"
          key={`text-${dot.code}`}
          textAnchor="middle"
          x={dot.cx}
          y={dot.cy + 2.3}
        >
          {dot.code}
        </text>
      ))}
      <path d="M96 10c.5 4 2.5 6 6.5 6.5-4 .5-6 2.5-6.5 6.5-.5-4-2.5-6-6.5-6.5 4-.5 6-2.5 6.5-6.5Z" fill="#B6A6E0" />
    </svg>
  );
}

function Logo() {
  return (
    <button className="logo" onClick={() => window.scrollTo({ top: 0 })}>
      <img alt="TruLens" src="/trulens-nav-logo.png" />
    </button>
  );
}

function Arrow({ size = 20 }: { size?: number }) {
  return (
    <Icon size={size}>
      <path d="M5 12h14M14 7l5 5-5 5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
    </Icon>
  );
}

function canvasCard(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  context.beginPath();
  context.roundRect(x, y, width, height, radius);
  context.fill();
}

function canvasParagraph(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
) {
  let line = "";
  let currentY = y;
  for (const character of text) {
    if (context.measureText(line + character).width > maxWidth && line) {
      context.fillText(line, x, currentY);
      line = character;
      currentY += lineHeight;
    } else {
      line += character;
    }
  }
  context.fillText(line, x, currentY);
}

async function exportTrustLongImage() {
  await document.fonts.ready;
  const canvas = document.createElement("canvas");
  canvas.width = 1440;
  canvas.height = 2920;
  const context = canvas.getContext("2d");
  if (!context) return;

  const background = context.createLinearGradient(0, 0, 1440, 2920);
  background.addColorStop(0, "#fbfafd");
  background.addColorStop(0.5, "#f2eff9");
  background.addColorStop(1, "#faf4f3");
  context.fillStyle = background;
  context.fillRect(0, 0, 1440, 2920);

  context.fillStyle = "rgba(211,199,241,.32)";
  context.beginPath();
  context.arc(1190, 430, 370, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "rgba(242,207,216,.26)";
  context.beginPath();
  context.arc(100, 2310, 390, 0, Math.PI * 2);
  context.fill();

  context.fillStyle = "#292535";
  context.font = '500 34px "DM Mono", monospace';
  context.fillText("✦ TruLens", 90, 110);
  context.textAlign = "right";
  context.font = '400 20px "DM Mono", monospace';
  context.fillStyle = "#817a89";
  context.fillText("TRUST PROFILE · 2025.06.18", 1350, 108);
  context.textAlign = "left";
  context.font = '500 76px "Noto Sans SC", sans-serif';
  context.fillStyle = "#272332";
  context.fillText("这篇种草，值得相信吗？", 90, 260);
  context.font = '400 25px "Noto Sans SC", sans-serif';
  context.fillStyle = "#827b88";
  context.fillText("秋冬奶油肌底妆分享 · 多模态内容可信度报告", 94, 316);

  context.fillStyle = "rgba(255,255,255,.8)";
  canvasCard(context, 90, 390, 1260, 650, 42);
  context.beginPath();
  context.arc(390, 705, 180, -Math.PI / 2, Math.PI * 1.18);
  context.strokeStyle = "#776b9d";
  context.lineWidth = 24;
  context.lineCap = "round";
  context.stroke();
  context.beginPath();
  context.arc(390, 705, 180, Math.PI * 1.18, Math.PI * 1.5);
  context.strokeStyle = "rgba(119,107,157,.14)";
  context.stroke();
  context.textAlign = "center";
  context.fillStyle = "#292535";
  context.font = '500 150px "Playfair Display", serif';
  context.fillText("84", 390, 740);
  context.font = '400 18px "DM Mono", monospace';
  context.fillStyle = "#89828e";
  context.fillText("TRUST SCORE / 100", 390, 790);

  context.textAlign = "left";
  context.fillStyle = "#e3f0e9";
  canvasCard(context, 680, 520, 150, 46, 23);
  context.fillStyle = "#547664";
  context.font = '500 19px "Noto Sans SC", sans-serif';
  context.fillText("●  高可信", 705, 551);
  context.fillStyle = "#292535";
  context.font = '500 52px "Noto Sans SC", sans-serif';
  context.fillText("真实内容为主，", 680, 660);
  context.fillText("有轻度 AI 修图。", 680, 730);
  context.fillStyle = "#756e7b";
  context.font = '400 23px "Noto Sans SC", sans-serif';
  canvasParagraph(context, "没有发现系统性 AI 造假或虚假营销证据。图片中存在局部生成式修饰，但不影响产品展示的主要真实性。", 680, 805, 540, 42);

  context.fillStyle = "#8b8491";
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("FOUR DIMENSIONS", 90, 1145);
  const exportDimensions = [
    ["T", "账号可信度", "82", "#eee9fb", "账号运营稳定，历史内容与商业合作节奏自然。"],
    ["R", "图像原生性", "88", "#e8f1fa", "发现两处生成式皮肤细化，但产品主体保持真实。"],
    ["U", "评论自然度", "74", "#f8eae7", "12% 短评存在相似句式，整体互动结构仍较自然。"],
    ["S", "文案真实性", "91", "#e7f2ec", "未使用绝对化功效承诺，合作标识与体验边界清晰。"],
  ];
  exportDimensions.forEach(([code, title, score, color, copy], index) => {
    const x = 90 + (index % 2) * 640;
    const y = 1210 + Math.floor(index / 2) * 430;
    context.fillStyle = color;
    canvasCard(context, x, y, 610, 390, 32);
    context.fillStyle = "#332e3c";
    context.font = '500 66px "Playfair Display", serif';
    context.fillText(code, x + 34, y + 85);
    context.font = '500 30px "Noto Sans SC", sans-serif';
    context.fillText(title, x + 34, y + 137);
    context.textAlign = "right";
    context.font = '500 72px "Playfair Display", serif';
    context.fillText(score, x + 565, y + 97);
    context.textAlign = "left";
    context.fillStyle = "rgba(49,43,59,.12)";
    canvasCard(context, x + 34, y + 174, 542, 6, 3);
    context.fillStyle = "#746982";
    canvasCard(context, x + 34, y + 174, 542 * (Number(score) / 100), 6, 3);
    context.fillStyle = "#716a77";
    context.font = '400 21px "Noto Sans SC", sans-serif';
    canvasParagraph(context, copy, x + 34, y + 237, 530, 38);
  });

  context.fillStyle = "rgba(255,255,255,.72)";
  canvasCard(context, 90, 2115, 1260, 480, 38);
  context.fillStyle = "#81788d";
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("TruLens DECISION SUPPORT", 135, 2185);
  context.fillStyle = "#292535";
  context.font = '500 48px "Noto Sans SC", sans-serif';
  context.fillText("可以参考，但请关注真实肤质差异。", 135, 2275);
  context.fillStyle = "#716a77";
  context.font = '400 24px "Noto Sans SC", sans-serif';
  canvasParagraph(context, "这篇内容可以作为妆效灵感与色号参考。由于博主对皮肤纹理做过局部 AI 修饰，不建议仅依据“零毛孔”效果判断产品遮瑕力。购买前可再查看自然光下的素人试色视频。", 135, 2360, 1150, 44);
  context.textAlign = "center";
  context.fillStyle = "#96909b";
  context.font = '400 18px "Noto Sans SC", sans-serif';
  context.fillText("由 TruLens 多模态模型生成 · AI 判断不构成医疗或购买建议", 720, 2750);
  context.font = '500 18px "DM Mono", monospace';
  context.fillText("TruLens — BEAUTY, VERIFIED WITH INTELLIGENCE.", 720, 2815);

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png", 1));
  if (!blob) return;
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "TruLens-美妆内容可信度报告.png";
  link.click();
  URL.revokeObjectURL(url);
}

function ShareMenu({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const [exportingImage, setExportingImage] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const closeOnOutsideClick = (event: MouseEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) onClose();
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("mousedown", closeOnOutsideClick);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOnOutsideClick);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [onClose]);

  const copyReportLink = async () => {
    const url = new URL(window.location.href);
    url.searchParams.set("report", "true");
    try {
      await navigator.clipboard.writeText(url.toString());
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt("复制这份报告链接", url.toString());
    }
  };

  return (
    <div className="share-menu" ref={menuRef}>
      <div className="share-menu-title">
        <strong>分享鉴别结果</strong>
        <small>链接接收者可直接查看报告</small>
      </div>
      <button onClick={copyReportLink}>
        <span className="share-action-icon">
          <Icon size={17}>
            <path d="m9.5 14.5 5-5M7.3 16.7l-1 1a3.5 3.5 0 0 1-5-5l3.2-3.2a3.5 3.5 0 0 1 5 0M16.7 7.3l1-1a3.5 3.5 0 1 1 5 5l-3.2 3.2a3.5 3.5 0 0 1-5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>{copied ? "链接已复制" : "复制分享链接"}</strong><small>{copied ? "可以发送给好友了" : "生成可直接访问的报告链接"}</small></span>
        <span className={copied ? "copy-state copied" : "copy-state"}>{copied ? "✓" : "⌘C"}</span>
      </button>
      <button
        onClick={async () => {
          setExportingImage(true);
          await exportTrustLongImage();
          setExportingImage(false);
        }}
      >
        <span className="share-action-icon image">
          <Icon size={17}>
            <rect height="17" rx="2.5" stroke="currentColor" strokeWidth="1.5" width="18" x="3" y="3.5" />
            <circle cx="8.5" cy="9" r="1.6" stroke="currentColor" strokeWidth="1.4" />
            <path d="m5.5 18 4.2-4.6 2.7 2.6 2.2-2 3.9 4" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>{exportingImage ? "正在生成长图…" : "导出成长图"}</strong><small>适合保存到相册或社交平台分享</small></span>
        <Arrow size={15} />
      </button>
      <button
        onClick={() => {
          onClose();
          window.setTimeout(() => window.print(), 100);
        }}
      >
        <span className="share-action-icon pdf">
          <Icon size={17}>
            <path d="M6 3h8l4 4v14H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
            <path d="M14 3v5h4M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
        </span>
        <span><strong>导出为 PDF</strong><small>保存或打印完整鉴别报告</small></span>
        <Arrow size={15} />
      </button>
      <p>报告不包含原帖作者的私密信息</p>
    </div>
  );
}

const storyScene = {
  step: "01 / READ",
  eyebrow: "BEFORE YOU BUY",
  title: "你还相信你自己看到的吗？",
  body: "一张完美的照片、一篇动人的分享、成千上万条好评，都可能隐藏着你看不到的信息。",
};

function StoryVisual() {
  return (
    <div className="story-post">
      <div className="post-browser">
        <span /><span /><span />
        <small>note / 3285491</small>
      </div>
      <div className="post-image">
        <img alt="模拟美妆种草帖子" src={postImage} />
        <span className="post-image-tag">原始内容 · 6 张图片</span>
      </div>
      <div className="post-copy">
        <div className="mock-avatar" />
        <div><strong>秋冬奶油肌底妆分享</strong><span>今天也要认真护肤 · 2 小时前</span></div>
      </div>
      <div className="post-lines"><i /><i /><i /></div>
      <div className="reading-line"><span /></div>
      <small className="reading-caption">正在建立内容语境 · 68%</small>
    </div>
  );
}

function StoryScroller() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardScrollRef = useRef<HTMLDivElement>(null);
  const countFrameRef = useRef(0);
  const dataPlayedRef = useRef(false);
  const [currentPanel, setCurrentPanel] = useState(0);
  const [sectionVisible, setSectionVisible] = useState(false);
  const [answers, setAnswers] = useState<Array<QuizChoice | null>>([null, null, null]);
  const [dataValues, setDataValues] = useState([0, 0, 0]);
  const [scrollHintVisible, setScrollHintVisible] = useState(true);
  const score = answers.reduce((total, answer, index) => total + (answer === aiImageQuizQuestions[index].aiAnswer ? 1 : 0), 0);
  const unanswered = answers.filter((answer) => answer === null).length;
  const resultTitle = score === 3 ? "眼力不错。" : score === 2 ? "差一点。" : "这很正常，这正是 AI 图的厉害之处。";
  const activeStep = currentPanel === 0 ? "data" : currentPanel < 4 ? "quiz" : "result";

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setSectionVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.cancelAnimationFrame(countFrameRef.current);
    if (!sectionVisible || currentPanel !== 0 || dataPlayedRef.current) return;
    dataPlayedRef.current = true;
    const targets = [66, 57, 35.7];
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDataValues(targets);
      return;
    }
    const start = performance.now();
    const animate = (time: number) => {
      const amount = Math.min(1, (time - start) / 1200);
      const eased = 1 - Math.pow(1 - amount, 3);
      setDataValues(targets.map((target) => target * eased));
      if (amount < 1) countFrameRef.current = window.requestAnimationFrame(animate);
    };
    countFrameRef.current = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(countFrameRef.current);
  }, [currentPanel, sectionVisible]);

  const scrollToPanel = (nextPanel: number) => {
    const scroller = cardScrollRef.current;
    if (!scroller) return;
    const targetPanel = Math.max(0, Math.min(4, nextPanel));
    scroller.scrollTo({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      top: targetPanel * scroller.clientHeight,
    });
  };

  const choose = (questionIndex: number, choice: QuizChoice) => {
    if (answers[questionIndex]) return;
    setAnswers((current) => current.map((answer, index) => index === questionIndex ? choice : answer));
  };

  const resetQuiz = () => {
    setAnswers([null, null, null]);
    scrollToPanel(1);
  };

  return (
    <section className="story-scroller story-scene-0 relative" ref={sectionRef}>
      <div className="story-sticky">
        <div className="story-ambient ambient-one" />
        <div className="story-ambient ambient-two" />
        <div className="story-rail">
          <span>TruLens / HOW IT WORKS</span>
          <div><i style={{ height: `${((currentPanel + 1) / 5) * 100}%` }} /></div>
          <small>01</small>
        </div>
        <div className="story-copy-stack">
          <article className="story-copy-layer is-active">
            {storyScene.step !== "01 / READ" && <span className="story-step">{storyScene.step}</span>}
            <small>{storyScene.eyebrow}</small>
            <h2>{storyScene.title}</h2>
            <p>{storyScene.body}</p>
            <div className="read-step-list">
              <button className={activeStep === "data" ? "active" : ""} onClick={() => scrollToPanel(0)}>
                <span>01</span><strong>数字</strong><i />
              </button>
              <button className={activeStep === "quiz" ? "active" : ""} onClick={() => scrollToPanel(activeStep === "quiz" ? currentPanel : 1)}>
                <span>02</span><strong>小测{activeStep === "quiz" ? ` · 第 ${currentPanel} / 3 题` : ""}</strong><i />
              </button>
              <button className={activeStep === "result" ? "active" : ""} onClick={() => scrollToPanel(4)}>
                <span>03</span><strong>结果</strong><i />
              </button>
            </div>
          </article>
        </div>
        <div className="merged-story-visual">
          <i className="merged-orbit merged-orbit-one" />
          <i className="merged-orbit merged-orbit-two" />
          <div className="merged-story-card">
            <div
              aria-label="互动内容，可在卡片内上下滚动"
              className="merged-card-scroll"
              onScroll={(event) => {
                const scroller = event.currentTarget;
                const nextPanel = Math.max(0, Math.min(4, Math.round(scroller.scrollTop / scroller.clientHeight)));
                setCurrentPanel(nextPanel);
                if (scroller.scrollTop > 4) setScrollHintVisible(false);
              }}
              ref={cardScrollRef}
              tabIndex={0}
            >
              <section className="merged-track-screen merged-data-screen">
                <span className="merged-panel-kicker">不只是你 · NOT JUST YOU</span>
                {[
                  ["66", dataValues[0], "消费者自信能识别 AI 图片", "Clutch Survey · 2025 年 9 月"],
                  ["57", dataValues[1], "人在实测中判断出错", "Clutch Survey · 2025 年 9 月"],
                  ["35.7", dataValues[2], "第三方测评账号涉嫌虚假测评", "中消协《第三方测评消费体验调查》"],
                ].map(([target, value, label]) => (
                  <div key={String(target)}>
                    <strong>{Number(value).toFixed(String(target).includes(".") ? 1 : 0)}%</strong>
                    <span>{label}</span>
                  </div>
                ))}
                <small>来源：Clutch Survey, Sep 2025；中消协《第三方测评消费体验调查》</small>
              </section>
              {aiImageQuizQuestions.map((question, index) => {
                const answer = answers[index];
                return (
                  <section className="merged-track-screen merged-quiz-screen" key={question.title}>
                    <header><span>试试看 · TRY IT</span><small>第 {index + 1} / 3 题 · {question.title}</small></header>
                    <h3>哪一张是 AI 生成的？</h3>
                    <div className="quiz-options">
                      {question.images.map((image) => {
                        const answered = answer !== null;
                        const isSelected = answer === image.choice;
                        const isAi = question.aiAnswer === image.choice;
                        return (
                          <div className="quiz-option" key={image.choice}>
                            <button
                              aria-label={`选择 ${image.choice}`}
                              className={`quiz-image-placeholder ${image.image} ${isSelected ? "selected" : ""}`}
                              disabled={answered}
                              onClick={() => choose(index, image.choice)}
                            >
                              <span>{image.choice}</span>
                              <small>示例图</small>
                              {image.icon === "product" ? (
                                <Icon size={52}><path d="M8 8c2-4 6-4 8 0 1.8 3.5-1 7.5-4 10-3-2.5-5.8-6.5-4-10Z" stroke="currentColor" strokeWidth="1.2" /><path d="M9 13c2 .8 4 .8 6 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.2" /></Icon>
                              ) : image.icon === "compare" ? (
                                <Icon size={52}><rect height="15" rx="3" stroke="currentColor" strokeWidth="1.2" width="18" x="3" y="4.5" /><path d="M12 5v14M6 15l3-3 3 2 3-4 3 3" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.2" /></Icon>
                              ) : (
                                <Icon size={52}><circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.2" /><path d="M7 10c2-2 3 2 5 0s3 2 5 0M7 14c2-2 3 2 5 0s3 2 5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.2" /></Icon>
                              )}
                              {answered && isAi && (
                                <i
                                  className="quiz-ai-marker"
                                  style={{ left: question.reveal.left, top: question.reveal.top }}
                                >
                                  <b />
                                  <em>{question.reveal.label}</em>
                                </i>
                              )}
                            </button>
                            <button className="quiz-choice-button" disabled={answered} onClick={() => choose(index, image.choice)}>
                              我选 {image.choice}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                    <div aria-live="polite" className="quiz-reveal">
                      {answer && (
                        <>
                          <strong className={answer === question.aiAnswer ? "correct" : "incorrect"}>
                            <i>{answer === question.aiAnswer ? "✓" : "!"}</i>
                            {answer === question.aiAnswer ? "答对了" : "差一点"}
                          </strong>
                          <p>{question.explanation}</p>
                          <small>继续向下滚动 <i>↓</i></small>
                        </>
                      )}
                    </div>
                  </section>
                );
              })}
              <section className="merged-track-screen merged-result-screen">
                <span className="quiz-result-kicker">你的结果 · YOUR RESULT</span>
                <strong>{score} <small>/ 3</small></strong>
                <h3>{resultTitle}</h3>
                {unanswered > 0 && <p>还有 {unanswered} 题没答，向上滚动可以回去答。</p>}
                <small>接下来，让 TruLens 帮你看。</small>
                <div className="quiz-result-actions">
                  <button onClick={() => document.querySelector(".trust-section")?.scrollIntoView({ behavior: "smooth" })}>
                    让 TruLens 帮你看 <span><Arrow size={18} /></span>
                  </button>
                  <button onClick={resetQuiz}>再测一次</button>
                </div>
              </section>
            </div>
            <i className="merged-card-mask mask-top" />
            <i className="merged-card-mask mask-bottom" />
            {scrollHintVisible && <span className="merged-scroll-hint">在卡片内滚动 <i>↓</i></span>}
            <div className="merged-card-controls">
              <small>示例内容 · 图片为占位</small>
              <div>
                <span>{currentPanel + 1} / 5</span>
                <button aria-label="上一个面板" disabled={currentPanel === 0} onClick={() => scrollToPanel(currentPanel - 1)}>
                  <Icon size={17}><path d="m7 14 5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                </button>
                <button aria-label="下一个面板" disabled={currentPanel === 4} onClick={() => scrollToPanel(currentPanel + 1)}>
                  <Icon size={17}><path d="m7 10 5 5 5-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

type QuizChoice = "A" | "B";

const aiImageQuizQuestions: Array<{
  title: string;
  aiAnswer: QuizChoice;
  images: Array<{ choice: QuizChoice; image: string; icon: "texture" | "product" | "compare" }>;
  reveal: { left: string; top: string; label: string };
  explanation: string;
}> = [
  {
    title: "肤质特写",
    aiAnswer: "B",
    images: [
      { choice: "A", image: "soft-lilac", icon: "texture" },
      { choice: "B", image: "soft-pink", icon: "texture" },
    ],
    reveal: { left: "62%", top: "42%", label: "高光与肤色过渡" },
    explanation: "高光方向与背景光源不一致，肤色过渡出现断层。",
  },
  {
    title: "产品质地图",
    aiAnswer: "A",
    images: [
      { choice: "A", image: "soft-blue", icon: "product" },
      { choice: "B", image: "soft-lilac", icon: "product" },
    ],
    reveal: { left: "55%", top: "58%", label: "质地边缘与反光" },
    explanation: "质地边缘过于平滑，缺少真实的反光颗粒。",
  },
  {
    title: "使用前后对比",
    aiAnswer: "B",
    images: [
      { choice: "A", image: "soft-pink", icon: "compare" },
      { choice: "B", image: "soft-blue", icon: "compare" },
    ],
    reveal: { left: "68%", top: "48%", label: "前后阴影方向" },
    explanation: "前后对比图里的阴影方向前后矛盾。",
  },
];

const evidenceHotspots = [
  {
    id: 1,
    label: "光影一致性",
    text: "高光方向与背景光源不一致",
    x: "62%",
    y: "24%",
  },
  {
    id: 2,
    label: "拼接痕迹",
    text: "脸颊与颈部边缘存在不自然的过渡",
    x: "38%",
    y: "56%",
  },
  {
    id: 3,
    label: "色彩过渡",
    text: "肤色渐变出现断层",
    x: "68%",
    y: "72%",
  },
];

function EvidenceSection({ onStart }: { onStart: () => void }) {
  const sectionRef = useRef<HTMLElement>(null);
  const imageFrameRef = useRef<HTMLDivElement>(null);
  const lensTargetRef = useRef({ x: 50, y: 45 });
  const lensCurrentRef = useRef({ x: 50, y: 45 });
  const lensAnimationRef = useRef(0);
  const demoTimersRef = useRef<number[]>([]);
  const demoPlayedRef = useRef(false);
  const touchDraggingRef = useRef(false);
  const touchMovedRef = useRef(false);
  const [visible, setVisible] = useState(false);
  const [lensVisible, setLensVisible] = useState(false);
  const [lensRender, setLensRender] = useState({
    x: 50,
    y: 45,
    backgroundWidth: 774,
    backgroundHeight: 968,
    backgroundX: -337,
    backgroundY: -389,
  });
  const [comparison, setComparison] = useState(0);
  const [mobileForensic, setMobileForensic] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [nearbyHotspot, setNearbyHotspot] = useState<number | null>(null);
  const [userInteracted, setUserInteracted] = useState(false);
  const [demoRunning, setDemoRunning] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 },
    );
    observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!lensVisible) return;
    const animateLens = () => {
      const frame = imageFrameRef.current;
      if (!frame) return;
      const current = lensCurrentRef.current;
      const target = lensTargetRef.current;
      current.x += (target.x - current.x) * 0.18;
      current.y += (target.y - current.y) * 0.18;

      const bounds = frame.getBoundingClientRect();
      const diameter = Math.max(180, Math.min(300, bounds.width * 0.4));
      const pointX = (current.x / 100) * bounds.width;
      const pointY = (current.y / 100) * bounds.height;
      const backgroundWidth = bounds.width * 1.8;
      const backgroundHeight = bounds.height * 1.8;
      setLensRender({
        x: current.x,
        y: current.y,
        backgroundWidth,
        backgroundHeight,
        backgroundX: diameter / 2 - pointX * 1.8,
        backgroundY: diameter / 2 - pointY * 1.8,
      });

      let nearest: number | null = null;
      let nearestDistance = Number.POSITIVE_INFINITY;
      evidenceHotspots.forEach((hotspot) => {
        const hotspotX = (Number.parseFloat(hotspot.x) / 100) * bounds.width;
        const hotspotY = (Number.parseFloat(hotspot.y) / 100) * bounds.height;
        const distance = Math.hypot(pointX - hotspotX, pointY - hotspotY);
        if (distance < diameter * 0.3 && distance < nearestDistance) {
          nearest = hotspot.id;
          nearestDistance = distance;
        }
      });
      setNearbyHotspot(nearest);
      lensAnimationRef.current = window.requestAnimationFrame(animateLens);
    };
    lensAnimationRef.current = window.requestAnimationFrame(animateLens);
    return () => window.cancelAnimationFrame(lensAnimationRef.current);
  }, [lensVisible]);

  useEffect(() => {
    if (!visible || userInteracted || demoPlayedRef.current) return;
    demoPlayedRef.current = true;
    const moveDemoLens = (hotspotIndex: number) => {
      const hotspot = evidenceHotspots[hotspotIndex];
      lensTargetRef.current = {
        x: Number.parseFloat(hotspot.x),
        y: Number.parseFloat(hotspot.y),
      };
    };
    demoTimersRef.current = [
      window.setTimeout(() => {
        setDemoRunning(true);
        setLensVisible(true);
        moveDemoLens(0);
      }, 500),
      window.setTimeout(() => moveDemoLens(1), 1700),
      window.setTimeout(() => moveDemoLens(2), 2900),
      window.setTimeout(() => {
        setDemoRunning(false);
        setLensVisible(false);
        setNearbyHotspot(null);
      }, 5000),
    ];
    return () => demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
  }, [visible, userInteracted]);

  const stopDemoAndTakeControl = () => {
    if (!userInteracted) setUserInteracted(true);
    demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    demoTimersRef.current = [];
    setDemoRunning(false);
  };

  const setLensTargetFromPointer = (
    clientX: number,
    clientY: number,
    verticalOffset = 0,
  ) => {
    const frame = imageFrameRef.current;
    if (!frame) return;
    const bounds = frame.getBoundingClientRect();
    lensTargetRef.current = {
      x: Math.max(0, Math.min(100, ((clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((clientY - bounds.top - verticalOffset) / bounds.height) * 100)),
    };
  };

  const nearbyEvidence = nearbyHotspot
    ? evidenceHotspots.find((hotspot) => hotspot.id === nearbyHotspot)
    : null;

  return (
    <section className={`evidence-section reveal-section ${visible ? "is-visible" : ""}`} ref={sectionRef}>
      <div className="evidence-heading">
        <span className="section-tag">THE EVIDENCE</span>
        <h2>证据，不是结论</h2>
        <p>每一个判断，都指给你看它是从哪里来的。</p>
      </div>

      <div className="evidence-layout">
        <div className="evidence-copy">
          <div className="evidence-points">
            <div>
              <span>
                <Icon size={19}>
                  <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
                  <path d="m16 16 4 4M8 11h6M11 8v6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>图像取证</strong><small>检查光影、拼接痕迹、色彩过渡</small></p>
            </div>
            <div>
              <span>
                <Icon size={19}>
                  <path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d="M15 3v4h3M9 11h6M9 15h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>文案分析</strong><small>识别绝对化的功效宣称</small></p>
            </div>
            <div>
              <span>
                <Icon size={19}>
                  <path d="M5 6.5h14v9H9l-4 3v-12Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.5" />
                  <path d="M8 10h8M8 13h5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
              </span>
              <p><strong>评论模式</strong><small>发现批量灌水与句式雷同</small></p>
            </div>
          </div>
          <p className="evidence-note">判定依据同步呈现，每一步都可追溯。</p>
          <button className="evidence-cta" onClick={onStart}>
            体验 TruLens Agent
            <span className="circle-arrow"><Arrow size={19} /></span>
          </button>
        </div>

        <div className="evidence-card">
          <div
            className={`evidence-image-frame ${mobileForensic ? "mobile-forensic" : ""}`}
            onClick={() => {
              if (window.matchMedia("(hover: none)").matches && !touchMovedRef.current) {
                setMobileForensic((current) => !current);
              }
              touchMovedRef.current = false;
            }}
            onPointerDown={(event) => {
              if (event.pointerType !== "touch") return;
              touchDraggingRef.current = true;
              touchMovedRef.current = false;
              event.currentTarget.setPointerCapture(event.pointerId);
              stopDemoAndTakeControl();
              setLensVisible(true);
              setLensTargetFromPointer(event.clientX, event.clientY, 90);
            }}
            onPointerEnter={(event) => {
              if (event.pointerType === "mouse") setLensVisible(true);
            }}
            onPointerLeave={(event) => {
              if (event.pointerType === "mouse" && !demoRunning) {
                setLensVisible(false);
                setNearbyHotspot(null);
              }
              setActiveHotspot(null);
            }}
            onPointerMove={(event) => {
              if (event.pointerType === "mouse") {
                stopDemoAndTakeControl();
                setLensVisible(true);
                setLensTargetFromPointer(event.clientX, event.clientY);
              } else if (touchDraggingRef.current) {
                touchMovedRef.current = true;
                stopDemoAndTakeControl();
                setLensTargetFromPointer(event.clientX, event.clientY, 90);
              }
            }}
            onPointerUp={(event) => {
              if (event.pointerType !== "touch") return;
              touchDraggingRef.current = false;
              setLensVisible(false);
              setNearbyHotspot(null);
            }}
            ref={imageFrameRef}
          >
            <img alt="肤质特写占位图" className="evidence-base-image" src={portrait} />
            <div
              className="evidence-forensic-layer evidence-slider-layer"
              style={{ clipPath: mobileForensic ? "inset(0)" : `inset(0 ${100 - comparison}% 0 0)` }}
            >
              <img alt="" src={portrait} />
              <span />
            </div>
            <div className={`evidence-image-dim ${lensVisible ? "visible" : ""}`} />
            <div
              className={`evidence-lens ${lensVisible ? "visible" : ""} ${nearbyHotspot ? "hotspot-near" : ""}`}
              style={{ left: `${lensRender.x}%`, top: `${lensRender.y}%` }}
            >
              <div
                className="evidence-lens-image"
                style={{
                  backgroundImage: `url(${portrait})`,
                  backgroundPosition: `${lensRender.backgroundX}px ${lensRender.backgroundY}px`,
                  backgroundSize: `${lensRender.backgroundWidth}px ${lensRender.backgroundHeight}px`,
                }}
              />
              <div className="evidence-lens-heat" />
              <div className="evidence-lens-grid" />
              <div className="evidence-lens-scan" />
              <div className="evidence-lens-glare" />
              <div className="evidence-reticle"><i /><b /><b /><b /><b /></div>
              <span>{nearbyEvidence ? `${nearbyEvidence.label} · 异常` : "取证层 · 扫描中"}</span>
            </div>
            <div className={`evidence-operation-hint ${userInteracted ? "hidden" : ""}`}>
              <Icon size={12}>
                <path d="m7 4 9 8-4 .8 2.2 4.2-2.2 1.1-2.1-4.2L7 17V4Z" fill="currentColor" />
              </Icon>
              移动鼠标，用镜头检查这张图
            </div>

            {evidenceHotspots.map((hotspot) => (
              <div
                className={`evidence-hotspot-wrap ${activeHotspot === hotspot.id ? "active" : ""} ${nearbyHotspot === hotspot.id ? "nearby" : ""}`}
                key={hotspot.id}
                style={{ left: hotspot.x, top: hotspot.y }}
              >
                <button
                  aria-label={`查看${hotspot.label}`}
                  onClick={(event) => {
                    event.stopPropagation();
                    setActiveHotspot((current) => current === hotspot.id ? null : hotspot.id);
                  }}
                  onMouseEnter={() => setActiveHotspot(hotspot.id)}
                >
                  <i />
                </button>
                {activeHotspot === hotspot.id && (
                  <div className="hotspot-popover">
                    <small>钉 {hotspot.id}</small>
                    <strong>{hotspot.label}</strong>
                    <p>{hotspot.text}</p>
                  </div>
                )}
              </div>
            ))}
            <span className="mobile-evidence-hint">点击切换原图 / 取证层</span>
          </div>

          <div className="evidence-slider">
            <span>原图</span>
            <input
              aria-label="调整原图与取证层对比"
              max="100"
              min="0"
              onChange={(event) => setComparison(Number(event.target.value))}
              style={{ "--slider-value": `${comparison}%` } as React.CSSProperties}
              type="range"
              value={comparison}
            />
            <span>取证层</span>
          </div>
          <small className="example-data">示例数据</small>
        </div>
      </div>
    </section>
  );
}

const agentScenes: Array<{
  code: DimensionCode;
  label: string;
  input: string;
  question: string;
  description: string;
  score: number;
}> = [
  {
    code: "T",
    label: "账号可信度",
    input: "账号主页",
    question: "这个账号长期可靠吗？",
    description: "分析发布节奏、带货占比和历史内容的一致性。",
    score: 55,
  },
  {
    code: "R",
    label: "图像原生性",
    input: "图片",
    question: "这张图是真的吗？",
    description: "检查光影一致性、拼接痕迹和色彩过渡。",
    score: 30,
  },
  {
    code: "U",
    label: "评论自然度",
    input: "评论",
    question: "评论是真人说的吗？",
    description: "检查句式相似度、发布时间与账号特征。",
    score: 40,
  },
  {
    code: "S",
    label: "文案真实性",
    input: "文案",
    question: "这段话是体验，还是写好的脚本？",
    description: "识别模板化话术、绝对化用语和缺少依据的功效宣称。",
    score: 50,
  },
];

const dimensionImageHotspots = [
  { id: 1, left: 34, top: 58, tag: "光影", text: "高光方向与背景光源不一致" },
  { id: 2, left: 78, top: 82, tag: "色彩过渡", text: "肤色过渡出现断层" },
];

function AgentSceneVisual({ code, instance }: { code: DimensionCode; instance: string }) {
  const [ratioHovered, setRatioHovered] = useState(false);
  const [commentHover, setCommentHover] = useState<"similar" | "time" | null>(null);
  const [commentSelected, setCommentSelected] = useState<"similar" | "time" | null>(null);
  const commentFocus = commentHover ?? commentSelected;

  if (code === "T") {
    const bars = [24, 38, 31, 66, 42, 76, 54, 28, 70, 48, 84, 61, 35, 73, 58, 88, 46, 69, 53, 78, 39, 67, 82, 49, 72, 57, 86, 63, 44, 75];
    return (
      <div className={`agent-account-card ${ratioHovered ? "ratio-highlight" : ""}`}>
        <div className="account-placeholder-head">
          <span className="account-placeholder-avatar"><Sparkle size={17} /></span>
          <div><strong>晚风护肤札记</strong><small>@beauty_profile</small></div>
          <em>营销特征较多</em>
        </div>
        <div className="account-placeholder-data">
          <div className="posting-rhythm">
            <span>近 30 篇笔记发布节奏</span>
            <div>{bars.map((height, index) => (
              <button
                aria-label={`第 ${index + 1} 篇笔记${index < 24 ? "，带商品链接" : ""}`}
                className={index < 24 ? "commerce-bar" : ""}
                key={index}
                style={{ height: `${height}%` }}
              >
                {index < 24 && <span>这一篇带商品链接</span>}
              </button>
            ))}</div>
            <small><b /> 日常内容 <b /> 带货内容</small>
          </div>
          <div className="commerce-ratio">
            <span>带货占比</span>
            <button
              aria-describedby={`commerce-ratio-tip-${instance}`}
              onBlur={() => setRatioHovered(false)}
              onFocus={() => setRatioHovered(true)}
              onMouseEnter={() => setRatioHovered(true)}
              onMouseLeave={() => setRatioHovered(false)}
            >
              <strong>80%</strong><small>近 30 篇</small>
              <em id={`commerce-ratio-tip-${instance}`}>近 30 篇笔记中 24 篇带商品链接</em>
            </button>
          </div>
        </div>
        <small className="agent-visual-example">示例数据</small>
      </div>
    );
  }

  if (code === "R") {
    return <DimensionImageForensics instance={instance} />;
  }

  if (code === "U") {
    const comments = [
      "质地很轻薄，用了一周真的很服帖！",
      "质地很轻盈，用了一周妆效特别服帖。",
      "用了一周，质地轻薄而且真的很服帖！",
      "质地轻薄不厚重，一周后依然很服帖。",
      "鼻翼位置四小时后有一点卡粉，干皮需要先保湿。",
    ];
    return (
      <div className="agent-comment-evidence">
        <div className="comment-evidence-tabs">
          <button className={commentFocus === "similar" ? "active" : ""} onBlur={() => setCommentHover(null)} onClick={() => setCommentSelected(commentSelected === "similar" ? null : "similar")} onFocus={() => setCommentHover("similar")} onMouseEnter={() => setCommentHover("similar")} onMouseLeave={() => setCommentHover(null)}>句式相似</button>
          <button className={commentFocus === "time" ? "active" : ""} onBlur={() => setCommentHover(null)} onClick={() => setCommentSelected(commentSelected === "time" ? null : "time")} onFocus={() => setCommentHover("time")} onMouseEnter={() => setCommentHover("time")} onMouseLeave={() => setCommentHover(null)}>集中发布</button>
        </div>
        <div className={`comment-evidence-list ${commentFocus === "similar" ? "highlighted" : ""}`}>
          {comments.map((comment, index) => <p className={index < 4 ? "similar" : ""} key={comment}><i />{comment}</p>)}
        </div>
        <div className={`comment-time-axis ${commentFocus === "time" ? "highlighted" : ""}`}>
          <span>00:00</span><span>12:00</span><span>24:00</span>
          <div>{[8, 12, 14, 16, 18, 21, 23, 67, 82].map((left, index) => <i className={index < 6 ? "clustered" : ""} key={index} style={{ left: `${left}%` }} />)}</div>
          <em>2 小时内集中发布</em>
        </div>
        <small>62 条评论中 41 条句式相似</small>
        <small className="agent-visual-example">示例数据</small>
      </div>
    );
  }

  return (
    <div className="agent-copy-card script-evidence-card">
      <div className="copy-card-head"><i /><span>种草笔记文案</span><small>内容检查</small></div>
      <p>
        <button aria-describedby={`script-tip-template-${instance}`}>姐妹们闭眼入<span id={`script-tip-template-${instance}`}>模板化话术</span></button>！这款粉底液一抹显白，
        <button className="risk" aria-describedby={`script-tip-risk-${instance}`}>24 小时不脱妆<span id={`script-tip-risk-${instance}`}>绝对化用语</span></button>，油皮干皮都适用，
        <button className="claim" aria-describedby={`script-tip-claim-${instance}`}>用完皮肤状态真的变好了<span id={`script-tip-claim-${instance}`}>功效缺少依据</span></button>。
      </p>
      <div className="copy-risk-labels">
        <span>模板化话术</span><span>绝对化用语</span><span>功效缺少依据</span>
      </div>
      <small className="agent-visual-example">示例数据</small>
    </div>
  );
}

function DimensionImageForensics({ instance }: { instance: string }) {
  const frameRef = useRef<HTMLDivElement>(null);
  const targetRef = useRef({ x: dimensionImageHotspots[0].left, y: dimensionImageHotspots[0].top });
  const currentRef = useRef({ x: 50, y: 48 });
  const animationRef = useRef(0);
  const autoTimerRef = useRef(0);
  const [lensPosition, setLensPosition] = useState({ x: 50, y: 48 });
  const [manual, setManual] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [userMoved, setUserMoved] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let hotspotIndex = 0;
    const moveAutomatically = () => {
      if (!manual) {
        const hotspot = dimensionImageHotspots[hotspotIndex % dimensionImageHotspots.length];
        targetRef.current = { x: hotspot.left, y: hotspot.top };
        hotspotIndex += 1;
      }
    };
    moveAutomatically();
    autoTimerRef.current = window.setInterval(moveAutomatically, 2000);
    const animate = () => {
      currentRef.current.x += (targetRef.current.x - currentRef.current.x) * 0.12;
      currentRef.current.y += (targetRef.current.y - currentRef.current.y) * 0.12;
      setLensPosition({ ...currentRef.current });
      const nearby = dimensionImageHotspots.find((hotspot) => Math.hypot(hotspot.left - currentRef.current.x, hotspot.top - currentRef.current.y) < 12);
      if (!manual) setActiveHotspot(nearby?.id ?? null);
      animationRef.current = window.requestAnimationFrame(animate);
    };
    animationRef.current = window.requestAnimationFrame(animate);
    return () => {
      window.clearInterval(autoTimerRef.current);
      window.cancelAnimationFrame(animationRef.current);
    };
  }, [manual]);

  const moveLens = (clientX: number, clientY: number) => {
    const frame = frameRef.current;
    if (!frame) return;
    const bounds = frame.getBoundingClientRect();
    targetRef.current = {
      x: Math.max(0, Math.min(100, ((clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((clientY - bounds.top) / bounds.height) * 100)),
    };
  };

  return (
    <div
      className="dimension-image-forensics"
      onPointerEnter={(event) => {
        if (event.pointerType === "mouse") setManual(true);
      }}
      onPointerLeave={() => {
        setManual(false);
        setActiveHotspot(null);
      }}
      onPointerMove={(event) => {
        if (event.pointerType !== "mouse") return;
        setUserMoved(true);
        moveLens(event.clientX, event.clientY);
      }}
      ref={frameRef}
    >
      <img alt="秋冬奶油肌底妆分享肤质特写示例" src={portrait} />
      <div
        className="dimension-forensic-lens"
        style={{
          backgroundImage: `url(${portrait})`,
          backgroundPosition: `${lensPosition.x}% ${lensPosition.y}%`,
          left: `${lensPosition.x}%`,
          top: `${lensPosition.y}%`,
        }}
      >
        <i /><b />
        <span>取证层 · 扫描中</span>
      </div>
      {dimensionImageHotspots.map((hotspot) => (
        <button
          aria-describedby={`dimension-hotspot-${instance}-${hotspot.id}`}
          aria-label={`查看${hotspot.tag}证据`}
          className={`dimension-hotspot ${activeHotspot === hotspot.id ? "active" : ""}`}
          key={hotspot.id}
          onBlur={() => setActiveHotspot(null)}
          onClick={() => setActiveHotspot(activeHotspot === hotspot.id ? null : hotspot.id)}
          onFocus={() => setActiveHotspot(hotspot.id)}
          onMouseEnter={() => setActiveHotspot(hotspot.id)}
          onMouseLeave={() => {
            if (manual) setActiveHotspot(null);
          }}
          style={{ left: `${hotspot.left}%`, top: `${hotspot.top}%` }}
        >
          <i />
          {activeHotspot === hotspot.id && <span id={`dimension-hotspot-${instance}-${hotspot.id}`}><small>{hotspot.tag}</small>{hotspot.text}</span>}
        </button>
      ))}
      {!userMoved && <p>移动鼠标，用放大镜查看</p>}
      <small className="agent-visual-example">示例数据</small>
    </div>
  );
}

function FlowConnector({
  direction,
  lineProgress,
  ruleProgress = 0,
}: {
  direction: "in" | "out";
  lineProgress: number[];
  ruleProgress?: number;
}) {
  const inputPaths = ["M0 24 L120 120", "M0 72 L120 120", "M0 168 L120 120", "M0 216 L120 120"];
  const outputPaths = ["M0 120 L145 48", "M0 120 L145 120", "M0 120 L145 192"];
  const paths = direction === "in" ? inputPaths : outputPaths;
  return (
    <div className={`agent-flow-connector connector-${direction}`} aria-hidden="true">
      <svg viewBox={`0 0 ${direction === "in" ? 120 : 145} 240`}>
        {paths.map((path, index) => (
          <path
            d={path}
            key={path}
            pathLength="1"
            style={{ strokeDasharray: 1, strokeDashoffset: 1 - (lineProgress[index] ?? 0) }}
          />
        ))}
      </svg>
      {direction === "out" && (
        <div className="rule-score-node" style={{ "--rule-progress": ruleProgress } as React.CSSProperties}>
          <strong>规则评分</strong>
          <small>分数由公开规则计算，<br />不由 AI 一句话拍板</small>
        </div>
      )}
    </div>
  );
}

function CheckSection({ active, replayKey, staticMode }: { active: boolean; replayKey: number; staticMode: boolean }) {
  const previousIndexRef = useRef(0);
  const [activeCode, setActiveCode] = useState<DimensionCode>("T");
  const [direction, setDirection] = useState<"forward" | "backward">("forward");
  const [autoStopped, setAutoStopped] = useState(false);

  useEffect(() => {
    setActiveCode("T");
    previousIndexRef.current = 0;
    setDirection("forward");
    setAutoStopped(false);
  }, [replayKey]);

  useEffect(() => {
    if (!active || staticMode || autoStopped) return;
    const timer = window.setInterval(() => {
      const nextIndex = (previousIndexRef.current + 1) % agentScenes.length;
      setDirection(nextIndex === 0 ? "backward" : "forward");
      previousIndexRef.current = nextIndex;
      setActiveCode(agentScenes[nextIndex].code);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [active, autoStopped, replayKey, staticMode]);

  const activateScene = (code: DimensionCode) => {
    const index = agentScenes.findIndex((scene) => scene.code === code);
    setDirection(index > previousIndexRef.current ? "forward" : "backward");
    previousIndexRef.current = index;
    setActiveCode(code);
  };

  const selectScene = (code: DimensionCode) => {
    setAutoStopped(true);
    activateScene(code);
  };

  const renderPanel = (scene: (typeof agentScenes)[number], mobile = false) => (
    <div
      aria-hidden={!mobile && scene.code !== activeCode}
      className={`agent-dimension-panel ${mobile ? "mobile-panel" : `${scene.code === activeCode ? "active" : ""} slide-${direction}`}`}
      id={mobile ? `dimension-panel-${scene.code.toLowerCase()}` : undefined}
      inert={!mobile && scene.code !== activeCode}
      key={`${mobile ? "mobile" : "desktop"}-${scene.code}`}
    >
      {mobile && <h3 className="mobile-dimension-title"><span>{scene.code}</span>{scene.label}</h3>}
      <div className="agent-scene-copy">
        <span>{scene.code} · {scene.label}</span>
        <h3>{scene.question}</h3>
        <p>{scene.description}</p>
        <small>TruLens 的四个维度之一</small>
        <div className="agent-dimension-score">
          <span>该维度评分</span>
          <strong>{scene.score}</strong>
          <div><i style={{ width: `${scene.score}%` }} /></div>
        </div>
      </div>
      <div className={`agent-scene-visual scene-${scene.code.toLowerCase()}`}>
        <AgentSceneVisual code={scene.code} instance={mobile ? "mobile" : "desktop"} />
      </div>
    </div>
  );

  return (
      <section
        className="one-agent-section"
        id="how-check"
      >
        <div className="one-agent-sticky">
          <div className="one-agent-heading">
        <span className="section-tag">02 / 查 · 多模态鉴伪</span>
            <h2>四个维度，各自取证</h2>
            <p>证据，不是结论。每一个判断，都能指给你看它从哪里来。</p>
          </div>

          <div aria-label="选择 TruLens 核验维度" className="agent-segmented" role="tablist">
            {agentScenes.map((scene) => (
              <button
                aria-selected={activeCode === scene.code}
                className={activeCode === scene.code ? "active" : ""}
                key={scene.code}
                onClick={() => selectScene(scene.code)}
                role="tab"
              >
                <span>{scene.code}</span>{scene.label}
                {activeCode === scene.code && active && !autoStopped && !staticMode && <i className="agent-tab-timer" key={`${replayKey}-${scene.code}`} />}
              </button>
            ))}
          </div>

          <div className="agent-scene-shell" onFocusCapture={() => setAutoStopped(true)} onPointerEnter={() => setAutoStopped(true)}>
            {agentScenes.map((scene) => renderPanel(scene))}
          </div>
          <div className="agent-mobile-panels">
            {agentScenes.map((scene) => renderPanel(scene, true))}
          </div>
        </div>
      </section>
  );
}

/**
 * Cross-check links drawn off the right edge of the result cards (viewBox 0 0 300 220).
 * Shared with App.tsx so both copies of the merge scene stay in sync.
 *
 * `from`/`to` are the measured vertical centres of the cards in that viewBox
 * (T≈38, R≈92, U≈146, S≈200), so every line leaves and re-enters the card rail
 * on the row it belongs to instead of floating between rows. The curve is
 * horizontal at both ends and bows `bow` px into the gutter — that is what makes
 * it read as a connector between two rows rather than a decorative loop.
 */
export const MERGE_LINK_ANCHOR_X = 186;
const MERGE_CARD_CENTER_Y = { T: 38, R: 92, U: 146, S: 200 } as const;
const mergeLinkPath = (from: number, to: number, bow: number) =>
  `M${MERGE_LINK_ANCHOR_X} ${from} ` +
  `C${MERGE_LINK_ANCHOR_X + bow} ${from} ${MERGE_LINK_ANCHOR_X + bow} ${to} ${MERGE_LINK_ANCHOR_X} ${to}`;

export const MERGE_CROSS_LINKS = [
  { id: "t-s", tone: "conflict", from: MERGE_CARD_CENTER_Y.T, to: MERGE_CARD_CENTER_Y.S, bow: 58 },
  { id: "r-u", tone: "conflict", from: MERGE_CARD_CENTER_Y.R, to: MERGE_CARD_CENTER_Y.U, bow: 42 },
  { id: "u-s", tone: "doubtful", from: MERGE_CARD_CENTER_Y.U, to: MERGE_CARD_CENTER_Y.S, bow: 33 },
].map((link) => ({ ...link, d: mergeLinkPath(link.from, link.to, link.bow) }));

function MergeSection({
  active,
  replayKey,
  scrollProgress = 0,
  staticMode,
}: {
  active: boolean;
  replayKey: number;
  scrollProgress?: number;
  staticMode: boolean;
}) {
  const animationFrameRef = useRef(0);
  const [elapsed, setElapsed] = useState(staticMode ? 4.6 : 0);

  useEffect(() => {
    window.cancelAnimationFrame(animationFrameRef.current);
    if (staticMode) {
      setElapsed(4.6);
      return;
    }
    if (!active) {
      setElapsed(0);
      return;
    }
    const startedAt = performance.now();
    const animate = (now: number) => {
      const nextElapsed = Math.min(4.6, (now - startedAt) / 1000);
      setElapsed(nextElapsed);
      if (nextElapsed < 4.6) animationFrameRef.current = window.requestAnimationFrame(animate);
    };
    animationFrameRef.current = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(animationFrameRef.current);
  }, [active, replayKey, staticMode]);

  const phaseProgress = staticMode ? Math.min(1, elapsed / 4.6) : scrollProgress;
  const phaseTimed = (start: number, duration: number) => Math.min(1, Math.max(0, (phaseProgress - start) / duration));
  const resultProgress = agentScenes.map((_, index) => phaseTimed(0.02 + index * 0.055, 0.13));
  const crossLinkProgress = [phaseTimed(0.14, 0.12), phaseTimed(0.24, 0.12), phaseTimed(0.34, 0.12)];
  const crossLabelProgress = [phaseTimed(0.18, 0.1), phaseTimed(0.28, 0.1), phaseTimed(0.38, 0.1)];
  const crossOpacity = 1 - phaseTimed(0.5, 0.09);
  const inputProgress = agentScenes.map((_, index) => phaseTimed(0.52 + index * 0.025, 0.14));
  const convergenceProgress = phaseTimed(0.57, 0.14);
  const outputProgress = [phaseTimed(-0.04, 0.14), phaseTimed(0.17, 0.14), phaseTimed(0.34, 0.14)];
  const verdictProgress = phaseTimed(0.12, 0.12);
  const secondStage = phaseProgress >= 0.5;

  return (
      <section className={`architecture-section ${active || staticMode ? "merge-visible" : ""}`} id="how-merge">
        <div className="architecture-sticky">
          <div className="architecture-heading">
            <span className="section-tag">03 / 合 · 语义一致性校验</span>
            <h2>四个结果，先对质，再汇成一个分数</h2>
            <AnimatePresence mode="wait">
              <motion.p animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} initial={{ opacity: 0, y: 4 }} key={secondStage ? "merge" : "cross"}>
                {secondStage
                  ? "不是四个工具拼在一起，而是同一个 Agent 的四种视角。"
                  : "单看一个维度，谎话可以很圆。放在一起，矛盾就藏不住了。"}
              </motion.p>
            </AnimatePresence>
          </div>

          <div className="one-agent-flow">
            <div className="flow-inputs merge-results">
              <small>四个维度的结果</small>
              <svg aria-hidden="true" className="merge-cross-links" viewBox="0 0 300 220">
                {MERGE_CROSS_LINKS.map((link, index) => (
                  <g key={link.id}>
                    <path
                      className={`cross-link-${link.tone}`}
                      d={link.d}
                      pathLength="1"
                      style={{ opacity: crossOpacity, strokeDashoffset: 1 - crossLinkProgress[index] }}
                    />
                    <circle
                      className={`cross-link-dot cross-link-dot-${link.tone}`}
                      cx={MERGE_LINK_ANCHOR_X}
                      cy={link.from}
                      r="2.4"
                      style={{ opacity: crossOpacity * crossLinkProgress[index] }}
                    />
                    <circle
                      className={`cross-link-dot cross-link-dot-${link.tone}`}
                      cx={MERGE_LINK_ANCHOR_X}
                      cy={link.to}
                      r="2.4"
                      style={{ opacity: crossOpacity * crossLinkProgress[index] }}
                    />
                  </g>
                ))}
              </svg>
              {agentScenes.map((scene, index) => (
                <div
                  aria-label={`${scene.code} ${scene.label}，评分 ${scene.score}`}
                  className={`merge-result result-${scene.code.toLowerCase()}`}
                  key={scene.code}
                  style={{ "--result-progress": resultProgress[index] } as React.CSSProperties}
                >
                  <span>{scene.code}</span>
                  <div>
                    <strong>{scene.label}</strong>
                    <i><b style={{ width: `${scene.score * resultProgress[index]}%` }} /></i>
                  </div>
                  <em>{resultProgress[index] > 0 ? Math.round(scene.score * resultProgress[index]) : ""}</em>
                </div>
              ))}
            </div>

            <FlowConnector direction="in" lineProgress={inputProgress} />

            <div className="aperture-column">
              <div className="aperture-orbits">
            <i className="aperture-orbit orbit-inner" />
            <i className="aperture-orbit orbit-outer" />
            <svg aria-label="TruLens 的四个核验维度" className="agent-aperture" viewBox="0 0 280 280">
              {[
                { code: "T" as DimensionCode, path: "M138 18A122 122 0 0 0 18 138H92a48 48 0 0 1 46-46Z", x: 75, y: 80, label: "账号可信度" },
                { code: "R" as DimensionCode, path: "M142 18a122 122 0 0 1 120 120h-74a48 48 0 0 0-46-46Z", x: 205, y: 80, label: "图像原生性" },
                { code: "U" as DimensionCode, path: "M262 142a122 122 0 0 1-120 120v-74a48 48 0 0 0 46-46Z", x: 205, y: 205, label: "评论自然度" },
                { code: "S" as DimensionCode, path: "M138 262A122 122 0 0 1 18 142h74a48 48 0 0 0 46 46Z", x: 75, y: 205, label: "文案真实性" },
              ].map((petal, index) => (
                <g
                  aria-label={`${petal.code} ${petal.label}`}
                  className={`aperture-petal petal-${petal.code.toLowerCase()}`}
                  key={petal.code}
                  style={{ "--petal-progress": resultProgress[index] } as React.CSSProperties}
                >
                  <path d={petal.path} />
                  <text className="petal-letter" textAnchor="middle" x={petal.x} y={petal.y}>{petal.code}</text>
                  <text className="petal-label" textAnchor="middle" x={petal.x} y={petal.y + 16}>{petal.label}</text>
                </g>
              ))}
              <g className="merge-rays" style={{ "--merge-progress": convergenceProgress } as React.CSSProperties}>
                <line pathLength="1" x1="75" x2="140" y1="80" y2="140" />
                <line pathLength="1" x1="205" x2="140" y1="80" y2="140" />
                <line pathLength="1" x1="205" x2="140" y1="205" y2="140" />
                <line pathLength="1" x1="75" x2="140" y1="205" y2="140" />
              </g>
              <g className="aperture-core">
                <circle cx="140" cy="140" r="45" />
                <g transform="translate(128 113)"><Sparkle size={24} /></g>
                <text textAnchor="middle" x="140" y="158">TruLens</text>
              </g>
            </svg>
              </div>
              <div className="merge-cross-checks" style={{ "--cross-opacity": crossOpacity } as React.CSSProperties}>
                {[
                  ["矛盾", "文案“直出实拍，无滤镜”", "图像：肤色过渡出现断层", "conflict"],
                  ["矛盾", "文案“纯自费分享”", "账号：近 30 篇中 24 篇带商品链接", "conflict"],
                  ["存疑", "评论“好用，已回购”集中", "文案：未提使用周期", "doubtful"],
                ].map(([state, left, right, tone], index) => (
                  <div className={`cross-check-preview preview-${tone}`} key={left} style={{ "--preview-progress": crossLabelProgress[index] } as React.CSSProperties}>
                    <em>{state}</em><span>{left}</span><i>×</i><span>{right}</span>
                  </div>
                ))}
                <small>示例数据</small>
              </div>
            </div>

            <FlowConnector direction="out" lineProgress={outputProgress} ruleProgress={convergenceProgress} />

            <div className="flow-outputs">
              <small>统一输出</small>
              <div
                aria-label={`Trust Score ${Math.round(43 * outputProgress[0])} / 100，置信度高`}
                className="merge-output score-output"
                style={{ "--output-progress": outputProgress[0], "--verdict-progress": verdictProgress } as React.CSSProperties}
              >
                <span>Trust Score 与置信度</span>
                <strong>{Math.round(43 * outputProgress[0])}<small>/ 100</small></strong>
                <em>置信度 高</em>
              </div>
              <div className="merge-output detail-output" style={{ "--output-progress": outputProgress[1] } as React.CSSProperties}><span>证据与交叉验证</span><strong>2 处矛盾 · 1 处存疑</strong></div>
              <div className="merge-output detail-output" style={{ "--output-progress": outputProgress[2] } as React.CSSProperties}><span>处理建议</span><strong>四类角色，各有下一步</strong></div>
            </div>
          </div>

          <small className="one-agent-example">示例数据</small>
        </div>
      </section>
  );
}

// Kept as a hot-reload compatibility bridge for sessions that still reference
// the pre-narrative component name. The current Home renders HowNarrative.
function OneAgentSection() {
  return (
    <>
      <CheckSection active replayKey={0} staticMode={false} />
      <MergeSection active replayKey={0} staticMode={false} />
    </>
  );
}

type ReportPart = "score" | "band" | "radar" | "evidence" | "missing" | "cross" | "advice";

const reportDimensions = [
  { code: "T" as DimensionCode, name: "账号可信度", score: 55, evidence: "近 30 篇笔记中 24 篇带商品链接" },
  { code: "R" as DimensionCode, name: "图像原生性", score: 30, evidence: "高光方向与背景光源不一致，肤色过渡出现断层" },
  { code: "U" as DimensionCode, name: "评论自然度", score: 40, evidence: "62 条评论中 41 条句式相似，集中在 2 小时内发布" },
  { code: "S" as DimensionCode, name: "文案真实性", score: 50, evidence: '文案模板化，并含绝对化用语“24 小时不脱妆”' },
];

const reportCallouts: Array<{ number: string; text: string; part: ReportPart; side: "left" | "right" }> = [
  { number: "01", text: "Trust Score 综合得分", part: "score", side: "left" },
  { number: "02", text: "风险色带", part: "band", side: "left" },
  { number: "03", text: "四维雷达图", part: "radar", side: "left" },
  { number: "04", text: "逐项证据，每个维度都附依据", part: "evidence", side: "right" },
  { number: "05", text: "购买建议，告诉你下一步", part: "advice", side: "right" },
  { number: "06", text: "交叉验证", part: "cross", side: "left" },
  { number: "07", text: "处理建议 · 按角色", part: "advice", side: "right" },
];

const reportRoleAdvice = [
  { role: "消费者", advice: "不建议依据这篇下单，先去官方渠道核实功效数据。" },
  { role: "创作者", advice: "如果内容属实，补充原图和凭证即可申诉。" },
  { role: "平台运营", advice: "建议人工复核，复核前先限流观察。" },
  { role: "品牌方", advice: "核实品牌名和功效数据是否被滥用，转合规评估。" },
];

function ReportSection({
  active,
  onStart,
  scrollProgress = 0,
  staticMode,
}: {
  active: boolean;
  onStart: () => void;
  scrollProgress?: number;
  staticMode: boolean;
}) {
  const missingComments = false;
  const [activePart, setActivePart] = useState<ReportPart | null>(null);
  const [activeDimension, setActiveDimension] = useState<DimensionCode | null>(null);
  const [activeRole, setActiveRole] = useState(0);
  const phaseTwoProgress = staticMode ? 1 : Math.min(1, Math.max(0, (scrollProgress - 0.42) / 0.58));
  const crossProgress = Math.min(1, Math.max(0, phaseTwoProgress / 0.28));
  const adviceProgress = Math.min(1, Math.max(0, (phaseTwoProgress - 0.22) / 0.36));
  const finalProgress = Math.min(1, Math.max(0, (phaseTwoProgress - 0.76) / 0.24));

  useEffect(() => {
    if (!active || phaseTwoProgress < 0.35) return;
    const timer = window.setInterval(() => {
      setActiveRole((current) => (current + 1) % reportRoleAdvice.length);
    }, 3000);
    return () => window.clearInterval(timer);
  }, [active, phaseTwoProgress >= 0.35]);

  const focusCallout = (part: ReportPart | null) => {
    setActivePart(part);
    setActiveDimension(part === "missing" ? "U" : null);
  };

  const radarPoints = missingComments
    ? "M120 60.5 L147 110 M75 110 L120 60.5"
    : "M120 60.5 L147 110 L120 146 L75 110 Z";

  return (
    <section
      className={`report-showcase-section ${active || staticMode ? "is-visible" : ""} ${staticMode ? "is-static" : ""}`}
      id="how-report"
      style={{
        "--report-advice-progress": adviceProgress,
        "--report-cross-progress": crossProgress,
        "--report-final-progress": finalProgress,
        "--report-scroll-offset": `${phaseTwoProgress * -258}px`,
      } as React.CSSProperties}
    >
      <div className="report-showcase-heading">
        <span className="section-tag">04 / 报 · 决策与建议</span>
        <h2>一份报告，读懂一条种草</h2>
        <p>不只告诉你真假，更告诉你为什么，以及下一步怎么做。</p>
      </div>

      <div className="report-showcase-stage">
        <div className="report-mode-switch single" role="tablist" aria-label="报告展示方式">
          <button
            aria-selected="true"
            className="active"
            role="tab"
          >
            多维可视化报告
          </button>
        </div>

        <article className={`trust-report-card ${missingComments ? "has-missing-data" : ""}`} data-focus={activePart ?? undefined}>
          <header className="trust-report-head">
            <div><strong>TruLens 核验报告</strong><small>秋冬奶油肌底妆分享 · 同一个 Agent 汇总四个维度</small></div>
            <span>示例数据</span>
          </header>

          <div className="trust-report-body">
          <section className="report-score-block report-highlight part-score">
            <div className="report-score-ring">
              <span>Trust Score</span>
              <strong className="report-state-swap" key={missingComments ? "score-missing" : "score-complete"}>
                {missingComments ? "暂不评分" : <>43 <small>/ 100</small></>}
              </strong>
              {missingComments && <em>评论数据不足，已核验 3 / 4 个维度</em>}
            </div>
            <span className={`report-verdict ${missingComments ? "missing" : ""}`} key={missingComments ? "verdict-missing" : "verdict-complete"}>
              {missingComments ? "数据不足" : "存疑 · 谨慎参考"}
            </span>
          </section>

          <section className="report-risk-band report-highlight part-band">
            <div><i /></div>
            <span>高风险</span><span>可信</span>
          </section>

          <section className="report-dimensions-block">
            <div className="report-radar report-highlight part-radar">
              <svg aria-label="T R U S 四维雷达图" viewBox="0 0 240 220">
                {[0.25, 0.5, 0.75, 1].map((scale) => {
                  const radius = 90 * scale;
                  return (
                    <polygon
                      className="radar-grid"
                      key={scale}
                      points={`120,${110 - radius} ${120 + radius},110 120,${110 + radius} ${120 - radius},110`}
                    />
                  );
                })}
                {[
                  { code: "T" as DimensionCode, x: 120, y: 20, tx: 120, ty: 12 },
                  { code: "R" as DimensionCode, x: 210, y: 110, tx: 224, ty: 114 },
                  { code: "U" as DimensionCode, x: 120, y: 200, tx: 120, ty: 215 },
                  { code: "S" as DimensionCode, x: 30, y: 110, tx: 16, ty: 114 },
                ].map((axis) => (
                  <g
                    aria-label={`${axis.code} 维度`}
                    className={`radar-axis axis-${axis.code.toLowerCase()} ${activeDimension && activeDimension !== axis.code ? "dimmed" : ""} ${missingComments && axis.code === "U" ? "missing" : ""}`}
                    key={axis.code}
                    onBlur={() => setActiveDimension(null)}
                    onClick={() => setActiveDimension((current) => current === axis.code ? null : axis.code)}
                    onFocus={() => setActiveDimension(axis.code)}
                    onMouseEnter={() => setActiveDimension(axis.code)}
                    onMouseLeave={() => setActiveDimension(null)}
                    role="button"
                    tabIndex={0}
                  >
                    <line x1="120" x2={axis.x} y1="110" y2={axis.y} />
                    <circle cx={axis.x} cy={axis.y} r="10" />
                    <text textAnchor="middle" x={axis.tx} y={axis.ty}>{axis.code}</text>
                    {axis.code === "S" && <text className="radar-axis-name" textAnchor="start" x="4" y="130">文案真实性</text>}
                  </g>
                ))}
                <path className="radar-data" d={radarPoints} />
                {[
                  ["T", 120, 60.5],
                  ["R", 147, 110],
                  ["U", 120, 146],
                  ["S", 75, 110],
                ].map(([code, x, y]) => (
                  !(missingComments && code === "U") && (
                    <circle
                      className={`radar-point ${activeDimension && activeDimension !== code ? "dimmed" : ""}`}
                      cx={x}
                      cy={y}
                      key={code}
                      r="4"
                    />
                  )
                ))}
                {missingComments && <circle className="radar-point missing-point" cx="120" cy="146" r="5" />}
              </svg>
              <small>四维核验分布</small>
            </div>

            <div className="report-dimension-list">
              {reportDimensions.map((dimension) => {
                const isMissing = missingComments && dimension.code === "U";
                return (
                  <div
                    className={`report-dimension-row report-highlight part-evidence ${dimension.code === "U" ? "part-missing" : ""} ${activeDimension && activeDimension !== dimension.code ? "dimension-dimmed" : ""} ${activeDimension === dimension.code ? "dimension-active" : ""} ${isMissing ? "is-missing" : ""}`}
                    key={dimension.code}
                    onClick={() => setActiveDimension((current) => current === dimension.code ? null : dimension.code)}
                    onMouseEnter={() => setActiveDimension(dimension.code)}
                    onMouseLeave={() => setActiveDimension(null)}
                  >
                    <span className={`report-dimension-badge badge-${dimension.code.toLowerCase()}`}>{dimension.code}</span>
                    <div>
                      <span className="report-state-swap" key={`${dimension.code}-${isMissing ? "missing" : "complete"}`}>
                        <strong>{dimension.name}</strong><b>{isMissing ? "数据不足，未评分" : dimension.score}</b>
                      </span>
                      <div className="dimension-meter"><i style={{ width: isMissing ? "100%" : `${dimension.score}%` }} /></div>
                      <small>{isMissing ? "数据不足，未评分" : dimension.evidence}</small>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="report-cross-check report-highlight part-cross">
            <span>
              <Icon size={15}>
                <circle cx="8" cy="12" r="4.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
                <circle cx="16" cy="12" r="4.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
              </Icon>
            </span>
            <strong>交叉验证 · 2 处矛盾 · 1 处存疑</strong>
          </section>

          <section className="report-decision-panel report-highlight part-advice">
            <div className="report-decision-levels" aria-label="处置等级">
              <span><i />放行·轻提示</span>
              <span><i />提示·补充核验</span>
              <span className="active"><i />人工复核·处置</span>
            </div>
            <div className="report-role-advice">
              <div role="tablist" aria-label="查看不同角色的建议">
                {reportRoleAdvice.map((item, index) => (
                  <button
                    aria-selected={activeRole === index}
                    className={activeRole === index ? "active" : ""}
                    key={item.role}
                    onClick={() => setActiveRole(index)}
                    role="tab"
                  >
                    {item.role}
                  </button>
                ))}
              </div>
              <p aria-live="polite" key={activeRole}>{reportRoleAdvice[activeRole].advice}</p>
            </div>
            <small>辅助决策，不构成购买建议或定性结论。</small>
          </section>
          </div>
        </article>

        <div className="report-callouts" aria-label="报告结构说明">
          {reportCallouts.map((callout, index) => (
            <button
              className={`report-callout callout-${callout.side} callout-${index + 1} ${index >= 5 ? "phase-two" : ""} ${activePart === callout.part ? "active" : ""}`}
              key={callout.number}
              onClick={() => focusCallout(activePart === callout.part ? null : callout.part)}
              onMouseEnter={() => focusCallout(callout.part)}
              onMouseLeave={() => focusCallout(null)}
            >
              <span>{callout.number}</span>
              <strong>{callout.text}</strong>
              <i />
            </button>
          ))}
        </div>
      </div>

      <p className="report-closing-line">想好下一步，决定，留给你。</p>
      <div className="report-final-action">
        <button onClick={onStart}>
          体验 TruLens Agent
          <span><Arrow size={18} /></span>
        </button>
        <small>示例数据，仅用于展示报告结构</small>
      </div>
    </section>
  );
}

const agentIntroExamples = [
  {
    label: "种草笔记",
    attachments: ["种草笔记截图.png", "评论区截图.png"],
    prompt: "这篇种草笔记可信吗？",
    score: 43,
    verdict: "存疑 · 谨慎参考",
    tone: "caution",
    reply: "账号带货占比高、评论句式相似、出现绝对化用语。下单前先核实 3 件事。",
  },
  {
    label: "清一色好评的评论区",
    attachments: ["评论区截图.png"],
    prompt: "这些好评是真的吗？",
    score: 31,
    verdict: "高风险",
    tone: "risk",
    reply: "62 条评论里有 41 条句式相似，集中在 2 小时内发布。",
  },
  {
    label: "过度修图的对比图",
    attachments: ["对比图.png"],
    prompt: "这张对比图被修过吗？",
    score: 28,
    verdict: "高风险",
    tone: "risk",
    reply: "高光方向与背景光源不一致，肤色过渡出现断层。",
  },
];

function AgentIntroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const demoTimersRef = useRef<number[]>([]);
  const playedRef = useRef(false);
  const [activeExample, setActiveExample] = useState(0);
  const [visibleAttachments, setVisibleAttachments] = useState(0);
  const [typedText, setTypedText] = useState("");
  const [sendPulse, setSendPulse] = useState(false);
  const [replyVisible, setReplyVisible] = useState(false);
  const [uploadHint, setUploadHint] = useState(false);
  const example = agentIntroExamples[activeExample];

  const clearDemoTimers = () => {
    demoTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    demoTimersRef.current = [];
  };

  const playDemo = (exampleIndex = activeExample) => {
    clearDemoTimers();
    const nextExample = agentIntroExamples[exampleIndex];
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setUploadHint(false);
    setVisibleAttachments(0);
    setTypedText("");
    setSendPulse(false);
    setReplyVisible(false);

    if (reduceMotion) {
      setVisibleAttachments(nextExample.attachments.length);
      setTypedText(nextExample.prompt);
      setReplyVisible(true);
      return;
    }

    nextExample.attachments.forEach((_, index) => {
      demoTimersRef.current.push(window.setTimeout(() => {
        setVisibleAttachments(index + 1);
      }, 180 + index * 200));
    });

    const typingStart = 300 + nextExample.attachments.length * 200;
    nextExample.prompt.split("").forEach((_, index) => {
      demoTimersRef.current.push(window.setTimeout(() => {
        setTypedText(nextExample.prompt.slice(0, index + 1));
      }, typingStart + index * 60));
    });

    const typingEnd = typingStart + nextExample.prompt.length * 60;
    demoTimersRef.current.push(window.setTimeout(() => setSendPulse(true), typingEnd + 180));
    demoTimersRef.current.push(window.setTimeout(() => setSendPulse(false), typingEnd + 620));
    demoTimersRef.current.push(window.setTimeout(() => setReplyVisible(true), typingEnd + 520));
  };

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !playedRef.current) {
          playedRef.current = true;
          playDemo(0);
          observer.disconnect();
        }
      },
      { threshold: 0.28 },
    );
    observer.observe(section);
    return () => {
      observer.disconnect();
      clearDemoTimers();
    };
  }, []);

  const selectExample = (index: number) => {
    setActiveExample(index);
    playDemo(index);
  };

  const showUploadHint = () => {
    setUploadHint(true);
    demoTimersRef.current.push(window.setTimeout(() => setUploadHint(false), 2000));
  };

  return (
    <section className="agent-intro-section" ref={sectionRef}>
      <div className="agent-intro-heading">
        <span className="section-tag">WHAT IS TRULENS</span>
        <h2>丢进一条种草笔记</h2>
        <p>TruLens 把它变成一份看得见依据的<span>可信度画像</span>。</p>
      </div>

      <div className="agent-intro-demo">
        <div className="agent-prompt-card">
          <div className="agent-prompt-attachments">
            {example.attachments.map((attachment, index) => (
              <span className={visibleAttachments > index ? "visible" : ""} key={attachment}>
                <i>
                  <Icon size={15}>
                    <rect height="14" rx="2" stroke="currentColor" strokeWidth="1.4" width="17" x="3.5" y="5" />
                    <circle cx="9" cy="10" r="1.5" stroke="currentColor" strokeWidth="1.3" />
                    <path d="m5.5 17 4-4 2.7 2.5 2.1-2 3.2 3.5" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.3" />
                  </Icon>
                </i>
                {attachment}
              </span>
            ))}
          </div>
          <div className="agent-prompt-text" aria-label={example.prompt}>
            {typedText}<i className="typing-cursor" />
          </div>
          <div className="agent-prompt-actions">
            <button aria-label="添加附件" className="agent-add-button" onClick={showUploadHint}>
              <Icon size={20}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            </button>
            {uploadHint && <span className="agent-upload-hint" role="status">演示版本，暂不支持上传</span>}
            <button
              aria-label="发送并重新播放演示"
              className={`agent-send-button ${sendPulse ? "pulse" : ""}`}
              onClick={() => playDemo()}
            >
              <Icon size={21}><path d="M12 19V5m0 0L7 10m5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7" /></Icon>
            </button>
          </div>
        </div>

        <div aria-live="polite" className="agent-intro-reply-live">
          {replyVisible && (
            <div className={`agent-intro-reply ${example.tone}`}>
              <div className="agent-reply-score" style={{ "--agent-score": example.score } as React.CSSProperties}>
                <div><strong>{example.score}</strong><small>/ 100</small></div>
              </div>
              <div className="agent-reply-copy">
                <span>{example.verdict}</span>
                <p>{example.reply}</p>
              </div>
              <small>示例数据</small>
            </div>
          )}
        </div>

        <div className="agent-example-row">
          <small>试试示例：</small>
          <div>
            {agentIntroExamples.map((item, index) => (
              <button
                aria-pressed={activeExample === index}
                className={activeExample === index ? "active" : ""}
                key={item.label}
                onClick={() => selectExample(index)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <p className="agent-intro-note">基于开源大模型 · 每个判断都附证据 · 数据不足时不硬判</p>
      <button
        className="agent-intro-next"
        onClick={() => document.querySelector(".story-scroller")?.scrollIntoView({ behavior: "smooth" })}
      >
        往下看，为什么你需要它
        <Icon size={16}><path d="M12 5v14m0 0-5-5m5 5 5-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
      </button>
    </section>
  );
}

const HOW_SCENE_RANGES = [
  { id: "trust", number: "01", label: "拆", start: 0, end: 0.16, status: "已收到" },
  { id: "how-check", number: "02", label: "查", start: 0.16, end: 0.49, status: "取证中" },
  { id: "how-merge", number: "03", label: "合", start: 0.49, end: 0.745, status: "评分中" },
  { id: "how-report", number: "04", label: "报", start: 0.745, end: 1, status: "报告已生成" },
];

function HowChapterRail({ activeChapter, onSelect, progress }: { activeChapter: number; onSelect: (index: number) => void; progress: number }) {
  return (
    <nav aria-label="How 章节导航" className="how-chapter-rail visible">
      <div>
        <span className="how-rail-progress" style={{ height: `${progress * 100}%` }} />
        {HOW_SCENE_RANGES.map((chapter, index) => (
          <button className={activeChapter === index ? "active" : ""} key={chapter.id} onClick={() => onSelect(index)}>
            <i /><span>{chapter.number}</span><strong>{chapter.label}</strong>
          </button>
        ))}
      </div>
      <button className="how-report-link" onClick={() => onSelect(3)}>直接看报告</button>
    </nav>
  );
}

function TrustScene({ active }: { active: boolean }) {
  return (
    <section className={`trust-section ${active ? "is-entered" : ""}`} id="trust">
      <div className="trust-heading">
        <span className="section-tag">01 / 拆 · 多模态鉴伪</span>
        <h2>认识你的 AI 信任顾问团队</h2>
        <p>从四种信号，读懂一条种草笔记</p>
      </div>
      <svg aria-hidden="true" className="trust-split-lines" preserveAspectRatio="none" viewBox="0 0 1200 100">
        {["M600 0 L110 100", "M600 0 L430 100", "M600 0 L770 100", "M600 0 L1090 100"].map((path, index) => (
          <path d={path} key={path} pathLength="1" style={{ "--line-index": index } as React.CSSProperties} />
        ))}
      </svg>
      <div className="trust-grid">
        <div className="trust-marquee-track">
          {[0, 1].map((group) => (
            <div aria-hidden={group === 1} className="trust-marquee-group" inert={group === 1} key={group}>
              {[
                ["T", "账号侦探", "Trustworthiness", "近 30 篇笔记的发布节奏与带货记录"],
                ["R", "视觉取证师", "Reality", "图片的光影、拼接痕迹与色彩过渡"],
                ["U", "口碑观察员", "User Voice", "评论的句式相似度与发布时间"],
                ["S", "文字检察官", "Script", "文案的话术模板与夸大用语"],
              ].map(([letter, name, title, text], index) => (
                <article className={`trust-card card-${index + 1}`} key={`${group}-${letter}`} tabIndex={group === 0 ? 0 : -1}>
                  <span>{letter}</span>
                  <h3>{name}</h3>
                  <img className="trust-card-expert" alt={group === 0 ? `${name}专家头像` : ""} src={roleAvatarByCode[letter as DimensionCode]} />
                  <div><strong>{title}</strong><p><small>{letter === "T" || letter === "R" ? "他" : "她"}看什么</small>{letter === "T" || letter === "R" ? "他" : "她"}看：{text}</p></div>
                </article>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowNarrative({ onStart }: { onStart: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRefs = useRef<Array<HTMLDivElement | null>>([]);
  const frameRef = useRef(0);
  const previousSceneRef = useRef(0);
  const previousStageVisibleRef = useRef(false);
  const [progress, setProgress] = useState(0);
  const [activeScene, setActiveScene] = useState(0);
  const [stageVisible, setStageVisible] = useState(false);
  const [linearMode, setLinearMode] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [visibleScenes, setVisibleScenes] = useState<Set<number>>(new Set([0]));
  const [replayKeys, setReplayKeys] = useState([1, 0, 0, 0]);

  useEffect(() => {
    const mobileQuery = window.matchMedia("(max-width: 899px)");
    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updateMode = () => {
      setLinearMode(mobileQuery.matches || motionQuery.matches);
      setReducedMotion(motionQuery.matches);
    };
    updateMode();
    mobileQuery.addEventListener("change", updateMode);
    motionQuery.addEventListener("change", updateMode);
    return () => {
      mobileQuery.removeEventListener("change", updateMode);
      motionQuery.removeEventListener("change", updateMode);
    };
  }, []);

  useEffect(() => {
    if (linearMode) return;
    const update = () => {
      const container = containerRef.current;
      if (!container) return;
      const bounds = container.getBoundingClientRect();
      const distance = container.offsetHeight - window.innerHeight;
      const nextProgress = Math.min(1, Math.max(0, -bounds.top / distance));
      const nextScene = HOW_SCENE_RANGES.findIndex((range, index) => nextProgress >= range.start && (index === 3 || nextProgress < range.end));
      const nextStageVisible = bounds.top < window.innerHeight * 0.65 && bounds.bottom > window.innerHeight * 0.35;
      setProgress(nextProgress);
      setActiveScene(nextScene);
      setStageVisible(nextStageVisible);
      if (nextStageVisible && !previousStageVisibleRef.current) {
        setReplayKeys((keys) => keys.map((key, index) => index === nextScene ? key + 1 : key));
      }
      previousStageVisibleRef.current = nextStageVisible;
      if (nextScene !== previousSceneRef.current) {
        previousSceneRef.current = nextScene;
        setReplayKeys((keys) => keys.map((key, index) => index === nextScene ? key + 1 : key));
      }
    };
    const onScroll = () => {
      window.cancelAnimationFrame(frameRef.current);
      frameRef.current = window.requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.cancelAnimationFrame(frameRef.current);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [linearMode]);

  useEffect(() => {
    if (!linearMode || reducedMotion) {
      if (reducedMotion) setVisibleScenes(new Set([0, 1, 2, 3]));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const index = Number((entry.target as HTMLElement).dataset.scene);
        setVisibleScenes((current) => {
          const next = new Set(current);
          if (entry.isIntersecting) next.add(index);
          else next.delete(index);
          return next;
        });
        if (entry.isIntersecting) {
          setActiveScene(index);
          setReplayKeys((keys) => keys.map((key, sceneIndex) => sceneIndex === index ? key + 1 : key));
        }
      });
    }, { threshold: 0.18 });
    sceneRefs.current.forEach((scene) => scene && observer.observe(scene));
    return () => observer.disconnect();
  }, [linearMode, reducedMotion]);

  const scrollToScene = (index: number) => {
    const container = containerRef.current;
    if (!container || linearMode) {
      document.getElementById(HOW_SCENE_RANGES[index].id)?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth" });
      return;
    }
    const top = window.scrollY + container.getBoundingClientRect().top;
    const distance = container.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + HOW_SCENE_RANGES[index].start * distance, behavior: "smooth" });
  };

  const presentation = (index: number) => {
    if (linearMode) return undefined;
    const range = HOW_SCENE_RANGES[index];
    const enter = index === 0 ? 1 : Math.min(1, Math.max(0, (progress - (range.start - 0.025)) / 0.05));
    const exit = index === 3 ? 1 : 1 - Math.min(1, Math.max(0, (progress - (range.end - 0.025)) / 0.05));
    const opacity = Math.min(enter, exit);
    const translateY = enter < 1 ? 32 * (1 - enter) : exit < 1 ? -24 * (1 - exit) : 0;
    return { opacity, transform: `translateY(${translateY}px) scale(${0.97 + opacity * 0.03})`, visibility: opacity > 0.01 ? "visible" : "hidden" } as React.CSSProperties;
  };

  const mergeRange = HOW_SCENE_RANGES[2];
  const mergeScrollProgress = linearMode
    ? 1
    : Math.min(1, Math.max(0, (progress - mergeRange.start) / (mergeRange.end - mergeRange.start)));
  const reportRange = HOW_SCENE_RANGES[3];
  const reportScrollProgress = linearMode
    ? 1
    : Math.min(1, Math.max(0, (progress - reportRange.start) / (reportRange.end - reportRange.start)));
  const scenes = [
    <TrustScene active={linearMode ? visibleScenes.has(0) : stageVisible && activeScene === 0} />,
    <CheckSection active={linearMode ? visibleScenes.has(1) : stageVisible && activeScene === 1} replayKey={replayKeys[1]} staticMode={linearMode} />,
    <MergeSection active={linearMode ? visibleScenes.has(2) : stageVisible && activeScene === 2} replayKey={replayKeys[2]} scrollProgress={mergeScrollProgress} staticMode={linearMode} />,
    <ReportSection active={linearMode ? visibleScenes.has(3) : stageVisible && activeScene === 3} onStart={onStart} scrollProgress={reportScrollProgress} staticMode={linearMode} />,
  ];

  return (
    <div className={`how-narrative ${linearMode ? "linear" : ""}`} id="how-journey" ref={containerRef}>
      <div className="how-stage">
        {!linearMode && <HowChapterRail activeChapter={activeScene} onSelect={scrollToScene} progress={progress} />}
        <div aria-live="polite" className="sr-only">当前：{HOW_SCENE_RANGES[activeScene].number} {HOW_SCENE_RANGES[activeScene].label}</div>
        {scenes.map((scene, index) => {
          const interactive = linearMode || activeScene === index;
          return (
            <div
              aria-hidden={!linearMode && !interactive}
              className={`how-scene ${visibleScenes.has(index) ? "mobile-visible" : ""}`}
              data-scene={index}
              inert={!linearMode && !interactive}
              key={HOW_SCENE_RANGES[index].id}
              ref={(element) => { sceneRefs.current[index] = element; }}
              style={presentation(index)}
            >
              <div className="how-scene-canvas">{scene}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

type HeroAttachment = {
  id: string;
  name: string;
  kind: "image" | "link";
  preview?: string;
  example?: boolean;
  value?: string;
};

const S_LABEL = "S · 文案真实性";
const HERO_SCENE_DURATION = 4200;

type HeroSceneData = {
  id: string;
  code: string;
  dimension: string;
  chineseName: string;
  englishName: string;
  action: string;
  result: string;
  icon: "search" | "focus" | "comment" | "quote" | "evidence" | "consistency" | "compass";
  visual: "account" | "reality" | "voice" | "copy" | "finale" | "consistency" | "decision";
  callouts: readonly string[];
};

const heroScenes: readonly HeroSceneData[] = [
  {
    id: "account",
    code: "T",
    dimension: "T · 账号可信度",
    chineseName: "账号侦探",
    englishName: "Trustworthiness",
    action: "翻账号底细",
    result: "你只管刷笔记",
    icon: "search",
    visual: "account",
    callouts: ["286 篇历史笔记", "身份信息一致", "推荐密度较高"],
  },
  {
    id: "reality",
    code: "R",
    dimension: "R · 图像原生性",
    chineseName: "视觉取证师",
    englishName: "Reality",
    action: "放大每寸皮肤",
    result: "你只管看对比图",
    icon: "focus",
    visual: "reality",
    callouts: ["局部磨皮痕迹", "光影一致"],
  },
  {
    id: "voice",
    code: "U",
    dimension: "U · 评论自然度",
    chineseName: "口碑观察员",
    englishName: "User Voice",
    action: "揪出复制的好评",
    result: "你只管刷评论",
    icon: "comment",
    visual: "voice",
    callouts: ["姐妹被你种草了！", "12% 评论句式雷同"],
  },
  {
    id: "copy",
    code: "S",
    dimension: S_LABEL,
    chineseName: "文案真实性",
    englishName: "待定",
    action: "核对每句说法",
    result: "你只管读文案",
    icon: "quote",
    visual: "copy",
    callouts: ["坚持7天，皮肤像鸡蛋一样嫩白", "夸大表述"],
  },
  {
    id: "consistency",
    code: "X",
    dimension: "语义一致性校验",
    chineseName: "交叉验证",
    englishName: "Semantic Consistency",
    action: "让四个发现互相对质",
    result: "你只管看哪里不一致",
    icon: "consistency",
    visual: "consistency",
    callouts: ["矛盾", "存疑"],
  },
  {
    id: "decision",
    code: "D",
    dimension: "决策与建议",
    chineseName: "行动建议",
    englishName: "Decision & Advice",
    action: "想好下一步",
    result: "决定，留给你",
    icon: "compass",
    visual: "decision",
    callouts: ["消费者", "创作者", "平台", "品牌方"],
  },
];

function HeroActionIcon({ name }: { name: HeroSceneData["icon"] }) {
  if (name === "search") {
    return <Icon size={28}><circle cx="11" cy="11" r="6" stroke="currentColor" strokeWidth="1.35" /><path d="m16 16 4 4M8 11h6M11 8v6" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "focus") {
    return <Icon size={28}><path d="M4 9V5a1 1 0 0 1 1-1h4m6 0h4a1 1 0 0 1 1 1v4m0 6v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4M8 12h8" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "comment") {
    return <Icon size={28}><path d="M5 17.5 3.8 21l4-2.1c1.2.7 2.6 1.1 4.2 1.1 4.9 0 8.8-3.5 8.8-8S16.9 4 12 4s-8.8 3.5-8.8 8c0 2.1.7 4 1.8 5.5Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.35" /><path d="M8 12h8M8 9h5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "quote") {
    return <Icon size={28}><path d="M7.5 8.5H5.7A2.7 2.7 0 0 0 3 11.2V16h5v-5H5.6M17.5 8.5h-1.8a2.7 2.7 0 0 0-2.7 2.7V16h5v-5h-2.4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.35" /></Icon>;
  }
  if (name === "consistency") {
    return <Icon size={28}><circle cx="9" cy="12" r="5.5" stroke="currentColor" strokeWidth="1.35" /><circle cx="15" cy="12" r="5.5" stroke="currentColor" strokeWidth="1.35" /></Icon>;
  }
  if (name === "compass") {
    return <Icon size={28}><circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.35" /><path d="m15.5 8.5-2.1 4.9-4.9 2.1 2.1-4.9 4.9-2.1Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.35" /></Icon>;
  }
  return <Sparkle size={28} />;
}

function AccountHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock account-mock">
      <div className="mock-profile-head">
        <span className="mock-profile-avatar"><img alt="" src={roleAvatarByCode.T} /></span>
        <div><b>美妆内容创作者</b><small>虚构主页 · 公开内容样本</small></div>
        <dl><div><dt>18.6k</dt><dd>关注者</dd></div><div><dt>286</dt><dd>历史笔记</dd></div><div><dt>68%</dt><dd>推荐内容</dd></div></dl>
      </div>
      <div className="mock-note-grid">{Array.from({ length: 8 }, (_, index) => <i key={index}><span /></i>)}</div>
      <span className="account-scan-line" />
      <div className="mock-callouts">{scene.callouts.map((label) => <span key={label}>{label}</span>)}</div>
    </div>
  );
}

function RealityHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock reality-mock">
      <div className="skin-panel before"><span>BEFORE</span></div>
      <div className="skin-panel after"><span>AFTER</span></div>
      {scene.callouts.map((label, index) => <div className={`forensic-box box-${index + 1}`} key={label}><span>{label}</span></div>)}
      <div className="reality-meter"><span>纹理保留</span><i><b /></i><strong>71%</strong></div>
    </div>
  );
}

function VoiceHeroScene({ scene }: { scene: HeroSceneData }) {
  const comments = [scene.callouts[0], "质地比想象中清爽", scene.callouts[0], scene.callouts[0], "使用感需要时间观察"];
  return (
    <div className="hero-product-mock voice-mock">
      <div className="comment-title"><span>评论样本</span><small>语义聚类中</small></div>
      <div className="comment-list">{comments.map((comment, index) => <div className={comment === scene.callouts[0] ? "matched" : ""} key={`${comment}-${index}`}><i /><span>{comment}</span><small>{String(index + 2).padStart(2, "0")}</small></div>)}</div>
      <svg aria-hidden="true" className="comment-links" viewBox="0 0 500 300"><path d="M75 67 C410 70 415 165 77 183" /><path d="M78 67 C455 88 455 216 79 223" /></svg>
      <span className="voice-callout">{scene.callouts[1]}</span>
    </div>
  );
}

function CopyHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div className="hero-product-mock copy-mock">
      <div className="copy-document-head"><i /><div><b>一篇待核验的种草笔记</b><small>正文证据分析</small></div></div>
      <div className="copy-lines"><i /><i /><i /></div>
      <p>最近持续记录肤感变化，<mark>{scene.callouts[0]}</mark>，使用前后看起来非常明显。</p>
      <div className="copy-lines lower"><i /><i /></div>
      <span className="copy-callout">{scene.callouts[1]}</span>
    </div>
  );
}

function FinaleHeroScene() {
  return (
    <div className="hero-product-mock finale-mock">
      <span className="finale-trace"><i /><i /><i /><i /></span>
      <small>EVIDENCE BEFORE CONCLUSION</small>
    </div>
  );
}

function ConsistencyHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div aria-hidden="true" className="hero-product-mock consistency-mock">
      <svg className="consistency-network" viewBox="0 0 360 360">
        <line x1="180" x2="285" y1="55" y2="180" />
        <line x1="285" x2="180" y1="180" y2="305" />
        <line x1="180" x2="75" y1="305" y2="180" />
        <line x1="75" x2="180" y1="180" y2="55" />
        <line x1="75" x2="285" y1="180" y2="180" />
        <line x1="180" x2="180" y1="55" y2="305" />
        {[
          ["T", 180, 55],
          ["R", 285, 180],
          ["U", 180, 305],
          ["S", 75, 180],
        ].map(([code, x, y]) => <g key={code}><circle cx={x} cy={y} r="27" /><text textAnchor="middle" x={x} y={Number(y) + 5}>{code}</text></g>)}
        <circle className="network-junction" cx="180" cy="180" r="10" />
      </svg>
      <div className="consistency-compare-card compare-left">
        <span>{scene.callouts[0]}</span>
        <div><i /><i /><i /></div>
        <div><i /><i /></div>
      </div>
      <div className="consistency-compare-card compare-right">
        <span>{scene.callouts[1]}</span>
        <div><i /><i /></div>
        <div><i /><i /><i /></div>
      </div>
    </div>
  );
}

function DecisionHeroScene({ scene }: { scene: HeroSceneData }) {
  return (
    <div aria-hidden="true" className="hero-product-mock decision-mock">
      <div className="decision-ladder-mock">
        <span className="ladder-pass"><i />放行 · 轻提示</span>
        <span className="ladder-verify active"><i />提示 · 补充核验</span>
        <span className="ladder-review"><i />人工复核 · 处置</span>
      </div>
      <div className="decision-advice-mock">
        <div className="decision-role-tags">{scene.callouts.map((role, index) => <span className={index === 0 ? "active" : ""} key={role}>{role}</span>)}</div>
        <div className="decision-blurred-lines"><i /><i /><i /><i /></div>
      </div>
    </div>
  );
}

function HeroSceneVisual({ scene }: { scene: HeroSceneData }) {
  if (scene.visual === "account") return <AccountHeroScene scene={scene} />;
  if (scene.visual === "reality") return <RealityHeroScene scene={scene} />;
  if (scene.visual === "voice") return <VoiceHeroScene scene={scene} />;
  if (scene.visual === "copy") return <CopyHeroScene scene={scene} />;
  if (scene.visual === "consistency") return <ConsistencyHeroScene scene={scene} />;
  if (scene.visual === "decision") return <DecisionHeroScene scene={scene} />;
  return <FinaleHeroScene />;
}

function HeroComposer({
  onSubmit,
  onEngagedChange,
  expanded,
}: {
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
  onEngagedChange: (engaged: boolean) => void;
  expanded: boolean;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const idleTimerRef = useRef<number | null>(null);
  const objectUrlsRef = useRef<string[]>([]);
  const [value, setValue] = useState("");
  const [attachments, setAttachments] = useState<HeroAttachment[]>([]);
  const [interacted, setInteracted] = useState(false);
  const [focused, setFocused] = useState(false);
  const [demoText, setDemoText] = useState("");
  const [dragging, setDragging] = useState(false);
  const [shaking, setShaking] = useState(false);
  const reducedMotion = Boolean(useReducedMotion());
  const idleDemo = !interacted && !focused && !value && attachments.length === 0;
  const canSubmit = Boolean(value.trim() || attachments.length);

  useEffect(() => () => {
    objectUrlsRef.current.forEach((url) => URL.revokeObjectURL(url));
    if (idleTimerRef.current) window.clearTimeout(idleTimerRef.current);
  }, []);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(textarea.scrollHeight, 174)}px`;
    textarea.style.overflowY = textarea.scrollHeight > 174 ? "auto" : "hidden";
  }, [value]);

  useEffect(() => {
    if (!idleDemo) {
      setDemoText("");
      return;
    }
    if (reducedMotion) {
      setDemoText(heroDemoPhrases[0]);
      return;
    }
    let cancelled = false;
    const wait = (duration: number) => new Promise((resolve) => window.setTimeout(resolve, duration));
    const run = async () => {
      while (!cancelled) {
        const phrase = "这篇种草笔记可信吗？";
        for (let index = 1; index <= phrase.length && !cancelled; index += 1) {
          setDemoText(phrase.slice(0, index));
          await wait(90);
        }
        await wait(1800);
        for (let index = phrase.length - 1; index >= 0 && !cancelled; index -= 1) {
          setDemoText(phrase.slice(0, index));
          await wait(35);
        }
      }
    };
    run();
    return () => { cancelled = true; };
  }, [idleDemo, reducedMotion]);

  const activate = () => {
    if (idleTimerRef.current) window.clearTimeout(idleTimerRef.current);
    setInteracted(true);
    setDemoText("");
    onEngagedChange(true);
  };

  const addFiles = (files: File[]) => {
    const images = files.filter((file) => file.type.startsWith("image/"));
    if (!images.length) return;
    activate();
    setAttachments((current) => [
      ...current,
      ...images.map((file) => {
        const preview = URL.createObjectURL(file);
        objectUrlsRef.current.push(preview);
        return { id: `${file.name}-${file.lastModified}-${Math.random()}`, name: file.name, kind: "image" as const, preview };
      }),
    ]);
  };

  const removeAttachment = (id: string) => {
    setAttachments((current) => {
      const target = current.find((item) => item.id === id);
      if (target?.preview?.startsWith("blob:")) URL.revokeObjectURL(target.preview);
      return current.filter((item) => item.id !== id);
    });
  };

  const addLink = (url: string) => {
    activate();
    setAttachments((current) => [
      ...current,
      { id: `link-${Date.now()}`, name: url.length > 30 ? `${url.slice(0, 30)}…` : url, kind: "link", value: url },
    ]);
  };

  const submit = () => {
    if (!canSubmit) {
      setShaking(false);
      window.requestAnimationFrame(() => setShaking(true));
      window.setTimeout(() => setShaking(false), 240);
      activate();
      textareaRef.current?.focus();
      return;
    }
    const link = attachments.find((attachment) => attachment.kind === "link");
    const writtenPrompt = value.trim();
    const linkValue = link?.value ?? link?.name;
    const prompt = writtenPrompt
      ? `${writtenPrompt}${linkValue ? `\n链接：${linkValue}` : ""}`
      : (linkValue ? `请帮我鉴别这个链接：${linkValue}` : "请帮我鉴别我上传的美妆种草内容");
    const filename = attachments.find((attachment) => attachment.kind === "image")?.name ?? "";
    onSubmit(prompt, filename, attachments.some((attachment) => attachment.example));
  };

  return (
    <div className={`hero-composer-wrap ${expanded ? "expanded" : ""}`}>
      <div
        className={`hero-composer ${focused ? "focused" : ""} ${dragging ? "dragging" : ""} ${shaking ? "shake" : ""}`}
        onDragEnter={(event) => {
          event.preventDefault();
          activate();
          setDragging(true);
        }}
        onDragLeave={(event) => {
          if (!event.currentTarget.contains(event.relatedTarget as Node)) setDragging(false);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          addFiles(Array.from(event.dataTransfer.files));
        }}
      >
        {dragging && <div className="hero-drop-overlay">松开以添加截图</div>}
        {attachments.length > 0 && (
          <div className="hero-attachments">
            {attachments.map((attachment) => (
              <span className="hero-attachment" key={attachment.id}>
                {attachment.kind === "image" ? (
                  <img alt="" src={attachment.preview} />
                ) : (
                  <i><Icon size={14}><path d="M10 13a4 4 0 0 0 5.7.1l2.4-2.4A4 4 0 0 0 12.4 5l-1.3 1.3M14 11a4 4 0 0 0-5.7-.1l-2.4 2.4A4 4 0 0 0 11.6 19l1.3-1.3" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" /></Icon></i>
                )}
                <b>{attachment.name}</b>
                {attachment.example && <em>示例</em>}
                <button aria-label="移除附件" onClick={() => removeAttachment(attachment.id)}>×</button>
              </span>
            ))}
          </div>
        )}
        <div className="hero-composer-tools">
          <div className="hero-textarea-shell">
            {idleDemo && <span aria-hidden="true" className="hero-demo-placeholder">{demoText}<i /></span>}
            <textarea
              aria-label="输入你想鉴别的种草内容"
              id="hero-trust-input"
              onBlur={() => {
                setFocused(false);
                if (!value && attachments.length === 0) {
                  idleTimerRef.current = window.setTimeout(() => {
                    setInteracted(false);
                    onEngagedChange(false);
                  }, 4000);
                }
              }}
              onChange={(event) => {
                activate();
                setValue(event.target.value);
              }}
              onFocus={() => {
                activate();
                setFocused(true);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  submit();
                }
              }}
              onPaste={(event) => {
                const pastedText = event.clipboardData.getData("text").trim();
                const imageFiles = Array.from(event.clipboardData.files).filter((file) => file.type.startsWith("image/"));
                if (imageFiles.length) {
                  event.preventDefault();
                  addFiles(imageFiles);
                } else if (/^https?:\/\//i.test(pastedText)) {
                  event.preventDefault();
                  addLink(pastedText);
                }
              }}
              ref={textareaRef}
              rows={1}
              value={value}
            />
          </div>
          <button
            aria-disabled={!canSubmit}
            aria-label="开始鉴别"
            className={`hero-send-button ${canSubmit ? "" : "disabled"}`}
            onClick={submit}
          >
            <Icon size={21}><path d="M12 19V5m0 0L7 10m5-5 5 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7" /></Icon>
          </button>
        </div>
      </div>
      <p className="hero-promises hero-sequence-6">
        <span>每个判断都附证据</span><i /><span>数据不足时不硬判</span><i /><span>你可以反驳</span>
      </p>
    </div>
  );
}

const landingNavigation = [
  { id: "how-journey", label: "产品介绍" },
  { id: "why-trust", label: "Why Trust Us" },
  { id: "who-uses", label: "谁在用" },
  { id: "learn", label: "美妆鉴别指南" },
  { id: "faq", label: "FAQ" },
] as const;

function LandingNavigation({ onStart, onTeam }: { onStart: () => void; onTeam: () => void }) {
  const [activeSection, setActiveSection] = useState(landingNavigation[0].id);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const updateActiveSection = () => {
      const marker = window.scrollY + 140;
      let active = landingNavigation[0].id;
      landingNavigation.forEach((item) => {
        const section = document.getElementById(item.id);
        if (section && section.offsetTop <= marker) active = item.id;
      });
      setActiveSection(active);
    };
    updateActiveSection();
    window.addEventListener("scroll", updateActiveSection, { passive: true });
    window.addEventListener("resize", updateActiveSection);
    return () => {
      window.removeEventListener("scroll", updateActiveSection);
      window.removeEventListener("resize", updateActiveSection);
    };
  }, []);

  const goToSection = (id: (typeof landingNavigation)[number]["id"]) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      block: "start",
    });
    setActiveSection(id);
    setMenuOpen(false);
  };

  return (
    <nav aria-label="主要导航" className="home-nav cinematic-nav landing-navigation">
      <button className="logo landing-brand" onClick={() => window.scrollTo({ top: 0 })}>
        <img alt="TruLens" src="/trulens-nav-logo.png" />
      </button>
      <div className="landing-nav-desktop">
        <div className="landing-nav-links">
          {landingNavigation.map((item) => (
            <button
              aria-current={activeSection === item.id ? "page" : undefined}
              className={activeSection === item.id ? "active" : ""}
              key={item.id}
              onClick={() => goToSection(item.id)}
            >
              {item.label}
            </button>
          ))}
        </div>
        <button className="landing-team-entry" onClick={onTeam}>团队版</button>
        <button className="landing-nav-cta" onClick={onStart}>开始核验 <span>↗</span></button>
      </div>
      <div className="landing-nav-mobile">
        <button className="landing-nav-mobile-cta" onClick={onStart}>开始核验 <span>↗</span></button>
        <button
          aria-expanded={menuOpen}
          aria-label={menuOpen ? "关闭导航菜单" : "打开导航菜单"}
          className={`landing-menu-toggle ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <i /><i />
        </button>
      </div>
      {menuOpen && (
        <div className="landing-mobile-menu">
          <button onClick={onTeam}>团队版<span>→</span></button>
          {landingNavigation.map((item) => (
            <button
              aria-current={activeSection === item.id ? "page" : undefined}
              className={activeSection === item.id ? "active" : ""}
              key={item.id}
              onClick={() => goToSection(item.id)}
            >
              {item.label}<span>→</span>
            </button>
          ))}
        </div>
      )}
    </nav>
  );
}

function TruLensHero({
  onSubmit,
}: {
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
}) {
  const reducedMotion = Boolean(useReducedMotion());
  const elapsedRef = useRef(0);
  const [activeIndex, setActiveIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [composerEngaged, setComposerEngaged] = useState(false);
  const paused = false;
  const activeScene = heroScenes[activeIndex];

  const goToScene = (index: number) => {
    elapsedRef.current = 0;
    setProgress(0);
    setActiveIndex((index + heroScenes.length) % heroScenes.length);
  };

  useEffect(() => {
    let animationFrame = 0;
    let previousTime = performance.now();
    const tick = (time: number) => {
      const delta = time - previousTime;
      previousTime = time;
      if (!paused) {
        elapsedRef.current += delta;
        if (elapsedRef.current >= HERO_SCENE_DURATION) {
          elapsedRef.current = 0;
          setProgress(0);
          setActiveIndex((current) => (current + 1) % heroScenes.length);
        } else {
          setProgress(elapsedRef.current / HERO_SCENE_DURATION);
        }
      }
      animationFrame = window.requestAnimationFrame(tick);
    };
    animationFrame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [paused]);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      if (event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLInputElement) return;
      event.preventDefault();
      elapsedRef.current = 0;
      setProgress(0);
      setActiveIndex((current) => event.key === "ArrowRight"
        ? (current + 1) % heroScenes.length
        : (current - 1 + heroScenes.length) % heroScenes.length);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <section
      aria-label="TruLens 产品能力演示"
      className={`cinematic-hero scene-${activeScene.id} ${composerEngaged ? "composer-engaged" : ""}`}
    >
      <AnimatePresence initial={false}>
        <motion.div
          animate={{ opacity: 1, scale: 1 }}
          className="hero-scene-background"
          exit={{ opacity: 0 }}
          initial={{ opacity: 0, scale: reducedMotion ? 1 : 1.018 }}
          key={activeScene.id}
          transition={{ duration: reducedMotion ? 0.2 : 0.6, ease: [0.22, 0.7, 0.2, 1] }}
        >
          <HeroSceneVisual scene={activeScene} />
        </motion.div>
      </AnimatePresence>
      <div className="cinematic-title-shell">
        <AnimatePresence mode="wait">
          <motion.div
            animate={{ opacity: 1, y: 0 }}
            className={`cinematic-title ${activeScene.visual === "finale" ? "finale-title" : ""}`}
            exit={{ opacity: 0, y: reducedMotion ? 0 : -8 }}
            initial={{ opacity: 0, y: reducedMotion ? 0 : 18 }}
            key={`title-${activeScene.id}`}
            transition={{ duration: reducedMotion ? 0.2 : 0.6, ease: [0.22, 0.7, 0.2, 1] }}
          >
            {activeScene.visual === "finale" ? (
              <h1>{activeScene.action}</h1>
            ) : (
              <h1>
                <span>TruLens 替你</span>
                <em><HeroActionIcon name={activeScene.icon} />{activeScene.action}</em>
                <span>{activeScene.result}</span>
              </h1>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="cinematic-controls">
        <div aria-label="场景进度" className="hero-scene-progress">
          {heroScenes.map((scene, index) => (
            <button
              aria-label={`切换到${scene.dimension}`}
              className={index === activeIndex ? "active" : ""}
              key={scene.id}
              onClick={() => goToScene(index)}
            >
              <i style={{ transform: `scaleX(${index < activeIndex ? 1 : index === activeIndex ? progress : 0})` }} />
            </button>
          ))}
        </div>
        <HeroComposer expanded={activeScene.visual === "finale"} onEngagedChange={setComposerEngaged} onSubmit={onSubmit} />
      </div>
    </section>
  );
}

const whyTrustContent = {
  eyebrow: "WHY TRUST US",
  exampleLabel: "示例",
  title: "凭什么，",
  emphasis: "相信我们？",
  subtitle: "TruLens 判断别人是否可信，也用同样的标准要求自己。",
  promises: [
    {
      id: "evidence",
      number: "01",
      label: "证据",
      title: "每个判断都附证据",
      description: "分数背后不是一句'AI 觉得'。每个结论都能点开，看到原始截图、被标出的句子、被框出的区域。",
      conclusion: "图像主体可信，但存在轻度 AI 修饰痕迹",
      signals: [
        { label: "原始信号", tone: "purple" },
        { label: "模型检测", tone: "rose" },
        { label: "评分结论", tone: "green" },
      ],
    },
    {
      id: "restraint",
      number: "02",
      label: "克制",
      title: "数据不足时不硬判",
      description: "只给了文字，就只评文字。没有评论区，就不会假装看过评论区。",
      dimensions: ["T", "R", "U", "S"],
      unavailable: "未提供 · 不计分",
      scoreLabel: "文案真实性",
      score: "78",
      scoreNote: "仅基于 1 个维度",
    },
    {
      id: "appeal",
      number: "03",
      label: "申诉",
      title: "你可以反驳",
      description: "我们也可能看走眼。不同意，就告诉我们理由，TruLens 会结合你的补充再核对一次。",
      userMessage: "这条评论是我真实用过之后写的",
      agentMessage: "已记录你的补充，正在重新核对评论维度……",
    },
  ],
  verification: {
    weights: [
      { code: "T", value: 25 },
      { code: "R", value: 30 },
      { code: "U", value: 20 },
      { code: "S", value: 25 },
    ],
    caption: "评分规则公开",
    sample: "在 {SAMPLE_COUNT} 条自建美妆样本上测试",
    metric: "{METRIC_NAME}：{METRIC_VALUE}",
  },
  backToTop: "回到顶部，试一条笔记 →",
} as const;

type PromiseData = (typeof whyTrustContent.promises)[number];

function EvidencePromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "evidence" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo evidence-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <motion.p animate={{ opacity: 1, y: 0 }} initial={reducedMotion ? false : { opacity: 0, y: 8 }} transition={{ duration: reducedMotion ? 0 : 0.35 }}>
        {data.conclusion}
      </motion.p>
      <div className="evidence-signal-row">
        {data.signals.map((signal, index) => (
          <div className="evidence-signal-step" key={signal.label}>
            {index > 0 && (
              <motion.i
                animate={{ scaleX: 1 }}
                initial={reducedMotion ? false : { scaleX: 0 }}
                transition={{ delay: reducedMotion ? 0 : 0.65 + index * 0.62, duration: reducedMotion ? 0 : 0.38 }}
              />
            )}
            <motion.span
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className={`signal-${signal.tone}`}
              initial={reducedMotion ? false : { opacity: 0, scale: 0.82, y: 7 }}
              transition={{ delay: reducedMotion ? 0 : 0.35 + index * 0.62, duration: reducedMotion ? 0 : 0.42, type: "spring", bounce: 0.22 }}
            >
              <b />{signal.label}
            </motion.span>
          </div>
        ))}
      </div>
    </div>
  );
}

function RestraintPromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "restraint" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo restraint-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <div className="restraint-dimensions">
        {data.dimensions.map((dimension, index) => (
          <motion.span
            animate={dimension === "S" ? { opacity: 1, filter: "grayscale(0)" } : { opacity: 0.32, filter: "grayscale(1)" }}
            className={`restraint-${dimension.toLowerCase()}`}
            initial={reducedMotion || dimension === "S" ? false : { opacity: 1, filter: "grayscale(0)" }}
            key={dimension}
            transition={{ delay: reducedMotion ? 0 : 0.65 + index * 0.58, duration: reducedMotion ? 0 : 0.45 }}
          >
            {dimension}
          </motion.span>
        ))}
      </div>
      <motion.small
        animate={{ opacity: 1, y: 0 }}
        className="unavailable-note"
        initial={reducedMotion ? false : { opacity: 0, y: 5 }}
        transition={{ delay: reducedMotion ? 0 : 2.45, duration: reducedMotion ? 0 : 0.35 }}
      >
        {data.unavailable}
      </motion.small>
      <motion.div
        animate={{ opacity: 1, y: 0 }}
        className="restraint-score"
        initial={reducedMotion ? false : { opacity: 0, y: 8 }}
        transition={{ delay: reducedMotion ? 0 : 2.8, duration: reducedMotion ? 0 : 0.4 }}
      >
        <span>{data.scoreLabel} <strong>{data.score}</strong></span>
        <small>{data.scoreNote}</small>
      </motion.div>
    </div>
  );
}

function AppealPromiseDemo({ data, replayKey, reducedMotion }: { data: Extract<PromiseData, { id: "appeal" }>; replayKey: number; reducedMotion: boolean }) {
  return (
    <div className="promise-demo appeal-promise-demo" key={replayKey}>
      <small className="promise-example">{whyTrustContent.exampleLabel}</small>
      <motion.p animate={{ opacity: 1, y: 0 }} className="appeal-user" initial={reducedMotion ? false : { opacity: 0, y: 7 }} transition={{ duration: reducedMotion ? 0 : 0.38 }}>
        {data.userMessage}
      </motion.p>
      <motion.div
        animate={{ opacity: 1, y: 0 }}
        className="appeal-agent"
        initial={reducedMotion ? false : { opacity: 0, y: 7 }}
        transition={{ delay: reducedMotion ? 0 : 0.9, duration: reducedMotion ? 0 : 0.4 }}
      >
        <span>
          <motion.i animate={{ width: "100%" }} initial={reducedMotion ? false : { width: "0%" }} transition={{ delay: reducedMotion ? 0 : 1.25, duration: reducedMotion ? 0 : 1.35, ease: "linear" }}>
            {data.agentMessage}
          </motion.i>
        </span>
        <b>
          <motion.i animate={{ scaleX: 1 }} initial={reducedMotion ? false : { scaleX: 0 }} transition={{ delay: reducedMotion ? 0 : 2.7, duration: reducedMotion ? 0 : 0.95, ease: [0.22, 0.7, 0.2, 1] }} />
        </b>
      </motion.div>
    </div>
  );
}

function PromiseCard({ data }: { data: PromiseData }) {
  const cardRef = useRef<HTMLElement>(null);
  const reducedMotion = Boolean(useReducedMotion());
  const playedRef = useRef(false);
  const [replayKey, setReplayKey] = useState(0);

  useEffect(() => {
    const card = cardRef.current;
    if (!card || reducedMotion) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !playedRef.current) {
        playedRef.current = true;
        setReplayKey((key) => key + 1);
        observer.disconnect();
      }
    }, { threshold: 0.35 });
    observer.observe(card);
    return () => observer.disconnect();
  }, [reducedMotion]);

  const replay = () => {
    if (!reducedMotion) setReplayKey((key) => key + 1);
  };

  return (
    <article
      className="promise-card"
      onClick={replay}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          replay();
        }
      }}
      onMouseEnter={replay}
      ref={cardRef}
      tabIndex={0}
    >
      <span className="promise-card-label"><b>{data.number}</b><i />{data.label}</span>
      {data.id === "evidence" && <EvidencePromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      {data.id === "restraint" && <RestraintPromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      {data.id === "appeal" && <AppealPromiseDemo data={data} reducedMotion={reducedMotion} replayKey={replayKey} />}
      <div className="promise-card-copy">
        <h3>{data.title}</h3>
        <p>{data.description}</p>
      </div>
    </article>
  );
}

function TrustVerificationBand() {
  const data = whyTrustContent.verification;
  const hasUnfilledPlaceholder = [data.sample, data.metric].some((value) => /\{[A-Z_]+\}/.test(value));
  if (hasUnfilledPlaceholder) return null;
  return (
    <section className="trust-verification-band">
      <div>
        <div className="verification-weights">
          {data.weights.map((weight) => <i className={`weight-${weight.code.toLowerCase()}`} key={weight.code} style={{ flex: weight.value }}>{weight.code} {weight.value}%</i>)}
        </div>
        <small>{data.caption}</small>
      </div>
      <p><span>{data.sample}</span><strong>{data.metric}</strong></p>
    </section>
  );
}

function WhyTrustSection() {
  const scrollToComposer = () => {
    window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
    window.setTimeout(() => document.getElementById("hero-trust-input")?.focus(), 650);
  };

  return (
    <section className="why-trust-section" id="why-trust">
      <div className="why-trust-shell">
        <header className="why-trust-heading">
          <span>{whyTrustContent.eyebrow}</span>
          <h2>{whyTrustContent.title}<em>{whyTrustContent.emphasis}</em></h2>
          <p>{whyTrustContent.subtitle}</p>
        </header>
        <div className="promise-card-grid">
          {whyTrustContent.promises.map((promise) => <PromiseCard data={promise} key={promise.id} />)}
        </div>
        <TrustVerificationBand />
        <button className="why-trust-back" onClick={scrollToComposer}>{whyTrustContent.backToTop}</button>
      </div>
    </section>
  );
}

const whoUsesContent = {
  eyebrow: "WHO USES IT",
  title: "谁在用，",
  emphasis: "怎么用？",
  subtitle: "同一套核验，给三类人不同的行动建议。",
  cards: [
    {
      id: "consumer",
      number: "01",
      label: "消费者",
      title: "买之前，先看看这篇种草可不可信",
      description: "粘贴链接或文案，得到可信度、证据，以及下单前该再核对的几点。",
      action: "进入核验",
    },
    {
      id: "creator",
      number: "02",
      label: "创作者",
      title: "发布前自检，避开容易被误判的表述",
      description: "标出可能踩线的句子，给出诚实的改写建议，改完可得到自检记录。",
      action: "进入创作者模式",
    },
    {
      id: "team",
      number: "03",
      label: "平台与品牌方",
      title: "批量核验，优先处理高风险内容",
      description: "按风险排序的核验队列，每条都有主要矛盾和建议动作，是否复核由你决定。",
      action: "进入团队版",
    },
  ],
} as const;

type WhoUsesCardData = (typeof whoUsesContent.cards)[number];

function WhoUsesDemo({ id }: { id: WhoUsesCardData["id"] }) {
  if (id === "consumer") {
    return (
      <div className="promise-demo who-use-demo consumer-use-demo">
        <small className="promise-example">示例</small>
        <div><strong>84</strong><span>高可信</span></div>
        <small>置信度 高</small>
        <p>建议：可以参考，对比图请打折看待</p>
      </div>
    );
  }
  if (id === "creator") {
    return (
      <div className="promise-demo who-use-demo creator-use-demo">
        <small className="promise-example">示例</small>
        <p>这款精华真的是我用过最有效的！<mark>7 天直接变白</mark></p>
        <div>
          <span>建议：我连续用了 <mark>【X】</mark> 天，个人感觉 <mark>【你的真实感受】</mark></span>
          <button>采用建议</button>
        </div>
      </div>
    );
  }
  return (
    <div className="promise-demo who-use-demo team-use-demo">
      <small className="promise-example">示例</small>
      {[
        ["42", "高风险", "人工复核", "high"],
        ["68", "中风险", "加标注", "medium"],
        ["86", "高可信", "放行", "trusted"],
      ].map(([score, risk, action, tone]) => (
        <div key={score}>
          <strong>{score}</strong>
          <span className={`risk-${tone}`}>{risk}</span>
          <small>{action}</small>
        </div>
      ))}
    </div>
  );
}

function WhoUsesSection({
  onCreator,
  onTeam,
  onVerify,
}: {
  onCreator: () => void;
  onTeam: () => void;
  onVerify: () => void;
}) {
  const reducedMotion = Boolean(useReducedMotion());
  const actions = { consumer: onVerify, creator: onCreator, team: onTeam };
  return (
    <section className="who-uses-section" id="who-uses">
      <div className="why-trust-shell">
        <header className="why-trust-heading">
          <span>{whoUsesContent.eyebrow}</span>
          <h2>{whoUsesContent.title}<em>{whoUsesContent.emphasis}</em></h2>
          <p>{whoUsesContent.subtitle}</p>
        </header>
        <div className="promise-card-grid who-use-grid">
          {whoUsesContent.cards.map((card, index) => (
            <motion.article
              className="promise-card who-use-card"
              initial={reducedMotion ? false : { opacity: 0, y: 14 }}
              key={card.id}
              transition={{ delay: reducedMotion ? 0 : index * 0.06, duration: reducedMotion ? 0 : 0.5, ease: [0.22, 0.7, 0.2, 1] }}
              viewport={{ amount: 0.22, once: true }}
              whileInView={{ opacity: 1, y: 0 }}
            >
              <span className="promise-card-label"><b>{card.number}</b><i />{card.label}</span>
              <WhoUsesDemo id={card.id} />
              <div className="promise-card-copy">
                <h3>{card.title}</h3>
                <p>{card.description}</p>
              </div>
              <button className="who-use-action" onClick={actions[card.id]}>{card.action}<span>↗</span></button>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

const learnContent = {
  eyebrow: "LEARN",
  title: "先学四个看法，",
  emphasis: "再试一试",
  subtitle: "这些是线索，不是判决。看得多了，你自己也会有判断。",
  progress: ["四个线索", "动手试试", "你的结果"],
  clueSection: {
    label: "01 · 四个线索",
    intro: "你不需要懂算法。下面这四个地方，值得多看一眼。",
    closing: "这些只是线索。线索越多，越值得认真核对。",
  },
  clues: [
    {
      code: "T",
      title: "看账号",
      points: [
        "翻一翻历史笔记：是不是突然从日常分享转成密集推荐同类产品？",
        "简介和内容是否一致，有没有标注合作？",
        "粉丝涨得快，不代表互动是真的，对一对点赞、收藏和评论的比例。",
      ],
      example: {
        labels: ["周末散步随记", "换季护肤记录", "精华推荐", "面霜推荐", "同类精华推荐"],
        note: "短时间内连续推荐",
      },
    },
    {
      code: "R",
      title: "看图片",
      points: [
        "对比图里，前后两张的光线方向、角度、背景是否一致？",
        "皮肤的毛孔和细纹是不是在某一侧突然变得特别光滑？",
        "看边缘：发际线、下颌线有没有涂抹或扭曲的痕迹。",
      ],
      reminder: "滤镜和轻度修饰很常见，不等于造假。关键是效果对比是否被刻意放大。",
      example: {
        labels: ["局部过于光滑", "光影方向不一致"],
      },
    },
    {
      code: "U",
      title: "看评论",
      points: [
        "有没有大量几乎一样的句式？",
        "发布时间是不是扎堆？",
        "只有夸奖，没有具体使用细节（用了多久、什么肤质、有没有缺点）的评论，要多留意。",
      ],
      example: {
        comments: ["姐妹被你种草了！", "真的被种草了姐妹！", "已经下单，被你种草了", "用了两周，眼周稍干", "敏感肌试用后没有刺痛"],
      },
    },
    {
      code: "S",
      title: "看文案",
      points: [
        "当心绝对化的说法：“一周变白”“彻底解决”“闭眼冲”。",
        "有没有写使用周期、使用条件，以及“因人而异”？",
        "功效描述和成分、价位是否对得上？",
      ],
      example: {
        text: "这款精华质地清爽，坚持7天，皮肤像鸡蛋一样嫩白，姐妹们闭眼冲。",
        highlight: "坚持7天，皮肤像鸡蛋一样嫩白",
        note: "夸大表述",
      },
    },
  ],
  quizSection: {
    label: "02 · 你现在可以分辨吗？",
    title: "你现在可以分辨吗？",
    description: "不用选真假。点出你觉得可疑的地方，我们再告诉你那里有什么。",
    reveal: "看看答案",
    retry: "再试一次",
    next: "下一题",
    found: "你找到了 {FOUND} / {TOTAL} 处线索",
  },
  rounds: [
    {
      id: "copy",
      label: "回合 1 · 文案",
      kind: "text",
      items: [
        { text: "作为敏感肌，我最近在找一款保湿精华。", suspicious: false, explanation: "" },
        { text: "用了这瓶一周，皮肤状态直接提升一个 level。", suspicious: true, explanation: "“直接提升一个 level”没有说明周期、使用条件和个体差异。" },
        { text: "质地偏清爽，我会薄涂两层，冬天可能还要叠一层面霜。", suspicious: false, explanation: "" },
        { text: "坚持 7 天，皮肤像鸡蛋一样嫩白，姐妹们闭眼冲！", suspicious: true, explanation: "“7 天变白”“闭眼冲”属于绝对化、催促式说法。" },
      ],
    },
    {
      id: "comments",
      label: "回合 2 · 评论",
      kind: "comments",
      items: [
        { text: "姐妹被你种草了！", suspicious: true, explanation: "句式雷同、缺少使用细节。" },
        { text: "已经买第三瓶！", suspicious: true, explanation: "句式简短，缺少具体使用信息。" },
        { text: "用了两周，T 区出油少了，但眼周有点干，我会换成薄涂。", suspicious: false, explanation: "含具体使用细节，更像真实互动。" },
        { text: "被你种草了姐妹！", suspicious: true, explanation: "与第 1 条几乎同一句式。" },
        { text: "同敏感肌，我拿去试了一小块，没有刺痛，会再观察一周。", suspicious: false, explanation: "含具体使用细节，更像真实互动。" },
        { text: "想问下有没有色号推荐？", suspicious: false, explanation: "提问型评论，更像真实互动。" },
      ],
      answerNote: "第 1、2、4 条句式雷同、缺少使用细节；另外三条含具体使用细节或提问。",
    },
    {
      id: "image",
      label: "回合 3 · 图片",
      kind: "image",
      placeholders: ["{IMAGE_SAMPLE_BEFORE}", "{IMAGE_SAMPLE_AFTER}"],
      items: [
        { text: "右侧脸颊纹理", suspicious: true, explanation: "右侧脸颊纹理过于光滑。", x: 72, y: 45 },
        { text: "两张图的光线方向", suspicious: true, explanation: "前后两张图的光线方向不一致。", x: 49, y: 24 },
        { text: "背景色调", suspicious: true, explanation: "前后背景色调有轻微偏移。", x: 55, y: 76 },
      ],
    },
  ],
  result: {
    label: "03 · 你的结果",
    title: "你找到了 {FOUND} / 8 条线索",
    bands: [
      { min: 6, text: "眼力不错。不过人眼也会累、会漏。" },
      { min: 3, text: "有一些门道已经看出来了。剩下的线索，值得再看一遍。" },
      { min: 0, text: "这些线索确实不容易一眼看出来，这很正常。" },
    ],
    summary: "就算是认真看，人眼也不总是可靠。调查显示，66% 的消费者自信能识别 AI 生成的图片，但实测中 57% 判断出错。",
    source: "数据来源：Clutch Survey, Sep 2025",
    sourceCheck: "{SOURCE_CHECK}",
    prompt: "现在，把一条真实的种草笔记交给 TruLens。",
    primary: "用 TruLens 检查一条笔记 →",
    reset: "再玩一次",
  },
  footer: "TruLens · 示例内容均为自造样本，不涉及真实账号与真人。",
  exampleLabel: "示例",
} as const;

type LearnClue = (typeof learnContent.clues)[number];
type LearnRound = (typeof learnContent.rounds)[number];

function LearnClueExample({ clue }: { clue: LearnClue }) {
  if (clue.code === "T") {
    return (
      <div className="learn-account-example">
        {clue.example.labels.map((label, index) => <span className={index > 1 ? "dense" : ""} key={label}>{label}</span>)}
        <small>{clue.example.note}</small>
      </div>
    );
  }
  if (clue.code === "R") {
    return (
      <div className="learn-image-example">
        <div><span>BEFORE</span></div><div><span>AFTER</span></div>
        {clue.example.labels.map((label, index) => <i className={`learn-image-callout callout-${index + 1}`} key={label}>{label}</i>)}
        <small>{learnContent.exampleLabel}</small>
      </div>
    );
  }
  if (clue.code === "U") {
    return (
      <div className="learn-comment-example">
        {clue.example.comments.map((comment, index) => <span className={index < 3 ? "similar" : ""} key={comment}>{comment}</span>)}
        <svg aria-hidden="true" viewBox="0 0 420 150"><path d="M15 19 C380 25 380 62 15 68 C380 72 380 108 15 116" /></svg>
      </div>
    );
  }
  const parts = clue.example.text.split(clue.example.highlight);
  return (
    <div className="learn-copy-example">
      <p>{parts[0]}<mark>{clue.example.highlight}</mark>{parts[1]}</p>
      <small>{clue.example.note}</small>
    </div>
  );
}

function LearnClueCard({ clue, index }: { clue: LearnClue; index: number }) {
  const reducedMotion = Boolean(useReducedMotion());
  return (
    <motion.article
      className={`learn-clue-card clue-${clue.code.toLowerCase()}`}
      initial={reducedMotion ? false : { opacity: 0, y: 18 }}
      transition={{ duration: reducedMotion ? 0 : 0.5, delay: reducedMotion ? 0 : index * 0.04 }}
      viewport={{ amount: 0.2, once: true }}
      whileInView={{ opacity: 1, y: 0 }}
    >
      <header><span>{clue.code}</span><h3>{clue.title}</h3></header>
      <ul>{clue.points.map((point) => <li key={point}>{point}</li>)}</ul>
      {"reminder" in clue && <p className="learn-reminder">{clue.reminder}</p>}
      <LearnClueExample clue={clue} />
    </motion.article>
  );
}

function QuizRound({
  index,
  onComplete,
  onNext,
  resetKey,
  round,
}: {
  index: number;
  onComplete: (index: number, score: number | null) => void;
  onNext: () => void;
  resetKey: number;
  round: LearnRound;
}) {
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [revealed, setRevealed] = useState(false);
  const total = round.items.filter((item) => item.suspicious).length;
  const found = round.items.filter((item, itemIndex) => item.suspicious && selected.has(itemIndex)).length;

  useEffect(() => {
    setSelected(new Set());
    setRevealed(false);
  }, [resetKey]);

  const toggle = (itemIndex: number) => {
    if (revealed) return;
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(itemIndex)) next.delete(itemIndex);
      else next.add(itemIndex);
      return next;
    });
  };

  const reveal = () => {
    setRevealed(true);
    onComplete(index, found);
  };

  const itemClass = (item: LearnRound["items"][number], itemIndex: number) => [
    selected.has(itemIndex) ? "selected" : "",
    revealed && item.suspicious ? "answer" : "",
    revealed && item.suspicious && !selected.has(itemIndex) ? "missed" : "",
  ].filter(Boolean).join(" ");

  return (
    <article className={`learn-quiz-round round-${round.kind}`}>
      <header><span>{round.label}</span><small>{index + 1} / {learnContent.rounds.length}</small></header>
      <div className="round-progress">{learnContent.rounds.map((item, dotIndex) => <i className={dotIndex <= index ? "active" : ""} key={item.id} />)}</div>
      {round.kind === "image" ? (
        <div className="quiz-image-sample">
          {round.placeholders.map((placeholder, sampleIndex) => (
            <div className={`sample-${sampleIndex}`} key={placeholder}>
              <span>{sampleIndex === 0 ? "使用前" : "使用后"}</span>
              <small>占位示例</small>
              <code>{placeholder}</code>
            </div>
          ))}
          {round.items.map((item, itemIndex) => (
            <button
              aria-label={`选择图片线索：${item.text}`}
              aria-pressed={selected.has(itemIndex)}
              className={itemClass(item, itemIndex)}
              key={item.text}
              onClick={() => toggle(itemIndex)}
              style={{ left: `${item.x}%`, top: `${item.y}%` }}
            >
              <i /><span>{revealed ? item.explanation : item.text}</span>
            </button>
          ))}
        </div>
      ) : (
        <div className={`quiz-select-list ${round.kind === "comments" ? "comment-select-list" : ""}`}>
          {round.items.map((item, itemIndex) => (
            <button
              aria-label={`选择${round.kind === "comments" ? "评论" : "句子"}：${item.text}`}
              aria-pressed={selected.has(itemIndex)}
              className={itemClass(item, itemIndex)}
              key={item.text}
              onClick={() => toggle(itemIndex)}
            >
              <span>{item.text}</span>
              {revealed && item.suspicious && <small>{item.explanation}</small>}
            </button>
          ))}
          {round.kind === "comments" && revealed && (
            <svg aria-hidden="true" className="quiz-comment-curve" viewBox="0 0 500 300"><path d="M18 30 C470 35 470 85 18 91 C470 96 470 190 18 194" /></svg>
          )}
        </div>
      )}
      {revealed && (
        <div aria-live="polite" className="round-answer">
          <strong>{learnContent.quizSection.found.replace("{FOUND}", String(found)).replace("{TOTAL}", String(total))}</strong>
          {"answerNote" in round && <p>{round.answerNote}</p>}
        </div>
      )}
      <footer>
        {!revealed ? (
          <button className="round-reveal" onClick={reveal}>{learnContent.quizSection.reveal}</button>
        ) : (
          <>
            <button onClick={() => { setSelected(new Set()); setRevealed(false); onComplete(index, null); }}>{learnContent.quizSection.retry}</button>
            <button className="round-next" onClick={onNext}>{learnContent.quizSection.next}</button>
          </>
        )}
      </footer>
    </article>
  );
}

function LearnResult({
  found,
  onReset,
}: {
  found: number;
  onReset: () => void;
}) {
  const reducedMotion = Boolean(useReducedMotion());
  const resultText = learnContent.result.bands.find((band) => found >= band.min)?.text ?? learnContent.result.bands[2].text;
  const scrollToComposer = () => {
    window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
    window.setTimeout(() => document.getElementById("hero-trust-input")?.focus(), reducedMotion ? 0 : 650);
  };
  return (
    <motion.section
      animate={{ opacity: 1, y: 0 }}
      className="learn-result"
      initial={reducedMotion ? false : { opacity: 0, y: 18 }}
      transition={{ duration: reducedMotion ? 0 : 0.5 }}
    >
      <span>{learnContent.result.label}</span>
      <strong>{learnContent.result.title.replace("{FOUND}", String(found))}</strong>
      <h3>{resultText}</h3>
      <p>{learnContent.result.summary}</p>
      <small>{learnContent.result.source}</small>
      <i aria-hidden="true">{learnContent.result.sourceCheck}</i>
      <b>{learnContent.result.prompt}</b>
      <button className="learn-result-primary" onClick={scrollToComposer}>{learnContent.result.primary}</button>
      <button className="learn-result-reset" onClick={onReset}>{learnContent.result.reset}</button>
    </motion.section>
  );
}

function LearnSection() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const quizRef = useRef<HTMLElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const roundRefs = useRef<Array<HTMLDivElement | null>>([]);
  const [progress, setProgress] = useState(0);
  const [scores, setScores] = useState<Array<number | null>>([null, null, null]);
  const [resetKey, setResetKey] = useState(0);
  const complete = scores.every((score) => score !== null);
  const found = scores.reduce<number>((sum, score) => sum + (score ?? 0), 0);

  const scrollInsideCard = (element: HTMLElement | null) => {
    const scroller = scrollRef.current;
    if (!scroller || !element) return;
    scroller.scrollTo({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      top: element.offsetTop - 48,
    });
  };

  const resetAll = () => {
    setScores([null, null, null]);
    setResetKey((key) => key + 1);
    setProgress(0);
    scrollInsideCard(scrollRef.current?.firstElementChild as HTMLElement | null);
  };

  return (
    <section className="learn-section" id="learn">
      <div className="learn-layout">
        <aside className="learn-intro">
          <span>{learnContent.eyebrow}</span>
          <h2>{learnContent.title}<em>{learnContent.emphasis}</em></h2>
          <p>{learnContent.subtitle}</p>
          <nav aria-label="学习进度">
            {learnContent.progress.map((label, index) => (
              <button className={progress === index ? "active" : progress > index ? "complete" : ""} key={label} onClick={() => {
                if (index === 0) scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
                if (index === 1) scrollInsideCard(quizRef.current);
                if (index === 2 && complete) scrollInsideCard(resultRef.current);
              }}>
                <i /><span>{label}</span>
              </button>
            ))}
          </nav>
        </aside>
        <div className="learn-card-wrap">
          <div
            className="learn-scroll-card"
            onScroll={(event) => {
              const scroller = event.currentTarget;
              const ratio = scroller.scrollTop / Math.max(1, scroller.scrollHeight - scroller.clientHeight);
              setProgress(ratio < 0.55 ? 0 : ratio < 0.88 ? 1 : 2);
            }}
            ref={scrollRef}
            tabIndex={0}
          >
            <div className="learn-card-content">
              <section className="learn-clues">
                <span className="learn-section-label">{learnContent.clueSection.label}</span>
                <p className="learn-section-intro">{learnContent.clueSection.intro}</p>
                <div className="learn-clue-list">
                  {learnContent.clues.map((clue, index) => <LearnClueCard clue={clue} index={index} key={clue.code} />)}
                </div>
                <p className="learn-clue-closing">{learnContent.clueSection.closing}</p>
              </section>
              <section className="learn-quiz" ref={quizRef}>
                <span className="learn-section-label">{learnContent.quizSection.label}</span>
                <h2>{learnContent.quizSection.title}</h2>
                <p>{learnContent.quizSection.description}</p>
                <div className="learn-round-list">
                  {learnContent.rounds.map((round, index) => (
                    <div key={round.id} ref={(element) => { roundRefs.current[index] = element; }}>
                      <QuizRound
                        index={index}
                        onComplete={(roundIndex, score) => setScores((current) => current.map((value, scoreIndex) => scoreIndex === roundIndex ? score : value))}
                        onNext={() => {
                          if (index < learnContent.rounds.length - 1) scrollInsideCard(roundRefs.current[index + 1]);
                          else if (complete || scores.slice(0, -1).every((score) => score !== null)) window.setTimeout(() => scrollInsideCard(resultRef.current), 80);
                        }}
                        resetKey={resetKey}
                        round={round}
                      />
                    </div>
                  ))}
                </div>
              </section>
              <div ref={resultRef}>
                {complete && <LearnResult found={found} onReset={resetAll} />}
              </div>
            </div>
          </div>
          <i className="learn-fade learn-fade-top" /><i className="learn-fade learn-fade-bottom" />
        </div>
      </div>
      <footer className="learn-footer">{learnContent.footer}</footer>
    </section>
  );
}

const faqContent = {
  eyebrow: "QUESTIONS & ANSWERS",
  title: "FAQ",
  subtitle: "关于 TruLens 的使用、结果和边界，这里先把常见问题说清楚。",
  groups: [
    {
      title: "一、它是什么、怎么用",
      items: [
        {
          question: "TruLens 是什么？能帮我做什么？",
          answer: "TruLens 是一个帮你判断美妆种草笔记是否可信的 AI 智能体。你把笔记丢进来，它从账号、图片、评论、文案四个角度看一遍，给你一个可信度分数，并把每个判断的依据摊开给你看。",
        },
        {
          question: "我需要提供什么？只给文字也行吗？",
          answer: "可以提供笔记链接、复制的文字或截图，三种都行，也可以组合着给。你给什么，我们就分析什么。只给文字，就只分析文案。",
        },
      ],
    },
    {
      title: "二、怎么理解结果",
      items: [
        {
          question: "84 分是什么意思？高可信就一定是真的吗？",
          answer: "分数是对这篇笔记在当前可见信息下的可信度评估，不是真伪判决。分数高代表没发现明显问题，但仍可能有值得留意的地方，所以请一并看报告里标出的留意项和每个维度的证据。",
        },
      ],
    },
    {
      title: "三、它的边界",
      items: [
        {
          question: "TruLens 会判错吗？",
          answer: "会。任何自动检测都可能漏掉或误判。所以我们不只给分数，还给证据，数据不足时不硬判，你不同意时也可以反驳。",
        },
        {
          question: "为什么不直接告诉我“真”还是“假”？",
          answer: "因为一个“真或假”的结论，对一篇真假混杂的笔记并不诚实。很多笔记是真的在分享，只是图被修得过头，或者评论里混了几条模板。我们给的是可信度和依据，让你自己判断。",
        },
        {
          question: "TruLens 能告诉我这个产品好不好用、适不适合我的皮肤吗？",
          answer: "不能。TruLens 判断的是这篇笔记可不可信，不是产品功效评测，也不是医疗建议，更不会替你决定买不买。",
        },
      ],
    },
    {
      title: "四、隐私与数据",
      items: [
        {
          question: "我提交的内容会被保存吗？",
          answer: "你提交的内容只用于生成这份报告和支持你后续的追问。保存多久、能否删除：【待确认：请后端确认后填写，不要凭感觉写“不保存”】。",
        },
      ],
    },
    {
      title: "五、追问和反驳",
      items: [
        {
          question: "报告出来之后，我还能做什么？",
          answer: "你可以基于这篇笔记继续追问，比如“为什么图片这一项扣分”，回答会标明用到了哪几个维度。如果你不同意某个判断，可以补充你的理由，让它重新核对。【待确认：反驳功能是真的能重新核对，还是只记录反馈，这决定这句怎么写】",
        },
      ],
    },
  ],
} as const;

type FAQItemData = (typeof faqContent.groups)[number]["items"][number];

function FAQItem({ index, item }: { index: number; item: FAQItemData }) {
  const [open, setOpen] = useState(false);
  const reducedMotion = Boolean(useReducedMotion());
  const answerId = `faq-answer-${index}`;
  return (
    <article className={`faq-item ${open ? "open" : ""}`}>
      <button aria-controls={answerId} aria-expanded={open} onClick={() => setOpen((current) => !current)}>
        <span>{String(index + 1).padStart(2, "0")}</span>
        <strong>{item.question}</strong>
        {"note" in item && <small>{item.note}</small>}
        <i aria-hidden="true"><b /><b /></i>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            animate={{ height: "auto", opacity: 1 }}
            className="faq-answer"
            exit={{ height: 0, opacity: 0 }}
            id={answerId}
            initial={reducedMotion ? false : { height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.28, ease: [0.22, 0.7, 0.2, 1] }}
          >
            <p>{item.answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </article>
  );
}

function FAQSection() {
  let itemIndex = 0;
  return (
    <section className="faq-section" id="faq">
      <header className="faq-heading">
        <span>{faqContent.eyebrow}</span>
        <h2>{faqContent.title}</h2>
        <p>{faqContent.subtitle}</p>
      </header>
      <div className="faq-shell">
        {faqContent.groups.map((group) => (
          <section className="faq-group" key={group.title}>
            <h3>{group.title}</h3>
            <div>
              {group.items.map((item) => {
                const currentIndex = itemIndex;
                itemIndex += 1;
                return <FAQItem index={currentIndex} item={item} key={item.question} />;
              })}
            </div>
          </section>
        ))}
      </div>
    </section>
  );
}

const footerContent = {
  explore: {
    title: "EXPLORE",
    links: [
      { label: "产品介绍", target: "how-journey" },
      { label: "信任依据", target: "why-trust" },
      { label: "美妆鉴别指南", target: "learn" },
      { label: "常见问题 FAQ", target: "faq" },
    ],
  },
  information: {
    title: "INFORMATION",
    links: ["隐私政策", "使用说明", "联系我们"],
  },
  copyright: "© 2026 TruLens. All rights reserved.",
  statement: "Made for more mindful beauty choices.",
} as const;

function LandingFooter() {
  const scrollTo = (target: string) => {
    document.getElementById(target)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      block: "start",
    });
  };
  return (
    <footer className="landing-footer">
      <div className="landing-footer-main">
        <div className="landing-footer-brand-area">
          <button className="landing-footer-brand" onClick={() => window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" })}>
            <img alt="TruLens" src="/trulens-nav-logo.png" />
          </button>
          <input aria-label="输入要鉴别的内容" placeholder="我今天帮你鉴别什么？" />
        </div>
        <nav aria-label="页脚探索导航" className="landing-footer-column">
          <strong>{footerContent.explore.title}</strong>
          {footerContent.explore.links.map((link) => (
            <button key={link.target} onClick={() => scrollTo(link.target)}>{link.label}</button>
          ))}
        </nav>
        <div className="landing-footer-column landing-footer-information">
          <strong>{footerContent.information.title}</strong>
          {footerContent.information.links.map((link) => <span key={link}>{link}</span>)}
        </div>
      </div>
      <div className="landing-footer-bottom">
        <span>{footerContent.copyright}</span>
        <span>{footerContent.statement}</span>
      </div>
    </footer>
  );
}

function Home({
  onCreator,
  onStart,
  onSubmit,
  onTeam,
}: {
  onCreator: () => void;
  onStart: () => void;
  onSubmit: (prompt: string, filename: string, example: boolean) => void;
  onTeam: () => void;
}) {

  return (
    <main className="home">
      <LandingNavigation onStart={onStart} onTeam={onTeam} />

      <TruLensHero onSubmit={onSubmit} />

      <HowNarrative onStart={onStart} />

      <WhyTrustSection />

      <WhoUsesSection onCreator={onCreator} onTeam={onTeam} onVerify={onStart} />

      <LearnSection />

      <FAQSection />

      <LandingFooter />
    </main>
  );
}

function Sidebar({
  active,
  activeTask,
  archivedScore,
  collapsed,
  historyCleared,
  onNew,
  onLogout,
  onResetAgent,
  onReport,
  onTask,
  onToggle,
}: {
  active: Screen;
  activeTask: RecentTask;
  archivedScore: number | null;
  collapsed: boolean;
  historyCleared: boolean;
  onNew: () => void;
  onLogout: () => void;
  onResetAgent: () => void;
  onReport: (task: RecentTask) => void;
  onTask: (task: RecentTask) => void;
  onToggle: () => void;
}) {
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [accountDialog, setAccountDialog] = useState<"help" | "reset" | "add" | "logout" | null>(null);
  const [accountInput, setAccountInput] = useState("");
  const [accountAdded, setAccountAdded] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchCategory, setSearchCategory] = useState<"all" | "reports">("all");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchableTasks: Array<{ task: RecentTask; title: string; date: string; status: string; score: number }> = [
    { task: "makeup", title: "秋冬奶油肌底妆分享", date: "今天", status: archivedScore ? `已归档 · ${archivedScore} 分` : "高可信", score: archivedScore ?? 84 },
    { task: "serum", title: "热门精华测评合集", date: "昨天", status: "存在风险", score: 58 },
    { task: "whitening", title: "七天美白挑战", date: "3 天前", status: "疑似营销", score: 39 },
  ];
  const filteredSearchTasks = historyCleared
    ? []
    : searchableTasks.filter((item) =>
      `${item.title} ${item.date} ${item.status}`.toLowerCase().includes(searchQuery.trim().toLowerCase()),
    );

  useEffect(() => {
    if (!accountDialog) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setAccountDialog(null);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [accountDialog]);

  useEffect(() => {
    if (!searchOpen) return;
    searchInputRef.current?.focus();
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [searchOpen]);

  const openDialog = (dialog: Exclude<typeof accountDialog, null>) => {
    setAccountMenuOpen(false);
    setAccountDialog(dialog);
    if (dialog === "add") {
      setAccountInput("");
      setAccountAdded(false);
    }
  };

  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="side-top">
        <Logo />
        <div className="side-top-actions">
          <button
            aria-label="搜索历史对话和报告"
            className="icon-button sidebar-search-button"
            onClick={() => {
              setAccountMenuOpen(false);
              setSearchQuery("");
              setSearchCategory("all");
              setSearchOpen(true);
            }}
            title="搜索"
          >
            <Icon size={18}>
              <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
              <path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
            </Icon>
          </button>
          <button
            aria-label={collapsed ? "展开侧栏" : "收起侧栏"}
            aria-pressed={collapsed}
            className="icon-button mobile-hide sidebar-toggle"
            onClick={onToggle}
            title={collapsed ? "展开侧栏" : "收起侧栏"}
          >
            <Icon size={18}>
              <path d="M4 5h16M4 12h10M4 19h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
            </Icon>
          </button>
        </div>
      </div>
      <button className="new-analysis" onClick={onNew}>
        <span>
          <Sparkle size={17} /> 新建鉴别
        </span>
        <small>⌘ K</small>
      </button>
      <button
        className="sidebar-report-library"
        onClick={() => {
          setAccountMenuOpen(false);
          setSearchQuery("");
          setSearchCategory("reports");
          setSearchOpen(true);
        }}
        title="报告库"
      >
        <span>
          <Icon size={17}>
            <path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" />
            <path d="M15 3v4h3M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" />
          </Icon>
          报告库
        </span>
        <small>{historyCleared ? 0 : searchableTasks.length}</small>
      </button>
      <button
        className="sidebar-help-guide"
        onClick={() => openDialog("help")}
        title="帮助指引"
      >
        <span>
          <Icon size={17}>
            <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.4" />
            <path d="M9.7 9.2a2.5 2.5 0 1 1 3.1 2.4c-.6.3-.8.8-.8 1.5M12 16.7v.1" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
          </Icon>
          帮助指引
        </span>
      </button>
      <div className="side-label">最近任务</div>
      <div className="history">
        {historyCleared ? (
          <p className="history-empty">暂无检测记录</p>
        ) : (
          <>
            <button className={activeTask === "makeup" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onTask("makeup")}>
              <span className="history-thumb">
                <img alt="" src={postImage} />
              </span>
              <span>
                <strong>秋冬奶油肌底妆分享</strong>
                <small>{archivedScore ? `今天 · 已归档 · ${archivedScore} 分` : "今天 · 高可信"}</small>
              </span>
            </button>
            <button className={activeTask === "serum" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onTask("serum")}>
              <span className="history-thumb purple">
                <Sparkle size={15} />
              </span>
              <span>
                <strong>热门精华测评合集</strong>
                <small>昨天 · 存在风险</small>
              </span>
            </button>
            <button className={activeTask === "whitening" && (active === "chat" || active === "result") ? "active" : ""} onClick={() => onTask("whitening")}>
              <span className="history-thumb blue">S</span>
              <span>
                <strong>七天美白挑战</strong>
                <small>3 天前 · 疑似营销</small>
              </span>
            </button>
          </>
        )}
      </div>
      {searchOpen && (
        <div
          aria-modal="true"
          className="global-search-backdrop"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setSearchOpen(false);
          }}
          role="dialog"
        >
          <div className="global-search-dialog">
            <header className="global-search-header">
              <div className="global-search-input">
                <Icon size={21}>
                  <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
                  <path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
                </Icon>
                <input
                  aria-label="搜索历史对话和报告"
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder="搜索历史对话或报告…"
                  ref={searchInputRef}
                  value={searchQuery}
                />
                {searchQuery && <button aria-label="清空搜索" onClick={() => setSearchQuery("")}>×</button>}
              </div>
              <button aria-label="关闭搜索" className="global-search-close" onClick={() => setSearchOpen(false)}>
                <Icon size={20}><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
              </button>
            </header>

            <div className="global-search-tabs" role="tablist">
              <button
                aria-selected={searchCategory === "all"}
                className={searchCategory === "all" ? "active" : ""}
                onClick={() => setSearchCategory("all")}
                role="tab"
              >
                <span>
                  <Icon size={18}><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /></Icon>
                </span>
                <strong>全部</strong>
                <small>历史对话</small>
              </button>
              <button
                aria-selected={searchCategory === "reports"}
                className={searchCategory === "reports" ? "active" : ""}
                onClick={() => setSearchCategory("reports")}
                role="tab"
              >
                <span>
                  <Icon size={18}><path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /><path d="M15 3v4h3M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" /></Icon>
                </span>
                <strong>报告库</strong>
                <small>历史报告合集</small>
              </button>
            </div>

            <div className="global-search-results">
              <div className="global-search-result-heading">
                <span>{searchCategory === "all" ? "历史对话" : "报告库"}</span>
                <small>{filteredSearchTasks.length} 项结果</small>
              </div>
              {filteredSearchTasks.length ? filteredSearchTasks.map((item) => (
                <button
                  className="global-search-result"
                  key={`${searchCategory}-${item.task}`}
                  onClick={() => {
                    setSearchOpen(false);
                    if (searchCategory === "reports") onReport(item.task);
                    else onTask(item.task);
                  }}
                >
                  <span className={`global-search-result-icon ${searchCategory === "reports" ? "report" : ""}`}>
                    {searchCategory === "reports" ? (
                      <Icon size={18}><path d="M6 3h9l3 3v15H6V3Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /><path d="M9 11h6M9 14h6M9 17h4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.3" /></Icon>
                    ) : (
                      <Icon size={18}><path d="M4 5h16v11H9l-5 4V5Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.4" /></Icon>
                    )}
                  </span>
                  <span>
                    <strong>{item.title}</strong>
                    <small>{item.date} · {item.status}</small>
                  </span>
                  {searchCategory === "reports" && <b>{item.score}<small>/100</small></b>}
                  <i>›</i>
                </button>
              )) : (
                <div className="global-search-empty">
                  <Icon size={24}><circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.4" /><path d="m16 16 4 4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" /></Icon>
                  <strong>没有找到相关内容</strong>
                  <small>尝试搜索任务名称、日期或核验状态</small>
                </div>
              )}
            </div>
            <footer className="global-search-footer"><span><kbd>Esc</kbd> 关闭</span><span>点击结果即可打开</span></footer>
          </div>
        </div>
      )}
      {accountMenuOpen && <button aria-label="关闭账户菜单" className="account-menu-scrim" onClick={() => setAccountMenuOpen(false)} />}
      {accountMenuOpen && (
        <div className="account-menu">
          <button className="account-menu-reset" onClick={() => openDialog("reset")}>
            <span className="account-menu-icon">
              <Icon size={20}><path d="M19 8a7 7 0 1 0 .2 7.6M19 4v4h-4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
            </span>
            <span><strong>重置 Agent</strong><small>清空聊天与检测历史</small></span>
          </button>
          <div className="account-menu-divider" />
          <button onClick={() => openDialog("add")}>
            <span className="account-menu-icon">
              <Icon size={20}><circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" /><path d="M12 8v8M8 12h8" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            </span>
            <span><strong>添加账号</strong><small>绑定另一个登录账号</small></span>
          </button>
          <button onClick={() => openDialog("logout")}>
            <span className="account-menu-icon">
              <Icon size={20}><path d="M10 5H5v14h5M14 8l4 4-4 4M9 12h9" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
            </span>
            <span><strong>退出登录</strong><small>退出当前个人账户</small></span>
          </button>
        </div>
      )}
      <div className="side-bottom">
        <button
          aria-expanded={accountMenuOpen}
          className={accountMenuOpen ? "account-trigger active" : "account-trigger"}
          onClick={() => setAccountMenuOpen((open) => !open)}
        >
          <span className="avatar">YZ</span>
          <span>
            <strong>Yuzuki</strong>
            <small>个人账户</small>
          </span>
          <span className="dots">
            <Icon size={18}><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5" /><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
          </span>
        </button>
      </div>

      {accountDialog && (
        <div
          aria-modal="true"
          className="account-dialog-backdrop"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setAccountDialog(null);
          }}
          role="dialog"
        >
          <div className="account-dialog">
            <button aria-label="关闭弹窗" className="account-dialog-close" onClick={() => setAccountDialog(null)}>×</button>
            {accountDialog === "help" && (
              <>
                <span className="account-dialog-tag">HELP CENTER</span>
                <h2>帮助指引</h2>
                <p>快速了解如何使用 TruLens 完成一次内容核验。</p>
                <div className="help-guide">
                  <section>
                    <h3>使用教程</h3>
                    <ol>
                      <li><span>1</span><div><strong>提供内容</strong><small>粘贴种草链接，或上传需要核验的图片。</small></div></li>
                      <li><span>2</span><div><strong>等待四维核验</strong><small>TruLens 从账号、图片、评论和宣传维度检查证据。</small></div></li>
                      <li><span>3</span><div><strong>阅读报告</strong><small>查看 Trust Score、逐项依据和购买建议。</small></div></li>
                    </ol>
                  </section>
                  <section className="help-faq">
                    <h3>FAQ</h3>
                    <details><summary>链接无法识别怎么办？</summary><p>请确认链接可公开访问，也可以补充截图或原始文案。</p></details>
                    <details><summary>Agent 的核查结论可以当作最终定论吗？</summary><p>TruLens Agent 是辅助核验工具，AI 存在误判、信息遗漏风险，不能直接作为事实定论，重要内容建议交叉查阅权威原始来源。</p></details>
                    <details><summary>数据不足会怎样显示？</summary><p>缺失维度会明确标注“数据不足”，不会由 AI 自动补全。</p></details>
                  </section>
                </div>
              </>
            )}
            {accountDialog === "reset" && (
              <>
                <span className="account-dialog-tag">RESET AGENT</span>
                <h2>重置 TruLens Agent？</h2>
                <p>这会清空当前聊天信息和所有检测历史。操作完成后无法恢复。</p>
                <div className="reset-summary"><span>聊天内容</span><strong>全部清空</strong><span>检测历史</span><strong>全部清空</strong></div>
                <div className="account-dialog-actions">
                  <button onClick={() => setAccountDialog(null)}>取消</button>
                  <button className="danger" onClick={() => { onResetAgent(); setAccountDialog(null); }}>确认重置</button>
                </div>
              </>
            )}
            {accountDialog === "add" && (
              <>
                <span className="account-dialog-tag">ADD ACCOUNT</span>
                <h2>添加账号</h2>
                <p>输入邮箱，将另一个账号添加到当前设备。</p>
                {accountAdded ? (
                  <div className="account-added"><span>✓</span><strong>账号已添加</strong><small>{accountInput}</small></div>
                ) : (
                  <>
                    <label className="account-input-label">邮箱地址<input onChange={(event) => setAccountInput(event.target.value)} placeholder="name@example.com" type="email" value={accountInput} /></label>
                    <div className="account-dialog-actions">
                      <button onClick={() => setAccountDialog(null)}>取消</button>
                      <button disabled={!accountInput.includes("@")} onClick={() => setAccountAdded(true)}>添加账号</button>
                    </div>
                  </>
                )}
              </>
            )}
            {accountDialog === "logout" && (
              <>
                <span className="account-dialog-tag">SIGN OUT</span>
                <h2>退出当前账户？</h2>
                <p>退出后将返回首页，本地检测记录不会被删除。</p>
                <div className="account-dialog-actions">
                  <button onClick={() => setAccountDialog(null)}>取消</button>
                  <button className="danger" onClick={() => { onLogout(); setAccountDialog(null); }}>退出登录</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </aside>
  );
}

const suggestionItems = [
  ["鉴别配图真实性", "上传截图或粘贴帖子链接"],
  ["分析博主的历史可信度", "输入主页链接，检索长期行为"],
  ["检查产品功效宣传", "识别夸大、误导与安全风险"],
];

const creatorExampleDraft = "这款精华真的是我用过最有效的！7 天直接变白，敏感肌孕妇都能放心用，100% 安全无刺激。别的都是智商税，闭眼入！";
const creatorExampleImages = [
  {
    name: "示例手背使用前后对比图.jpg",
    url: "https://images.unsplash.com/photo-1605552987364-7fe8c2b19b8b?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=720&h=720",
  },
  {
    name: "示例无品牌精华产品图.jpg",
    url: "https://images.unsplash.com/photo-1781344116880-029945a42b75?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=720&h=720",
  },
];

type VerificationSubmission = {
  prompt: string;
  imageCount: number;
  dimensions: DimensionCode[];
  isExample: boolean;
};

type SupplementalMaterialKey = "comments" | "account" | "reviews" | "service";

const supplementalMaterialOptions: Array<{
  key: SupplementalMaterialKey;
  code: DimensionCode;
  title: string;
  effect: string;
  placeholder: string;
}> = [
  { key: "comments", code: "U", title: "评论区", effect: "补充后将启用：评论自然度", placeholder: "粘贴评论文字，或上传评论区截图" },
  { key: "account", code: "T", title: "作者主页或账号信息", effect: "补充后将启用：账号可信度", placeholder: "粘贴主页简介、账号链接或历史发布信息" },
  { key: "reviews", code: "U", title: "商品评价", effect: "补充后将启用：评论自然度", placeholder: "粘贴商品评价文字，或上传评价截图" },
  { key: "service", code: "R", title: "客服凭证截图", effect: "补充后将增强：图像原生性", placeholder: "粘贴客服说明，或上传凭证截图" },
];

const verificationExampleText = "最近换季皮肤有点干，连续使用这款精华 14 天后，我个人感觉保湿度有所提升。本文为自费购买，具体效果会因肤质和使用方式不同。";

function VerificationInput({ onConfirm }: { onConfirm: (submission: VerificationSubmission) => void }) {
  const [entry, setEntry] = useState<"link" | "content">("link");
  const [noteLink, setNoteLink] = useState("");
  const [authorLink, setAuthorLink] = useState("");
  const [copy, setCopy] = useState("");
  const [images, setImages] = useState<Array<{ id: string; name: string; url: string; example?: boolean }>>([]);
  const [supplementOpen, setSupplementOpen] = useState(false);
  const [supplements, setSupplements] = useState<Record<SupplementalMaterialKey, { text: string; file: string }>>({
    comments: { text: "", file: "" },
    account: { text: "", file: "" },
    reviews: { text: "", file: "" },
    service: { text: "", file: "" },
  });
  const [panel, setPanel] = useState<"recognition" | "scarce" | "link-error" | null>(null);
  const [isExample, setIsExample] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const addImages = (files: File[]) => {
    const room = Math.max(0, 9 - images.length);
    setImages((current) => [...current, ...files.slice(0, room).map((file) => ({
      id: `${file.name}-${file.lastModified}-${Math.random()}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }))]);
  };

  const activeDimensions = (() => {
    if (entry === "link" && noteLink) {
      return allDimensions.filter((code) => code !== "T" || Boolean(authorLink)) as DimensionCode[];
    }
    const enabled = new Set<DimensionCode>();
    if (copy.trim()) enabled.add("S");
    if (images.length || supplements.service.text || supplements.service.file) enabled.add("R");
    if (supplements.comments.text || supplements.comments.file || supplements.reviews.text || supplements.reviews.file) enabled.add("U");
    if (supplements.account.text || supplements.account.file) enabled.add("T");
    return allDimensions.filter((code) => enabled.has(code));
  })();

  const recognitionMaterials = [
    { key: "copy", label: "帖子正文", ready: entry === "link" ? Boolean(noteLink) : Boolean(copy.trim()), detail: "" },
    { key: "images", label: "配图", ready: entry === "link" ? Boolean(noteLink) : images.length > 0, detail: entry === "content" && images.length ? `${images.length} 张` : "" },
    { key: "comments", label: "评论", ready: entry === "link" ? Boolean(noteLink) : Boolean(supplements.comments.text || supplements.comments.file), detail: "" },
    { key: "reviews", label: "商品评价", ready: Boolean(supplements.reviews.text || supplements.reviews.file), detail: "" },
    { key: "service", label: "客服凭证", ready: Boolean(supplements.service.text || supplements.service.file), detail: "" },
  ];

  const loadExample = () => {
    setEntry("content");
    setCopy(verificationExampleText);
    setImages([{
      id: "verification-example",
      name: "示例护肤笔记配图.jpg",
      url: creatorExampleImages[1].url,
      example: true,
    }]);
    setIsExample(true);
  };

  const startRecognition = () => {
    if (entry === "link") {
      const readable = /xiaohongshu|xhslink|redbook/i.test(noteLink);
      setPanel(readable ? "recognition" : "link-error");
      return;
    }
    const compactCopy = copy.trim().replace(/\s/g, "");
    setPanel(compactCopy.length > 0 && compactCopy.length < 24 && images.length === 0 ? "scarce" : "recognition");
  };

  const confirmSubmission = (forcedDimensions?: DimensionCode[]) => {
    const dimensions = forcedDimensions ?? activeDimensions;
    const prompt = entry === "link"
      ? `请核验这篇笔记：${noteLink}${authorLink ? `\n作者主页：${authorLink}` : ""}`
      : copy.trim() || "请核验我上传的帖子截图";
    onConfirm({ prompt, imageCount: images.length, dimensions, isExample });
  };

  if (panel === "link-error") {
    return (
      <div className="verification-feedback-panel link-error-panel">
        <span className="verification-panel-icon">!</span>
        <small>LINK UNAVAILABLE</small>
        <h3>这个链接暂时无法读取</h3>
        <p>你可以粘贴文案或上传截图，已填写的链接会继续保留。</p>
        <button onClick={() => { setEntry("content"); setPanel(null); }}>改用文案 / 图片核验 <Arrow size={16} /></button>
      </div>
    );
  }

  if (panel === "scarce") {
    return (
      <div className="verification-feedback-panel scarce-panel">
        <span className="verification-panel-icon">S</span>
        <small>LIMITED MATERIAL</small>
        <h3>材料较少，只能核验文案真实性</h3>
        <p>当前只有一句简短文案且没有图片，报告置信度会偏低。</p>
        <div><button onClick={() => { setPanel(null); setSupplementOpen(true); }}>补充材料</button><button onClick={() => confirmSubmission(["S"])}>仍然继续 <Arrow size={16} /></button></div>
      </div>
    );
  }

  if (panel === "recognition") {
    return (
      <div className="verification-recognition-panel">
        <header><small>MATERIAL RECOGNITION</small><h3>识别结果</h3><p>请确认 Agent 即将使用的材料与核验范围。</p></header>
        <div className="recognition-layout">
          <section>
            <span>材料清单</span>
            {recognitionMaterials.map((material) => (
              <div className={material.ready ? "ready" : "missing"} key={material.key}>
                <i>{material.ready ? "✓" : "✕"}</i><strong>{material.label}</strong>{material.detail && <small>{material.detail}</small>}
                {!material.ready && <button onClick={() => { setPanel(null); setEntry("content"); setSupplementOpen(true); }}>补充</button>}
              </div>
            ))}
          </section>
          <section>
            <span>本次启用维度</span>
            {allDimensions.map((code) => {
              const enabled = activeDimensions.includes(code);
              const labels: Record<DimensionCode, string> = { T: "账号可信度", R: "图像原生性", U: "评论自然度", S: "文案真实性" };
              const reasons: Record<DimensionCode, string> = { T: "未提供账号信息，不参与计分", R: "未提供图片，不参与计分", U: "未提供评论，不参与计分", S: "未提供文案，不参与计分" };
              return (
                <div className={enabled ? "enabled" : "disabled"} key={code}>
                  <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
                  <div><strong>{labels[code]}</strong><small>{enabled ? "将核验" : reasons[code]}</small></div>
                </div>
              );
            })}
          </section>
        </div>
        <p className="recognition-scope-note"><Sparkle size={14} /> Agent 只会核验你提供的材料，缺失的部分不会被推测或补全。</p>
        <footer><button onClick={() => { setPanel(null); setEntry("content"); setSupplementOpen(true); }}>补充材料</button><button onClick={() => confirmSubmission()}>确认并开始 <Arrow size={16} /></button></footer>
      </div>
    );
  }

  return (
    <div className="verification-input">
      <div className="verification-entry-tabs" role="tablist">
        <button className={entry === "link" ? "active" : ""} onClick={() => setEntry("link")} role="tab" style={{ width: "50%" }}>链接核验</button>
        <button className={entry === "content" ? "active" : ""} onClick={() => setEntry("content")} role="tab" style={{ width: "50%" }}>文案 / 图片核验</button>
      </div>

      {entry === "link" ? (
        <div className="link-verification-form">
          <label><span>笔记链接</span><input onChange={(event) => setNoteLink(event.target.value)} placeholder="粘贴公开可访问的笔记链接" value={noteLink} /></label>
          <label><span>作者主页链接 <small>可选</small></span><input onChange={(event) => setAuthorLink(event.target.value)} placeholder="补充后可启用账号可信度" value={authorLink} /></label>
        </div>
      ) : (
        <>
          {noteLink && <p className="retained-link">已保留链接：{noteLink}</p>}
          <div className="content-verification-grid">
            <label className="verification-copy-field">
              <span>文案 <small>至少一项</small></span>
              <textarea onChange={(event) => { setCopy(event.target.value); setIsExample(false); }} placeholder="粘贴帖子正文、标题或宣传文案" value={copy} />
              <em>{copy.length} 字</em>
            </label>
            <div className="verification-image-field">
              <span>图片 <small>至少一项 · 最多 9 张</small></span>
              <input accept="image/*" hidden multiple onChange={(event) => addImages(Array.from(event.target.files ?? []))} ref={imageInputRef} type="file" />
              <button disabled={images.length >= 9} onClick={() => imageInputRef.current?.click()}>
                <Icon size={21}><path d="M12 5v14M5 12h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
                <strong>上传图片或截图</strong><small>{images.length}/9</small>
              </button>
              {images.length > 0 && <div>{images.map((image) => <figure key={image.id}><img alt={image.name} src={image.url} />{image.example && <figcaption>示例</figcaption>}<button onClick={() => setImages((current) => current.filter((item) => item.id !== image.id))}>×</button></figure>)}</div>}
            </div>
          </div>

          <div className={`supplemental-materials ${supplementOpen ? "open" : ""}`}>
            <button onClick={() => setSupplementOpen((open) => !open)}>＋ 补充材料（可选） <span>{supplementOpen ? "收起" : "展开"}</span></button>
            {supplementOpen && (
              <div>
                {supplementalMaterialOptions.map((option) => (
                  <article key={option.key}>
                    <header><span className={`report-dimension-badge badge-${option.code.toLowerCase()}`}>{option.code}</span><div><strong>{option.title}</strong><small>{option.effect}</small></div></header>
                    <textarea onChange={(event) => setSupplements((current) => ({ ...current, [option.key]: { ...current[option.key], text: event.target.value } }))} placeholder={option.placeholder} value={supplements[option.key].text} />
                    <label><input accept="image/*" hidden onChange={(event) => setSupplements((current) => ({ ...current, [option.key]: { ...current[option.key], file: event.target.files?.[0]?.name ?? "" } }))} type="file" /><span>{supplements[option.key].file || "上传图片"}</span></label>
                  </article>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      <div className="verification-submit-row">
        <small>文案与图片至少提供一项</small>
        <button className="verification-example-link" onClick={loadExample}>载入示例</button>
        <button className="verification-start-button" disabled={entry === "link" ? !noteLink.trim() : !copy.trim() && images.length === 0} onClick={startRecognition}>开始核验 <Arrow size={16} /></button>
      </div>
    </div>
  );
}

function Composer({
  compact = false,
  filename,
  onFile,
  onPauseToggle,
  onSubmit,
  pauseDisabled = false,
  paused = false,
  preset = "",
}: {
  compact?: boolean;
  filename: string;
  onFile: (name: string) => void;
  onPauseToggle?: () => void;
  onSubmit: (prompt: string) => void;
  pauseDisabled?: boolean;
  paused?: boolean;
  preset?: string;
}) {
  const [value, setValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setValue(preset);
  }, [preset]);

  const submit = () => {
    if (value.trim() || filename) {
      onSubmit(value.trim() || "请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
      setValue("");
    }
  };

  return (
    <div className={`composer ${compact ? "composer-compact" : ""}`}>
      <textarea
        aria-label="输入鉴别需求"
        onChange={(event) => setValue(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            submit();
          }
        }}
        placeholder={compact ? "继续追问这份报告…" : "粘贴帖子链接，或告诉我你想鉴别什么…"}
        rows={compact ? 1 : 3}
        value={value}
      />
      {filename && (
        <div className="file-chip">
          <span className="file-preview"><img alt="" src={postImage} /></span>
          <span><strong>{filename}</strong><small>已准备进行图像取证</small></span>
          <button aria-label="移除附件" onClick={() => onFile("")}>×</button>
        </div>
      )}
      <div className="composer-actions">
        <div>
          <input
            accept="image/*"
            hidden
            onChange={(event) => onFile(event.target.files?.[0]?.name || "")}
            ref={inputRef}
            type="file"
          />
          <button className="tool-button" onClick={() => inputRef.current?.click()} title="上传图片">
            <Icon size={18}>
              <path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.6" />
            </Icon>
          </button>
          {!compact && (
            <button className="tool-button" title="粘贴链接">
              <Icon size={18}>
                <path d="m9.5 14.5 5-5M7.3 16.7l-1 1a3.5 3.5 0 0 1-5-5l3.2-3.2a3.5 3.5 0 0 1 5 0M16.7 7.3l1-1a3.5 3.5 0 1 1 5 5l-3.2 3.2a3.5 3.5 0 0 1-5 0" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
              </Icon>
            </button>
          )}
          {!compact && <span className="composer-hint">支持图片、链接与文案</span>}
        </div>
        <div className="composer-submit-actions">
          {compact && onPauseToggle && (
            <button
              aria-label={pauseDisabled ? "当前回答已完成" : paused ? "继续生成" : "暂停生成"}
              className={paused ? "composer-pause paused" : "composer-pause"}
              disabled={pauseDisabled}
              onClick={onPauseToggle}
              title={pauseDisabled ? "当前回答已完成" : paused ? "继续生成" : "暂停生成"}
            >
              <Icon size={21}>
                {paused ? (
                  <path d="m8 5 11 7-11 7V5Z" fill="currentColor" />
                ) : (
                  <>
                    <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" />
                    <rect fill="currentColor" height="6" rx="1.2" width="6" x="9" y="9" />
                  </>
                )}
              </Icon>
            </button>
          )}
          <button className="send-button" disabled={!value.trim() && !filename} onClick={submit}>
            <Arrow size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

function Workspace({
  initialCreatorInput,
  mode,
  onHome,
  onModeChange,
  onCreatorSubmit,
  onVerifySubmit,
}: {
  initialCreatorInput?: CreatorReportInput | null;
  mode: WorkspaceMode;
  onHome: () => void;
  onModeChange: (mode: WorkspaceMode) => void;
  onCreatorSubmit: (input: CreatorReportInput) => void;
  onVerifySubmit: (submission: VerificationSubmission) => void;
}) {
  const [draft, setDraft] = useState(initialCreatorInput?.draft ?? "");
  const [creatorImages, setCreatorImages] = useState<Array<{ id: string; name: string; url: string; example?: boolean }>>(initialCreatorInput?.images ?? []);
  const [isCollaboration, setIsCollaboration] = useState(initialCreatorInput?.isCollaboration ?? false);
  const [category, setCategory] = useState(initialCreatorInput?.category ?? "护肤");
  const [isDragging, setIsDragging] = useState(false);
  const creatorInputRef = useRef<HTMLInputElement>(null);

  const addCreatorImages = (files: File[]) => {
    const room = Math.max(0, 9 - creatorImages.length);
    const nextImages = files.slice(0, room).map((file) => ({
      id: `${file.name}-${file.lastModified}-${Math.random()}`,
      name: file.name,
      url: URL.createObjectURL(file),
    }));
    setCreatorImages((current) => [...current, ...nextImages]);
  };

  const removeCreatorImage = (id: string) => {
    setCreatorImages((current) => {
      const target = current.find((image) => image.id === id);
      if (target && !target.example) URL.revokeObjectURL(target.url);
      return current.filter((image) => image.id !== id);
    });
  };

  const loadExampleDraft = () => {
    creatorImages.forEach((image) => {
      if (!image.example) URL.revokeObjectURL(image.url);
    });
    setDraft(creatorExampleDraft);
    setCategory("护肤");
    setIsCollaboration(true);
    setCreatorImages(creatorExampleImages.map((image, index) => ({ ...image, id: `creator-example-${index}`, example: true })));
  };

  return (
    <section className={`workspace ${mode === "creator" ? "creator-workspace" : "verification-workspace"}`}>
      <div className="workspace-orb orb-left" />
      <div className="workspace-orb orb-right" />
      <header className="workspace-header">
        <div className="workspace-status-group">
          <button aria-label="返回首页" className="workspace-home" onClick={onHome} title="返回首页">
            <Icon size={22}>
              <path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </Icon>
          </button>
        </div>
        <div aria-label="核验模式" className="workspace-mode-switch">
          <button className={mode === "verify" ? "active" : ""} onClick={() => onModeChange("verify")}>核验别人的笔记</button>
          <button className={mode === "creator" ? "active" : ""} onClick={() => onModeChange("creator")}>我是创作者 · 发布前自检</button>
        </div>
      </header>
      {mode === "verify" ? (
        <div className="workspace-center verification-workspace-center">
          <div className="agent-symbol"><Sparkle size={29} /></div>
          <p className="hello">你好，我是 TruLens</p>
          <h2>今天想鉴别什么？</h2>
          <p className="workspace-intro">上传美妆种草内容，我会从账号、图像、评论和文案四个维度寻找 AI 生成与营销造假痕迹。</p>
          <VerificationInput onConfirm={onVerifySubmit} />
          <div className="suggestions" />
        </div>
      ) : (
        <div className="creator-self-check">
          <header>
            <span><Sparkle size={16} /> CREATOR PRE-CHECK</span>
            <h2>发布前，让 TruLens 帮你查一遍。</h2>
            <p>只检查你的文案和配图，帮你避开容易被误判的表述。</p>
          </header>
          <div className="creator-form">
            <label className="creator-draft-field">
              <span>草稿文案</span>
              <textarea
                maxLength={3000}
                onChange={(event) => setDraft(event.target.value)}
                placeholder="把你准备发布的笔记文案粘贴到这里"
                value={draft}
              />
              <small>{draft.length} / 3000</small>
            </label>
            <div className="creator-upload-field">
              <div className="creator-field-label"><span>配图</span><small>{creatorImages.length} / 9</small></div>
              <input
                accept="image/*"
                hidden
                multiple
                onChange={(event) => addCreatorImages(Array.from(event.target.files ?? []))}
                ref={creatorInputRef}
                type="file"
              />
              <button
                className={`creator-dropzone ${isDragging ? "dragging" : ""}`}
                disabled={creatorImages.length >= 9}
                onClick={() => creatorInputRef.current?.click()}
                onDragEnter={(event) => { event.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                  event.preventDefault();
                  setIsDragging(false);
                  addCreatorImages(Array.from(event.dataTransfer.files).filter((file) => file.type.startsWith("image/")));
                }}
              >
                <Icon size={23}><path d="M12 16V5m0 0L8 9m4-4 4 4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                <span><strong>拖拽配图到这里，或点击上传</strong><small>支持 JPG、PNG，最多 9 张</small></span>
              </button>
              {creatorImages.length > 0 && (
                <div className="creator-image-grid">
                  {creatorImages.map((image) => (
                    <figure key={image.id}>
                      <img alt={image.name} src={image.url} />
                      {image.example && <figcaption>示例草稿</figcaption>}
                      <button aria-label={`删除${image.name}`} onClick={() => removeCreatorImage(image.id)}>×</button>
                    </figure>
                  ))}
                </div>
              )}
            </div>
            <div className="creator-options">
              <label className="creator-switch">
                <button aria-pressed={isCollaboration} className={isCollaboration ? "active" : ""} onClick={() => setIsCollaboration((current) => !current)} type="button"><i /></button>
                <span>这篇是合作或赠品</span>
              </label>
              <label className="creator-category"><span>品类</span><select onChange={(event) => setCategory(event.target.value)} value={category}><option>护肤</option><option>彩妆</option><option>其他</option></select></label>
            </div>
            <div className="creator-form-actions">
              <button className="creator-example-button" onClick={loadExampleDraft}><Sparkle size={14} /> 载入示例草稿</button>
              <button
                className="creator-submit-button"
                disabled={!draft.trim() && creatorImages.length === 0}
                onClick={() => onCreatorSubmit({
                  draft: draft.trim() || "请检查这些待发布配图",
                  images: creatorImages,
                  isCollaboration,
                  category,
                  isExample: creatorImages.some((image) => image.example),
                })}
              >
                开始自检 <Arrow size={17} />
              </button>
            </div>
            <p className="creator-dimensions-note"><span>本次启用：文案真实性、图像原生性。</span>账号可信度、评论自然度发布前暂无数据，不参与。</p>
          </div>
        </div>
      )}
    </section>
  );
}

function AnalysisSteps({
  done,
  activeDimensions,
  creatorMode = false,
  paused,
}: {
  done: boolean;
  activeDimensions: DimensionCode[];
  creatorMode?: boolean;
  paused: boolean;
}) {
  const [expandedRole, setExpandedRole] = useState<string | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const roles = [
    {
      code: "T",
      role: "账号侦探",
      dimension: "Trustworthiness",
      weight: 25,
      score: 82,
      verdict: "可信",
      thinking: "正在回溯 286 篇历史内容与商业合作轨迹…",
      thinkingLabels: ["我正在冷静思考", "让我核对一下", "事实不会说谎"],
      insight: "账号持续运营 2.3 年，商业内容占比 18%，身份与发布节奏稳定。",
      evidence: ["历史内容连续，无集中删帖", "商业合作均有明确标识", "互动增长曲线未见突变"],
    },
    {
      code: "R",
      role: "视觉取证师",
      dimension: "Reality",
      weight: 30,
      score: creatorMode ? 82 : 88,
      verdict: "轻度修饰",
      thinking: "正在比对皮肤纹理、边缘结构与光影方向…",
      thinkingLabels: ["我在快速扫图", "有异常，抓到了", "我再确认一遍"],
      insight: creatorMode ? "配图主体结构自然，但局部质感经过柔化，建议发布时注明滤镜或修饰。" : "面中存在两处生成式细化痕迹，但产品主体与整体光影保持真实。",
      evidence: ["局部毛孔纹理重复", "产品边缘连续自然", "环境光线方向一致"],
    },
    {
      code: "U",
      role: "口碑观察员",
      dimension: "User Voice",
      weight: 20,
      score: 74,
      verdict: "需留意",
      thinking: "正在聚类评论语义、发布时间与互动关系…",
      thinkingLabels: ["我在听大家说", "我在头脑风暴中", "慢慢拼出共识"],
      insight: "12% 的短评存在相似句式，其余评论具有具体问题与真实讨论特征。",
      evidence: ["有效评论 168 条", "同质短评占比 12%", "未发现批量账号联动"],
    },
    {
      code: "S",
      role: "宣传安全官",
      dimension: "Safety",
      weight: 25,
      score: creatorMode ? 28 : 91,
      verdict: creatorMode ? "需修改" : "安全",
      thinking: "正在核验功效承诺、广告表达与风险边界…",
      thinkingLabels: ["正在严谨审阅", "我按规范核验", "准备出具意见"],
      insight: creatorMode ? "检测到“7 天直接变白”“100% 安全”等绝对化承诺，发布前需要改写。" : "未发现绝对化功效承诺，合作标识清晰，个人体验边界完整。",
      evidence: creatorMode ? ["绝对化功效表达 3 处", "敏感人群安全承诺缺少依据", "包含贬损性购买引导"] : ["无医疗功效宣称", "包含个体差异说明", "品牌合作标识清晰"],
    },
  ];
  const activeRoles = roles.filter((item) => activeDimensions.includes(item.code as DimensionCode));
  const displayedRoles = roles;
  const activeWeightTotal = activeRoles.reduce((total, item) => total + item.weight, 0);
  const analysisScore = Math.round(activeRoles.reduce((total, item) => total + item.score, 0) / activeRoles.length);
  const dimensionWord = ["", "单", "双", "三", "四"][activeRoles.length];

  useEffect(() => {
    if (done || paused) return;
    const timer = window.setInterval(() => {
      setElapsedSeconds((current) => Math.min(10, current + 0.1));
    }, 100);
    return () => window.clearInterval(timer);
  }, [done, paused]);

  const thinkingStage = Math.min(2, Math.floor(elapsedSeconds / 1.8));
  const reasoningStage = done ? 4 : Math.min(4, Math.floor(elapsedSeconds / 2));
  const reasoningFlow = [
    [`调用${activeRoles.length}个分析视角`, `正在唤醒 ${activeRoles.map((item) => item.code).join(" / ")} 分析角色`],
    [`生成${dimensionWord}维评分`, "正在校准各维度分数与证据权重"],
    ["发现关键风险", "正在定位可能改变消费判断的核心风险"],
    ["内部推理", "Reasoning · 正在消解不同证据之间的冲突"],
    ["生成最终报告", "正在组织可解释结论与决策依据"],
  ];
  const debateMessages = [
    ["T", "账号侦探", "提出判断", "账号轨迹稳定，现有证据不支持系统性造假。"],
    ["R", "视觉取证师", "提出异议", "我不同意完全放行。两处生成式修饰必须降低图像证据权重。"],
    ["U", "口碑观察员", "补充证据", "评论里确有相似话术，但多数反馈具体，暂不足以否定整篇内容。"],
    ["S", "宣传安全官", "形成裁定", "综合各方证据，建议保留风险说明后判定为高可信。"],
  ];
  const activeDebateMessages = debateMessages.filter(([code]) => activeDimensions.includes(code as DimensionCode));
  const debateDuration = 4 / activeDebateMessages.length;
  const debateIndex = Math.min(activeDebateMessages.length - 1, Math.floor(Math.max(0, elapsedSeconds - 4) / debateDuration));
  const activeDebate = activeDebateMessages[debateIndex];
  const debateFocus = activeDimensions.includes("R")
    ? "图像修饰是否足以改变宣传安全维度的判断？"
    : activeDimensions.includes("U")
      ? "评论异常是否足以推翻文案本身的安全性？"
      : "账号历史信号与当前宣传表达是否相互一致？";

  return (
    <div className={`trus-council ${done ? "is-complete" : "is-thinking"} ${paused ? "is-paused" : ""}`}>
      <div className="council-header">
        <div className="council-avatars">
          {displayedRoles.map((item) => {
            const isActive = activeDimensions.includes(item.code as DimensionCode);
            return (
            <span className={`council-avatar role-${item.code.toLowerCase()} ${isActive ? "" : "inactive"}`} key={item.code}>
              <img alt="" src={roleAvatarByCode[item.code as DimensionCode]} />
              <i>{item.code}</i>
            </span>
            );
          })}
        </div>
        <div className="council-title">
          <span>TRUS REASONING COUNCIL</span>
          <strong>你的 AI 信任评审团正在讨论</strong>
          <small>{done ? `${activeRoles.length} 个角色已完成验证，点击角色查看证据` : `${activeRoles.length} 个角色正在分析当前输入`}</small>
        </div>
        <div className="council-state">
          <i />
          {done ? `${activeRoles.length} / ${activeRoles.length} 完成 · ${elapsedSeconds.toFixed(1)} 秒` : paused ? `已暂停 · ${elapsedSeconds.toFixed(1)} 秒` : `已思考 ${elapsedSeconds.toFixed(1)} 秒`}
        </div>
      </div>

      <div className="reasoning-flow">
        <div className="reasoning-flow-steps">
          {reasoningFlow.map(([label], index) => (
            <div
              className={index < reasoningStage || done ? "completed" : index === reasoningStage ? "active" : ""}
              key={label}
            >
              <span>{index < reasoningStage || done ? "✓" : index + 1}</span>
              <small>{label}</small>
            </div>
          ))}
        </div>
        <p key={reasoningStage}>
          <Sparkle size={13} />
          {done ? "推理链已完成，最终报告已生成" : reasoningFlow[reasoningStage][1]}
        </p>
      </div>

      <div className="council-columns">
        <span>分析视角与观点</span>
        <span>权重</span>
        <span>判断</span>
      </div>

      <div className="council-roles">
        {displayedRoles.map((item, index) => {
          const isActive = activeDimensions.includes(item.code as DimensionCode);
          if (!isActive) {
            return (
              <div className="council-role-wrap inactive" key={item.code}>
                <div className={`council-role role-${item.code.toLowerCase()}`}>
                  <span className="role-persona">
                    <span className="role-avatar"><img alt={`${item.role}角色`} src={roleAvatarByCode[item.code as DimensionCode]} /><i>{item.code}</i></span>
                    <span>
                      <strong>{item.role}</strong>
                      <small>{item.dimension}</small>
                      <p>{creatorMode ? "发布前暂无账号互动与评论数据，未启用" : "当前输入缺少该维度材料，未启用"}</p>
                    </span>
                  </span>
                  <span className="role-weight">—</span>
                  <span className="role-judgement"><small>未启用</small></span>
                  <span className="role-chevron">—</span>
                </div>
              </div>
            );
          }
          const activeIndex = activeRoles.findIndex((role) => role.code === item.code);
          return (
          <div className={`council-role-wrap ${expandedRole === item.code ? "expanded" : ""}`} key={item.code}>
            <button
              className={`council-role role-${item.code.toLowerCase()}`}
              onClick={() => setExpandedRole((current) => current === item.code ? null : item.code)}
              style={{ "--role-delay": `${activeIndex * 120}ms` } as React.CSSProperties}
            >
              <span className="role-persona">
                <span className="role-avatar">
                  <img alt={`${item.role}角色`} src={roleAvatarByCode[item.code as DimensionCode]} />
                  <i>{item.code}</i>
                </span>
                <span>
                  <strong>{item.code === "S" ? "文案检查官" : item.role}</strong>
                  <small>{item.code === "S" ? "Script" : item.dimension}</small>
                  <p>{done ? item.insight : item.thinking}</p>
                </span>
              </span>
              <span className="role-weight">{Math.round((item.weight / activeWeightTotal) * 100)}%</span>
              <span className="role-judgement">
                {done ? (
                  <><strong>{item.score}</strong><small>已完成 · {item.verdict}</small></>
                ) : reasoningStage >= 1 ? (
                  <><strong>{item.score}</strong><small>{item.thinkingLabels[thinkingStage]}</small></>
                ) : (
                  <><i /><small>{item.thinkingLabels[thinkingStage]}</small></>
                )}
              </span>
              <span className="role-chevron">⌄</span>
            </button>
            <div className="role-progress"><i style={{ "--role-score": `${item.score}%` } as React.CSSProperties} /></div>
            {expandedRole === item.code && (
              <div className="role-evidence">
                <span>证据链</span>
                {item.evidence.map((evidence) => <p key={evidence}>✓ {evidence}</p>)}
              </div>
            )}
          </div>
          );
        })}
      </div>

      {reasoningStage >= 2 && reasoningStage < 4 && activeDebateMessages.length > 1 && (
        <div className="expert-debate">
          <div className="debate-header">
            <span><i /> EXPERT DISCUSSION</span>
            <div className="debate-cast">
              {activeDebateMessages.map(([code], index) => (
                <i className={index === debateIndex ? "active" : index < debateIndex ? "heard" : ""} key={code}>
                  {code}
                </i>
              ))}
            </div>
            <small>{debateIndex + 1} / {activeDebateMessages.length}</small>
          </div>
          <div className={`debate-message role-${activeDebate[0].toLowerCase()}`} key={debateIndex}>
            <span className="debate-avatar">
              <img alt={`${activeDebate[1]}头像`} src={roleAvatarByCode[activeDebate[0] as DimensionCode]} />
              <i>{activeDebate[0]}</i>
            </span>
            <div>
              <span><strong>{activeDebate[1]}</strong><small>{activeDebate[2]}</small></span>
              <p>“{activeDebate[3]}”</p>
            </div>
          </div>
          <div className="debate-focus">
            <span>争议焦点</span>
            {debateFocus}
          </div>
        </div>
      )}

      {reasoningStage >= 2 && reasoningStage < 4 && activeDebateMessages.length === 1 && (
        <div className="reasoning-finding stage-3">
          <span>INDEPENDENT REVIEW</span>
          <p>{activeDebate[3]}</p>
        </div>
      )}

      {reasoningStage >= 4 && (
        <div className="debate-consensus">
          <span><Sparkle size={13} /> {activeRoles.length > 1 ? `${activeRoles.length} 位专家达成共识` : `${activeRoles[0].role}完成独立审查`}</span>
          <p>{activeRoles.length > 1 ? "已结合当前可用模态完成交叉验证，并生成对应维度的可信度报告。" : "当前输入仅支持单维度判断，报告会明确标注证据范围。"}</p>
        </div>
      )}

      <div className="council-result">
        <div>
          {activeRoles.map((item, index) => (
            <span key={item.code}>
              {index > 0 && (item.code === "R" ? <span className="fg-inline-italic">+</span> : <i>+</i>)}
              <span>{item.code} {item.code === "R" || item.code === "U" ? 25 : Math.round((item.weight / activeWeightTotal) * 100)}%</span>
            </span>
          ))}
        </div>
        <div>
          <small>{done ? "加权结果" : `等待交叉验证 · ${elapsedSeconds.toFixed(1)}s`}</small>
          {done ? <><strong>{analysisScore}</strong><span>{analysisScore >= 80 ? "高可信" : "需留意"}</span></> : <span className="council-loading"><i /><i /><i /></span>}
        </div>
      </div>
    </div>
  );
}

const initialQuickFollowups = [
  "哪些图片区域可能经过 AI 修饰？",
  "评论区有哪些异常话术？",
  "这个博主长期可信吗？",
  "我该购买吗",
];

const appealPrompt = "我想申诉或辩解当前核验结论";
const appealOptions: Array<{
  code: DimensionCode;
  label: string;
  role: string;
  reply: string;
}> = [
  {
    code: "R",
    label: "视觉取证不准",
    role: "视觉专家",
    reply: "收到您的申诉！视觉专家 R 正在重新对该区域进行局部像素频域分析……正在剥离环境光影干扰……请稍候。",
  },
  {
    code: "T",
    label: "账号侦测误判",
    role: "账号专家",
    reply: "收到您的申诉！账号专家 T 正在重新回溯主页简介、历史动态与商业合作轨迹……正在排除账号成长周期带来的误判……请稍候。",
  },
  {
    code: "U",
    label: "评论区误伤",
    role: "评论专家",
    reply: "收到您的申诉！评论专家 U 正在重新聚类评论句式、发布时间与互动关系……正在区分真实共鸣与协同传播……请稍候。",
  },
  {
    code: "S",
    label: "文案检查误判",
    role: "文案专家",
    reply: "收到您的申诉！文案专家 S 正在重新核对原文语境、体验边界与功效主张……正在排除修辞表达造成的误判……请稍候。",
  },
];

function getInitialQuickFollowups(activeDimensions: DimensionCode[]) {
  if (activeDimensions.length === 1) {
    return ["文案中有哪些夸大表达？", "是否存在绝对化宣传？", "这段文案足以支持决策吗？", "还需要补充什么证据？"];
  }
  if (activeDimensions.includes("U")) {
    return ["哪些评论最像批量生成的？", "评论与文案结论一致吗？", "真实用户主要在讨论什么？", "评论区整体可信吗？"];
  }
  if (activeDimensions.includes("T")) {
    return ["这个博主长期可信吗？", "商业合作比例高吗？", "历史内容有没有异常？", "账号与文案是否一致？"];
  }
  return ["哪些图片区域可能经过 AI 修饰？", "图片与文案结论一致吗？", "有没有整图生成痕迹？", "当前证据足够可信吗？"];
}

function getNextQuickFollowups(question?: string) {
  if (!question) return initialQuickFollowups;
  if (question.includes("图片区域") || question.includes("AI 修饰")) {
    return [
      "这些修饰会影响产品效果判断吗？",
      "能进一步解释脸颊区域的异常吗？",
      "这是普通美化还是 AI 造假？",
      "我还需要查看哪些原图？",
    ];
  }
  if (question.includes("效果") || question.includes("美化") || question.includes("原图")) {
    return [
      "这项图像风险会如何影响帖子可信度？",
      "如果图片可信度降低，我该如何决策？",
      "哪些证据能够抵消这项风险？",
      "评论是否支持图片中的结论？",
    ];
  }
  if (question.includes("评论") || question.includes("话术")) {
    return [
      "哪些评论最像批量生成的？",
      "真实用户主要在意什么问题？",
      "评论异常会影响可信分吗？",
      "结合图片给我最终建议",
    ];
  }
  if (question.includes("博主") || question.includes("账号")) {
    return [
      "她的商业合作比例高吗？",
      "历史内容有没有前后矛盾？",
      "哪些账号行为值得警惕？",
      "结合本篇内容给出可信结论",
    ];
  }
  if (question.includes("购买") || question.includes("最终建议") || question.includes("相差")) {
    return [
      "哪些证据最影响这次购买决定？",
      "如果只看可信度，我该如何选择？",
      "当前还缺少什么关键证据？",
      "帮我总结这次决策的风险等级",
    ];
  }
  return [
    "这条证据的置信度是多少？",
    "还有其他风险需要注意吗？",
    "它会如何影响购买决定？",
    "帮我总结当前结论",
  ];
}

function ContextualFollowupAnswer({ question }: { question: string }) {
  let title = "已结合当前报告继续核验";
  let answer = "这条新问题与已有的账号、图像、评论和文案证据进行了交叉验证。目前没有出现足以推翻原结论的新风险信号。";
  let facts = ["与原始证据一致", "未发现新增高风险项", "综合可信度保持稳定"];

  if (question.includes("影响产品效果")) {
    title = "会影响对遮瑕力的判断，但不影响色号参考";
    answer = "AI 细化主要抹平了面中毛孔和轻微卡粉，因此画面会高估底妆的柔焦与遮瑕表现。产品色号、光泽方向和整体服帖度没有明显被改变。";
    facts = ["遮瑕表现可能被高估", "色号参考仍有效", "建议查看 4 小时持妆图"];
  } else if (question.includes("脸颊区域")) {
    title = "异常来自过度均匀的高频皮肤纹理";
    answer = "真实皮肤的毛孔、绒毛和细小纹理通常具有随机变化；该区域出现重复频率和方向高度一致的纹理，同时没有对应的光影起伏。";
    facts = ["纹理周期重复", "毛孔方向一致", "缺少自然光影起伏"];
  } else if (question.includes("普通美化") || question.includes("AI 造假")) {
    title = "更接近 AI 辅助美化，而非整图造假";
    answer = "人物结构、产品边缘和环境光线都保持连续，异常只集中在局部皮肤纹理。这说明工具可能用于精修肤质，而不是重新生成产品效果。";
    facts = ["主体结构真实", "局部生成式精修", "未改变产品形态"];
  } else if (question.includes("哪些原图") || question.includes("确认什么")) {
    title = "优先补充三类未经精修的证据";
    answer = "自然光近景、四小时后的持妆图，以及包含鼻翼与下颌边缘的视频帧，最能验证遮瑕、卡粉和真实皮肤纹理。";
    facts = ["自然光近景", "四小时持妆图", "连续视频原帧"];
  } else if (question.includes("评论")) {
    title = "评论区存在少量同质话术，但未形成批量水评";
    answer = "约 12% 的短评使用了相似的情绪词和购买号召，发布时间也较集中；其余评论包含肤质差异、使用时长和具体问题，整体仍有真实讨论特征。";
    facts = ["相似短评 12%", "真实提问占多数", "未发现大规模账号联动"];
  } else if (question.includes("帖子可信度") || question.includes("图像风险")) {
    title = "图像证据折损会降低结论强度，但不会让整篇帖子失信";
    answer = "当前图像维度的异常只影响视觉展示证据，账号轨迹、评论结构和文案安全性仍提供独立支持。因此综合可信度会小幅下降，而不是直接变成“不可信”。";
    facts = ["视觉证据权重下降", "其他模态仍可验证", "综合结论保持中高可信"];
  } else if (
    question.includes("购买") ||
    question.includes("决策") ||
    question.includes("风险等级") ||
    question.includes("只看可信度") ||
    question.includes("关键证据")
  ) {
    title = "帖子可以作为参考，但不足以单独支持购买决定";
    answer = "账号历史和文本表达提供了正向可信信号，局部图像修饰则降低了展示证据的可靠性。更稳妥的决策方式，是把这篇帖子作为一个信息来源，并等待其他独立内容对关键结论形成交叉验证。";
    facts = ["整体可信度较高", "图像证据存在折损", "需要独立来源交叉验证"];
  }

  return (
    <div className="contextual-answer">
      <span className="contextual-answer-tag">FOLLOW-UP INSIGHT</span>
      <strong>{title}</strong>
      <p>{answer}</p>
      <div>{facts.map((fact) => <span key={fact}>✓ {fact}</span>)}</div>
    </div>
  );
}

function ArgueReviewFlow({
  evidenceName,
  explanation,
  onArchive,
  onViewReport,
  option,
}: {
  evidenceName: string;
  explanation: string;
  onArchive: (score: number) => void;
  onViewReport: (score: number) => void;
  option: (typeof appealOptions)[number];
}) {
  const [stage, setStage] = useState(0);
  const [archived, setArchived] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const accepted = option.code === "R" || option.code === "S";
  const oldScore = 84;
  const newScore = option.code === "R" ? 93 : option.code === "S" ? 90 : oldScore;
  const decisionCopy = option.code === "R"
    ? "感谢纠错，经二次复核，该区域确系环境强反光与底妆高光叠加，并非 AI 生成式修饰。我们已降低原异常信号权重，并对视觉取证结论作出修正。"
    : option.code === "S"
      ? "感谢补充。结合完整上下文后，原文属于个人体验描述而非确定性功效承诺，文案风险等级已下调。"
      : option.code === "U"
        ? "您的申诉部分成立：部分短评可能来自真实用户的品牌共识，但评论区仍存在明显的同质化传播痕迹，因此综合信任分维持原样，建议重点关注评论风险。"
        : "您的申诉部分成立：账号的高关注数不足以单独证明互关增长，但历史内容中的产品推荐密度依然较高，因此综合信任分维持原样，并优化账号风险提示。";
  const thinkingLabels = [
    `正在仅调用 ${option.role} ${option.code} 接收申诉材料`,
    `${option.role} ${option.code} 正在独立重检争议证据`,
    "单维复核完成，T / R / U / S 圆桌会议已启动",
    "四位专家正在交换反证并重新校准权重",
    "圆桌会诊结束，重新评估报告已生成",
  ];

  useEffect(() => {
    if (stage >= 4) return;
    const timer = window.setTimeout(() => setStage((current) => current + 1), stage >= 2 ? 1700 : 1300);
    return () => window.clearTimeout(timer);
  }, [stage]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [stage]);

  return (
    <div className="argue-consultation">
      <div className="argue-consultation-head">
        <div>
          <span>ARGUE COUNCIL · 重新会诊</span>
          <strong>{stage < 2 ? `${option.role}正在单独复核“${option.label}”` : stage < 4 ? "四位专家正在进行圆桌会议" : "重新评估报告已生成"}</strong>
          {explanation && <small>用户补充：“{explanation}”</small>}
          {evidenceName && <small>新增证据：{evidenceName}</small>}
        </div>
        <span className="argue-live"><i /> {stage < 4 ? "会诊中" : "已完成"}</span>
      </div>

      <div className="argue-council-cast">
        {(["T", "R", "U", "S"] as DimensionCode[]).map((code) => (
          <span className={`${code === option.code ? "lead" : ""} ${code === option.code || stage >= 2 ? "active" : ""}`} key={code}>
            <img alt={`${code} 专家`} src={roleAvatarByCode[code]} />
            <i>{code}</i>
          </span>
        ))}
        <div>
          <span>{thinkingLabels[stage]}</span>
          <small>{Math.min(100, 18 + stage * 22)}% · 正在重新计算证据权重</small>
        </div>
      </div>

      <div className="argue-thinking-flow">
        {["专属专家接单", "单维证据复核", "四专家圆桌会议", "生成重评报告"].map((label, index) => (
          <span className={stage > index ? "complete" : stage === index ? "active" : ""} key={label}>
            <i>{stage > index ? "✓" : index + 1}</i>{label}
          </span>
        ))}
      </div>

      {stage >= 1 && (
        <div className={`argue-expert-feedback role-${option.code.toLowerCase()}`}>
          <span>
            <img alt={`${option.role} ${option.code}`} src={roleAvatarByCode[option.code]} />
            <i>{option.code}</i>
          </span>
          <div><small>{option.role} · 单专家二次取证</small><p>{option.reply}</p></div>
        </div>
      )}

      {stage >= 2 && stage < 4 && (
        <div className="argue-roundtable-note">
          <span><Sparkle size={13} /> ROUND TABLE</span>
          <p>专项复核结果已提交圆桌。T / R / U / S 正在从账号、图像、评论与文案四个维度重新评估其对综合信任分的影响。</p>
        </div>
      )}

      {stage >= 4 && (
        <div className={`argue-final-decision ${accepted ? "accepted" : "partial"}`}>
          <header>
            <div>
              <span>重新评估报告 · {accepted ? "申诉已采纳" : "申诉部分成立"}</span>
              <strong>{accepted ? "AI 已修正原核验结论" : "保留原分数，风险提示已优化"}</strong>
            </div>
            <div className="argue-score-change">
              <span>{oldScore}</span><i>→</i><strong>{newScore}</strong><small>/100</small>
            </div>
          </header>
          <p>{decisionCopy}</p>
          <div className="argue-decision-meta">
            <span>复核编号 TL-A-{option.code}-0618</span>
            <span>原始报告与申诉过程已保留</span>
          </div>
          <div className="argue-final-actions">
            <button
              className={archived ? "archived" : ""}
              disabled={archived}
              onClick={() => {
                setArchived(true);
                onArchive(newScore);
              }}
            >
              {archived ? "✓ 已保存到报告库" : "保存到报告库"}
              {!archived && <Arrow size={16} />}
            </button>
            <button className="view-revised-report" onClick={() => onViewReport(newScore)}>
              查看新报告 <Arrow size={16} />
            </button>
          </div>
        </div>
      )}
      <div ref={endRef} />
    </div>
  );
}

const processStages = [
  { title: "多模态鉴伪", subtitle: "四位专家并行检验" },
  { title: "语义一致性校验", subtitle: "交叉比对宣称与证据" },
  { title: "决策与建议", subtitle: "生成风险提示与处理建议" },
];

type ConclusionMethod = "llm" | "rule";

const technicalConfig = {
  dimensionCapabilities: {
    T: "大模型判断",
    R: "视觉语言模型",
    U: "大模型判断",
    S: "大模型判断",
  } satisfies Record<DimensionCode, string>,
  methods: {
    llm: {
      label: "大模型判断",
      tooltip: "由大模型阅读内容后给出的判断",
    },
    rule: {
      label: "规则校验",
      tooltip: "按固定规则计算得出，结果可复现",
    },
  } satisfies Record<ConclusionMethod, { label: string; tooltip: string }>,
  models: [
    "文本理解：DeepSeek【版本待确认】",
    "图像理解：Qwen-VL【版本待确认】",
  ],
  deployment: "【待确认】",
  disclaimer: "模型与部署信息以实际运行环境为准。",
  processNotes: [
    "① 文本由 DeepSeek 理解，图片由 Qwen-VL 理解",
    "② 大模型对比各维度结果",
    "③ 大模型生成建议",
  ],
};

function TechnicalViewToggle({ enabled, onChange }: { enabled: boolean; onChange: (enabled: boolean) => void }) {
  return (
    <button
      aria-pressed={enabled}
      className={`technical-view-toggle ${enabled ? "enabled" : ""}`}
      onClick={() => onChange(!enabled)}
      title={enabled ? "关闭技术视图" : "开启技术视图"}
    >
      <span>技术视图</span>
      <i aria-hidden="true"><b /></i>
    </button>
  );
}

function MethodBadge({ method = "llm" }: { method?: ConclusionMethod }) {
  const config = technicalConfig.methods[method];
  return (
    <span className={`technical-method-badge method-${method}`} title={config.tooltip}>
      <Icon size={11}>
        {method === "llm" ? (
          <path d="m12 3 1.15 3.85L17 8l-3.85 1.15L12 13l-1.15-3.85L7 8l3.85-1.15L12 3Zm5 9 .7 2.3L20 15l-2.3.7L17 18l-.7-2.3L14 15l2.3-.7L17 12Z" fill="currentColor" />
        ) : (
          <path d="m8 7 1.4 1.4L12 5.8M8 12l1.4 1.4L12 10.8M8 17l1.4 1.4L12 15.8M14 8h4m-4 5h4m-4 5h4" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.4" />
        )}
      </Icon>
      {config.label}
    </span>
  );
}

function AnalysisProcessProgress({
  creatorMode,
  done,
  stage,
  technicalView,
}: {
  creatorMode: boolean;
  done: boolean;
  stage: number;
  technicalView: boolean;
}) {
  const consistencyMessages = [
    "正在比对文案宣称与图片证据…",
    "正在核对评论与账号关系…",
    "正在检查不同信号之间是否存在矛盾…",
  ];
  return (
    <section className="analysis-process-progress">
      <div>
        {processStages.map((item, index) => {
          const number = index + 1;
          const completed = done || number < stage;
          const active = !done && number === stage;
          return (
            <div className={`${completed ? "completed" : ""} ${active ? "active" : ""}`} key={item.title}>
              <span>{completed ? "✓" : number}</span>
              <div>
                <strong>{number === 1 && creatorMode ? "多模态鉴伪" : item.title}</strong>
                <small>{number === 1 && creatorMode ? "文案与图片两位专家检验" : item.subtitle}</small>
                <AnimatePresence>
                  {technicalView && (
                    <motion.p animate={{ opacity: 1, height: "auto" }} className="technical-stage-note" exit={{ opacity: 0, height: 0 }} initial={{ opacity: 0, height: 0 }}>
                      {technicalConfig.processNotes[index]}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
              {index < processStages.length - 1 && <i><b /></i>}
            </div>
          );
        })}
      </div>
      <AnimatePresence>
        {stage === 2 && !done && (
          <motion.div animate={{ opacity: 1, height: "auto" }} className="consistency-live-messages" exit={{ opacity: 0, height: 0 }} initial={{ opacity: 0, height: 0 }}>
            {consistencyMessages.map((message, index) => <small key={message} style={{ animationDelay: `${index * 700}ms` }}>{message}</small>)}
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

function Chat({
  prompt,
  filename,
  hidden = false,
  isExampleSubmission,
  activeDimensions,
  creatorMode = false,
  onArchiveReport,
  onFile,
  onHome,
  onResult,
  onTechnicalViewChange,
  technicalView,
  onViewRevisedReport,
}: {
  prompt: string;
  filename: string;
  hidden?: boolean;
  isExampleSubmission: boolean;
  activeDimensions: DimensionCode[];
  creatorMode?: boolean;
  onArchiveReport: (score: number) => void;
  onFile: (name: string) => void;
  onHome: () => void;
  onResult: (event: React.MouseEvent<HTMLButtonElement>) => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  technicalView: boolean;
  onViewRevisedReport: (score: number) => void;
}) {
  const [done, setDone] = useState(false);
  const [paused, setPaused] = useState(false);
  const [quickPrompt, setQuickPrompt] = useState("");
  const [followups, setFollowups] = useState<Array<{ id: number; question: string; answered: boolean; detail?: string; evidenceName?: string }>>([]);
  const [appealDraftCode, setAppealDraftCode] = useState<DimensionCode | null>(null);
  const [appealExplanation, setAppealExplanation] = useState("");
  const [appealEvidenceName, setAppealEvidenceName] = useState("");
  const [shareOpen, setShareOpen] = useState(false);
  const [processStage, setProcessStage] = useState(1);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const replyTimerRef = useRef<number | null>(null);
  const analysisRemainingRef = useRef(10000);
  const analysisStartedAtRef = useRef(0);
  const followupRemainingRef = useRef(1100);
  const followupStartedAtRef = useRef(0);
  const latestFollowup = followups[followups.length - 1];
  const hasAppealed = followups.some((followup) => followup.question === appealPrompt);
  const selectedAppeal = appealOptions.find((option) =>
    followups.some((followup) => followup.question === option.label),
  );
  const isGenerating = !done || Boolean(latestFollowup && !latestFollowup.answered);
  const isArgueFlow = hasAppealed && (!latestFollowup || latestFollowup.question === appealPrompt || Boolean(selectedAppeal));
  const quickFollowups = isArgueFlow
    ? []
    : latestFollowup && !latestFollowup.answered
    ? []
    : latestFollowup
      ? getNextQuickFollowups(latestFollowup.question)
      : getInitialQuickFollowups(activeDimensions);
  const expertNames: Record<DimensionCode, string> = {
    T: "账号侦探",
    R: "视觉取证师",
    U: "口碑观察员",
    S: "宣传安全官",
  };
  const scoreByDimension: Record<DimensionCode, number> = { T: 82, R: creatorMode ? 82 : 88, U: 74, S: creatorMode ? 28 : 91 };
  const analysisScore = Math.round(activeDimensions.reduce((total, code) => total + scoreByDimension[code], 0) / activeDimensions.length);
  const analysisSummary = activeDimensions.includes("R")
    ? "图像主体可信，但存在轻度 AI 修饰痕迹"
    : activeDimensions.includes("U")
      ? "评论整体可参考，但存在少量相似话术"
      : activeDimensions.includes("T")
        ? "账号轨迹稳定，宣传表达未见明显风险"
        : "文案表达整体安全，未见高风险宣传承诺";
  useEffect(() => {
    if (paused || done) return;
    analysisStartedAtRef.current = Date.now();
    const timer = window.setTimeout(() => {
      analysisRemainingRef.current = 0;
      setDone(true);
    }, analysisRemainingRef.current);
    return () => {
      window.clearTimeout(timer);
      analysisRemainingRef.current = Math.max(
        0,
        analysisRemainingRef.current - (Date.now() - analysisStartedAtRef.current),
      );
    };
  }, [paused, done]);

  useEffect(() => {
    if (paused || done || processStage >= 3) return;
    const timer = window.setTimeout(() => setProcessStage((current) => Math.min(3, current + 1)), processStage === 1 ? 3200 : 3500);
    return () => window.clearTimeout(timer);
  }, [done, paused, processStage]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [done, followups]);

  useEffect(() => {
    if (!latestFollowup || latestFollowup.answered || paused) return;
    const followupId = latestFollowup.id;
    followupStartedAtRef.current = Date.now();
    replyTimerRef.current = window.setTimeout(() => {
      followupRemainingRef.current = 0;
      setFollowups((current) =>
        current.map((item) => item.id === followupId ? { ...item, answered: true } : item),
      );
    }, followupRemainingRef.current);
    return () => {
      if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current);
      followupRemainingRef.current = Math.max(
        0,
        followupRemainingRef.current - (Date.now() - followupStartedAtRef.current),
      );
    };
  }, [latestFollowup, paused]);

  const sendFollowup = (question: string, detail?: string, evidenceName?: string) => {
    const cleanQuestion = question.trim();
    if (!cleanQuestion || (latestFollowup && !latestFollowup.answered)) return;
    if (replyTimerRef.current) window.clearTimeout(replyTimerRef.current);
    setQuickPrompt("");
    setPaused(false);
    followupRemainingRef.current = 1100;
    const id = Date.now();
    setFollowups((current) => [...current, { id, question: cleanQuestion, answered: false, detail, evidenceName }]);
  };

  const submitAppeal = () => {
    const option = appealOptions.find((item) => item.code === appealDraftCode);
    if (!option) return;
    sendFollowup(option.label, appealExplanation.trim(), appealEvidenceName);
    setAppealDraftCode(null);
    setAppealExplanation("");
    setAppealEvidenceName("");
  };

  return (
    <section className="chat" hidden={hidden}>
      <header className="chat-header">
        <div className="chat-header-main">
          <button aria-label="返回首页" className="chat-home-button" onClick={onHome} title="返回首页">
            <Icon size={22}>
              <path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </Icon>
          </button>
          <div className="chat-header-title">
            <strong>{creatorMode ? "创作者发布前自检" : activeDimensions.length === 1 ? "文案安全性鉴别" : `${activeDimensions.length} 维内容鉴别`}</strong>
            <small>{paused && isGenerating ? "生成已暂停" : !done ? `正在调用 ${activeDimensions.map((code) => expertNames[code]).join("、")}…` : latestFollowup && !latestFollowup.answered ? "正在生成追问回答…" : "分析完成"}</small>
          </div>
        </div>
        <div className="chat-header-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <div className="share-wrap">
            <button className="header-share" onClick={() => setShareOpen((open) => !open)}>
              <Icon size={17}>
                <circle cx="18" cy="5" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="6" cy="12" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="18" cy="19" r="2.2" stroke="currentColor" strokeWidth="1.5" />
                <path d="m8 11 8-5M8 13l8 5" stroke="currentColor" strokeWidth="1.5" />
              </Icon>
              分享
            </button>
            {shareOpen && <ShareMenu onClose={() => setShareOpen(false)} />}
          </div>
        </div>
      </header>
      <div className="chat-scroll">
        <div className="demo-version-banner">
          <Sparkle size={14} />
          <span><strong>演示版本</strong>以下为示例结果，并非对你输入内容的判断</span>
        </div>
        <AnalysisProcessProgress creatorMode={creatorMode} done={done} stage={processStage} technicalView={technicalView} />
        <div className="user-message">
          <div>
            <p>{prompt}</p>
            {filename && (
              <span className="message-attachment">
                <img alt="待分析美妆帖子预览" src={postImage} />
                <span><strong>{filename}</strong><small>{isExampleSubmission ? "示例 · 演示附件" : "图片内容 · 已上传"}</small></span>
              </span>
            )}
          </div>
          <span className="avatar user-avatar">YZ</span>
        </div>

        <div className="agent-message">
          <span className="agent-avatar"><Sparkle size={17} /></span>
          <div className="agent-content">
            <div className="agent-name">TruLens <span>多模态鉴别 Agent</span></div>
            <p>{creatorMode ? "收到。发布前自检仅调用文案检查官与视觉取证师；账号和评论数据会明确标记为未启用。" : <>收到。根据当前输入，我将调用 {activeDimensions.map((code) => expertNames[code]).join("和")}，只分析有足够证据支持的维度。</>}</p>
            <AnalysisSteps activeDimensions={activeDimensions} creatorMode={creatorMode} done={done} paused={paused} />
            {!done ? (
              <div className={`thinking ${paused ? "paused" : ""}`}><i /><i /><i /> {paused ? "分析已暂停，点击继续恢复推理" : activeDimensions.length > 1 ? `${activeDimensions.length} 位专家正在交换证据并校准权重` : `${expertNames[activeDimensions[0]]}正在独立核验证据`}</div>
            ) : (
              <>
                <div className="analysis-complete">
                  <div className="mini-score" style={{ "--mini-score": analysisScore } as React.CSSProperties}>
                    <span><strong>{analysisScore}</strong>/100</span>
                    <small>综合可信度</small>
                  </div>
                  <div>
                    <strong>{analysisSummary}</strong>
                    <p>本次结论仅基于当前输入可识别的 {activeDimensions.join(" / ")} 维度生成；未提供的模态不会被模型假设或补全。</p>
                    <div className="evidence-tags">
                      {activeDimensions.map((code) => <span key={code}>{expertNames[code]}已完成</span>)}
                    </div>
                  </div>
                </div>
                <motion.div
                  animate={{ opacity: 1, y: 0 }}
                  className="analysis-result-entry"
                  initial={{ opacity: 0, y: 10 }}
                  transition={{ delay: 0.18, duration: 0.42 }}
                >
                  <small>分析已完成，点击查看完整报告</small>
                  <button onClick={(event) => onResult(event)}>
                    {creatorMode ? "查看自检报告 →" : "查看核验结果 →"}
                  </button>
                </motion.div>
                <button
                  className="appeal-button"
                  disabled={hasAppealed}
                  onClick={() => sendFollowup(appealPrompt)}
                >
                  {hasAppealed ? "已进入申诉辩论" : "申诉或辩解"}
                </button>
              </>
            )}
          </div>
        </div>

        {followups.map((followup, index) => {
          const isImageDetection = followup.question.includes("图片区域") || followup.question.includes("AI 修饰");
          const isAppealStart = followup.question === appealPrompt;
          const appealSelection = appealOptions.find((option) => option.label === followup.question);
          return (
            <div className="followup-thread" key={followup.id}>
              <div className="user-message followup-user-message">
                <div>
                  <p>{followup.question}</p>
                  {followup.detail && <small className="appeal-user-detail">我觉得这里没问题，因为：{followup.detail}</small>}
                  {followup.evidenceName && <small className="appeal-user-evidence">附件证据 · {followup.evidenceName}</small>}
                </div>
                <span className="avatar user-avatar">YZ</span>
              </div>
              <div className="agent-message followup-agent-message">
                <span className="agent-avatar"><Sparkle size={17} /></span>
                <div className="agent-content">
                  <div className="agent-name">
                    TruLens
                    <span>
                      {isAppealStart || appealSelection
                        ? "ARGUE · 结论复议"
                        : isImageDetection
                          ? "图像取证 Agent"
                          : `上下文推理 · 回合 ${index + 2}`}
                    </span>
                  </div>
                  {!followup.answered ? (
                    <div className={`agent-typing ${paused ? "paused" : ""}`}>
                      <span><i /><i /><i /></span>
                      {paused
                        ? "回答已暂停，点击顶部继续"
                        : isAppealStart
                          ? "正在建立申诉议题并召回复核专家"
                          : appealSelection
                            ? `正在将异议移交给${appealSelection.role} ${appealSelection.code}`
                            : "正在结合上一轮证据生成回答"}
                    </div>
                  ) : isAppealStart ? (
                    <div className="argue-entry">
                      <div className="argue-entry-head">
                        <span><Sparkle size={14} /> 已进入 ARGUE 辩论环节</span>
                        <small>原结论暂不变更</small>
                      </div>
                      <strong>收到。你不同意当前核验结果的哪一部分？</strong>
                      <p>请选择一项具体异议，TruLens 会将原始证据和评分依据交给对应专家重新审查。</p>
                      <div className="argue-options">
                        {appealOptions.map((option) => (
                          <div
                            className={`argue-option-card ${appealDraftCode === option.code && !selectedAppeal ? "selected" : ""}`}
                            key={option.code}
                          >
                            <button
                              disabled={Boolean(selectedAppeal)}
                              onClick={() => {
                                setAppealDraftCode(option.code);
                                setAppealExplanation("");
                                setAppealEvidenceName("");
                              }}
                            >
                              <span className={`report-dimension-badge badge-${option.code.toLowerCase()}`}>{option.code}</span>
                              <span><strong>{option.label}</strong><small>{option.role}重新核验</small></span>
                              <i aria-hidden="true">{appealDraftCode === option.code ? "⌄" : "→"}</i>
                            </button>
                            {appealDraftCode === option.code && !selectedAppeal && (
                              <div className="argue-appeal-input">
                                <label htmlFor={`appeal-${option.code}`}>补充你的判断依据 <small>选填</small></label>
                                <textarea
                                  id={`appeal-${option.code}`}
                                  onChange={(event) => setAppealExplanation(event.target.value)}
                                  placeholder="我觉得这里没问题，因为……"
                                  rows={3}
                                  value={appealExplanation}
                                />
                                <div className="argue-appeal-actions">
                                  <label className="argue-evidence-upload" title="上传图片或其他证据">
                                    <input
                                      accept="image/*,.pdf,.doc,.docx,.txt"
                                      onChange={(event) => setAppealEvidenceName(event.target.files?.[0]?.name ?? "")}
                                      type="file"
                                    />
                                    <Icon size={15}><path d="M12 16V4m0 0L8 8m4-4 4 4M5 14v5h14v-5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
                                    <span>{appealEvidenceName || "上传图片或其他证据"}</span>
                                  </label>
                                  <div>
                                    <button className="skip" onClick={submitAppeal}>跳过，不填写</button>
                                    <button onClick={submitAppeal}>{appealExplanation.trim() || appealEvidenceName ? "提交申诉材料" : "直接提交"} <Arrow size={14} /></button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : appealSelection ? (
                    <ArgueReviewFlow
                      evidenceName={followup.evidenceName ?? ""}
                      explanation={followup.detail ?? ""}
                      onArchive={onArchiveReport}
                      onViewReport={onViewRevisedReport}
                      option={appealSelection}
                    />
                  ) : isImageDetection ? (
                    <>
                      <p>检测完成。我在主图中定位到 <strong>2 处疑似 AI 辅助修饰区域</strong>。它们更接近局部美化，而不是整张图片由 AI 生成。</p>
                      <div className="photo-detection-result">
                        <div className="detected-photo">
                          <img alt="照片 AI 修饰区域检测结果" src={postImage} />
                          <span className="detection-box zone-a"><i>A</i></span>
                          <span className="detection-box zone-b"><i>B</i></span>
                          <div className="detection-scanline" />
                          <small>IMAGE FORENSICS · FRAME 01</small>
                        </div>
                        <div className="detection-findings">
                          <div className="detection-score">
                            <span>图像原生性</span>
                            <strong>88<small>/100</small></strong>
                          </div>
                          <div className="finding-item">
                            <span>A</span>
                            <div>
                              <strong>面中与脸颊纹理</strong>
                              <p>局部毛孔纹理重复且过于均匀，疑似使用生成式皮肤细化。</p>
                            </div>
                            <em>78%</em>
                          </div>
                          <div className="finding-item">
                            <span>B</span>
                            <div>
                              <strong>唇周与下颌边缘</strong>
                              <p>边缘过渡异常平滑，但光影方向与原图保持一致。</p>
                            </div>
                            <em>64%</em>
                          </div>
                        </div>
                      </div>
                      <div className="detection-conclusion">
                        <span>结论</span>
                        <p>产品主体、背景和整体光影未发现生成痕迹。修饰主要集中在肤质优化，可能会让底妆遮瑕力看起来优于真实效果，建议参考自然光下的素人试妆。</p>
                      </div>
                    </>
                  ) : (
                    <ContextualFollowupAnswer question={followup.question} />
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div className="chat-end-anchor" ref={chatEndRef} />
      </div>
      <div className="chat-composer-wrap">
        {!isArgueFlow && (
          <div className="quick-followups">
            <span>{quickFollowups.length ? "继续追问" : "正在生成追问"}</span>
            <div>
              {quickFollowups.length ? quickFollowups.map((question) => (
                <button
                  className={quickPrompt === question ? "active" : ""}
                  key={question}
                  onClick={() => setQuickPrompt(question)}
                >
                  {question}
                </button>
              )) : <span className="quick-loading"><i /><i /><i /></span>}
            </div>
          </div>
        )}
        <Composer
          compact
          filename=""
          onFile={onFile}
          onPauseToggle={() => setPaused((current) => !current)}
          onSubmit={sendFollowup}
          pauseDisabled={!isGenerating}
          paused={paused}
          preset={quickPrompt}
        />
        <small>TruLens 可能会出错，请结合实际体验判断。</small>
      </div>
    </section>
  );
}

const dimensions = [
  { code: "T", title: "账号可信度", en: "Trustworthiness", score: 82, status: "可信", tone: "violet", text: "“眠云的护肤手账”明确标注为虚构演示账号，简介与历史笔记都围绕日常护肤、精华体验和成分记录展开；内容轨迹稳定，连续体验记录仍需结合原始素材核对。", evidence: ["粉丝 3.5 万", "获赞与收藏 24.6 万", "历史内容垂直"] },
  { code: "R", title: "图像原生性", en: "Reality", score: 88, status: "轻度修饰", tone: "blue", text: "左右脸对比中的人物结构、拍摄角度和环境光线基本一致；右侧皮肤微纹理明显减少，存在局部磨皮或生成式细化信号。", evidence: ["人物结构一致", "右脸纹理减少", "未见整图生成"] },
  { code: "U", title: "评论自然度", en: "User Voice", score: 74, status: "较自然", tone: "peach", text: "可见评论以保湿感、成分、敏感肌适配和使用周期等具体问题为主，作者也针对肤质差异与成分进行回复；暂未发现集中复制的模板话术。", evidence: ["问题表达具体", "作者回复有针对性", "评论地域与时间分散"] },
  { code: "S", title: "文案真实性", en: "Safety", score: 91, status: "安全", tone: "green", text: "未使用绝对化功效承诺，色号、持妆与肤质描述均保留了个人体验边界。", evidence: ["无医疗功效宣称", "含个体差异说明", "合作标识清晰"] },
];

const archivedTasks = {
  makeup: {
    date: "今天",
    title: "秋冬奶油肌底妆分享",
    subtitle: "秋冬奶油肌底妆分享 · 多模态可信度报告",
    score: 84,
    status: "高可信",
    tone: "trusted",
    headline: "内容整体可信，图像存在轻度修饰痕迹。",
    summary: "账号身份与历史内容轨迹稳定，评论区保留真实体验反馈，文案表达边界清晰；右侧肤质细节存在局部优化，但未发现整图生成证据。",
    risks: [
      ["图像修饰", "右侧眼下与面中区域的微纹理明显减少", "低"],
      ["评论同质", "部分短评重复品牌名称，缺少具体体验", "中"],
      ["账号内容", "历史笔记长期垂直于美妆护肤领域", "低"],
    ],
    dimensions,
    decision: "这篇内容可以作为底妆效果参考，但局部肤质可能经过优化。建议结合自然光原图和其他真实用户的持妆反馈作出购买决定。",
  },
  serum: {
    date: "2025.06.17",
    title: "热门精华测评合集",
    subtitle: "12 款热门精华横向测评 · 多模态可信度报告",
    score: 58,
    status: "存在风险",
    tone: "warning",
    headline: "部分结论可信，评论与功效表达存在异常。",
    summary: "账号本身具有稳定运营记录，但测评中的排序逻辑缺少统一标准；部分评论存在协同传播特征，三项功效结论未提供可追溯依据。",
    risks: [
      ["评论协同", "27 个账号在 18 分钟内发布高度相似的推荐话术", "高"],
      ["测评标准", "不同产品使用了不同观察周期，横向排名依据不足", "中"],
      ["功效表达", "“修护翻倍”等结论未标注数据来源", "中"],
    ],
    dimensions: [
      { code: "T", title: "账号可信度", en: "Trustworthiness", score: 68, status: "一般", tone: "violet", text: "账号持续运营 1.8 年，但近 30 天商业合作密度明显上升。", evidence: ["历史发布 174 篇", "商业内容占比 42%", "近期合作集中"] },
      { code: "R", title: "图像原生性", en: "Reality", score: 81, status: "较真实", tone: "blue", text: "产品包装与质地图片未发现明显生成痕迹，部分对比图曝光不一致。", evidence: ["主体边缘自然", "两组曝光差异", "无整图生成"] },
      { code: "U", title: "评论自然度", en: "User Voice", score: 42, status: "高风险", tone: "peach", text: "评论区存在集中发布与重复句式，真实体验反馈被营销话术稀释。", evidence: ["相似评论 31%", "27 个关联账号", "发布时间集中"] },
      { code: "S", title: "文案真实性", en: "Safety", score: 47, status: "需核验", tone: "green", text: "多处功效对比缺乏统一条件，部分结论超出个人体验表达边界。", evidence: ["3 项无来源结论", "对比标准不统一", "合作标识存在"] },
    ],
    decision: "暂缓将该合集作为主要决策依据。建议寻找采用统一测试周期、披露合作关系，并能提供原始观察记录的独立测评进行交叉验证。",
  },
  whitening: {
    date: "2025.06.15",
    title: "七天美白挑战",
    subtitle: "短周期功效挑战 · 多模态可信度报告",
    score: 39,
    status: "疑似营销",
    tone: "danger",
    headline: "内容具有明显营销结构，关键效果证据不足。",
    summary: "账号、评论和文案同时出现营销信号。前后对比图拍摄条件不一致，“七天显著变白”的核心结论缺少可验证记录，不足以支持内容主张。",
    risks: [
      ["视觉对比", "前后图片的白平衡、曝光与拍摄角度均不一致", "高"],
      ["时间证据", "未提供连续七天的原始记录或可验证时间信息", "高"],
      ["传播结构", "核心口号在多个关联账号中同步出现", "高"],
    ],
    dimensions: [
      { code: "T", title: "账号可信度", en: "Trustworthiness", score: 55, status: "需留意", tone: "violet", text: "账号存在真实历史内容，但挑战发布前后集中出现同品牌合作。", evidence: ["运营 11 个月", "合作发布集中", "关联账号 8 个"] },
      { code: "R", title: "图像原生性", en: "Reality", score: 43, status: "条件异常", tone: "blue", text: "对比图未发现整图生成，但曝光和白平衡差异足以改变视觉结果。", evidence: ["曝光差异 +18%", "白平衡不一致", "拍摄角度变化"] },
      { code: "U", title: "评论自然度", en: "User Voice", score: 38, status: "低可信", tone: "peach", text: "大量评论重复挑战口号，缺少具体使用过程与差异化体验。", evidence: ["重复话术 36%", "短时集中发布", "体验细节不足"] },
      { code: "S", title: "文案真实性", en: "Safety", score: 22, status: "高风险", tone: "green", text: "短周期确定性功效表达缺乏依据，并使用明显的结果导向措辞。", evidence: ["绝对化表达 4 处", "无证据来源", "缺少差异说明"] },
    ],
    decision: "不建议根据该帖子作出购买决定。核心主张缺少可追溯证据，且三个模态的风险信号相互强化，应等待独立来源或更完整记录。",
  },
};

const archivedConversations = {
  makeup: {
    prompt: "请帮我鉴别这篇“秋冬奶油肌底妆分享”是否可信，重点检查账号、图片和评论区。",
    acknowledgement: "收到。我已完成账号历史、左右脸肤质对比、评论区原文和宣传文案的多模态核验，并保留了生成报告时使用的证据。",
    followups: [
      ["图片里哪些地方可能经过修饰？", "右侧眼下与面中区域的毛孔和微纹理明显少于左侧，但人物结构、拍摄角度与主光方向保持一致，更接近局部磨皮或生成式细化，而不是整图生成。"],
      ["评论区整体可信吗？", "可见评论包含保湿感、成分、敏感肌适配和使用周期等具体问题，作者回复也结合了不同肤质与使用方式。当前样本未见集中复制的模板话术，整体互动较自然，但仍只代表可见评论范围。"],
    ],
  },
  serum: {
    prompt: "帮我核验这篇 12 款热门精华横向测评，重点看排名依据和评论自然度。",
    acknowledgement: "收到。我会对账号历史、测评图片、评论传播结构和功效文案进行交叉核验，并检查不同产品是否使用了统一测评标准。",
    followups: [
      ["这些产品的测评标准一致吗？", "不完全一致。部分产品观察 7 天，部分产品观察 28 天，肤质、用量和搭配产品也没有统一，因此现有横向排名不能直接比较。"],
      ["评论区有没有协同传播？", "有明显信号。27 个账号在 18 分钟内发布高度相似的推荐话术，且多个账号缺少其他真实互动记录。"],
    ],
  },
  whitening: {
    prompt: "这篇“七天美白挑战”可信吗？请检查前后对比图和功效宣传。",
    acknowledgement: "收到。我会核验账号合作记录、前后图片条件、评论区传播结构，以及“七天显著变白”等核心功效主张。",
    followups: [
      ["前后对比图的问题在哪里？", "两组图片的曝光、白平衡和拍摄角度均不一致。即使没有整图生成，这些条件差异也足以让后图看起来更亮。"],
      ["“七天显著变白”有依据吗？", "当前内容没有提供连续七天的原始记录、统一光线下的测量结果或可追溯数据，因此不足以支持确定性功效结论。"],
    ],
  },
};

function ArchivedConversation({
  onHome,
  onResult,
  task,
}: {
  onHome: () => void;
  onResult: () => void;
  task: RecentTask;
}) {
  const data = archivedTasks[task];
  const conversation = archivedConversations[task];
  return (
    <section className="chat archived-chat">
      <header className="chat-header">
        <div className="chat-header-main">
          <button aria-label="返回首页" className="chat-home-button" onClick={onHome} title="返回首页">
            <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
          </button>
          <div className="chat-header-title"><strong>{data.title}</strong><small>{data.date} · 历史对话记录</small></div>
        </div>
      </header>

      <div className="chat-scroll">
        <div className="user-message">
          <div><p>{conversation.prompt}</p></div>
          <span className="avatar user-avatar">YZ</span>
        </div>
        <div className="agent-message">
          <span className="agent-avatar"><Sparkle size={17} /></span>
          <div className="agent-content">
            <div className="agent-name">TruLens <span>多模态鉴别 Agent</span></div>
            <p>{conversation.acknowledgement}</p>
            <div className="archive-analysis-summary">
              <span className="archive-chat-score">{data.score}<small>/100</small></span>
              <div><strong>{data.headline}</strong><p>{data.summary}</p></div>
              <button className="report-button" onClick={onResult}>查看核验报告 <Arrow size={17} /></button>
            </div>
          </div>
        </div>

        {conversation.followups.map(([question, answer], index) => (
          <div className="followup-thread" key={question}>
            <div className="user-message followup-user-message">
              <div><p>{question}</p></div>
              <span className="avatar user-avatar">YZ</span>
            </div>
            <div className="agent-message followup-agent-message">
              <span className="agent-avatar"><Sparkle size={17} /></span>
              <div className="agent-content">
                <div className="agent-name">TruLens <span>上下文推理 · 回合 {index + 2}</span></div>
                <p>{answer}</p>
              </div>
            </div>
          </div>
        ))}
        <p className="archive-chat-end">历史对话已结束 · 报告保留生成时的证据与结论</p>
      </div>
    </section>
  );
}

type UnifiedReportDimension = {
  code: string;
  title: string;
  en: string;
  score: number;
  status: string;
  tone: string;
  text: string;
  evidence: string[];
  method?: ConclusionMethod;
};

const accountActivityBars = [
  34, 48, 41, 62, 78, 56, 39, 72, 81, 46,
  68, 85, 57, 74, 64, 88, 44, 69, 52, 79,
  43, 71, 77, 49, 73, 61, 86, 65, 82, 59,
];

const accountProfileSignals = [
  {
    label: "发布节奏",
    value: "间隔偏密",
    strength: 68,
    detail: "近 30 篇平均每 1.6 天发布，合作节点前后更集中。",
  },
  {
    label: "带货占比",
    value: "24 / 30 · 80%",
    strength: 80,
    detail: "近 30 篇中有 24 篇包含商品链接或购买引导。",
  },
  {
    label: "主题集中度",
    value: "76%",
    strength: 76,
    detail: "内容主要围绕护肤、成分与产品体验，主题较集中。",
  },
  {
    label: "广告披露情况",
    value: "8 / 24",
    strength: 33,
    detail: "可识别的带货内容中，8 篇明确标注合作或广告关系。",
  },
];

function AccountProfileEvidence() {
  return (
    <section className="account-profile-evidence" aria-label="晚风护肤札记账号画像">
      <header>
        <span className="account-profile-avatar"><Sparkle size={18} /></span>
        <div>
          <strong>晚风护肤札记</strong>
          <small>账号 ID：beauty_profile</small>
        </div>
        <em>示例数据</em>
      </header>
      <div className="account-profile-signals">
        {accountProfileSignals.map((signal) => (
          <div className="account-profile-signal" key={signal.label}>
            <div>
              <strong>{signal.label}</strong>
              <span>{signal.value}</span>
            </div>
            <div className="account-profile-meter" aria-label={`${signal.label}：${signal.value}`}>
              <i style={{ width: `${signal.strength}%` }} />
            </div>
            <p>{signal.detail}</p>
          </div>
        ))}
      </div>
      <div className="account-profile-summary">
        <span>信号摘要</span>
        <strong>近期带货密度较高，营销特征较多；主题仍保持集中。</strong>
      </div>
      <footer>画像由信号组成，不是对账号的定性结论。</footer>
    </section>
  );
}

function AccountActivityEvidence() {
  return (
    <section className="account-activity-evidence" aria-label="眠云的护肤手账账号活跃度">
      <header>
        <span className="account-activity-mark"><Sparkle size={20} /></span>
        <div><strong>眠云的护肤手账</strong><small>账号活跃度</small></div>
        <em>内容垂直</em>
      </header>
      <div className="account-activity-body">
        <div className="account-posting-rhythm">
          <span>近 30 篇笔记发布节奏</span>
          <div className="account-activity-bars">
            {accountActivityBars.map((height, index) => (
              <i
                aria-label={`第 ${index + 1} 篇，${index > 21 ? "日常内容" : "带货内容"}`}
                className={index > 19 ? "organic" : "commerce"}
                key={`${height}-${index}`}
                style={{ height: `${height}%` }}
              />
            ))}
          </div>
          <small><i />日常内容 <i />带货内容</small>
        </div>
        <div className="account-commerce-share">
          <span>带货占比</span>
          <div><strong>67%</strong><small>近 30 篇</small></div>
        </div>
      </div>
      <small className="account-activity-example">示例数据</small>
    </section>
  );
}

function MaterialTraceEvidence({ hasMatches = true, technicalView }: { hasMatches?: boolean; technicalView: boolean }) {
  const timeline = [
    { label: "最早出现", title: "换季底妆观察记录", date: "2025-02-18" },
    { label: "第二次出现", title: "通勤妆效对比笔记", date: "2025-03-02" },
    { label: "本篇", title: "秋冬奶油肌底妆分享", date: "2025-03-16" },
  ];

  return (
    <section className={`material-trace-evidence ${hasMatches ? "" : "no-match"}`} aria-label="素材溯源">
      <header>
        <div>
          <span>素材溯源</span>
          <small>比对范围：TruLens 已核验内容库，不含其他平台。</small>
        </div>
        <div>
          {technicalView && <em>算法检测</em>}
          <b>示例数据</b>
        </div>
      </header>
      {hasMatches ? (
        <>
          <p>这张图片与内容库中 2 篇已核验笔记的配图高度相似</p>
          <div className="material-trace-timeline">
            {timeline.map((node, index) => (
              <article key={node.label}>
                <div className="material-trace-thumbnail" aria-label="灰色占位缩略图">
                  <Icon size={22}>
                    <rect height="13" rx="2" stroke="currentColor" strokeWidth="1.2" width="17" x="3.5" y="5.5" />
                    <path d="m5.5 16 4-4 2.8 2.5 2-2 3.2 3.5" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.2" />
                  </Icon>
                </div>
                <i />
                <span>{node.label}</span>
                {index === 0 && <em>最早出现</em>}
                <strong>{node.title}</strong>
                <time>{node.date}</time>
              </article>
            ))}
          </div>
        </>
      ) : (
        <div className="material-trace-empty">
          <span><Icon size={17}><path d="m7 12 3 3 7-7" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon></span>
          <div><strong>未在内容库中发现雷同素材</strong><small>当前图片与已核验内容库中的素材未形成高相似匹配。</small></div>
        </div>
      )}
    </section>
  );
}

function ReportEvidenceModal({
  code,
  dimension,
  onClose,
  showAccountActivity = false,
  technicalView,
}: {
  code: DimensionCode;
  dimension: UnifiedReportDimension;
  onClose: () => void;
  showAccountActivity?: boolean;
  technicalView: boolean;
}) {
  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [onClose]);

  const modalTitle = {
    T: "账号可信度证据链",
    R: "图像原生性证据链",
    U: "评论自然度证据链",
    S: "文案真实性证据链",
  }[code];

  return (
    <div
      aria-label={modalTitle}
      aria-modal="true"
      className={`report-evidence-backdrop evidence-${code.toLowerCase()}`}
      onMouseDown={(event) => {
        if (event.currentTarget === event.target) onClose();
      }}
      role="dialog"
    >
      <article className="report-evidence-modal">
        <header className="report-evidence-header">
          <div>
            <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
            <div>
              <small>EVIDENCE CHAIN · 可解释评分依据</small>
              <strong>{modalTitle}</strong>
            </div>
          </div>
          <div className="evidence-modal-score">
            <span>维度评分</span>
            <strong>{dimension.score}%</strong>
          </div>
          <button aria-label="关闭证据链" className="evidence-modal-close" onClick={onClose}>
            <Icon size={18}><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
          </button>
        </header>

        <div className="evidence-chain-summary">
          <span>结论</span>
          <p>{dimension.text}</p>
          <div>
            {dimension.evidence.map((item) => (
              <span className="evidence-summary-item" key={item}>
                <small>{item}</small>
                {technicalView && <MethodBadge method={dimension.method} />}
              </span>
            ))}
          </div>
        </div>

        {code === "T" && (
          <>
            <AccountProfileEvidence />
            <div className="account-evidence-layout">
              <div className="evidence-source-pair">
                <figure>
                  <img alt={`${showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}账号主页原始材料`} src="/evidence/account-profile.jpg" />
                  <figcaption>图 1 · 账号主页与公开资料</figcaption>
                </figure>
                <figure>
                  <img alt={`${showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}历史美妆护肤笔记原始材料`} src="/evidence/account-history.jpg" />
                  <figcaption>图 2 · 历史笔记内容抽样</figcaption>
                </figure>
              </div>
              <div className="evidence-document account-evidence-document">
                <div className="evidence-document-head">
                  <span className="evidence-profile-avatar">贴</span>
                  <div><strong>{showAccountActivity ? "眠云的护肤手账" : "贴贴银河"}</strong><small>{showAccountActivity ? "ID：mianyun_demo_208 · 虚拟档案" : "小红书号 601047506 · IP 广东"}</small></div>
                  <em>账号材料 2 份</em>
                </div>
                <div className="account-metrics">
                  <span><strong>128</strong>关注</span>
                  <span><strong>3.5 万</strong>粉丝</span>
                  <span><strong>24.6 万</strong>获赞与收藏</span>
                </div>
                <section>
                  <small>账号简介</small>
                  <p>“慢慢护肤，认真记录”｜日常护肤｜精华体验｜成分记录。<mark>主页已明确标注为虚构演示账号</mark>。</p>
                </section>
                <section>
                  <small>历史动态文本抽样</small>
                  <p><b>05-12</b> 换季护肤清单｜我的精简步骤 <em>♡ 326</em></p>
                  <p><b>05-10</b> <mark>连续 7 天精华记录（虚构示例）</mark> <em>♡ 184</em></p>
                  <p><b>05-08</b> 护肤日记：保湿感比想象中重要 <em>♡ 241</em></p>
                  <p><b>05-06</b> 成分党笔记｜新手怎么读精华 <em>♡ 118</em></p>
                </section>
                <footer><span>演示身份标注清楚</span><span>内容垂直稳定</span><span className="attention">连续体验需核对原始素材</span></footer>
              </div>
            </div>
            {showAccountActivity && <AccountActivityEvidence />}
          </>
        )}

        {code === "R" && (
          <>
            <div className="image-evidence-layout">
              <div className="report-forensic-image">
                <img alt="同一人物左右脸肤质对比原始材料" src="/evidence/skin-comparison.jpg" />
                <span className="forensic-anchor anchor-one">①</span>
                <span className="forensic-anchor anchor-two">②</span>
                <small>图 3 · 左右脸肤质对比原图</small>
              </div>
              <div className="forensic-findings">
                <span>锚点检测</span>
                <div><b>①</b><p><strong>左侧原始肤质区域</strong><small>毛孔、色素点与细小起伏分布自然，保留随机高频纹理，可作为真实皮肤基准。</small></p><em>基准</em></div>
                <div><b>②</b><p><strong>右侧眼下与面中区域</strong><small>微纹理和毛孔明显减少，表面平滑度显著高于左侧，符合局部磨皮或生成式细化特征。</small></p><em>72%</em></div>
                <p>两侧五官结构、镜头角度和主光方向基本一致，未见拼接错位或整图生成；当前风险集中在右侧肤质呈现被优化。</p>
              </div>
            </div>
            <MaterialTraceEvidence hasMatches={dimension.score < 90} technicalView={technicalView} />
          </>
        )}

        {code === "U" && (
          <>
            <div className="comment-evidence-layout">
              <div className="comment-source-stack">
                <figure><img alt="评论区原始材料上半部分" src="/evidence/comments-1.jpg" /><figcaption>图 4 · 评论原文</figcaption></figure>
                <figure><img alt="评论区原始材料下半部分" src="/evidence/comments-2.jpg" /><figcaption>图 5 · 评论原文</figcaption></figure>
              </div>
              <div className="evidence-document comment-evidence-document">
                <div className="comment-analysis-head"><span>评论区原文抽样</span><small>可见样本 12 条 · 具体问题与追问为主</small></div>
                <div className="report-comment detailed"><i>晚</i><p><strong>晚风饮茶</strong>用了几天，保湿感还不错，先继续观察</p><time>江苏</time></div>
                <div className="report-comment"><i>鱼</i><p><strong>小鱼汽水</strong>这个精华的质地看起来好清爽呀</p><time>广东</time></div>
                <div className="report-comment detailed"><i>梨</i><p><strong>阿梨今天早睡</strong>七天变化会不会和作息也有关系？</p><time>浙江</time></div>
                <div className="report-comment"><i>桃</i><p><strong>桃桃汽泡</strong>蹲一个后续，敏感肌能用吗？</p><time>上海</time></div>
                <div className="report-comment detailed"><i>橘</i><p><strong>橘子海</strong>姐妹们先看成分表，别只看前后对比图</p><time>四川</time></div>
                <div className="report-comment"><i>薄</i><p><strong>薄荷糖不加冰</strong>请问这是合作分享吗？</p><time>北京</time></div>
                <div className="report-comment detailed"><i>眠</i><p><strong>眠云的护肤手账</strong>我自己是敏感肌，用下来没什么刺激感，建议先在耳后试一下哦</p><time>作者回复</time></div>
                <div className="report-comment"><i>云</i><p><strong>云朵收藏夹</strong>期待更多真实使用记录～</p><time>湖北</time></div>
                <footer><span className="comment-swatch" />浅紫色标记具体问题与作者回复 <b>互动自然 · 未见集中模板话术</b></footer>
              </div>
            </div>
            <p className="comment-simulation-note">以上评论均为模拟文本，刻意包含不同观点与表达模式，方便测试对重复话术、夸大效果、购买引导及合作披露缺失等线索的识别能力。</p>
          </>
        )}

        {code === "S" && (
          <div className="evidence-document copy-evidence-document">
            <div className="evidence-document-head copy-source-head">
              <div><small>帖子原文</small><strong>秋冬奶油肌底妆分享</strong></div>
              <em>语义主张检测</em>
            </div>
            <div className="copy-evidence-legend" aria-label="文本标注说明">
              <span className="template">模版化术语</span>
              <span className="absolute">绝对化用语</span>
              <span className="unsupported">功效缺少依据</span>
            </div>
            <p>
              最近换季皮肤有点干，试了这套底妆。妆前薄涂，粉底少量叠加，在我脸上<mark className="unsupported">大约能维持 8 小时</mark>。<mark className="template">像开了原生柔焦一样</mark>，<mark className="absolute">毛孔直接隐形</mark>，但鼻翼到下午还是会有一点卡粉。色号是按我自己的肤色选的，<mark className="absolute">所有肤质都能放心入</mark>。本篇含品牌合作，具体效果会因肤质和上妆方式不同。
            </p>
            <div className="copy-annotations">
              <span><b>01</b><p><strong>模板化话术</strong><small>“像开了原生柔焦一样”属于常见的效果包装表达。</small></p></span>
              <span><b>02</b><p><strong>绝对化用语</strong><small>“毛孔直接隐形”“所有肤质都能放心入”把个人体验扩大为确定结论。</small></p></span>
              <span><b>03</b><p><strong>功效缺少依据</strong><small>“大约能维持 8 小时”未提供测试条件或可核对记录。</small></p></span>
            </div>
            <footer><span>已披露品牌合作</span><span>保留个体体验边界</span><span className="attention">2 处表述需留意</span></footer>
          </div>
        )}

        {(code === "T" || code === "R" || code === "S") && (
          <small className="evidence-ai-case-note">虚构案例 · AI 生成</small>
        )}

        <footer className="evidence-modal-footer">
          <p><span /> 原始信号 <i /> 模型检测 <em /> 评分结论</p>
          <button onClick={onClose}>返回报告</button>
        </footer>
      </article>
    </div>
  );
}

const evidenceDimensionOptions: Record<DimensionCode, { label: string; hint: string }> = {
  T: { label: "账号可信度", hint: "账号主页链接、简介或历史发布记录" },
  R: { label: "图像原生性", hint: "原始图片、对比图或局部细节截图" },
  U: { label: "评论自然度", hint: "评论区截图、评论文本或发布时间信息" },
  S: { label: "文案真实性", hint: "笔记正文、标题或功效描述" },
};

function EvidenceExpansionPrompt({
  availableCodes,
  onAddEvidence,
}: {
  availableCodes: DimensionCode[];
  onAddEvidence: (code: DimensionCode) => void;
}) {
  const missingCodes = allDimensions.filter((code) => !availableCodes.includes(code));
  const [mode, setMode] = useState<"idle" | "adding" | "dismissed">("idle");
  const [selectedCode, setSelectedCode] = useState<DimensionCode>(missingCodes[0] ?? "T");
  const [evidenceText, setEvidenceText] = useState("");
  const [filename, setFilename] = useState("");
  const [addedCode, setAddedCode] = useState<DimensionCode | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!missingCodes.includes(selectedCode) && missingCodes[0]) setSelectedCode(missingCodes[0]);
  }, [missingCodes, selectedCode]);

  if (!missingCodes.length || mode === "dismissed") return null;

  const submitEvidence = () => {
    if (!evidenceText.trim() && !filename) return;
    onAddEvidence(selectedCode);
    setAddedCode(selectedCode);
    setEvidenceText("");
    setFilename("");
    setMode("idle");
  };

  return (
    <section className="evidence-expansion-prompt" aria-live="polite">
      <div className="evidence-expansion-heading">
        <span>
          <Icon size={18}>
            <path d="M12 4v16M4 12h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" />
          </Icon>
        </span>
        <div>
          <small>MORE EVIDENCE · 可选</small>
          <h3>{addedCode ? `${evidenceDimensionOptions[addedCode].label}证据已加入` : "要加入更多维度的证据吗？"}</h3>
          <p>
            {addedCode
              ? `报告已纳入新的证据维度。你还可以继续补充其余 ${missingCodes.length} 个维度。`
              : `当前报告基于 ${availableCodes.length} 个维度生成。补充证据可以让交叉核验更充分，也可以保留当前结果。`}
          </p>
        </div>
      </div>

      {mode === "idle" ? (
        <div className="evidence-expansion-actions">
          <button onClick={() => { setAddedCode(null); setMode("adding"); }}>补充更多证据</button>
          <button onClick={() => setMode("dismissed")}>先看当前报告</button>
        </div>
      ) : (
        <div className="evidence-expansion-form">
          <div aria-label="选择要补充的证据维度" className="missing-dimension-options" role="group">
            {missingCodes.map((code) => (
              <button
                aria-pressed={selectedCode === code}
                className={selectedCode === code ? "active" : ""}
                key={code}
                onClick={() => setSelectedCode(code)}
              >
                <span>{code}</span>
                <div><strong>{evidenceDimensionOptions[code].label}</strong><small>{evidenceDimensionOptions[code].hint}</small></div>
              </button>
            ))}
          </div>
          <label className="evidence-expansion-input">
            <span>粘贴链接或补充说明</span>
            <textarea
              onChange={(event) => setEvidenceText(event.target.value)}
              placeholder={evidenceDimensionOptions[selectedCode].hint}
              rows={3}
              value={evidenceText}
            />
          </label>
          <div className="evidence-expansion-submit">
            <input
              accept="image/*"
              onChange={(event) => setFilename(event.target.files?.[0]?.name ?? "")}
              ref={fileRef}
              type="file"
            />
            <button className="evidence-upload-button" onClick={() => fileRef.current?.click()}>
              <Icon size={15}><path d="M12 16V5m0 0L8 9m4-4 4 4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.4" /></Icon>
              {filename || "上传截图"}
            </button>
            <div>
              <button onClick={() => setMode("idle")}>暂不补充</button>
              <button
                className="evidence-submit-button"
                disabled={!evidenceText.trim() && !filename}
                onClick={submitEvidence}
              >
                加入证据并重新核验
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

type CrossCheckState = "conflict" | "consistent" | "corroborated" | "doubtful" | "unverified";

export type CrossCheckItem = {
  id: string;
  from: DimensionCode;
  to: DimensionCode;
  left: string;
  right: string;
  conclusion: string;
  state: CrossCheckState;
  dimension: string;
  detail: string;
  confidence?: "高" | "中" | "低";
  method?: ConclusionMethod;
  kind?: "material-trace";
  label?: string;
};

const crossCheckPairResults: CrossCheckItem[] = [
  { id: "purchase", from: "T", to: "R", left: "账号：历史图片风格稳定", right: "图片：主体与既往内容一致", conclusion: "已比对，未发现矛盾", state: "consistent", confidence: "中", dimension: "账号 × 图片", detail: "当前图片主体、拍摄环境与账号既往发布风格一致，暂未发现来源冲突。" },
  { id: "account-comments", from: "T", to: "U", left: "账号：互动增长连续", right: "评论：用户表达分散自然", conclusion: "账号互动与评论分布相互佐证", state: "corroborated", confidence: "中", dimension: "账号 × 评论", detail: "账号互动增长没有突变，评论发布时间与表达方式也较为分散，两类信号相互支持。" },
  { id: "identity-copy", from: "T", to: "S", left: "账号：长期发布美妆内容", right: "文案：当前为底妆体验分享", conclusion: "主题匹配，账号与文案一致", state: "consistent", confidence: "高", dimension: "账号 × 文案", detail: "历史内容长期围绕美妆与护肤展开，本篇底妆分享没有偏离账号稳定主题。" },
  { id: "image-comments", from: "R", to: "U", left: "图片：展示局部肤质细节", right: "评论：围绕肤质和妆效讨论", conclusion: "已比对，未发现矛盾", state: "consistent", confidence: "中", dimension: "图片 × 评论", detail: "评论讨论集中在图片可见的肤质和妆效细节，暂未发现评论描述与画面明显冲突。" },
  { id: "copy-image", from: "S", to: "R", left: "文案：“同一光源未修图”", right: "图片：左右图色彩被统一调整", conclusion: "文案与图片存在待说明差异", state: "doubtful", confidence: "中", dimension: "文案 × 图片", detail: "文案声称同一光源且未修图，但图像检测到左右图色彩被统一调整，建议补充修图与拍摄条件说明。" },
  { id: "claim-feedback", from: "S", to: "U", left: "文案：保留个人体验边界", right: "评论：保湿与成分反馈具体", conclusion: "用户反馈支持文案的温和体验", state: "corroborated", confidence: "中", dimension: "文案 × 评论", detail: "评论集中在肤质、保湿感和成分等具体体验，没有集中复述夸大功效话术。" },
];

const crossCheckStateLabels: Record<CrossCheckState, string> = {
  conflict: "矛盾",
  consistent: "一致",
  corroborated: "佐证",
  doubtful: "存疑",
  unverified: "未核验",
};

const crossCheckDimensionNames: Record<DimensionCode, { material: string; short: string }> = {
  T: { material: "账号", short: "账号" },
  R: { material: "图片", short: "图片" },
  U: { material: "评论", short: "评论" },
  S: { material: "文案", short: "文案" },
};

const intraDimensionChecks: Record<DimensionCode, Omit<CrossCheckItem, "from" | "to">> = {
  T: { id: "intra-t", left: "账号历史：内容主题连续", right: "账号当前：发布节奏稳定", conclusion: "账号内部信息前后一致", state: "consistent", confidence: "中", dimension: "账号维度内", detail: "账号历史主题、身份信息与当前发布节奏之间暂未发现明显矛盾。" },
  R: { id: "intra-r", left: "图片文字：妆效对比", right: "图片画面：展示对应区域", conclusion: "图片文字与画面一致", state: "consistent", confidence: "中", dimension: "图片维度内", detail: "图片中的文字标注能够对应画面区域，当前未发现文字描述与可见内容相互矛盾。" },
  U: { id: "intra-u", left: "评论观点：存在不同体验", right: "评论互动：追问与回复连续", conclusion: "评论内部语境自洽", state: "consistent", confidence: "中", dimension: "评论维度内", detail: "评论观点存在自然差异，追问与回复关系连续，暂未发现明显的内部语义冲突。" },
  S: { id: "intra-s", left: "文案前段：个人使用感受", right: "文案后段：效果因人而异", conclusion: "文案前后表述未发现矛盾", state: "consistent", confidence: "中", dimension: "文案维度内", detail: "文案中的体验描述与边界声明能够相互对应，暂未发现前后自相矛盾。" },
};

function getCrossCheckItems(activeDimensions: DimensionCode[], creatorMode = false) {
  const enabled = new Set(activeDimensions);
  const pairItems = crossCheckPairResults.map((item) => {
    if (enabled.has(item.from) && enabled.has(item.to)) {
      if (creatorMode && item.id === "copy-image") {
        return {
          ...item,
          left: "文案：声称“真实对比”",
          right: "图片：图 1 检测到局部磨皮",
          conclusion: "图片有轻度修饰，建议主动注明",
          detail: "文案声称“真实对比”，图 1 检测到局部磨皮。建议友好说明滤镜或修饰情况，帮助读者准确理解。",
        };
      }
      return item;
    }
    const missing = [item.from, item.to].filter((code) => !enabled.has(code));
    const missingText = missing.map((code) => crossCheckDimensionNames[code].material).join("、");
    const leftName = crossCheckDimensionNames[item.from].short;
    const rightName = crossCheckDimensionNames[item.to].short;
    return {
      ...item,
      left: `${leftName} × ${rightName}`,
      right: `缺少${missingText}材料`,
      conclusion: `未提供${missingText}，无法比对${leftName}与${rightName}`,
      state: "unverified" as const,
      confidence: undefined,
      detail: `本次未启用${missingText}维度，因此无法完成${leftName}与${rightName}之间的交叉验证。`,
    };
  });
  const baseItems = activeDimensions.length !== 1
    ? pairItems
    : [{ ...intraDimensionChecks[activeDimensions[0]], from: activeDimensions[0], to: activeDimensions[0] }, ...pairItems];
  if (!enabled.has("R")) return baseItems;
  return [
    ...baseItems,
    {
      id: "material-trace",
      from: "R" as const,
      to: "R" as const,
      left: "本篇图片",
      right: "TruLens 已核验内容库",
      conclusion: "发现 2 篇配图高度相似的已核验笔记",
      state: "doubtful" as const,
      confidence: "高" as const,
      dimension: "图片 × 内容库",
      detail: "本篇图片与内容库中 2 篇已核验笔记的配图高度相似，建议结合最早出现时间与发布语境进一步复核素材来源。",
      kind: "material-trace" as const,
      label: "内容库比对",
      method: "rule" as const,
    },
  ];
}

function CrossCheckEvidenceModal({ item, onClose, technicalView }: { item: CrossCheckItem; onClose: () => void; technicalView: boolean }) {
  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [onClose]);

  return createPortal(
    <div
      aria-label="交叉验证证据链"
      aria-modal="true"
      className="report-evidence-backdrop"
      onMouseDown={(event) => event.currentTarget === event.target && onClose()}
      role="dialog"
    >
      <article className="report-evidence-modal cross-evidence-modal">
        <header className="report-evidence-header">
          <div>
            <span className={`cross-state-dot state-${item.state}`} />
            <div><small>CROSS-CHECK EVIDENCE · 双信号对照</small><strong>{item.conclusion}</strong></div>
          </div>
          <span className={`cross-state-pill state-${item.state}`}>{crossCheckStateLabels[item.state]}</span>
          <button aria-label="关闭证据链" className="evidence-modal-close" onClick={onClose}>
            <Icon size={18}><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
          </button>
        </header>
        <div className="cross-evidence-summary">
          <span>交叉结论</span>
          <p>{item.detail}</p>
          <small>关联维度 · {item.dimension} {technicalView && <MethodBadge method={item.method} />}</small>
        </div>
        {item.kind === "material-trace" ? (
          <MaterialTraceEvidence technicalView={technicalView} />
        ) : (
        <div className="cross-evidence-columns">
          <section>
            <header><span className={`report-dimension-badge badge-${item.from.toLowerCase()}`}>{item.from}</span><div><small>信号 A</small><strong>{item.left}</strong></div></header>
            <div className="cross-evidence-capture"><span>{item.from === item.to ? "维度内信号 A" : "原始材料摘录"}</span><p>{item.left}</p><mark>{item.state === "unverified" ? "材料未提供" : "检测到可核验事实"}</mark></div>
          </section>
          <section>
            <header><span className={`report-dimension-badge badge-${item.to.toLowerCase()}`}>{item.to}</span><div><small>信号 B</small><strong>{item.right}</strong></div></header>
            <div className="cross-evidence-capture"><span>{item.from === item.to ? "维度内信号 B" : "关联材料摘录"}</span><p>{item.right}</p><mark>{item.state === "unverified" ? "等待补充材料" : "与信号 A 进行语义对照"}</mark></div>
          </section>
        </div>
        )}
        <footer className="evidence-modal-footer">
          <p><span /> 原始信号 <i /> 交叉关系 <em /> 综合结论</p>
          <button onClick={onClose}>返回交叉验证</button>
        </footer>
      </article>
    </div>,
    document.body,
  );
}

function CrossCheckSection({
  activeDimensions,
  creatorMode = false,
  items,
  live = false,
  technicalView,
}: {
  activeDimensions: DimensionCode[];
  creatorMode?: boolean;
  items?: CrossCheckItem[];
  live?: boolean;
  technicalView: boolean;
}) {
  const [activeItem, setActiveItem] = useState<CrossCheckItem | null>(null);
  const [filteredId, setFilteredId] = useState<string | null>(null);
  const crossCheckItems = items ?? getCrossCheckItems(activeDimensions, creatorMode);
  const enabled = new Set(activeDimensions);
  const graphItems = crossCheckItems.filter((item) => item.from !== item.to && item.state !== "unverified");
  const shownItems = filteredId ? crossCheckItems.filter((item) => item.id === filteredId) : crossCheckItems;
  const stateCounts = crossCheckItems.reduce<Record<CrossCheckState, number>>((counts, item) => {
    counts[item.state] += 1;
    return counts;
  }, { conflict: 0, consistent: 0, corroborated: 0, doubtful: 0, unverified: 0 });
  const headline = activeDimensions.length === 1
    ? stateCounts.doubtful
      ? `${crossCheckDimensionNames[activeDimensions[0]].short}维度内存在待复核风险信号。`
      : stateCounts.conflict
        ? `${crossCheckDimensionNames[activeDimensions[0]].short}维度内存在冲突信号。`
        : `${crossCheckDimensionNames[activeDimensions[0]].short}维度内表述自洽。`
    : stateCounts.conflict
      ? "发现跨维度矛盾，建议优先复核。"
      : stateCounts.doubtful
        ? creatorMode
          ? "文案与图片存在可补充说明之处。"
          : "部分维度存在待说明差异，暂未发现明确矛盾。"
        : "已启用维度相互印证，暂未发现矛盾。";
  const nodePositions: Record<DimensionCode, [number, number]> = {
    T: [210, 34],
    R: [364, 120],
    U: [210, 206],
    S: [56, 120],
  };

  useEffect(() => {
    const openReferencedEvidence = (event: Event) => {
      const id = (event as CustomEvent<string>).detail;
      const item = crossCheckItems.find((entry) => entry.id === id);
      if (!item) return;
      setFilteredId(id);
      setActiveItem(item);
    };
    window.addEventListener("trulens:open-cross-evidence", openReferencedEvidence);
    return () => window.removeEventListener("trulens:open-cross-evidence", openReferencedEvidence);
  }, [crossCheckItems]);

  return (
    <section className={`cross-check-section ${creatorMode ? "creator-cross-check" : ""}`} id={creatorMode ? "creator-cross-check-section" : "cross-check-section"}>
      <header>
        <div>
          <span>Semantic Consistency</span>
          <h3>{creatorMode ? "交叉验证" : "② 交叉验证"}</h3>
          <h4>{headline}</h4>
          <p>{activeDimensions.length === 1 ? "需至少提供两类材料，才能进行跨维度交叉验证。当前先完成维度内自洽检查。" : live ? "基于本次报告的可信分、风险等级与证据数量比较维度间方向；未评估的维度会明确保留为未核验。" : "用不同维度的独立信号互相校验，未启用的组合会保留并说明原因。"}</p>
        </div>
        <div className="cross-check-summary">
          {(["conflict", "corroborated", "doubtful", "consistent", "unverified"] as CrossCheckState[]).map((state, index) => (
            <Fragment key={state}>{index > 0 && <span>·</span>}<b><strong>{stateCounts[state]}</strong> {crossCheckStateLabels[state]}</b></Fragment>
          ))}
        </div>
      </header>
      <div className="cross-check-layout">
        <div className="cross-check-graph">
          <svg aria-label="T R U S 四维交叉关系图" viewBox="0 0 420 240">
            {graphItems.map((item, index) => {
              const [x1, y1] = nodePositions[item.from];
              const [x2, y2] = nodePositions[item.to];
              return (
                <g
                  aria-label={`${item.left}与${item.right}：${crossCheckStateLabels[item.state]}`}
                  className={`cross-edge state-${item.state} ${filteredId === item.id ? "active" : ""}`}
                  key={item.id}
                  onClick={() => setFilteredId((current) => current === item.id ? null : item.id)}
                  role="button"
                  style={{ animationDelay: `${index * 120}ms` }}
                  tabIndex={0}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") setFilteredId((current) => current === item.id ? null : item.id);
                  }}
                >
                  <line x1={x1} x2={x2} y1={y1} y2={y2} />
                  <circle cx={(x1 + x2) / 2} cy={(y1 + y2) / 2} r="9" />
                  <text textAnchor="middle" x={(x1 + x2) / 2} y={(y1 + y2) / 2 + 3}>{index + 1}</text>
                </g>
              );
            })}
            {(Object.entries(nodePositions) as [DimensionCode, [number, number]][]).map(([code, [x, y]]) => (
              <g className={`cross-node node-${code.toLowerCase()} ${enabled.has(code) ? "" : "inactive"}`} key={code}>
                <circle cx={x} cy={y} r="23" />
                <text textAnchor="middle" x={x} y={y + 4}>{code}</text>
                {!enabled.has(code) && <text className="cross-node-disabled-label" textAnchor="middle" x={x} y={y + (code === "U" ? 32 : 36)}>未启用</text>}
              </g>
            ))}
          </svg>
          <small>点击连线筛选对应关系，再次点击恢复全部</small>
        </div>
        <div className="cross-check-list">
          {shownItems.map((item) => (
            <button className={`cross-check-row state-${item.state}`} key={item.id} onClick={() => setActiveItem(item)}>
              <span className="cross-pair"><b>{item.from}</b><i>↔</i><b>{item.to}</b></span>
              <span>
                <small>{item.left} × {item.right}</small>
                <strong>{item.conclusion}</strong>
                {item.label && <b className="cross-check-source-label">{item.label}</b>}
                {technicalView && <MethodBadge method={item.method} />}
              </span>
              <em>{crossCheckStateLabels[item.state]}{item.confidence ? ` · ${item.confidence}` : ""}</em>
              <i className="cross-arrow">→</i>
            </button>
          ))}
        </div>
      </div>
      <small className="cross-check-note">{live ? "实时报告 · 关系状态由本次维度分数和证据数量计算。" : "示例数据 · 交叉关系由 TruLens 基于当前可用信号生成。"}</small>
      {activeItem && <CrossCheckEvidenceModal item={activeItem} onClose={() => setActiveItem(null)} technicalView={technicalView} />}
    </section>
  );
}

type DecisionTier = "pass" | "verify" | "review";
type DecisionPerspective = "consumer" | "creator" | "platform" | "brand";

type DecisionAdvice = {
  text: string;
  basis?: string;
  importance?: "重点";
  evidenceId?: string;
  action?: "appeal";
};

const decisionPerspectives: { id: DecisionPerspective; label: string }[] = [
  { id: "consumer", label: "消费者" },
  { id: "creator", label: "创作者" },
  { id: "platform", label: "平台运营" },
  { id: "brand", label: "品牌方" },
];

const passDecisionAdvice: Record<DecisionPerspective, DecisionAdvice[]> = {
  consumer: [
    { text: "可以参考这篇的成分和使用感受。", basis: "账号、文案、评论三项稳定。", evidenceId: "identity-copy" },
    { text: "对比图的“前后效果”请打折看待。", basis: "右侧检测到局部磨皮信号。", importance: "重点", evidenceId: "copy-image" },
    { text: "下单前再核对：使用周期、肤质是否与你相近。", basis: "未提供订单凭证，购买真实性未核验。", evidenceId: "purchase" },
  ],
  creator: [
    { text: "对比图建议注明“已磨皮/滤镜”，避免被误判为 AI 修饰。", basis: "右侧检测到局部磨皮信号。", importance: "重点", evidenceId: "copy-image" },
    { text: "补充未修图原图或使用周期时间线，可显著提升可信度。", basis: "评论自然度是当前最低分项。", evidenceId: "claim-feedback" },
    { text: "如对结果有异议，可提交材料申诉。", action: "appeal" },
  ],
  platform: [
    { text: "不建议限流；可加“含 AI 辅助修饰”提示标注。", basis: "轻度修饰，不属于违规。", importance: "重点", evidenceId: "copy-image" },
    { text: "暂无需人工复核，保持观察。", basis: "无矛盾项，无刷评聚集。", evidenceId: "identity-copy" },
  ],
  brand: [
    { text: "可作为 KOC 合作的候选参考。", basis: "内容稳定，无夸大宣称。", evidenceId: "claim-feedback" },
    { text: "合作前建议索取原始素材，核对对比图。", basis: "对比图存在修饰信号。", importance: "重点", evidenceId: "copy-image" },
  ],
};

const decisionAdviceByTier: Record<DecisionTier, Record<DecisionPerspective, DecisionAdvice[]>> = {
  pass: passDecisionAdvice,
  verify: {
    ...passDecisionAdvice,
    consumer: [
      { text: "暂缓直接采用帖子中的效果结论。", basis: "当前信号存在待补充核验项。", importance: "重点", evidenceId: "purchase" },
      { text: "补充查看自然光原图与长期使用反馈。", basis: "单次对比不足以验证持续效果。", evidenceId: "copy-image" },
      { text: "核对合作披露与独立用户评价后再决策。", basis: "需要更多独立信号相互印证。", evidenceId: "copy-comments" },
    ],
  },
  review: {
    ...passDecisionAdvice,
    consumer: [
      { text: "暂停将这篇内容作为购买依据。", basis: "综合风险已进入人工复核区间。", importance: "重点", evidenceId: "copy-image" },
      { text: "等待平台复核或独立来源给出补充证据。", basis: "当前材料不足以排除关键风险。", evidenceId: "purchase" },
    ],
  },
};

const limitedMaterialAdvice: Record<DecisionPerspective, DecisionAdvice> = {
  consumer: { text: "材料有限，建议再提供评论区或作者主页，再下结论。", importance: "重点" },
  creator: { text: "补充评论或账号信息，可以让核验更完整。", importance: "重点" },
  platform: { text: "置信度较低，建议补充材料后再复核，暂不处置。", importance: "重点" },
  brand: { text: "信息不足，建议先索取完整材料，再评估是否需要跟进。", importance: "重点" },
};

const dimensionDecisionAdvice: Record<DimensionCode, {
  basis: string;
  evidenceId: string;
  advice: Record<DecisionPerspective, string>;
}> = {
  T: {
    basis: "账号可信度。",
    evidenceId: "intra-t",
    advice: {
      consumer: "当前账号轨迹可作为有限参考，但仍建议结合具体内容判断。",
      creator: "保持账号身份、合作关系与历史内容说明一致。",
      platform: "可记录账号当前信号，暂不基于单一账号维度处置。",
      brand: "合作前可先核对账号历史发布与合作披露记录。",
    },
  },
  R: {
    basis: "图像原生性。",
    evidenceId: "intra-r",
    advice: {
      consumer: "对图片中的前后效果保持谨慎，优先参考未经修饰的原图。",
      creator: "建议注明滤镜或修饰情况，并保留可核对的原始图片。",
      platform: "可先加图片修饰提示，不依据单一图像信号直接处置。",
      brand: "建议索取原始素材，确认画面修饰是否影响效果表达。",
    },
  },
  U: {
    basis: "评论自然度。",
    evidenceId: "intra-u",
    advice: {
      consumer: "评论只能作为辅助参考，优先关注具体体验与自然追问。",
      creator: "保持评论互动自然，避免集中重复相似回复。",
      platform: "可继续观察评论增长与相似话术，暂不扩大处置。",
      brand: "评估合作反馈时，建议区分具体体验与同质化短评。",
    },
  },
  S: {
    basis: "文案真实性。",
    evidenceId: "intra-s",
    advice: {
      consumer: "文案中有绝对化的功效表述，请谨慎对待。",
      creator: "文案中的绝对化表述建议修改。",
      platform: "可先加“待核实”提示标注。",
      brand: "文案涉及功效宣称，建议留意。",
    },
  },
};

const decisionTiers: { id: DecisionTier; number: string; label: string; range: string }[] = [
  { id: "pass", number: "①", label: "放行 · 轻提示", range: "80–100" },
  { id: "verify", number: "②", label: "提示 · 补充核验", range: "60–79" },
  { id: "review", number: "③", label: "人工复核 · 处置", range: "0–59" },
];

function DecisionSupport({
  activeDimensions,
  confidenceLevel,
  continueLabel,
  creatorMode = false,
  liveAdvice,
  onContinue,
  recommendations,
  score,
  sourceLabel = "示例数据",
  subtitle,
}: {
  activeDimensions: DimensionCode[];
  confidenceLevel: ReportConfidenceLevel;
  continueLabel: string;
  creatorMode?: boolean;
  liveAdvice?: Array<{
    perspective: DecisionPerspective;
    priority: "重点" | "建议";
    title: string;
    basis: string;
    action?: string | null;
  }>;
  onContinue: () => void;
  recommendations?: string[];
  score: number;
  sourceLabel?: string;
  subtitle: string;
}) {
  const initialTier: DecisionTier = score >= 80 ? "pass" : score >= 60 ? "verify" : "review";
  const [tier, setTier] = useState<DecisionTier>(initialTier);
  const [perspective, setPerspective] = useState<DecisionPerspective>("consumer");
  const hasLimitedMaterial = activeDimensions.length < 4 || confidenceLevel === "low";
  const supplementAdvice = creatorMode && perspective === "creator" ? [] : [limitedMaterialAdvice[perspective]];
  const fallbackAdvice = hasLimitedMaterial
    ? [
        ...supplementAdvice,
        ...activeDimensions.map((code) => {
          const config = dimensionDecisionAdvice[code];
          const pairEvidenceId = crossCheckPairResults.find((item) =>
            (item.from === code || item.to === code)
            && activeDimensions.includes(item.from)
            && activeDimensions.includes(item.to),
          )?.id;
          return {
            text: config.advice[perspective],
            basis: config.basis,
            evidenceId: activeDimensions.length === 1 ? config.evidenceId : pairEvidenceId,
          };
        }),
      ]
    : decisionAdviceByTier[tier][perspective];
  const liveRecommendations: DecisionAdvice[] | null = perspective === "consumer" && recommendations?.length
    ? recommendations.slice(0, 5).map((text, index) => ({
        text,
        basis: "来自本次分析报告的后端建议。",
        importance: index === 0 ? "重点" : undefined,
      }))
    : null;
  const backendAdvice = liveAdvice
    ?.filter((item) => item.perspective === perspective)
    .map((item) => ({
      text: item.title,
      basis: item.basis,
      importance: item.priority === "重点" ? "重点" as const : undefined,
      action: item.action === "appeal" ? "appeal" as const : undefined,
    }));
  const advice = backendAdvice?.length ? backendAdvice : liveRecommendations ?? fallbackAdvice;

  const openEvidence = (id: string) => {
    document.getElementById(creatorMode ? "creator-cross-check-section" : "cross-check-section")?.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => {
      window.dispatchEvent(new CustomEvent("trulens:open-cross-evidence", { detail: id }));
    }, 320);
  };

  return (
    <section className={`decision-support ${hasLimitedMaterial ? "limited-material" : ""}`} id={creatorMode ? "creator-decision-section" : "decision-section"}>
      <header>
        <div><span>Decision &amp; Advice</span><h3>③ 决策与建议</h3><p>{subtitle}</p></div>
        <small>{sourceLabel}</small>
      </header>
      <div className="decision-support-layout">
        <aside className="decision-tier-panel">
          <span>分级策略</span>
          <div>
            {decisionTiers.map((item, index) => (
              <button
                aria-pressed={tier === item.id}
                className={`decision-tier tier-${item.id} ${tier === item.id ? "active" : ""} ${hasLimitedMaterial && tier === item.id ? "provisional" : ""}`}
                key={item.id}
                onClick={() => setTier(item.id)}
              >
                <i /><b>{item.number}</b><strong>{hasLimitedMaterial && tier === item.id ? `倾向第 ${index + 1} 档 · 待补充材料` : item.label}</strong><small>{item.range}</small>
              </button>
            ))}
          </div>
        </aside>
        <div className="decision-recommendations">
          <div aria-label="建议视角" className="decision-perspectives" role="tablist">
            {decisionPerspectives.map((item) => (
              <button
                aria-selected={perspective === item.id}
                className={perspective === item.id ? "active" : ""}
                key={item.id}
                onClick={() => setPerspective(item.id)}
                role="tab"
              >
                {item.label}
              </button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            <motion.div
              animate={{ opacity: 1, y: 0 }}
              className="decision-advice-list"
              exit={{ opacity: 0, y: -4 }}
              initial={{ opacity: 0, y: 4 }}
              key={`${tier}-${perspective}`}
              transition={{ duration: 0.2 }}
            >
              {advice.map((item, index) => (
                <div className="decision-advice-row" key={item.text}>
                  <span className={item.importance ? "important" : ""}>{item.importance ?? "建议"}</span>
                  <b>{String(index + 1).padStart(2, "0")}</b>
                  <div><strong>{item.text}</strong>{item.basis && <small>依据：{item.basis}</small>}</div>
                  {item.action === "appeal"
                    ? <button onClick={() => window.alert("申诉入口将在接入材料提交服务后开放。")}>提交申诉</button>
                    : item.evidenceId && <button onClick={() => openEvidence(item.evidenceId!)}>查看依据 →</button>}
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
      <footer>
        <small>辅助决策，不构成购买建议或定性结论。</small>
        <button onClick={onContinue}>{continueLabel} <Arrow size={17} /></button>
      </footer>
    </section>
  );
}

type ReportConfidenceLevel = "high" | "medium" | "low";

const reportConfidenceProfiles: Record<ReportConfidenceLevel, { label: string; evidenceCount: number; crossCheckCount: number; bars: number }> = {
  high: { label: "高", evidenceCount: 14, crossCheckCount: 5, bars: 3 },
  medium: { label: "中", evidenceCount: 8, crossCheckCount: 2, bars: 2 },
  low: { label: "低", evidenceCount: 3, crossCheckCount: 0, bars: 1 },
};

function UnifiedReportTemplate({
  decision,
  dimensions: availableDimensions,
  onAddEvidence,
  onContinue,
  continueLabel,
  score,
  status,
  subtitle,
  technicalView,
  title,
  tone,
}: {
  decision: string;
  dimensions: UnifiedReportDimension[];
  onAddEvidence?: (code: DimensionCode) => void;
  onContinue: () => void;
  continueLabel: string;
  score: number;
  status: string;
  subtitle: string;
  technicalView: boolean;
  title: string;
  tone: string;
}) {
  const [openEvidence, setOpenEvidence] = useState<DimensionCode | null>(null);
  const [confidenceOpen, setConfidenceOpen] = useState(false);
  const [activeReportSection, setActiveReportSection] = useState("forensics-section");
  const orderedCodes = ["T", "R", "U", "S"];
  const isCurrentFullReport = title === "当前美妆种草内容" && availableDimensions.length === 4;
  const confidenceLevel: ReportConfidenceLevel = availableDimensions.length === 4 ? "high" : availableDimensions.length >= 2 ? "medium" : "low";
  const confidence = reportConfidenceProfiles[confidenceLevel];
  const scoreWeights: Record<string, number> = { T: 25, R: 30, U: 25, S: 20 };
  const dimensionMap = new Map(availableDimensions.map((dimension) => [dimension.code, dimension]));
  const missingDimensions = orderedCodes
    .filter((code) => !dimensionMap.has(code))
    .map((code) => ({ T: "账号材料", R: "图片材料", U: "评论材料", S: "文案材料" })[code])
    .filter(Boolean);
  const radarCoordinates = orderedCodes.map((code, index) => {
    const dimension = dimensionMap.get(code);
    const radius = dimension ? dimension.score * 0.82 : 0;
    if (index === 0) return [120, 110 - radius];
    if (index === 1) return [120 + radius, 110];
    if (index === 2) return [120, 110 + radius];
    return [120 - radius, 110];
  });

  useEffect(() => {
    const sectionIds = ["forensics-section", "cross-check-section", "decision-section"];
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActiveReportSection(visible.target.id);
    }, { rootMargin: "-24% 0px -58% 0px", threshold: [0.05, 0.25, 0.5] });
    sectionIds.forEach((id) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, [isCurrentFullReport]);

  return (
    <div className="unified-report-page">
      <article className={`unified-report-card ${tone}`}>
        <header>
          <div><strong>TruLens 核验报告</strong><small>{title === "当前美妆种草内容" ? "当前美妆种草内容 · 一个 Agent 汇总四个维度 · 生成核验报告" : `${title} · 同一个 Agent 汇总四个维度`}</small></div>
          <span>AI 生成报告</span>
        </header>

        <nav className="report-anchor-nav" aria-label="报告章节导航">
          {[
            ["forensics-section", "① 鉴伪结果"],
            ["cross-check-section", "② 一致性校验"],
            ["decision-section", "③ 决策与建议"],
          ].map(([id, label]) => (
            <button className={activeReportSection === id ? "active" : ""} key={id} onClick={() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" })}>{label}</button>
          ))}
        </nav>

        <div className="unified-score-row">
          <div className="unified-score-cluster">
            <div className="unified-score">
              <span>Trust Score</span>
              <strong>{score}<small>/ 100</small></strong>
              <em>基于 {availableDimensions.length}/4 个维度</em>
              {confidenceLevel === "low" && <p>材料有限，结论仅供参考</p>}
            </div>
            <div className="report-confidence-wrap">
              <button className={`report-confidence confidence-${title === "当前美妆种草内容" ? "low" : confidenceLevel}`} onClick={() => setConfidenceOpen((open) => !open)}>
                <span>置信度</span><strong>{title === "当前美妆种草内容" ? "中" : confidence.label}</strong><i>{[1, 2, 3].map((bar) => <b className={title === "当前美妆种草内容" || bar <= confidence.bars ? "filled" : ""} key={bar} />)}</i>
              </button>
              {confidenceOpen && (
                <div className="report-confidence-popover">
                  <strong>置信度依据</strong>
                  <span>启用维度 <b>{availableDimensions.length}/4</b></span>
                  <span>证据条数 <b>{confidence.evidenceCount}</b></span>
                  <span>交叉验证项 <b>{confidence.crossCheckCount}</b></span>
                  <span>缺失材料 <b>{missingDimensions.length ? missingDimensions.join("、") : "无"}</b></span>
                </div>
              )}
            </div>
          </div>
          <div className="unified-verdict-group">
            <span className="unified-verdict">{status}</span>
            {isCurrentFullReport && <button onClick={() => document.getElementById("cross-check-section")?.scrollIntoView({ behavior: "smooth", block: "center" })}>已完成交叉验证 ↓</button>}
          </div>
        </div>

        <div className="unified-risk-band">
          <div><i style={{ left: `${score}%` }} /></div>
          <span>高风险</span><span>可信</span>
        </div>

        <section className="report-section-block" id="forensics-section">
          <header className="report-section-heading"><span>Multimodal Forensics</span><h2>① 四维结果</h2></header>
        <div className="unified-dimensions">
          <div className="unified-radar">
            <svg aria-label="T R U S 四维核验分布" viewBox="0 0 240 220">
              {[0.25, 0.5, 0.75, 1].map((scale) => {
                const radius = 78 * scale;
                return <polygon className="radar-grid" key={scale} points={`120,${110 - radius} ${120 + radius},110 120,${110 + radius} ${120 - radius},110`} />;
              })}
              <line x1="120" x2="120" y1="32" y2="188" />
              <line x1="42" x2="198" y1="110" y2="110" />
              <polygon className="unified-radar-data" points={radarCoordinates.map(([x, y]) => `${x},${y}`).join(" ")} />
              {[
                ["T", 120, 32, 120, 12, 120, 24],
                ["R", 198, 110, 218, 114, 218, 126],
                ["U", 120, 188, 120, 216, 120, 204],
                ["S", 42, 110, 22, 114, 22, 126],
              ].map(([code, x, y, tx, ty, mx, my]) => (
                <g className={dimensionMap.has(String(code)) ? "" : "missing"} key={code}>
                  <circle cx={x} cy={y} r="10" />
                  <text textAnchor="middle" x={tx} y={ty}>{code}</text>
                  {!dimensionMap.has(String(code)) && <text className="radar-disabled-label" textAnchor="middle" x={mx} y={my}>未启用</text>}
                </g>
              ))}
              {radarCoordinates.map(([x, y], index) => dimensionMap.has(orderedCodes[index]) && <circle className="unified-radar-point" cx={x} cy={y} key={orderedCodes[index]} r="4" />)}
            </svg>
            <small>四维核验分布</small>
          </div>

          <div className="unified-dimension-list">
            {orderedCodes.map((code) => {
              const dimension = dimensionMap.get(code);
              return (
                <button
                  aria-label={dimension ? `查看${dimension.title}评分证据链` : `${code} 维度数据不足`}
                  className={`unified-dimension-row ${dimension ? "" : "missing"}`}
                  disabled={!dimension}
                  key={code}
                  onClick={() => dimension && setOpenEvidence(code as DimensionCode)}
                >
                  <span className={`report-dimension-badge badge-${code.toLowerCase()}`}>{code}</span>
                  <div>
                    <span>
                      <strong>{dimension?.title ?? { T: "账号可信度", R: "图像原生性", U: "评论自然度", S: "文案真实性" }[code as DimensionCode]}</strong>
                      <b>{dimension ? <>{dimension.score}<small>/100 · 权重 {scoreWeights[code]}%</small><i aria-hidden="true">查看证据 →</i></> : "未启用"}</b>
                    </span>
                    <div><i style={{ width: dimension ? `${dimension.score}%` : "0%" }} /></div>
                    <small>{dimension?.text ?? "未提供材料，不参与计分"}</small>
                    <AnimatePresence>
                      {technicalView && dimension && (
                        <motion.p animate={{ opacity: 1, height: "auto" }} className="technical-capability" exit={{ opacity: 0, height: 0 }} initial={{ opacity: 0, height: 0 }}>
                          所用能力 · {technicalConfig.dimensionCapabilities[code as DimensionCode]}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        </section>

        <CrossCheckSection
          activeDimensions={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          technicalView={technicalView}
        />

        <DecisionSupport
          activeDimensions={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          confidenceLevel={confidenceLevel}
          continueLabel={continueLabel}
          onContinue={onContinue}
          score={score}
          subtitle={subtitle}
        />
      </article>
      <AnimatePresence>
        {technicalView && (
          <motion.section animate={{ opacity: 1, height: "auto", y: 0 }} className="technical-explanation" exit={{ opacity: 0, height: 0, y: -4 }} initial={{ opacity: 0, height: 0, y: -4 }}>
            <div>
              <section><strong>模型</strong>{technicalConfig.models.map((model) => <span key={model}>{model}</span>)}</section>
              <section><strong>部署</strong><span>{technicalConfig.deployment}</span></section>
            </div>
            <small>{technicalConfig.disclaimer}</small>
          </motion.section>
        )}
      </AnimatePresence>
      <p className="method-note">本报告由 TruLens 根据当前可用信号生成；未提供的模态不参与判断，AI 结论不构成医疗或购买建议。</p>
      {onAddEvidence && availableDimensions.length < allDimensions.length && (
        <EvidenceExpansionPrompt
          availableCodes={availableDimensions.map((dimension) => dimension.code as DimensionCode)}
          onAddEvidence={onAddEvidence}
        />
      )}
      {openEvidence && dimensionMap.get(openEvidence) && (
        <ReportEvidenceModal
          code={openEvidence}
          dimension={dimensionMap.get(openEvidence)!}
          onClose={() => setOpenEvidence(null)}
          showAccountActivity={tone === "trusted"}
          technicalView={technicalView}
        />
      )}
    </div>
  );
}

function ArchivedResult({
  task,
  onBack,
  onTechnicalViewChange,
  technicalView,
}: {
  task: Exclude<RecentTask, "makeup">;
  onBack: () => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  technicalView: boolean;
}) {
  const data = archivedTasks[task];
  return (
    <section className="result archive-result">
      <header className="result-header">
        <button aria-label="返回新鉴别" className="back-button" onClick={onBack} title="返回新鉴别">
          <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
        </button>
        <div className="result-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <button onClick={() => window.print()}>
            <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            导出 PDF
          </button>
        </div>
      </header>
      <UnifiedReportTemplate
        continueLabel="开始新的鉴别"
        decision={data.decision}
        dimensions={data.dimensions}
        onContinue={onBack}
        score={data.score}
        status={data.status}
        subtitle={data.headline}
        technicalView={technicalView}
        title={data.title}
        tone={data.tone}
      />
    </section>
  );
}

type CreatorIssueSeverity = "must" | "suggest" | "tip";
type CreatorIssueStatus = "accepted" | "ignored";

const SELFCHECK_CANVAS_CJK_FONT = '"Noto Sans SC", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Source Han Sans SC", "Noto Sans CJK SC", sans-serif';

/** In-memory progress of one 发布前自检 report (kept by the parent while the session lasts). */
export type CreatorSelfCheckProgress = {
  draft: string;
  issueStatus: Record<string, CreatorIssueStatus>;
  imageHandled: boolean;
  latestResult: CreatorCheckRead | null;
  rechecked: boolean;
  acceptedMustIds: string[];
  acceptedSuggestionIds: string[];
};

type CreatorDraftIssue = {
  id: string;
  severity: CreatorIssueSeverity;
  type: string;
  original?: string;
  suggestion: string;
  reason: string;
  remove?: boolean;
};

const creatorDraftIssues: CreatorDraftIssue[] = [
  { id: "most-effective", severity: "must", type: "绝对化比较", original: "最有效", suggestion: "目前用下来我个人觉得挺有效的", reason: "平台和广告规范常见关注点：避免把个人感受表达成适用于所有人的比较结论。" },
  { id: "seven-days", severity: "must", type: "效果承诺", original: "7 天直接变白", suggestion: "我连续用了【X】天，个人感觉【你的真实感受】，效果因人而异", reason: "平台和广告规范常见关注点：短周期确定性效果需要真实使用条件与个人体验边界。" },
  { id: "sensitive-safe", severity: "must", type: "安全性绝对化", original: "敏感肌孕妇都能放心用", suggestion: "敏感肌和孕期人群建议先咨询医生或做局部测试；我自己的肤质是【你的肤质】", reason: "平台和广告规范常见关注点：特殊人群的适用性不宜作统一保证。" },
  { id: "absolute-safe", severity: "must", type: "绝对化", original: "100% 安全无刺激", suggestion: "我用下来没有刺痛感，但每个人情况不同", reason: "平台和广告规范常见关注点：安全和刺激感会受到肤质、用法与个体差异影响。" },
  { id: "dismiss-others", severity: "suggest", type: "贬低同行", original: "别的都是智商税", suggestion: "建议删除", reason: "平台和广告规范常见关注点：减少对其他产品或消费者选择的否定性表达。" , remove: true },
  { id: "disclosure", severity: "tip", type: "披露", suggestion: "如有合作或赠品，请添加披露；如自费购买可写“自费购买”", reason: "平台和广告规范常见关注点：清楚说明内容与品牌、产品之间的关系，更便于读者判断。" },
];

const creatorSeverityLabels: Record<CreatorIssueSeverity, string> = {
  must: "必改",
  suggest: "建议",
  tip: "提示",
};

function CreatorSelfCheckReport({
  error = null,
  input,
  loading = false,
  onContinueAgent,
  onContinueOther,
  onRestart,
  onReturnModify,
  result = null,
  technicalView,
  onRecheck,
  progress,
  onProgressChange,
  onCompletionChange,
  appeals = [],
  onDispute,
}: {
  error?: string | null;
  input: CreatorReportInput;
  loading?: boolean;
  onContinueAgent: () => void;
  onContinueOther: () => void;
  onRestart: () => void;
  onReturnModify: (draft: string) => void;
  result?: CreatorCheckRead | null;
  technicalView: boolean;
  /** Real 再次检测: re-runs checkCreator with the current draft (same arguments as the first check). */
  onRecheck?: (draft: string) => Promise<CreatorCheckRead>;
  /** Progress kept by the parent so leaving and returning to the report keeps it. */
  progress?: CreatorSelfCheckProgress | null;
  onProgressChange?: (progress: CreatorSelfCheckProgress) => void;
  onCompletionChange?: (state: { complete: boolean; reasons: string[] }) => void;
  /** Appeals already submitted for this self-check (recorded only; scores do not change). */
  appeals?: Array<{ code: DimensionCode; issueId?: string }>;
  /** 「我有异议」: open the appeal flow with this issue pre-selected. */
  onDispute?: (dispute: { code: DimensionCode; text: string; issueId?: string }) => void;
}) {
  const [draft, setDraft] = useState(progress?.draft ?? input.draft);
  const [issueStatus, setIssueStatus] = useState<Record<string, CreatorIssueStatus>>(progress?.issueStatus ?? {});
  // Latest real result from 再次检测 (null until the first recheck) and what the user did.
  const [latestResult, setLatestResult] = useState<CreatorCheckRead | null>(progress?.latestResult ?? null);
  const [rechecked, setRechecked] = useState(progress?.rechecked ?? false);
  const [acceptedMustIds, setAcceptedMustIds] = useState<string[]>(progress?.acceptedMustIds ?? []);
  const [acceptedSuggestionIds, setAcceptedSuggestionIds] = useState<string[]>(progress?.acceptedSuggestionIds ?? []);
  const [recheckError, setRecheckError] = useState<string | null>(null);
  const [hoveredIssue, setHoveredIssue] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<number | null>(input.images.length ? 0 : null);
  const [imageHandled, setImageHandled] = useState(progress?.imageHandled ?? false);
  const [flashDraft, setFlashDraft] = useState(false);
  const [isRechecking, setIsRechecking] = useState(false);

  const currentResult = latestResult ?? result;
  const activeIssues = currentResult?.issues ?? creatorDraftIssues;
  const unresolvedIssues = activeIssues.filter((issue) => !issueStatus[issue.id]);
  const requiredCount = unresolvedIssues.filter((issue) => issue.severity === "must").length;
  const ignoredCount = Object.values(issueStatus).filter((status) => status === "ignored").length;
  const ignoredRequiredCount = activeIssues.filter((issue) => issue.severity === "must" && issueStatus[issue.id] === "ignored").length;
  const ignoredRequired = activeIssues.some((issue) => issue.severity === "must" && issueStatus[issue.id] === "ignored");
  const checklistSuggestion = /数据|来源|检测|测试/.test(draft) ? 0 : 1;
  const suggestionCount = unresolvedIssues.filter((issue) => issue.severity === "suggest").length + (imageHandled ? 0 : input.images.length ? 1 : 0) + checklistSuggestion;
  const tipCount = unresolvedIssues.filter((issue) => issue.severity === "tip").length;
  const pendingCount = requiredCount + suggestionCount + tipCount;
  const acceptedRequired = activeIssues.filter((issue) => issue.severity === "must" && issueStatus[issue.id] === "accepted").length;
  const baseCopyScore = result?.copy_score ?? 28;
  // Real runs show real numbers only: first check → latest 再次检测. The demo keeps its old preview.
  const copyScore = result
    ? Math.round(currentResult?.copy_score ?? baseCopyScore)
    : Math.min(96, baseCopyScore + acceptedRequired * 10 + (issueStatus.disclosure === "accepted" ? 4 : 0));
  const hasImages = input.images.length > 0 || result?.image_score != null;
  const baseImageScore = result?.image_score ?? (hasImages ? 82 : null);
  const imageScore = result ? (currentResult?.image_score ?? baseImageScore) : (hasImages ? imageHandled ? 90 : 82 : null);
  const imageAfterScore = result ? imageScore : imageScore != null ? (imageHandled ? Math.min(96, imageScore + 8) : imageScore) : null;
  const imageDimension = currentResult?.report.dimensions.find((dimension) => dimension.code === "R");
  const imageNeedsReview = currentResult
    ? Boolean(imageDimension?.assessed && imageDimension.risk_level !== "low")
    : hasImages;
  const imageFinding = imageDimension?.evidence[0]?.reason || imageDimension?.evidence[0]?.evidence;
  const creatorDimensions: DimensionCode[] = hasImages ? ["R", "S"] : ["S"];
  const creatorOverallScore = hasImages && imageScore != null ? Math.round((copyScore + imageScore) / 2) : copyScore;
  const publicationState = ignoredRequired
    ? "hold"
    : requiredCount > 0
      ? result?.publication_state === "hold"
        ? "hold"
        : "revise"
      : "ready";
  const publicationTitle = { ready: "可以发布", revise: "建议修改后发布", hold: "建议暂缓发布" }[publicationState];
  const checkDate = currentResult?.check_date || new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());

  if (loading) {
    return (
      <div className="creator-report-page">
        <article className="creator-report-sheet">
          <section className="creator-recheck-state">
            <span><i className="expert-s">S</i><b>文案检查官</b><small>正在运行真实文案分析</small></span>
            {input.images.length > 0 && <span><i className="expert-r">R</i><b>视觉取证师</b><small>正在运行真实图片分析</small></span>}
          </section>
          <p className="creator-badge-hint">正在调用后端分析与改写建议服务，请稍候。</p>
        </article>
      </div>
    );
  }

  if (error) {
    return (
      <div className="creator-report-page">
        <article className="creator-report-sheet">
          <p className="new-analysis-error">创作者自检失败：{error}</p>
          <div className="creator-report-actions">
            <div><button onClick={() => onReturnModify(draft)}>返回修改</button></div>
          </div>
        </article>
      </div>
    );
  }

  const scrollToIssue = (id: string) => {
    document.getElementById(`creator-issue-${id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const flashUpdatedDraft = () => {
    setFlashDraft(false);
    window.requestAnimationFrame(() => setFlashDraft(true));
    window.setTimeout(() => setFlashDraft(false), 900);
  };

  const concreteCreatorSuggestion = (issue: CreatorDraftIssue) => {
    const suggestion = issue.suggestion.trim();
    const original = issue.original ?? "";
    if (/补充可核验依据|主观体验并注明个体差异/.test(suggestion)) {
      if (/7\s*天|变白|美白|痘印|毛孔/.test(original)) {
        return "我连续用了 14 天，个人感觉肤色看起来更均匀，痘印有变淡；具体效果会因肤质和使用方式不同。";
      }
      return "我连续用了 14 天，个人感觉状态有改善；具体效果会因肤质和使用方式不同。";
    }
    if (/弱化绝对化表述/.test(suggestion)) {
      return "我个人用下来感觉不错，具体效果会因肤质和使用方式不同。";
    }
    if (/医疗化功效/.test(suggestion)) {
      return "这里改成日常使用感受会更稳妥，不延伸为医疗或治疗功效。";
    }
    return suggestion;
  };

  const acceptIssue = (issue: CreatorDraftIssue) => {
    const rewrite = concreteCreatorSuggestion(issue);
    const changesDraft =
      issue.id === "disclosure" ||
      Boolean(issue.original) ||
      rewrite !== issue.suggestion.trim();
    setDraft((current) => {
      if (issue.id === "disclosure") {
        const disclosure = input.isCollaboration ? "本篇含品牌合作或产品赠送。" : "本产品为自费购买。";
        return current.includes(disclosure) ? current : `${current.trim()}\n${disclosure}`;
      }
      if (!issue.original) {
        return current.includes(rewrite) ? current : `${current.trim()}\n${rewrite}`;
      }
      if (issue.remove) return current.replace(`${issue.original}，`, "").replace(issue.original, "");
      return current.includes(rewrite) ? current : current.replace(issue.original, rewrite);
    });
    setIssueStatus((current) => ({ ...current, [issue.id]: "accepted" }));
    if (issue.severity === "must") setAcceptedMustIds((current) => (current.includes(issue.id) ? current : [...current, issue.id]));
    else setAcceptedSuggestionIds((current) => (current.includes(issue.id) ? current : [...current, issue.id]));
    // Advisory items may have no source sentence and therefore do not change
    // the draft. Accepting those after a recheck must not invalidate that run.
    if (changesDraft) setRechecked(false);
    flashUpdatedDraft();
  };

  const acceptImageSuggestion = () => {
    const disclosure = "（图片已做轻度磨皮处理）";
    setDraft((current) => current.includes(disclosure) ? current : `${current.trim()}\n${disclosure}`);
    setImageHandled(true);
    setAcceptedSuggestionIds((current) => (current.includes("image") ? current : [...current, "image"]));
    setRechecked(false);
    flashUpdatedDraft();
  };

  const runRecheck = () => {
    if (isRechecking) return;
    if (onRecheck && result) {
      setIsRechecking(true);
      setRecheckError(null);
      void onRecheck(draft)
        .then((next) => {
          // New result: 必改 must be re-adopted if still flagged; an explicit 忽略 of a
          // 建议 / 提示 carries over when the same item comes back.
          setIssueStatus((previous) => {
            const carried: Record<string, CreatorIssueStatus> = {};
            next.issues.forEach((issue) => {
              if (issue.severity !== "must" && previous[issue.id] === "ignored") carried[issue.id] = "ignored";
            });
            return carried;
          });
          setLatestResult(next);
          setRechecked(true);
        })
        .catch((err: unknown) => setRecheckError(err instanceof Error ? err.message : String(err)))
        .finally(() => setIsRechecking(false));
      return;
    }
    setIsRechecking(true);
    window.setTimeout(() => {
      const nextStatus: Record<string, CreatorIssueStatus> = {};
      activeIssues.forEach((issue) => {
        if (issue.id === "disclosure") {
          if (/品牌合作|产品赠送|自费购买/.test(draft)) nextStatus[issue.id] = "accepted";
          return;
        }
        if (issue.original && !draft.includes(issue.original)) nextStatus[issue.id] = "accepted";
      });
      setIssueStatus(nextStatus);
      setImageHandled(/图片已做轻度磨皮处理/.test(draft));
      setIsRechecking(false);
      onRestart();
    }, 1500);
  };

  const saveBadgeAsPng = async () => {
    if (!selfCheckComplete) return;
    // Canvas text falls back silently: wait for webfonts, and list system CJK fonts so a
    // machine without Noto Sans SC still renders Chinese instead of boxes.
    try {
      await document.fonts?.ready;
    } catch {
      /* drawing with the fallback chain is still fine */
    }
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 630;
    const context = canvas.getContext("2d");
    if (!context) return;

    context.fillStyle = "#f9f7fc";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.strokeStyle = "#cbbde2";
    context.lineWidth = 4;
    context.beginPath();
    context.roundRect(28, 28, 1144, 574, 38);
    context.stroke();

    context.save();
    context.translate(118, 112);
    context.fillStyle = "#e1d9f2";
    context.strokeStyle = "#a999d5";
    context.lineWidth = 3;
    context.beginPath();
    context.moveTo(48, 0);
    context.lineTo(96, 48);
    context.lineTo(48, 96);
    context.lineTo(0, 48);
    context.closePath();
    context.fill();
    context.stroke();
    ["#b9a8de", "#d7a9ae", "#9eb9d3", "#9ebfae"].forEach((color, index) => {
      const dots = [[48, -15], [111, 48], [48, 111], [-15, 48]];
      context.fillStyle = color;
      context.beginPath();
      context.arc(dots[index][0], dots[index][1], 11, 0, Math.PI * 2);
      context.fill();
    });
    context.restore();

    context.fillStyle = "#332d3b";
    context.font = `600 48px ${SELFCHECK_CANVAS_CJK_FONT}`;
    context.fillText("已完成发布前自检", 270, 135);
    context.fillStyle = "#648471";
    context.font = `500 30px ${SELFCHECK_CANVAS_CJK_FONT}`;
    context.fillText(requiredCount ? `仍有 ${requiredCount} 处待处理` : "无必改项", 272, 185);
    context.fillStyle = "#8a8290";
    context.font = `22px ${SELFCHECK_CANVAS_CJK_FONT}`;
    context.fillText(`自检日期  ${checkDate}  ·  ${result ? "真实分析" : "示例数据"}`, 272, 230);

    context.strokeStyle = "#e1dbe8";
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(88, 310);
    context.lineTo(1112, 310);
    context.stroke();

    const scoreBlocks = [
      { code: "S", label: "文案真实性", before: Math.round(baseCopyScore), after: Math.round(copyScore), x: 88, color: "#e5f0e9" },
      ...(hasImages && imageScore != null ? [{ code: "R", label: "图像原生性", before: Math.round(baseImageScore ?? imageScore), after: Math.round(imageAfterScore ?? imageScore), x: 612, color: "#e6eef7" }] : []),
    ];
    scoreBlocks.forEach((block) => {
      context.fillStyle = block.color;
      context.beginPath();
      context.roundRect(block.x, 360, 78, 78, 18);
      context.fill();
      context.fillStyle = "#675a71";
      context.font = '600 25px ui-monospace, monospace';
      context.fillText(block.code, block.x + 30, 408);
      context.fillStyle = "#746d79";
      context.font = `24px ${SELFCHECK_CANVAS_CJK_FONT}`;
      context.fillText(block.label, block.x + 103, 390);
      context.fillStyle = "#8e8793";
      context.font = '500 40px Georgia, serif';
      context.fillText(String(block.before), block.x + 103, 444);
      context.fillStyle = "#9589a0";
      context.font = `24px ${SELFCHECK_CANVAS_CJK_FONT}`;
      context.fillText("→", block.x + 170, 440);
      context.fillStyle = block.code === "S" ? "#5f806c" : "#5d7b96";
      context.font = '500 52px Georgia, serif';
      context.fillText(String(block.after), block.x + 215, 445);
    });

    context.fillStyle = "#5d5563";
    context.font = `500 23px ${SELFCHECK_CANVAS_CJK_FONT}`;
    context.fillText(`已处理 ${handledMustCount} 处必改  ·  采纳 ${acceptedSuggestions} 条建议`, 88, 500);
    context.fillStyle = "#9a939f";
    context.font = `20px ${SELFCHECK_CANVAS_CJK_FONT}`;
    context.fillText("仅代表自检时点的结果，不代表平台审核或背书。", 88, 555);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `TruLens-发布前自检-${new Intl.DateTimeFormat("sv-SE").format(new Date())}.png`;
      link.click();
      URL.revokeObjectURL(link.href);
    }, "image/png");
  };

  const renderDraft = () => {
    const highlightedIssues = unresolvedIssues.filter((issue) => issue.original && draft.includes(issue.original));
    const tokens = [
      ...highlightedIssues.map((issue) => issue.original!),
      ...Array.from(draft.matchAll(/【[^】]+】/g), (match) => match[0]),
    ].sort((a, b) => b.length - a.length);
    if (!tokens.length) return draft;
    const escaped = tokens.map((token) => token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const parts = draft.split(new RegExp(`(${escaped.join("|")})`, "g"));
    return parts.map((part, index) => {
      const issue = highlightedIssues.find((entry) => entry.original === part);
      if (issue) {
        return (
          <button
            className={`creator-copy-hit severity-${issue.severity} ${hoveredIssue === issue.id ? "linked" : ""}`}
            key={`${part}-${index}`}
            onClick={() => scrollToIssue(issue.id)}
            onMouseEnter={() => setHoveredIssue(issue.id)}
            onMouseLeave={() => setHoveredIssue(null)}
          >
            {part}
          </button>
        );
      }
      if (/^【[^】]+】$/.test(part)) {
        return (
          <span
            aria-label={`待填写：${part.slice(1, -1)}`}
            className="creator-copy-placeholder"
            contentEditable
            key={`${part}-${index}`}
            onBlur={(event) => {
              const value = event.currentTarget.textContent?.trim();
              if (value && value !== part) setDraft((current) => current.replace(part, value));
            }}
            suppressContentEditableWarning
          >
            {part}
          </span>
        );
      }
      return <span key={`${index}-${part.slice(0, 5)}`}>{part}</span>;
    });
  };

  const disclosureItems = result
    ? Object.entries(result.disclosures)
    : [
        ["合作或赠品披露", /品牌合作|产品赠送|自费购买/.test(draft)],
        ["修图披露", /轻度磨皮|滤镜|修图/.test(draft)],
        ["使用周期说明", /连续用了|使用了.{0,4}天|使用周期/.test(draft)],
        ["个人体验边界声明", /个人觉得|个人感觉|因人而异|每个人情况不同|我用下来/.test(draft)],
        ["数据来源说明", /数据|来源|检测|测试/.test(draft)],
      ];
  const creatorCrossChecks = result?.report.cross_checks?.map((item) => ({
    id: item.id,
    from: item.from_code,
    to: item.to_code,
    left: item.left,
    right: item.right,
    conclusion: item.conclusion,
    state: item.state,
    dimension: item.dimension,
    detail: item.detail,
    confidence: item.confidence ?? undefined,
    method: item.method,
    label: item.label ?? undefined,
  }));
  const goodPoints = result
    ? result.good_points.length
      ? result.good_points
      : ["暂未识别到明确优点"]
    : ["语气有个人体验色彩", "没有医疗化功效描述"];
  const acceptedSuggestions = result ? acceptedSuggestionIds.length : Object.values(issueStatus).filter((status) => status === "accepted").length;
  const handledMustCount = result ? acceptedMustIds.length : acceptedRequired;

  // 自检完成: nothing to fix on the first check, or — after a real 再次检测 — no 必改 left
  // and every 建议 / 提示 (and the image suggestion) adopted or explicitly ignored.
  const openMust = activeIssues.filter((issue) => issue.severity === "must" && issueStatus[issue.id] !== "accepted").length;
  const openOther = activeIssues.filter((issue) => issue.severity !== "must" && !issueStatus[issue.id]).length + (imageNeedsReview && !imageHandled ? 1 : 0);
  const initiallyClean = Boolean(result) && !rechecked && (result?.issues.length ?? 0) === 0 && !imageNeedsReview;
  const selfCheckComplete = !result ? publicationState === "ready" : initiallyClean || (rechecked && openMust === 0 && openOther === 0);
  const pendingReasons = selfCheckComplete
    ? []
    : [
        ...(openMust ? [`还有 ${openMust} 条必改未处理`] : []),
        ...(openOther ? [`还有 ${openOther} 条建议 / 提示未处理（采用或忽略均可）`] : []),
        ...(!rechecked ? ["尚未再次检测"] : []),
      ];
  const lockedReason = "采用修改建议并再次检测通过后，可保存自检记录";

  useEffect(() => {
    onCompletionChange?.({ complete: selfCheckComplete, reasons: pendingReasons });
  }, [selfCheckComplete, pendingReasons.join("|")]);

  useEffect(() => {
    onProgressChange?.({ draft, issueStatus, imageHandled, latestResult, rechecked, acceptedMustIds, acceptedSuggestionIds });
  }, [draft, issueStatus, imageHandled, latestResult, rechecked, acceptedMustIds, acceptedSuggestionIds]);


  // One layout for both states of the 自检记录 card: label → title → one line → checklist.
  const recordSteps: Array<{ done: boolean; text: string }> = result
    ? [
        { done: openMust === 0, text: openMust === 0 ? "必改项已全部采用修改建议" : `还有 ${openMust} 条必改未处理` },
        { done: openOther === 0, text: openOther === 0 ? "建议 / 提示已全部处理" : `还有 ${openOther} 条建议 / 提示未处理（采用或忽略均可）` },
        {
          done: rechecked || initiallyClean,
          text: initiallyClean ? "首次检测无必改项，无需再次检测" : rechecked ? "已再次检测，无必改项" : "尚未再次检测",
        },
        ...(ignoredRequiredCount > 0 ? [{ done: false, text: `有 ${ignoredRequiredCount} 处必改已忽略，必改需采用修改建议` }] : []),
      ]
    : pendingReasons.map((reason) => ({ done: false, text: reason }));

  const renderSelfCheckRecord = (complete: boolean) => (
    <motion.section
      animate={{ opacity: 1, y: 0 }}
      className={`creator-badge-area creator-record-area ${complete ? "is-complete" : "is-locked"}`}
      initial={{ opacity: 0, y: 10 }}
      key={complete ? "badge" : "locked"}
    >
      <div className="creator-record-column">
        <article aria-disabled={!complete} className={`creator-record-card ${complete ? "is-complete" : "is-locked"}`}>
          <header className="creator-record-card-head">
            <img alt="TruLens" height={44} src="/trulens-selfcheck-logo.png" width={84} />
            <div>
              <span className="creator-record-label">SELF-CHECK RECORD · 自检记录（非认证）{result ? "" : " · 示例数据"}</span>
              <strong className="creator-record-title">{complete ? "已完成发布前自检" : "尚未完成发布前自检"}</strong>
              <p className="creator-record-note">{complete ? `检测日期 ${checkDate}` : lockedReason}</p>
            </div>
          </header>
          {complete && (
            <div className="creator-record-compare">
              <span><i>S</i><small>文案真实性</small><b>{Math.round(baseCopyScore)}</b><em>→</em><strong>{Math.round(copyScore)}</strong></span>
              {hasImages && imageScore != null && (
                <span className="is-image"><i>R</i><small>图像原生性</small><b>{Math.round(baseImageScore ?? imageScore)}</b><em>→</em><strong>{Math.round(imageAfterScore ?? imageScore)}</strong></span>
              )}
            </div>
          )}
          <ul aria-label={complete ? "已完成的步骤" : "还差这几步"} className="creator-record-steps">
            {recordSteps.map((step) => (
              <li className={step.done ? "done" : "pending"} key={step.text}>
                <i aria-hidden="true">{step.done ? "✓" : ""}</i>
                <span>{step.text}</span>
              </li>
            ))}
          </ul>
          {complete && <p className="creator-record-tally">已处理 {handledMustCount} 处必改 · 采纳 {acceptedSuggestions} 条建议</p>}
        </article>
        <small className="creator-record-disclaimer">仅代表自检时点的结果，不代表平台审核或背书。</small>
      </div>
      <div className="creator-badge-actions">
        {complete ? (
          <button onClick={saveBadgeAsPng} type="button">保存为图片</button>
        ) : (
          <span className="creator-locked-action" title={lockedReason}>
            <button aria-describedby="creator-locked-reason" disabled type="button">保存为图片</button>
          </span>
        )}
        <button onClick={onContinueOther} type="button">继续检查其他内容 <Arrow size={15} /></button>
        {!complete && <small className="sr-only" id="creator-locked-reason">{lockedReason}</small>}
      </div>
    </motion.section>
  );

  return (
    <div className="creator-report-page">
      <article className="creator-report-sheet">
        <header className="creator-report-hero">
          <div>
            <span>发布前自检{appeals.length > 0 && <b className="creator-appeal-flag">已提交申诉 {appeals.length} 条</b>}</span>
            <h1 className={`state-${publicationState}`}>{publicationTitle}</h1>
            <p><strong>{requiredCount}</strong> 处必改 · <strong>{suggestionCount}</strong> 处建议 · <strong>{tipCount}</strong> 项提示{ignoredCount > 0 && <> · <strong>{ignoredCount}</strong> 项已忽略</>}</p>
          </div>
          <div className="creator-report-scores">
            <div><span className="badge-s">S</span><small><b>文案真实性</b><em>修改后可提升</em></small><strong>{copyScore}</strong></div>
            {hasImages && <div><span className="badge-r">R</span><small>图像原生性</small><strong>{imageScore}</strong></div>}
          </div>
          <small>{hasImages ? "账号可信度、评论自然度发布前暂无数据，未启用。" : "账号可信度、评论自然度、图像原生性发布前暂无数据，未启用。"}</small>
          {input.isExample && <em>示例草稿</em>}
        </header>

        <AnimatePresence mode="wait">
          {isRechecking ? (
            <motion.section animate={{ opacity: 1, y: 0 }} className="creator-recheck-state" exit={{ opacity: 0, y: -6 }} initial={{ opacity: 0, y: 6 }} key="checking">
              <span><i className="expert-s">S</i><b>文案检查官</b><small>正在重新扫描当前文案</small></span>
              {hasImages && <span><i className="expert-r">R</i><b>视觉取证师</b><small>正在复核图片与披露</small></span>}
            </motion.section>
          ) : (
            renderSelfCheckRecord(selfCheckComplete)
          )}
        </AnimatePresence>

        <div className="creator-report-columns">
          <section className="creator-copy-panel">
            <header><span>YOUR DRAFT</span><h2>你的文案</h2><small>点击标注可定位修改建议</small></header>
            <p className={flashDraft ? "updated" : ""}>{renderDraft()}</p>
          </section>
          <section className="creator-issues-panel">
            <header><span>REVIEW NOTES</span><h2>需要留意的地方</h2><small>{pendingCount} 项待处理</small></header>
            <div>
              {activeIssues.map((issue) => {
                const status = issueStatus[issue.id];
                if (status === "ignored") {
                  return (
                    <button className="creator-issue-collapsed" key={issue.id} onClick={() => setIssueStatus((current) => {
                      const next = { ...current };
                      delete next[issue.id];
                      return next;
                    })}>
                      <span>已忽略</span>{issue.type}<small>点击恢复</small>
                    </button>
                  );
                }
                return (
                  <article
                    className={`creator-issue-card severity-${issue.severity} ${status === "accepted" ? "handled" : ""} ${hoveredIssue === issue.id ? "linked" : ""}`}
                    id={`creator-issue-${issue.id}`}
                    key={issue.id}
                    onMouseEnter={() => setHoveredIssue(issue.id)}
                    onMouseLeave={() => setHoveredIssue(null)}
                  >
                    <header>
                      <span>{status === "accepted" ? "✓ 已处理" : creatorSeverityLabels[issue.severity]}</span><em>{issue.type}</em>
                      {appeals.some((appeal) => appeal.issueId === issue.id) && <b className="creator-appeal-flag">已提交申诉</b>}
                    </header>
                    <p>{issue.reason}</p>
                    <div className="creator-rewrite">
                      {issue.original && <span><small>原句</small><del>{issue.original}</del></span>}
                      <span><small>示例改写</small><strong>{concreteCreatorSuggestion(issue).split(/(【[^】]+】)/g).map((part) => /^【/.test(part) ? <mark key={part}>{part}</mark> : part)}</strong></span>
                    </div>
                    {!status && <footer><button onClick={() => acceptIssue(issue)}>采用建议</button><button onClick={() => setIssueStatus((current) => ({ ...current, [issue.id]: "ignored" }))}>忽略</button></footer>}
                    {onDispute && (
                      <button
                        className="creator-dispute-link"
                        onClick={() => onDispute({ code: "S", issueId: issue.id, text: `对「${issue.type}」有异议：${issue.reason}` })}
                        type="button"
                      >
                        我有异议
                      </button>
                    )}
                  </article>
                );
              })}
            </div>
          </section>
        </div>

        <section className="creator-image-review">
          <header><div><span>IMAGE REVIEW</span><h2>配图检查</h2></div><small>{input.images.length} 张配图 · 点击查看建议</small></header>
          {input.images.length ? (
            <>
              <div className="creator-report-thumbnails">
                {input.images.map((image, index) => (
                  <button className={selectedImage === index ? "active" : ""} key={image.id} onClick={() => setSelectedImage(index)}>
                    {index === 0 && image.example ? (
                      <div className="creator-skin-comparison">
                        <span><img alt="使用前手背皮肤纹理" src={image.url} /><b>使用前</b></span>
                        <span><img alt="使用后手背皮肤纹理" src={image.url} /><b>使用后</b></span>
                      </div>
                    ) : <img alt={image.name} src={image.url} />}
                    {index === 0 && imageNeedsReview && !imageHandled && <i>需留意</i>}
                    <span>图 {index + 1}</span>
                  </button>
                ))}
              </div>
              <AnimatePresence mode="wait">
                {selectedImage !== null && (
                  <motion.div animate={{ opacity: 1, y: 0 }} className={`creator-image-note ${selectedImage !== 0 || imageHandled ? "handled" : ""}`} initial={{ opacity: 0, y: 5 }} key={selectedImage}>
                    <span>{result && selectedImage !== 0 ? "未分析" : selectedImage !== 0 ? "✓ 预览" : imageHandled ? "✓ 已处理" : imageNeedsReview ? "图片建议" : "✓ 已分析"}</span>
                    <div>
                      <strong>图 {selectedImage + 1}{result && selectedImage !== 0 ? " 仅作草稿预览" : selectedImage === 0 ? imageNeedsReview ? " 检测到需要说明的图片信号" : " 后端未发现明显图片风险" : " 暂未发现明显异常"}</strong>
                      <p>{result && selectedImage !== 0 ? "本轮后端只分析首张配图；这张图片保留用于草稿预览，未生成真实性评分。" : selectedImage === 0 ? imageFinding || (imageNeedsReview ? "建议注明滤镜或修饰情况，并保留原始素材。" : "图片维度已完成真实分析，当前未返回需要整改的图片证据。") : "主体边缘、纹理和光影关系自然，可保留当前图片。"}</p>
                    </div>
                    {selectedImage === 0 && imageNeedsReview && !imageHandled && <button onClick={acceptImageSuggestion}>采用建议</button>}
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          ) : <p className="creator-no-images">本次没有上传配图，图像原生性未产生额外建议。</p>}
        </section>

        <CrossCheckSection
          activeDimensions={creatorDimensions}
          creatorMode
          items={creatorCrossChecks}
          live={Boolean(result)}
          technicalView={technicalView}
        />

        <DecisionSupport
          activeDimensions={creatorDimensions}
          confidenceLevel={result?.report.confidence?.level ?? "low"}
          continueLabel="返回 Agent 继续追问"
          creatorMode
          liveAdvice={result?.report.decision?.advice}
          onContinue={onContinueAgent}
          recommendations={result?.report.recommendations}
          score={creatorOverallScore}
          sourceLabel={result ? "实时报告" : "示例数据"}
          subtitle={result?.report.decision?.headline ?? publicationTitle}
        />

        <div className="creator-report-extras">
          <section className="creator-disclosure-list">
            <header><span>DISCLOSURE</span><h2>披露清单</h2></header>
            <div>{disclosureItems.map(([label, ready]) => <label className={ready ? "ready" : ""} key={label}><input checked={ready} readOnly type="checkbox" /><span>{ready ? "✓ 已具备" : "△ 建议补充"}</span><strong>{label}</strong></label>)}</div>
          </section>
          <section className="creator-good-points">
            <header><span>WHAT WORKS</span><h2>做得好的地方</h2></header>
            {goodPoints.map((point) => <p key={point}><i>✓</i>{point}</p>)}
          </section>
        </div>

        <footer className="creator-report-actions">
          <small>自检建议用于发布前优化，不构成平台审核结论。</small>
          <div>
            <button onClick={() => onReturnModify(draft)}>返回修改</button>
            <button aria-busy={isRechecking} disabled={isRechecking} onClick={runRecheck}>{isRechecking ? "再次检测中…" : "再次检测"} <Arrow size={16} /></button>
          </div>
        </footer>
        {recheckError && (
          <p className="live-error creator-recheck-error" role="alert">
            再次检测未完成：{recheckError}
            <button className="live-resume-button" disabled={isRechecking} onClick={runRecheck} type="button">重试</button>
          </p>
        )}
      </article>
    </div>
  );
}

function Result({
  onBack,
  onAddEvidence,
  scoreOverride,
  activeDimensions,
  creatorMode = false,
  creatorInput,
  onContinueOther,
  onReturnModify,
  onTechnicalViewChange,
  technicalView,
}: {
  onBack: () => void;
  onAddEvidence: (code: DimensionCode) => void;
  scoreOverride?: number | null;
  activeDimensions: DimensionCode[];
  creatorMode?: boolean;
  creatorInput?: CreatorReportInput | null;
  onContinueOther?: () => void;
  onReturnModify?: (draft: string) => void;
  onTechnicalViewChange: (enabled: boolean) => void;
  technicalView: boolean;
}) {
  const [shareOpen, setShareOpen] = useState(false);
  const reportDimensions = dimensions
    .filter((item) => activeDimensions.includes(item.code as DimensionCode))
    .map((item) => creatorMode && item.code === "S"
      ? { ...item, score: 28, status: "需修改", text: "检测到“7 天直接变白”“100% 安全无刺激”“闭眼入”等绝对化或无依据表达，建议改为可验证的个人体验描述。", evidence: ["绝对化功效表达 3 处", "敏感人群安全承诺缺少依据", "贬损性购买引导"] }
      : creatorMode && item.code === "R"
        ? { ...item, score: 82, text: "配图主体结构自然，但局部质感经过柔化；建议发布时主动注明滤镜或修饰情况。" }
        : item);
  const reportScore = scoreOverride ?? Math.round(reportDimensions.reduce((total, item) => total + item.score, 0) / reportDimensions.length);
  const dimensionName = ["", "单维", "双维", "三维", "四维"][reportDimensions.length];
  const reportHeadline = activeDimensions.includes("R")
    ? "图片主体可信，存在轻度 AI 修饰。"
    : activeDimensions.includes("U")
      ? "评论整体自然，少量话术需留意。"
      : activeDimensions.includes("T")
        ? "账号轨迹稳定，长期行为可信。"
        : "文案表达安全，未见高风险宣称。";
  if (creatorMode && creatorInput) {
    return (
      <section className="result creator-result">
        <header className="result-header">
          <button aria-label="返回过程页" className="back-button" onClick={onBack} title="返回过程页">
            <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
          </button>
          <div className="result-actions">
            <button onClick={() => window.print()}>
              <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" /></Icon>
              导出 PDF
            </button>
          </div>
        </header>
        <CreatorSelfCheckReport input={creatorInput} onContinueAgent={onBack} onContinueOther={onContinueOther ?? onBack} onRestart={() => undefined} onReturnModify={onReturnModify ?? (() => onBack())} technicalView={technicalView} />
      </section>
    );
  }
  return (
    <section className="result">
      <header className="result-header">
        <button aria-label="返回对话" className="back-button" onClick={onBack} title="返回对话">
          <Icon size={22}><path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" /></Icon>
        </button>
        <div className="result-actions">
          <TechnicalViewToggle enabled={technicalView} onChange={onTechnicalViewChange} />
          <button onClick={() => window.print()}>
            <Icon size={17}><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" /></Icon>
            导出 PDF
          </button>
          <div className="share-wrap">
            <button onClick={() => setShareOpen((open) => !open)}>
              <Icon size={17}><circle cx="18" cy="5" r="2" stroke="currentColor" strokeWidth="1.5" /><circle cx="6" cy="12" r="2" stroke="currentColor" strokeWidth="1.5" /><circle cx="18" cy="19" r="2" stroke="currentColor" strokeWidth="1.5" /><path d="m8 11 8-5M8 13l8 5" stroke="currentColor" strokeWidth="1.5" /></Icon>
              分享
            </button>
            {shareOpen && <ShareMenu onClose={() => setShareOpen(false)} />}
          </div>
        </div>
      </header>
      <UnifiedReportTemplate
        continueLabel="向 Agent 继续追问"
        decision={creatorMode
          ? "发布前建议优先修改绝对化功效表达，并补充未经修饰的原图与真实使用条件后再发布。"
          : activeDimensions.length < 4
          ? "当前输入不足以完成四维交叉验证。建议补充账号主页、原始图片或评论区，以获得更完整的可信度判断。"
          : "综合判断：内容整体可信，但图片轻度修饰，账号带货密度较高。可参考，不建议仅凭此内容做购买决策。"}
        dimensions={reportDimensions}
        onAddEvidence={onAddEvidence}
        onContinue={onBack}
        score={reportScore}
        status={reportScore >= 80 ? "高可信" : "需留意"}
        subtitle={creatorMode ? "发布前发现高风险表述，配图存在轻度修饰信号。" : reportHeadline}
        technicalView={technicalView}
        title={creatorMode ? "创作者发布前自检" : activeDimensions.includes("R") ? "当前美妆种草内容" : `${dimensionName}内容核验`}
        tone={reportScore >= 80 ? "trusted" : "warning"}
      />
    </section>
  );
}

type TeamRole = "platform" | "brand";
type TeamRisk = "高风险" | "中风险" | "高可信";
type TeamStatus = "待复核" | "观察中" | "已处理";
type TeamIssueType = "绝对化功效" | "凭证矛盾" | "疑似刷评" | "疑似 AI 生成" | "账号异常" | "无明显问题";
type TeamView = "queue" | "groups";

export type TeamQueueItem = {
  id: string;
  taskId: string;
  title: string;
  author: string;
  score: number;
  risk: TeamRisk;
  confidence: "高" | "中" | "低";
  dimensions: DimensionCode[];
  contradiction: string;
  issueType: TeamIssueType;
  actions: Record<TeamRole, string>;
  status: TeamStatus;
  checks: [string, string][];
};

export type TeamSummary = {
  total: number;
  highRisk: number;
  pending: number;
  trusted: number;
  mediumRisk: number;
  confidenceHigh: number;
  confidenceMedium: number;
  confidenceLow: number;
};

export type TeamRelatedGroup = {
  id: string;
  signals: string[];
  members: Array<{
    id: string;
    taskId: string;
    title: string;
    author: string;
    time: string;
    /** Full ISO timestamp, when the data source provides one. */
    createdAt?: string;
  }>;
};

const teamQueueSeed: TeamQueueItem[] = [
  { id: 1, title: "7 天变白！这瓶精华我闭眼入", author: "晚风护肤札记", score: 31, risk: "高风险", confidence: "高", dimensions: ["S", "R", "U"], contradiction: "效果承诺与使用周期不符", issueType: "绝对化功效", actions: { platform: "人工复核 · 限流观察", brand: "核实宣称并联系创作者" }, status: "待复核", checks: [["“7 天直接变白”", "使用记录仅覆盖 3 天"], ["“真实用户都说有效”", "评论短时集中且句式重复"]] },
  { id: 2, title: "敏感肌孕妇可用的面霜？", author: "云朵成分簿", score: 38, risk: "高风险", confidence: "高", dimensions: ["S", "U"], contradiction: "安全性绝对化，评论集中模板好评", issueType: "绝对化功效", actions: { platform: "人工复核", brand: "核实宣称，评估合规风险" }, status: "待复核", checks: [["“敏感肌孕妇都可用”", "未提供特殊人群测试依据"], ["“大家都说不刺激”", "评论出现集中模板话术"]] },
  { id: 3, title: "三款精华横评，到底怎么选", author: "玻璃杯实验室", score: 64, risk: "中风险", confidence: "中", dimensions: ["R", "S"], contradiction: "对比图疑似同源调色", issueType: "疑似 AI 生成", actions: { platform: "加标注 · 观察", brand: "索取原始素材" }, status: "观察中", checks: [["“统一光线横向对比”", "三张图片色温曲线高度一致"], ["“无滤镜原图”", "局部纹理出现平滑处理"]] },
  { id: 4, title: "换季干皮救星", author: "北窗护肤日记", score: 71, risk: "中风险", confidence: "中", dimensions: ["U"], contradiction: "3 条评论文案重复", issueType: "疑似刷评", actions: { platform: "观察", brand: "持续监测" }, status: "待复核", checks: [["“真实反馈很多”", "3 条评论文本完全一致"], ["“自然讨论”", "相似评论发布时间集中"]] },
  { id: 5, title: "我的晚间护肤流程", author: "月光梳妆台", score: 86, risk: "高可信", confidence: "高", dimensions: [], contradiction: "四项均稳定", issueType: "无明显问题", actions: { platform: "放行", brand: "可作合作参考" }, status: "已处理", checks: [["个人体验描述", "内容边界清楚"], ["合作关系披露", "文案与账号信息一致"]] },
  { id: 6, title: "平价面霜用了一个月", author: "慢慢空瓶记", score: 84, risk: "高可信", confidence: "高", dimensions: ["R"], contradiction: "对比图轻度修饰", issueType: "疑似 AI 生成", actions: { platform: "加提示标注", brand: "可作合作参考，建议注明修图" }, status: "已处理", checks: [["“自然光原图”", "右侧纹理轻度平滑"], ["“使用一个月”", "时间线与发布记录一致"]] },
  { id: 7, title: "成分表看不懂？一篇讲清楚", author: "配方阅读课", score: 58, risk: "高风险", confidence: "低", dimensions: ["S"], contradiction: "材料有限，仅核验文案", issueType: "凭证矛盾", actions: { platform: "补充材料后复核", brand: "暂不判断，建议补充材料" }, status: "待复核", checks: [["“成分结论有出处”", "未附数据来源"], ["“完整核验”", "仅提供文案材料"]] },
  { id: 8, title: "学生党开架护肤清单", author: "青柠省钱簿", score: 77, risk: "中风险", confidence: "中", dimensions: ["S"], contradiction: "标签堆砌、广告披露缺失", issueType: "绝对化功效", actions: { platform: "加标注", brand: "提醒创作者补充披露" }, status: "观察中", checks: [["“纯自用分享”", "文案包含密集购买引导"], ["“客观清单”", "广告合作关系未披露"]] },
];

const teamRelatedGroups = [
  {
    ids: [7, 3, 1],
    signals: ["文案相似 87%", "图片复用 2 张", "评论账号重合 5 个"],
    members: [
      { id: 7, title: "换季修护面霜实测｜第 7 天", author: "小满护肤手记", time: "3 月 08 日 09:20" },
      { id: 3, title: "干敏肌换季修护记录", author: "青禾成分簿", time: "3 月 09 日 14:35" },
      { id: 1, title: "秋冬面霜空瓶分享", author: "棉云日记", time: "3 月 11 日 18:10" },
    ],
  },
  {
    ids: [4, 2],
    signals: ["文案相似 79%", "图片复用 1 张", "评论账号重合 3 个"],
    members: [
      { id: 4, title: "学生党早八底妆实测", author: "栗子梳妆台", time: "3 月 12 日 08:05" },
      { id: 2, title: "通勤持妆 8 小时记录", author: "晴窗美妆录", time: "3 月 13 日 20:40" },
    ],
  },
];

const teamDimensionShortName: Record<DimensionCode, string> = { T: "账号", R: "图像", U: "评论", S: "文案" };

/** Assessment scope next to a score, built from the dimensions the report actually assessed. */
function teamAssessedScope(dimensions: DimensionCode[]): string | null {
  const assessed = allDimensions.filter((code) => dimensions.includes(code));
  if (assessed.length === allDimensions.length) return null;
  if (assessed.length === 0) return "未评估任何维度";
  if (assessed.length === 1) return `仅评估${teamDimensionShortName[assessed[0]]}`;
  return `已评估 ${assessed.length}/${allDimensions.length} 维`;
}

type TeamGroupMember = TeamRelatedGroup["members"][number];

/** One-line basis for a related group, derived only from fields the queue already has. */
function teamGroupBasis(group: TeamRelatedGroup): string {
  const parts: string[] = [];
  const signals = group.signals.join(" ");
  const authors = [...new Set(group.members.map((member) => member.author))];
  if (signals.includes("同一账号")) parts.push(`同一账号（${authors[0] ?? "未知账号"}）`);
  if (signals.includes("SHA-256")) parts.push("使用完全相同的图片");
  if (group.members.length > 1 && new Set(group.members.map((member) => member.title)).size === 1) parts.push("标题摘要完全相同");
  const times = group.members.map((member) => (member.createdAt ? Date.parse(member.createdAt) : NaN)).filter((time) => !Number.isNaN(time));
  if (times.length === group.members.length && times.length > 1) {
    const minutes = Math.round((Math.max(...times) - Math.min(...times)) / 60000);
    const span = minutes < 60 ? `${Math.max(1, minutes)} 分钟` : minutes < 1440 ? `${Math.round(minutes / 60)} 小时` : `${Math.round(minutes / 1440)} 天`;
    parts.push(minutes <= 60 ? `发布时间集中（${span}内）` : `发布时间跨度 ${span}`);
  }
  return parts.length ? `关联依据：${parts.join(" · ")}` : `关联依据：${group.signals.join(" · ")}`;
}

/** Collapse members that share account + title into one row ("×N"); keeps first-seen order. */
function teamGroupRows(members: TeamGroupMember[]) {
  const rows: Array<{ key: string; members: TeamGroupMember[] }> = [];
  members.forEach((member) => {
    const key = `${member.author}\u0000${member.title}`;
    const row = rows.find((item) => item.key === key);
    if (row) row.members.push(member);
    else rows.push({ key, members: [member] });
  });
  return rows;
}

function teamEarliestMemberId(members: TeamGroupMember[]) {
  const dated = members.filter((member) => member.createdAt);
  if (dated.length !== members.length || !dated.length) return members[0]?.id;
  return dated.reduce((earliest, member) => (Date.parse(member.createdAt!) < Date.parse(earliest.createdAt!) ? member : earliest)).id;
}

/** "未提供账号" is a placeholder from the backend, not an account — never treat it as a match. */
function teamKnownAuthor(author: string | undefined) {
  return Boolean(author && author.trim() && author !== "未提供账号");
}

type TeamGraphLink = "account" | "image" | "title" | "time";

const teamGraphLinkLabel: Record<TeamGraphLink, string> = {
  account: "同一账号",
  image: "图片完全相同",
  title: "标题摘要相同",
  time: "60 分钟内发布",
};

const TEAM_GRAPH_MAX_NODES = 12;

/** Relationship graph for one related group. Every edge is derived from existing fields only. */
function TeamGroupGraph({ group, items }: { group: TeamRelatedGroup; items: TeamQueueItem[] }) {
  const [hovered, setHovered] = useState<string | null>(null);
  const centerId = teamEarliestMemberId(group.members);
  const center = group.members.find((member) => member.id === centerId) ?? group.members[0];
  if (!center) return null;
  const others = group.members.filter((member) => member !== center);
  const shown = others.slice(0, others.length > TEAM_GRAPH_MAX_NODES ? TEAM_GRAPH_MAX_NODES - 1 : TEAM_GRAPH_MAX_NODES);
  const hiddenCount = others.length - shown.length;
  const sameImage = group.signals.some((signal) => signal.includes("SHA-256"));
  const riskOf = (member: TeamGroupMember) => items.find((item) => item.taskId === member.taskId)?.risk;
  const tone = (member: TeamGroupMember) => {
    const risk = riskOf(member);
    return risk === "高风险" ? "high" : risk === "中风险" ? "medium" : risk === "高可信" ? "trusted" : "unknown";
  };
  const linksTo = (member: TeamGroupMember): TeamGraphLink[] => {
    const links: TeamGraphLink[] = [];
    if (teamKnownAuthor(member.author) && member.author === center.author) links.push("account");
    if (sameImage) links.push("image");
    if (member.title === center.title) links.push("title");
    if (member.createdAt && center.createdAt && Math.abs(Date.parse(member.createdAt) - Date.parse(center.createdAt)) <= 3600000) links.push("time");
    return links;
  };
  const width = 360;
  const height = 210;
  const cx = width / 2;
  const cy = height / 2;
  const slots = shown.length + (hiddenCount > 0 ? 1 : 0);
  const position = (index: number) => {
    const angle = -Math.PI / 2 + (index / Math.max(1, slots)) * Math.PI * 2;
    return { x: cx + Math.cos(angle) * 140, y: cy + Math.sin(angle) * 78 };
  };
  const usedLinks = new Set<TeamGraphLink>();
  shown.forEach((member) => linksTo(member).forEach((link) => usedLinks.add(link)));
  const describe = (member: TeamGroupMember) =>
    `${member.title} · ${riskOf(member) ?? "风险档位未知"} · ${member.createdAt ? new Date(member.createdAt).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }) : member.time}`;
  const hoveredMember = group.members.find((member) => member.id === hovered);

  return (
    <figure className="team-group-graph">
      <svg aria-label={`关系图：中心为最早出现的一篇，周围 ${others.length} 篇`} role="img" viewBox={`0 0 ${width} ${height}`}>
        {shown.map((member, index) => {
          const { x, y } = position(index);
          const links = linksTo(member);
          const length = Math.hypot(x - cx, y - cy) || 1;
          const nx = -(y - cy) / length;
          const ny = (x - cx) / length;
          return links.map((link, linkIndex) => {
            const offset = (linkIndex - (links.length - 1) / 2) * 3.2;
            return <line className={`graph-link link-${link}`} key={`${member.id}-${link}`} x1={cx + nx * offset} x2={x + nx * offset} y1={cy + ny * offset} y2={y + ny * offset} />;
          });
        })}
        {shown.map((member, index) => {
          const { x, y } = position(index);
          return (
            <g
              aria-label={describe(member)}
              className={`graph-node tone-${tone(member)} ${hovered === member.id ? "active" : ""}`}
              key={member.id}
              onBlur={() => setHovered(null)}
              onFocus={() => setHovered(member.id)}
              onMouseEnter={() => setHovered(member.id)}
              onMouseLeave={() => setHovered(null)}
              tabIndex={0}
            >
              <circle cx={x} cy={y} r={9} />
              <text textAnchor="middle" x={x} y={y + 3.5}>{index + 2}</text>
            </g>
          );
        })}
        {hiddenCount > 0 && (() => {
          const { x, y } = position(shown.length);
          return (
            <g className="graph-node tone-more">
              <circle cx={x} cy={y} r={12} />
              <text textAnchor="middle" x={x} y={y + 3.5}>+{hiddenCount}</text>
            </g>
          );
        })()}
        <g
          aria-label={`中心：${describe(center)}`}
          className={`graph-node graph-center tone-${tone(center)} ${hovered === center.id ? "active" : ""}`}
          onBlur={() => setHovered(null)}
          onFocus={() => setHovered(center.id)}
          onMouseEnter={() => setHovered(center.id)}
          onMouseLeave={() => setHovered(null)}
          tabIndex={0}
        >
          <circle cx={cx} cy={cy} r={15} />
          <text textAnchor="middle" x={cx} y={cy + 4}>1</text>
        </g>
      </svg>
      <p aria-live="polite" className="team-group-graph-tip">
        {hoveredMember ? describe(hoveredMember) : "悬停节点查看笔记摘要与风险档位 · 1 号为最早出现的一篇"}
      </p>
      <figcaption>
        {[...usedLinks].map((link) => <span className={`legend-link link-${link}`} key={link}><i />{teamGraphLinkLabel[link]}</span>)}
        <span className="legend-risk"><i className="tone-high" />高风险<i className="tone-medium" />中风险<i className="tone-trusted" />高可信</span>
      </figcaption>
    </figure>
  );
}

/** Count items per distinct suggested-action wording for one role (the backend's own phrases). */
function teamActionDistribution(items: TeamQueueItem[], role: TeamRole, buckets: Array<{ label: string; match: (action: string) => boolean }>) {
  return buckets.map((bucket) => ({ label: bucket.label, count: items.filter((item) => bucket.match(item.actions[role] ?? "")).length }));
}

/** Frontend-only CSV of queue rows (UTF-8 BOM so Excel opens Chinese text correctly). */
function downloadTeamCsv(rows: TeamQueueItem[], role: TeamRole) {
  const roleName = role === "platform" ? "平台运营" : "品牌方";
  const header = ["笔记摘要", "账号", "总分(百分制)", "风险档位", "置信度", "主要矛盾", `建议动作(${roleName})`, "处理状态"];
  const cell = (value: string | number) => {
    const text = String(value ?? "");
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const lines = [header, ...rows.map((item) => [item.title, item.author, item.dimensions.length ? Math.round(item.score) : "暂不评分", item.risk, item.confidence, item.contradiction, item.actions[role] ?? "", item.status])]
    .map((line) => line.map(cell).join(","));
  const now = new Date();
  const date = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  const blob = new Blob(["\ufeff" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `TruLens复核报告_${roleName}_${date}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const teamStatusRank: Record<TeamStatus, number> = { 待复核: 0, 观察中: 1, 已处理: 2 };
const teamRiskRank: Record<TeamRisk, number> = { 高风险: 0, 中风险: 1, 高可信: 2 };

function TeamWorkspace({
  error,
  groups: remoteGroups,
  items: remoteItems,
  loading = false,
  onBack,
  onOpenReport,
  onRefresh,
  onUpdateStatus,
  summary: remoteSummary,
}: {
  onBack: () => void;
  onOpenReport: (taskId?: string) => void;
  items?: TeamQueueItem[];
  groups?: TeamRelatedGroup[];
  summary?: TeamSummary;
  loading?: boolean;
  error?: string | null;
  onRefresh?: () => void;
  onUpdateStatus?: (taskIds: string[], status: TeamStatus) => Promise<void> | void;
}) {
  const [role, setRole] = useState<TeamRole>("platform");
  const [view, setView] = useState<TeamView>("queue");
  const [items, setItems] = useState<TeamQueueItem[]>(remoteItems ?? teamQueueSeed);
  const [riskFilter, setRiskFilter] = useState("全部");
  const [confidenceFilter, setConfidenceFilter] = useState<"全部" | "低">("全部");
  const [issueFilter, setIssueFilter] = useState("全部");
  const [statusFilter, setStatusFilter] = useState("全部");
  // null = priority order (待复核 → 观察中 → 已处理, then 高 → 中 → 低 risk); otherwise sort by score.
  const [scoreSort, setScoreSort] = useState<"asc" | "desc" | null>(null);
  const [selectedIds, setSelectedIds] = useState<Array<string | number>>([]);
  const [activeItem, setActiveItem] = useState<TeamQueueItem | null>(null);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [expandedGroupRows, setExpandedGroupRows] = useState<string[]>([]);
  const [drawerNotice, setDrawerNotice] = useState<string | null>(null);
  const relatedGroups = remoteGroups ?? teamRelatedGroups;

  useEffect(() => {
    if (remoteItems) setItems(remoteItems);
  }, [remoteItems]);

  const filteredItems = items
    .filter((item) => riskFilter === "全部" || (riskFilter === "高" && item.risk === "高风险") || (riskFilter === "中" && item.risk === "中风险") || (riskFilter === "低" && item.risk === "高可信"))
    .filter((item) => confidenceFilter === "全部" || item.confidence === confidenceFilter)
    .filter((item) => issueFilter === "全部" || item.issueType === issueFilter)
    .filter((item) => statusFilter === "全部" || item.status === statusFilter)
    .sort((a, b) => {
      if (scoreSort) return scoreSort === "asc" ? a.score - b.score : b.score - a.score;
      return teamStatusRank[a.status] - teamStatusRank[b.status] || teamRiskRank[a.risk] - teamRiskRank[b.risk] || a.score - b.score;
    });
  const pendingCount = items.filter((item) => item.status === "待复核").length;
  const summary = remoteSummary ?? {
    total: items.length,
    highRisk: items.filter((item) => item.risk === "高风险").length,
    pending: items.filter((item) => item.status === "待复核").length,
    trusted: items.filter((item) => item.risk === "高可信").length,
    mediumRisk: items.filter((item) => item.risk === "中风险").length,
    confidenceHigh: items.filter((item) => item.confidence === "高").length,
    confidenceMedium: items.filter((item) => item.confidence === "中").length,
    confidenceLow: items.filter((item) => item.confidence === "低").length,
  };
  const riskTotal = Math.max(1, summary.total);
  const hasQueue = items.length > 0;
  const metric = (value: number) => (hasQueue ? value : "—");
  const contactableAccounts = new Set(
    items.filter((item) => item.risk !== "高可信" && teamKnownAuthor(item.author)).map((item) => item.author),
  ).size;
  const roleCards = role === "platform"
    ? [
        { label: "待复核", value: metric(items.filter((item) => item.status === "待复核").length), note: "需要人工判断" },
        { label: "高风险", value: metric(items.filter((item) => item.risk === "高风险").length), note: "风险档位为高" },
        { label: "疑似同源 / 灌水分组", value: hasQueue ? relatedGroups.length : "—", note: "见「关联分组」" },
      ]
    : [
        { label: "绝对化功效等违规话术", value: metric(items.filter((item) => item.issueType === "绝对化功效").length), note: "问题类型为绝对化功效" },
        { label: "文案与图像矛盾", value: "—", note: "队列暂无区分矛盾维度的字段" },
        { label: "可联系整改的账号", value: metric(contactableAccounts), note: "中高风险内容涉及的账号" },
      ];
  const roleDistribution = role === "platform"
    ? teamActionDistribution(items, "platform", [
        { label: "人工复核 · 限流观察", match: (action) => action.includes("人工复核") },
        { label: "加标注 · 继续观察", match: (action) => !action.includes("人工复核") && action.includes("观察") },
        { label: "放行", match: (action) => action.includes("放行") },
      ])
    : teamActionDistribution(items, "brand", [
        { label: "暂缓合作并核实", match: (action) => action.includes("暂缓合作") },
        { label: "索取材料复核", match: (action) => action.includes("索取材料") },
        { label: "可作合作参考", match: (action) => action.includes("合作参考") },
      ]);
  const confidenceTotal = Math.max(1, summary.confidenceHigh + summary.confidenceMedium + summary.confidenceLow);
  const isMobileLayout = window.matchMedia("(max-width: 720px)").matches;

  const updateStatus = async (ids: Array<string | number>, status: TeamStatus) => {
    setItems((current) => current.map((item) => ids.includes(item.id) ? { ...item, status } : item));
    setActiveItem((current) => current && ids.includes(current.id) ? { ...current, status } : current);
    setSelectedIds([]);
    if (onUpdateStatus) {
      await onUpdateStatus(
        ids.map(String),
        status,
      );
    }
  };

  const exportRows = selectedIds.length ? filteredItems.filter((item) => selectedIds.includes(item.id)) : filteredItems;

  const openItem = (item: TeamQueueItem | null) => {
    setDrawerNotice(null);
    setActiveItem(item);
  };

  // Mark the open item as handled (same updateStatus path as the existing button), then
  // move to the next 待复核 item in the current list order.
  const markAndNext = async () => {
    if (!activeItem) return;
    const order = filteredItems.filter((item) => item.id !== activeItem.id && item.status === "待复核");
    const currentIndex = filteredItems.findIndex((item) => item.id === activeItem.id);
    const next = order.find((item) => filteredItems.indexOf(item) > currentIndex) ?? order[0] ?? null;
    await updateStatus([activeItem.id], "已处理");
    if (next) openItem(next);
    else setDrawerNotice("队列已处理完");
  };

  const filterGroups = [
    { label: "风险等级", value: riskFilter, setValue: setRiskFilter, options: ["全部", "高", "中", "低"] },
    { label: "问题类型", value: issueFilter, setValue: setIssueFilter, options: ["全部", "绝对化功效", "凭证矛盾", "疑似刷评", "疑似 AI 生成", "账号异常"] },
    { label: "处理状态", value: statusFilter, setValue: setStatusFilter, options: ["全部", "待复核", "观察中", "已处理"] },
  ];

  return (
    <main className="team-workspace">
      <nav className="team-top-nav">
        <button className="team-brand" onClick={onBack}><img alt="TruLens" src="/trulens-nav-logo.png" /></button>
        <span>团队版</span>
        <button onClick={onBack}>返回个人版</button>
      </nav>
      <button className="team-example-badge" onClick={onRefresh} title="刷新真实核验队列">
        {remoteItems ? "实时数据" : "示例数据"} · {loading ? "同步中" : `${summary.total} 条`}
      </button>
      <section className="team-page">
        <header className="team-page-heading">
          <div><span>TEAM VERIFICATION QUEUE</span><h1>批量核验队列</h1><p>按风险排序，优先处理高风险内容</p></div>
          <div className="team-role-switch"><button className={role === "platform" ? "active" : ""} onClick={() => setRole("platform")}>平台运营</button><button className={role === "brand" ? "active" : ""} onClick={() => setRole("brand")}>品牌方</button></div>
        </header>

        <div className="team-view-switch" role="tablist" aria-label="团队核验视图">
          <button aria-selected={view === "queue"} className={view === "queue" ? "active" : ""} onClick={() => setView("queue")} role="tab">核验队列</button>
          <button aria-selected={view === "groups"} className={view === "groups" ? "active" : ""} onClick={() => setView("groups")} role="tab">关联分组</button>
        </div>

        {view === "queue" ? (
        <>
          <section className="team-summary">
          {roleCards.map((card) => (
            <div className="team-role-card" key={card.label}><span>{card.label}</span><strong>{card.value}</strong><small>{card.note}</small></div>
          ))}
          <div className="team-role-card team-action-distribution">
            <span>{role === "platform" ? "建议处置分布" : "建议动作分布"}</span>
            <ul>
              {roleDistribution.map((bucket) => (
                <li key={bucket.label}><b>{hasQueue ? bucket.count : "—"}</b><em>{bucket.label}</em></li>
              ))}
            </ul>
          </div>
          <div className="team-risk-distribution">
            <header><span>风险分布</span><small>共 {summary.total} 条</small></header>
            <div className="team-distribution-bar team-risk-bar"><i className="trusted" style={{ width: `${summary.trusted / riskTotal * 100}%` }} title={`高可信 ${summary.trusted} 条`} /><i className="medium" style={{ width: `${summary.mediumRisk / riskTotal * 100}%` }} title={`中风险 ${summary.mediumRisk} 条`} /><i className="high" style={{ width: `${summary.highRisk / riskTotal * 100}%` }} title={`高风险 ${summary.highRisk} 条`} /></div>
            <footer className="team-distribution-labels team-risk-labels"><span>高可信 {summary.trusted}</span><span>中风险 {summary.mediumRisk}</span><span>高风险 {summary.highRisk}</span></footer>
            <div className="team-confidence-distribution">
              <header><span>置信度分布</span><small>高 {summary.confidenceHigh} · 中 {summary.confidenceMedium} · 低 {summary.confidenceLow}</small></header>
              <div className="team-distribution-bar team-confidence-bar">
                <i className="confidence-high" style={{ width: `${summary.confidenceHigh / confidenceTotal * 100}%` }} title={`高置信度 ${summary.confidenceHigh} 条`} />
                <i className="confidence-medium" style={{ width: `${summary.confidenceMedium / confidenceTotal * 100}%` }} title={`中置信度 ${summary.confidenceMedium} 条`} />
                <button
                  aria-label="筛选低置信度条目"
                  aria-pressed={confidenceFilter === "低"}
                  className={`confidence-low ${confidenceFilter === "低" ? "active" : ""}`}
                  onClick={() => setConfidenceFilter((current) => current === "低" ? "全部" : "低")}
                  style={{ width: `${Math.max(4, summary.confidenceLow / confidenceTotal * 100)}%` }}
                  title={`低置信度 ${summary.confidenceLow} 条，点击筛选`}
                />
              </div>
              <footer className="team-distribution-labels team-confidence-labels"><span>高 {summary.confidenceHigh}</span><span>中 {summary.confidenceMedium}</span><button className={confidenceFilter === "低" ? "active" : ""} onClick={() => setConfidenceFilter((current) => current === "低" ? "全部" : "低")}>低 {summary.confidenceLow}</button></footer>
              <small>低置信度条目建议补充材料后再复核</small>
            </div>
          </div>
          </section>

          <button className="team-mobile-filter-toggle" onClick={() => setMobileFiltersOpen((open) => !open)}>筛选 <span>{mobileFiltersOpen ? "收起" : "展开"}</span></button>
          <section className={`team-filters ${mobileFiltersOpen ? "open" : ""}`}>
            {filterGroups.map((group) => (
              <div key={group.label}><span>{group.label}</span><div>{group.options.map((option) => <button className={group.value === option ? "active" : ""} key={option} onClick={() => group.setValue(option)}>{option}</button>)}</div></div>
            ))}
            {confidenceFilter === "低" && <button className="team-confidence-filter-chip" onClick={() => setConfidenceFilter("全部")}>低置信度 ×</button>}
          </section>

          <div className="team-priority-row">
            <button
              aria-pressed={statusFilter === "待复核"}
              className={`team-priority-hint ${statusFilter === "待复核" ? "active" : ""}`}
              disabled={!pendingCount}
              onClick={() => setStatusFilter((current) => (current === "待复核" ? "全部" : "待复核"))}
              type="button"
            >
              建议优先处理：待复核 <strong>{pendingCount}</strong> 条{statusFilter === "待复核" ? " · 已筛选" : ""}
            </button>
            <span>{scoreSort ? `按总分${scoreSort === "asc" ? "从低到高" : "从高到低"}` : "按优先级：待复核在前，风险从高到低"}</span>
            {scoreSort && <button className="team-sort-reset" onClick={() => setScoreSort(null)} type="button">按优先级</button>}
            <button className="team-export-button" disabled={!exportRows.length} onClick={() => downloadTeamCsv(exportRows, role)} type="button">
              导出复核报告 <small>{selectedIds.length ? `已勾选 ${exportRows.length} 条` : `当前筛选 ${exportRows.length} 条`}</small>
            </button>
          </div>

          <section className="team-queue">
          {loading && <div className="team-empty">正在读取真实核验队列…</div>}
          {error && <div className="team-empty">{error}</div>}
          {selectedIds.length > 0 && (
            <div className="team-batch-bar"><strong>已选 {selectedIds.length} 项</strong><span /><button onClick={() => updateStatus(selectedIds, "观察中")}>加入观察</button><button onClick={() => updateStatus(selectedIds, "已处理")}>标记已处理</button></div>
          )}
          <table>
            <thead><tr><th><input aria-label="选择当前列表全部内容" checked={filteredItems.length > 0 && filteredItems.every((item) => selectedIds.includes(item.id))} onChange={(event) => setSelectedIds(event.target.checked ? filteredItems.map((item) => item.id) : [])} type="checkbox" /></th><th>笔记内容</th><th><button onClick={() => setScoreSort((value) => (value === "asc" ? "desc" : "asc"))}>总分 {scoreSort === "asc" ? "↑" : scoreSort === "desc" ? "↓" : "↕"}</button></th><th>T / R / U / S</th><th>主要矛盾</th><th>建议动作 · {role === "platform" ? "平台运营" : "品牌方"}</th><th>处理状态</th></tr></thead>
            <tbody>
              {filteredItems.map((item) => (
                <tr key={item.id} onClick={() => openItem(item)} onKeyDown={(event) => event.key === "Enter" && openItem(item)} tabIndex={0}>
                  <td className="team-select-cell"><input aria-label={`选择${item.title}`} checked={selectedIds.includes(item.id)} onChange={(event) => setSelectedIds((current) => event.target.checked ? [...current, item.id] : current.filter((id) => id !== item.id))} onClick={(event) => event.stopPropagation()} type="checkbox" /></td>
                  <td className="team-title-cell"><strong>{item.title}</strong><small>{item.author}</small></td>
                  <td className="team-score-cell"><div><strong>{item.dimensions.length ? Math.round(item.score) : <small>暂不评分</small>}</strong>{teamAssessedScope(item.dimensions) && <em className="team-score-scope" title={`已评估：${item.dimensions.join(" / ") || "无"}`}>{teamAssessedScope(item.dimensions)}</em>}<span className={`team-risk-pill risk-${item.risk === "高风险" ? "high" : item.risk === "中风险" ? "medium" : "trusted"}`}>{item.risk}</span><small>置信度 {item.confidence}</small></div></td>
                  <td className="team-dimensions-cell"><div>{allDimensions.map((code) => <i className={`${item.dimensions.includes(code) ? "active" : ""} dot-${code.toLowerCase()}`} key={code}>{code}</i>)}</div></td>
                  <td className="team-contradiction-cell">{item.contradiction}</td>
                  <td className="team-action-cell"><span>{item.actions[role]}</span></td>
                  <td className="team-status-cell"><span className={`status-${item.status === "待复核" ? "pending" : item.status === "观察中" ? "watching" : "done"}`}>{item.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filteredItems.length && <div className="team-empty">当前筛选条件下没有内容</div>}
          </section>
        </>
        ) : (
          <section className="team-related-groups">
            <header><p>基于已核验内容库的比对，不含其他平台数据。</p><span>{remoteGroups ? "实时数据" : "示例数据"}</span></header>
            <div>
              {relatedGroups.map((group, groupIndex) => {
                const memberTaskIds = group.members.map((member) => member.taskId).filter(Boolean);
                const groupKey = group.id ?? group.ids?.join("-") ?? `group-${groupIndex}`;
                return (
                <article className="team-related-card" key={groupKey}>
                  <header><div><small>RELATED GROUP {String(groupIndex + 1).padStart(2, "0")}</small><h2>疑似同源内容组 · {group.members.length} 篇</h2></div><span>{remoteGroups ? "实时数据" : "示例数据"}</span></header>
                  <p className="team-related-basis">{teamGroupBasis(group)}</p>
                  <TeamGroupGraph group={group} items={items} />
                  <div className="team-related-signals">{group.signals.map((signal) => <span key={signal}>{signal}</span>)}</div>
                  <div className="team-related-members">
                    {teamGroupRows(group.members).map((row, rowIndex) => {
                      const earliestId = teamEarliestMemberId(group.members);
                      const first = row.members[0];
                      const rowKey = `${groupKey}-${rowIndex}`;
                      const expanded = expandedGroupRows.includes(rowKey);
                      const containsEarliest = row.members.some((member) => member.id === earliestId);
                      if (row.members.length === 1) {
                        return (
                          <button key={first.id} onClick={() => onOpenReport(first.taskId)}>
                            <span>{String(rowIndex + 1).padStart(2, "0")}</span>
                            <div><strong>{first.title}</strong><small>{first.author}</small></div>
                            <time>{first.time}</time>
                            {containsEarliest && <em>最早出现</em>}
                            <b>查看报告</b>
                          </button>
                        );
                      }
                      return (
                        <div className={`team-related-merged ${expanded ? "open" : ""}`} key={rowKey}>
                          <button aria-expanded={expanded} onClick={() => setExpandedGroupRows((current) => (expanded ? current.filter((key) => key !== rowKey) : [...current, rowKey]))}>
                            <span>{String(rowIndex + 1).padStart(2, "0")}</span>
                            <div><strong>{first.title}</strong><small>{first.author} · 账号与标题相同</small></div>
                            <time className="team-related-count">×{row.members.length}</time>
                            {containsEarliest && <em>含最早出现</em>}
                            <b>{expanded ? "收起" : "展开明细"}</b>
                          </button>
                          {expanded && (
                            <ol>
                              {row.members.map((member) => (
                                <li key={member.id}>
                                  <time>{member.createdAt ? new Date(member.createdAt).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }) : member.time}</time>
                                  {member.id === earliestId && <em>最早出现</em>}
                                  <button onClick={() => onOpenReport(member.taskId)}>查看报告</button>
                                </li>
                              ))}
                            </ol>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <footer>
                    <button onClick={() => setActiveItem(items.find((item) => item.taskId === memberTaskIds[0]) ?? null)}>逐篇查看</button>
                    <button onClick={() => { setSelectedIds(memberTaskIds); setView("queue"); }}>合并复核</button>
                  </footer>
                </article>
                );
              })}
            </div>
          </section>
        )}
      </section>

      <AnimatePresence>
        {activeItem && (
          <>
            <motion.button animate={{ opacity: 1 }} aria-label="关闭详情" className="team-drawer-backdrop" exit={{ opacity: 0 }} initial={{ opacity: 0 }} onClick={() => setActiveItem(null)} />
            <motion.aside
              animate={{ x: 0, y: 0 }}
              className="team-drawer"
              exit={isMobileLayout ? { y: "100%" } : { x: "100%" }}
              initial={isMobileLayout ? { y: "100%" } : { x: "100%" }}
              transition={{ duration: 0.28, ease: [0.22, 0.7, 0.2, 1] }}
            >
              <header><span>QUEUE DETAIL · 实时数据</span><button aria-label="关闭详情" onClick={() => setActiveItem(null)}>×</button></header>
              <h2>{activeItem.title}</h2><p>{activeItem.author}</p>
              <div className="team-drawer-score"><strong>{activeItem.dimensions.length ? Math.round(activeItem.score) : <small>暂不评分</small>}</strong>{teamAssessedScope(activeItem.dimensions) && <em className="team-score-scope">{teamAssessedScope(activeItem.dimensions)}</em>}<span className={`team-risk-pill risk-${activeItem.risk === "高风险" ? "high" : activeItem.risk === "中风险" ? "medium" : "trusted"}`}>{activeItem.risk}</span><small>置信度 {activeItem.confidence}</small></div>
              <section><span>关键交叉验证</span>{activeItem.checks.map(([claim, evidence]) => <div key={claim}><strong>{claim}</strong><i>×</i><p>{evidence}</p></div>)}</section>
              <section className="team-drawer-action"><span>建议动作 · {role === "platform" ? "平台运营" : "品牌方"}</span><strong>{activeItem.actions[role]}</strong></section>
              {drawerNotice && <p aria-live="polite" className="team-drawer-notice">{drawerNotice}</p>}
              <footer><button onClick={() => onOpenReport(activeItem.taskId)}>打开完整报告</button><button disabled={activeItem.status === "已处理"} onClick={() => void updateStatus([activeItem.id], "已处理")}>{activeItem.status === "已处理" ? "已处理" : "标记已处理"}</button></footer>
              <button className="team-drawer-next" disabled={activeItem.status === "已处理" && !!drawerNotice} onClick={() => void markAndNext()} type="button">标记并看下一条 →</button>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </main>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>(() =>
    new URLSearchParams(window.location.search).get("report") === "true" ? "result" : "home",
  );
  const [filename, setFilename] = useState("");
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceMode>("verify");
  const [creatorFlow, setCreatorFlow] = useState(false);
  const [creatorReportInput, setCreatorReportInput] = useState<CreatorReportInput | null>(null);
  const [prompt, setPrompt] = useState("请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
  const [activeTask, setActiveTask] = useState<RecentTask>("makeup");
  const [activeDimensions, setActiveDimensions] = useState<DimensionCode[]>(() =>
    new URLSearchParams(window.location.search).get("confidence") === "low" ? ["R"] : allDimensions,
  );
  const [exampleSubmission, setExampleSubmission] = useState(false);
  const [historyCleared, setHistoryCleared] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [viewingHistory, setViewingHistory] = useState(false);
  const [archivedScore, setArchivedScore] = useState<number | null>(() => {
    const saved = window.localStorage.getItem("trulens-archived-score");
    return saved ? Number(saved) : null;
  });
  const [revisedScore, setRevisedScore] = useState<number | null>(null);
  const [technicalView, setTechnicalView] = useState(false);

  const start = () => {
    setActiveTask("makeup");
    setExampleSubmission(false);
    setViewingHistory(false);
    setWorkspaceMode("verify");
    setCreatorFlow(false);
    setCreatorReportInput(null);
    setScreen("workspace");
  };
  const submit = (newPrompt: string, submittedFilename = filename, isExample = false) => {
    setActiveTask("makeup");
    setViewingHistory(false);
    setFilename(submittedFilename);
    setExampleSubmission(isExample);
    setCreatorFlow(false);
    setCreatorReportInput(null);
    setActiveDimensions(inferDimensions(newPrompt, submittedFilename));
    setRevisedScore(null);
    setPrompt(newPrompt);
    setScreen("chat");
  };

  if (screen === "home") {
    return (
      <Home
        onCreator={() => {
          setActiveTask("makeup");
          setExampleSubmission(false);
          setViewingHistory(false);
          setWorkspaceMode("creator");
          setCreatorFlow(false);
          setCreatorReportInput(null);
          setScreen("workspace");
        }}
        onStart={start}
        onSubmit={(newPrompt, submittedFilename, isExample) => submit(newPrompt, submittedFilename, isExample)}
        onTeam={() => setScreen("team")}
      />
    );
  }

  if (screen === "team") {
    return (
      <TeamWorkspace
        onBack={() => setScreen("home")}
        onOpenReport={() => {
          setActiveTask("makeup");
          setActiveDimensions(allDimensions);
          setCreatorFlow(false);
          setViewingHistory(false);
          setScreen("result");
        }}
      />
    );
  }

  return (
    <main className={`app-shell ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar
        active={screen}
        activeTask={activeTask}
        archivedScore={archivedScore}
        collapsed={sidebarCollapsed}
        historyCleared={historyCleared}
        onLogout={() => {
          setFilename("");
          setScreen("home");
        }}
        onNew={() => {
          setFilename("");
          setExampleSubmission(false);
          setCreatorFlow(false);
          setCreatorReportInput(null);
          setWorkspaceMode("verify");
          setActiveTask("makeup");
          setActiveDimensions(allDimensions);
          setViewingHistory(false);
          setScreen("workspace");
        }}
        onResetAgent={() => {
          setFilename("");
          setExampleSubmission(false);
          setCreatorFlow(false);
          setCreatorReportInput(null);
          setWorkspaceMode("verify");
          setPrompt("请帮我鉴别这篇美妆种草帖子是否由 AI 造假");
          setActiveTask("makeup");
          setActiveDimensions(allDimensions);
          setHistoryCleared(true);
          setViewingHistory(false);
          setArchivedScore(null);
          window.localStorage.removeItem("trulens-archived-score");
          setScreen("workspace");
        }}
        onReport={(task) => {
          setActiveTask(task);
          setViewingHistory(true);
          if (task === "makeup") setActiveDimensions(allDimensions);
          setScreen("result");
        }}
        onTask={(task) => {
          setActiveTask(task);
          setViewingHistory(true);
          if (task === "makeup") setActiveDimensions(allDimensions);
          setScreen("chat");
        }}
        onToggle={() => setSidebarCollapsed((collapsed) => !collapsed)}
      />
      {screen === "workspace" && (
        <Workspace
          initialCreatorInput={creatorReportInput}
          mode={workspaceMode}
          onCreatorSubmit={(input) => {
            setActiveTask("makeup");
            setViewingHistory(false);
            setFilename(input.images.length ? `${input.images.length} 张待发布配图` : "");
            setExampleSubmission(input.isExample);
            setActiveDimensions(["R", "S"]);
            setRevisedScore(null);
            setCreatorFlow(true);
            setCreatorReportInput(input);
            setPrompt(input.draft);
            setScreen("chat");
          }}
          onHome={() => setScreen("home")}
          onModeChange={setWorkspaceMode}
          onVerifySubmit={(submission) => {
            setActiveTask("makeup");
            setViewingHistory(false);
            setFilename(submission.imageCount ? `${submission.imageCount} 张核验配图` : "");
            setExampleSubmission(submission.isExample);
            setActiveDimensions(submission.dimensions);
            setRevisedScore(null);
            setCreatorFlow(false);
            setCreatorReportInput(null);
            setPrompt(submission.prompt);
            setScreen("chat");
          }}
        />
      )}
      {(screen === "chat" || screen === "result") && activeTask === "makeup" && !viewingHistory && (
        <Chat
          activeDimensions={activeDimensions}
          creatorMode={creatorFlow}
          filename={filename}
          hidden={screen !== "chat"}
          isExampleSubmission={exampleSubmission}
          onArchiveReport={(score) => {
            setArchivedScore(score);
            setHistoryCleared(false);
            window.localStorage.setItem("trulens-archived-score", String(score));
          }}
          onFile={setFilename}
          onHome={() => setScreen("home")}
          onResult={(event) => {
            if (!event.nativeEvent.isTrusted) return;
            setActiveTask("makeup");
            setRevisedScore(null);
            setScreen("result");
          }}
          onTechnicalViewChange={setTechnicalView}
          onViewRevisedReport={(score) => {
            setActiveTask("makeup");
            setRevisedScore(score);
            setScreen("result");
          }}
          prompt={prompt}
          technicalView={technicalView}
        />
      )}
      {screen === "chat" && viewingHistory && (
        <ArchivedConversation
          onHome={() => {
            setViewingHistory(false);
            setScreen("workspace");
          }}
          onResult={() => setScreen("result")}
          task={activeTask}
        />
      )}
      {screen === "result" && activeTask === "makeup" && (
        <Result
          activeDimensions={activeDimensions}
          creatorInput={creatorReportInput}
          creatorMode={creatorFlow}
          onAddEvidence={(code) => setActiveDimensions((current) => allDimensions.filter((dimension) => current.includes(dimension) || dimension === code))}
          onBack={() => setScreen("chat")}
          onContinueOther={() => {
            setCreatorReportInput(null);
            setFilename("");
            setExampleSubmission(false);
            setWorkspaceMode("creator");
            setScreen("workspace");
          }}
          onReturnModify={(draft) => {
            setCreatorReportInput((current) => current ? { ...current, draft } : current);
            setWorkspaceMode("creator");
            setScreen("workspace");
          }}
          onTechnicalViewChange={setTechnicalView}
          scoreOverride={revisedScore}
          technicalView={technicalView}
        />
      )}
      {screen === "result" && activeTask !== "makeup" && (
        <ArchivedResult onBack={() => setScreen("chat")} onTechnicalViewChange={setTechnicalView} task={activeTask} technicalView={technicalView} />
      )}
    </main>
  );
}

export {
  AccountProfileEvidence,
  AnalysisProcessProgress,
  CreatorSelfCheckReport,
  CrossCheckSection,
  DecisionSupport,
  MaterialTraceEvidence,
  MethodBadge,
  TeamWorkspace,
  TechnicalViewToggle,
  WhoUsesSection,
  reportConfidenceProfiles,
  technicalConfig,
};
export type { ConclusionMethod, CreatorReportInput };
export type { TeamQueueItem, TeamRelatedGroup, TeamSummary };
